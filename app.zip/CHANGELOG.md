# V6.1.0-debug

## V6.1.0-debug — 2026-09-30（V6.1 Debug Loader：加载证据日志版）

### 背景（用户指定）
V6.0.0/V6.1 已可正常安装、设置页正常、不进安全模式、DynamicLibraries 可见 `RecordingSharingan.dylib` + plist（Filter: com.apple.springboard），但录屏后写轮眼素材未覆盖、日志无新增。第一步：不改显示逻辑，先确认 dylib 是否真正加载。

### 本版改动（仅日志，零行为改动）
- `Tweak.xm` 新增 `V6.1 Debug Loader` 段：
  - `RSDebugLog()`：`[V6.1]` 格式记录，**同时写入两个位置**：
    - `/var/mobile/Library/Logs/RecordingSharingan-V6.log`
    - `/var/jb/tmp/RecordingSharingan-V6.log`
  - `RSDebugDylibPath()`：`dladdr` 取当前 dylib 自身路径。
  - `RSDebugDumpEnvironment()`：进程名 / bundleIdentifier / bundlePath / executablePath / dylib 路径 / 是否 SpringBoard。
- `%ctor` 最开头依次执行：`RSClearLog()`（原行为）→ `RSDebugClearV6Logs()`（清空两个 V6 日志，保证文件里只有本次加载的记录）→ `RSDebugLog(@"dylib loaded")` → `RSDebugLog(@"ctor executed")` → `RSDebugDumpEnvironment()`。
- 仅使用 Foundation / dlfcn / os_log，不触碰 UIScreen / UIKit / SpringBoard 视图树，遵守项目 %ctor 安全红线。
- 未修改：动画、定位、设置页、V6 SystemAperture 逻辑、V5.7.25 全部稳定逻辑。

### 版本同步
- `Tweak.xm` RSVersion = `6.1.0-debug`；`control` Version = `6.1.0~debug`（排序低于未来正式 6.1.0，可被正式版覆盖升级）；设置页页脚/标题/当前版本同步；CI workflow 输出名同步。

### 判定方法（安装本版后）
1. 安装 → Respring（或重启）。
2. 打开 `/var/jb/tmp/RecordingSharingan-V6.log`（或 `/var/mobile/Library/Logs/RecordingSharingan-V6.log`）：
   - 有 `[V6.1] dylib loaded` + `[V6.1] ctor executed` + `SpringBoard detected` → dylib 已加载进 SpringBoard，进入第二阶段（SystemAperture 检查）。
   - 文件不存在 / 内容为空 / 时间戳是旧时间 → dylib 未被加载，问题在注入层（Dopamine/RootHide 隐藏、路径、签名），与插件代码无关。
3. 录屏一次，确认 `/var/mobile/Library/Logs/RecordingSharingan.log` 是否新增运行日志（旧行为不变）。

# V6.0.0

## V6.0.0 — 2026-09-28（SystemAperture ScreenRecording 精准定位版）

### 背景（用户指定）
V5.7.25 三个主要问题：
1. 切后台时写轮眼位置过渡不完整；
2. 切音乐/其他灵动岛活动时容易重新定位错误；
3. 容器变化时可能出现跳动。

### 方案
不再单纯扫描 `_SAUIProvidedViewContainerView`，改为优先定位真正的录屏灵动岛元素：

- 控制器链路（主）：
  `[UIApplication systemApertureControllerForMainDisplay]` → `_systemApertureViewController` → `_systemApertureManager` → `registeredElements[]` → `elementIdentifier` 匹配 `systemApertureElementIdentifierScreenRecording`（dlsym 运行时取 SpringBoard 导出的常量，取不到用 "ScreenRecording" 字面量兜底）→ `elementViewControllerForElement:` → `view`（SAUIElementView）。
- 视图树链路（备）：
  全窗口扫描 `SAUIElementView`；identifier 命中（KVC 多键探测 + element 对象透传）或子树证据（`SBSystemApertureSceneElement` 类名 + 红色叶子 + 元素内 provided 容器）命中即认定录屏元素。
- 挂载（View 挂载函数）：
  写轮眼作为额外动画层挂进元素子树（元素不裁剪直接挂元素，裁剪则向上找第一个非裁剪祖先），宿主跟随系统 morph，天然解决切后台过渡与容器跳动。
- 位置同步：
  hook `SAUIElementView setFrame:/setCenter:/layoutSubviews` + 既有 CADisplayLink 逐帧驱动，写轮眼跟随宿主；系统布局清掉子视图时自动重新挂载。
- 防重复 addSubview：
  全局单写轮眼不变量；已挂载只同步不重复添加；元素挂载模式下禁止旧窗口 overlay 安装路径。
- 生命周期：
  开始/停止录屏沿用旧状态机（0→1/1→0、1.35s grace、结束尾部假恢复确认）；元素失效自动回退旧 provided-container 评分管线，并对录屏元素子树内容器给予 +160 决定性加分，避免误绑音乐/媒体容器。
- 红点约定（第一版）：
  系统 3-2-1 保留、系统录屏红点默认保留（设置新增“隐藏系统红点”开关，默认关）、不删除 `SBRecordingIndicatorView`、不修改 `record.circle.fill`。

### 修改范围
- `Tweak.xm`：新增 V6.0.0 SystemAperture 定位/挂载/同步段；`RSUpdateEyeGeometry`/`RSInstallOnContainer`/`RSDiscoverAll`/`RSRemoveSharingan` 做最小集成；`SAUIElementView` hook 扩展 setFrame/setCenter，新增 `SBSystemApertureContainerView` layoutSubviews hook；红点隐藏默认关闭。
- `control` / 设置 plist / README / CHANGELOG / DEVELOPMENT / AI 接手说明 / 历史问题与踩坑记录 / CI：版本同步为 6.0.0。
- 未重写插件：V5.7.25 全部函数与逻辑保留，仅在既有事件点插入 V6 分支。

### 待实机验证
- 控制中心 3-2-1 原生录屏：元素链路是否命中（看日志 `V6 element via SystemApertureController` / `V6 mounted eye into element`）。
- 切后台、切音乐/高德 Live Activity、暂停/收起、容器 19.67x19↔22x22 重建时的过渡与跳动。
- 若元素链路未命中（identifier 探测失败），会自动回退旧管线；此时可开启设置“Bug 测试记录”看候选日志。

# V5.7.25

## V5.7.25 — 2026-09-01（录屏 element 红点叶子追踪 + 恢复容差校准）
- 实机 V5.7.24 视频确认：right-session lock 已稳定，但暂停/收起期间系统会在同一个 SAUIElementView 子树中重建或搬运原生红点 leaf，导致“红点 ↔ 写轮眼”闪烁；只压 RSInstalledContainer 本身不够。
- 新增严格的“当前录屏 element 子树”红色小叶子压制：不重绑、不改 side、不跟随 morph，仅在当前录屏 element 内隐藏小型红色 leaf。
- 额外隐藏的 leaf 以弱引用记录，恢复显示/真正停止时还原，避免污染高德/其它 Live Activity。
- 恢复几何容差由 2pt 调整为 5pt。最新日志稳定 drift 为 4.0~4.33pt，旧 2pt 门槛导致每次都走 0.37s timeout；5pt 可让真实稳定右圆提前通过，而仍远低于历史 145pt 错位。
- capture-off grace 期间不再更新隐藏 eye 几何，只保留身份并压红点，避免无意义跟随 morph。
- 保留 V5.7.23 已验证 right-session side lock；禁止回退。

# V5.7.24

- 右侧 Live Activity 展开/收起交接：写轮眼不再做 0.08s 淡入，恢复时固定保存的 right anchor 后一次性显示，减少闪烁/阴影。
- capture-off 右侧交接前 0.42s 使用 4 次有限 dispatch_after 重复压住系统红点叶子，防系统重建红点造成闪一下；不增加 Timer/DisplayLink/Hook。
- 保留 V5.7.23 session side lock，禁止 x≈166 morph 临时态改判 left。

# V5.7.24

## V5.7.24 — 2026-09-01（恢复显示双门槛 + 原生红点闪现抑制）
- 根据 V5.7.21 实机视频/日志，三次恢复都执行了 `eye force-shown after short resume settle`，说明“不再永久 hidden”已生效，但 0.16s 到点硬亮仍可能撞上右侧独立圆的最后 morph。
- 0.16s 改为“最早允许显示”，不再无条件点亮；恢复期间比较 model / raw presentation 与绑定锚点的漂移，并要求连续两次稳定命中。
- 增加 0.35s 最大等待上限：若系统动画持续不稳定，则直接使用保存的绑定锚点显示，避免重新出现 V5.7.20 的永久消失。
- 恢复等待期间持续隐藏当前录屏容器中新建的红色叶子，减少“写轮眼隐藏时原生红点闪一下”的过渡。
- 不修改容器识别、左右弹簧锁、结束尾部假恢复过滤、%ctor 安全初始化；不新增 Timer / DisplayLink / Hook，仅使用少量一次性 dispatch_after 检查。

# V5.7.21

## V5.7.21 — 2026-09-01（二次点开消失 + 右侧 morph 误判修复）
- 修复 V5.7.20 在右侧独立圆第二次点开/收起后可能永久隐藏写轮眼：恢复可见性增加 0.16s 硬上限，不再无限等待 stable geometry。
- 同一已确认录屏容器的左右身份固定使用绑定时身份；morph 中 modelCenter 临时跨到左侧时，不再切换左侧尺寸/X 偏移，避免左滑跑到左边并超出。
- 右侧 morph 最多只隐藏 0.22s；超时后回到已确认右侧锚点，并短暂锁锚 0.22s，禁止横穿长条。
- 保留 V5.7.19 已验证的结束尾部假恢复抑制，以及 V5.7.15 已验证的单独录屏左右弹簧锁。

# V5.7.20

- 实机视频确认：京东外卖等 Live Activity 占据长条、录屏位于右侧独立圆时，点写轮眼展开或点空白收起，会把 overlay 在系统 morph 期间拖进长条/穿过药丸，视觉过渡不自然。
- 新增“右侧独立圆 transition suppression”：过渡期间只隐藏 overlay，不删除、不重绑、不重扫；红点隐藏和录屏容器身份继续保留。
- 同时比较 model center 与 raw presentation center；偏离已确认右侧锚点超过约 2.25pt 即判定为系统 morph。
- 回到稳定右圆后等待 0.16s，再用 0.10s 淡入，避免第一帧从长条内部跳出。
- capture-off grace 恢复时不再直接点亮 eye，先恢复旋转时间轴，再由稳定几何放行可见性。
- 保留 V5.7.15 起已验证的左右弹簧不飞出、V5.7.19 结束尾声不复活逻辑，不修改高风险 `%ctor` 初始化。

## V5.7.20 — 2026-09-01（右侧独立圆结束后的尾部假恢复抑制）

- 实机 V5.7.18 日志确认：APP/Live Activity 场景从右侧 22x22 独立圆结束录屏后，`UIScreen.isCaptured` 会在真正停止尾声多次 `NO -> YES -> NO` 抖动。旧逻辑一见 YES 就恢复写轮眼和驱动，因此出现“右圆结束后又弹成长条/红点，写轮眼转一下再暂停”。
- V5.7.20 改为“持续 YES 确认后才恢复”：左侧普通录屏确认 0.28s，右侧独立圆确认 0.75s；确认期间 eye 保持隐藏、旋转冻结、poll/displayLink 保持暂停。
- 若确认期间再次回到 NO，立即否决本次假恢复；若旧录屏 container 已离开 window，也不复活旧 overlay。
- 1.35s stop grace 到期时若恰好遇到一次 YES，不再直接恢复，而是转入稳定恢复确认；避免停止尾声视觉回弹。
- 保持 V5.7.15 已验证通过的左右弹簧锁、V5.7.16 的暂停隐藏/冻结和 V5.7.18 的 grace 驱动暂停，不回退。

## V5.7.18 — 2026-09-01（暂停卡住：grace 期间暂停插件驱动）

- 实机 V5.7.17 日志确认：真正停止时会固定等待 1.35 秒 grace；同时 grace 内插件的 0.10s poll 与 CADisplayLink 仍在运行。
- V5.7.18 在 capture-off grace 一开始就隐藏/冻结写轮眼，并立即暂停 poll timer 与 geometry display link。
- 宽限期只保留会话、容器和动画相位，不再逐帧调用隐藏红点/更新几何，避免与系统暂停/收起动画争抢 UI。
- 若 1.35 秒内 capture 恢复，原地恢复同一眼睛并重启既有驱动；不重新 baseline、不重新安装。
- 真正停止仍在 grace 到期后彻底清理，暂不缩短 1.35 秒，以免把已验证流畅的短暂 0→1 抖动重新变成拆装卡顿。
- 保留 V5.7.15 已验证的左右弹簧防飞出逻辑；不改 %ctor 安全初始化。

## V5.7.17 — 2026-09-01（设置数值防误调 + 扩大位置范围）

- 根据实机反馈，V5.7.15/16 左右弹簧飞出已验证稳定，不修改这部分核心逻辑。
- 首次安装 V5.7.17 时一次性恢复推荐数值：速度 1.0、左 X -2.5、右 X 0、Y 0、左大小 31、右大小 37；素材选择保留。
- 新增“一键恢复推荐数值”开关，误调后无需记默认值。
- 左/右 X 调整范围从 ±8pt 扩大到 ±20pt，解决滑到最右仍不够的问题；Y 扩为 ±12pt。
- 新增左 X、右 X、Y 的 0.5pt 精确点选入口，避免小屏幕拖滑杆难以精确对齐。
- 设置页顶部增加带写轮眼图标的版本信息行；继续保留主设置入口图标。
- 不引入新的 PreferenceBundle、自定义控制器或额外高频 Hook，避免重新触发历史空白设置页/编译风险。

## V5.7.17 — 2026-09-01（暂停时隐藏并冻结写轮眼，恢复原相位继续）

- 实机确认 V5.7.15 已解决单独录屏左右弹簧滑动的偶发飞出/卡住，后续不得为修暂停逻辑回退这部分。
- V5.7.15 的 1.35 秒 capture-off grace 让“暂停 → 点空白 → 回到录屏”明显流畅，但 grace 内保留的写轮眼仍在面板后方旋转。
- V5.7.17 不删除、不重建写轮眼：grace 开始时把现有 UIImageView 隐藏，并把 CALayer 本地时间冻结（speed=0 + timeOffset）。
- capture 很快恢复时恢复同一个 layer 的时间轴，取消隐藏，从原旋转相位继续；不重新扫描、不重新 install。
- 真正停止超过 1.35 秒仍按原逻辑彻底清理；清理前恢复 layer 时间参数，避免 speed/timeOffset 脏状态。
- 没有新增 Hook、Timer、DisplayLink；%ctor 安全初始化路径未改。

## V5.7.15 — 2026-09-01（原生录屏：capture-off 去抖 + 暂停/收起过渡优化）

- 根据 V5.7.14 实机日志确认：点开录屏灵动岛、暂停/收起过程中，`UIScreen.isCaptured` 会在很短时间内反复 `1 -> 0 -> 1`。旧逻辑每次都会拆掉写轮眼、停止 polling/displayLink，再马上重新扫描和安装，造成“点空白收起后回到继续录屏时卡一下”。
- 新增 1.35 秒短暂 capture-off 宽限：若很快恢复录屏，保留同一录屏会话、同一容器身份、同一写轮眼实例和旋转动画，不重新 baseline / 不重新安装。
- 宽限期内禁止重新选容器，只维持当前绑定，减少展开/收起阶段误抢临时容器。
- 单独原生录屏弹簧跟随进一步收紧：presentationLayer 最大弹性跟随由 2pt 收紧到 0.75pt，锚点漂移阈值同步收紧。
- 真正停止录屏超过宽限期后仍会正常清理，不长期挂住。
- 不新增 Hook / Timer / DisplayLink；继续复用现有通知和已有定时/逐帧机制，不动 `%ctor` 安全初始化。

## V5.7.14 — 2026-09-01（控制中心单独录屏：弹簧手势锚点锁定）

- 实机 V5.7.13 仍复现：只开启控制中心原生录屏时，灵动岛右滑会把写轮眼带出稳定位置；左滑又恢复。
- 新日志显示同一录屏小容器可在不同会话以约 `143.83` / `139.50` 的左侧中心出现，说明不能继续把手势中的临时几何当成稳定位置。
- 新增 `RSBaselineContainerCount`，只在录屏开始基线容器 `<=3` 的“单独录屏”场景启用强锚点锁，暂不扩散到音乐/高德多活动场景。
- 已绑定左侧录屏小容器在弹簧/交互几何动画中，写轮眼使用 `RSLastConfirmedCenter` 会话锚点，不再逐帧追随大幅 presentation/model 漂移。
- presentation 小范围跟随上限由 5pt 收紧到 2pt；真正大漂移由锚点锁处理。
- 静止状态仍缺一点角属于位置微调，继续由设置页“左侧 X”负责；建议先在 -3.0～-3.5pt 附近微调，不再和弹簧修复混成一个逻辑。
- 不新增 Hook / Timer / DisplayLink；不修改 `%ctor` 安全初始化。

## V5.7.13 — 2026-09-01（控制中心弹簧拖动锁定修复）
- 当前仍只以“控制中心 → 屏幕录制 → 3、2、1”作为主线；02 分屏快捷录屏继续不适配。
- V5.7.12 实机复现：单独录屏时左右弹簧拖动灵动岛，写轮眼会被带到岛外，偶发松手后卡住/回不来。
- 修复关键身份污染：`RSUpdateEyeGeometry()` 不再把逐帧 presentation 视觉中心写回 `RSLastConfirmedCenter/RSLastWasRight/RSLastConfirmedAt`；稳定身份只在真正绑定容器时更新。
- 新增 model/visual 几何分离：left/right 身份和尺寸由 model center 决定，弹簧 overshoot 只影响有限视觉位移，不再临时翻转身份。
- 对同一已绑定容器的 presentation 弹性 overshoot 做小范围限幅（X 约 ±5pt、Y 约 ±4pt），保留原生轻微弹性，但禁止 Overlay 飞出灵动岛。
- 当前容器仍有效时，禁止同侧距离稳定中心超过约 16pt 的临时小圆抢绑；真实左右侧切换仍保留。
- 不新增 Hook / Timer / DisplayLink；不修改 `%ctor` 安全初始化；继续使用既有轮询和 geometry DisplayLink。
- 出包前继续执行 `-Werror` 风格静态检查、版本号全局同步、plist/XML 校验与 ZIP 根目录检查。

## V5.7.12 — 2026-09-01（控制中心原生录屏二次稳固）
- 用户实测确认 V5.7.11 使用控制中心 3-2-1 录屏“确实好一点”，说明当前动画跟随方向有效。
- V5.7.11 日志同时证明设置页已真正生效：素材 style 1/2 与 speed 0.66～3.00 可即时写入并触发 reload。
- 新日志发现：典型原生会话会绑定 `17x22`、center≈`{143.83,29.67}`；但 Live Activity 已存在后重新开始录屏时，可能先出现 `22x22`、center.x≈`166.33～166.67` 的左内侧候选。
- 新增“左内侧 22x22 过渡候选保护”：新会话尚未绑定时降低它的抢占优先级，并要求约 0.36 秒稳定确认；若它确实是最终录屏容器仍允许接管，不做永久黑名单。
- 继续只优化控制中心原生录屏；02 分屏快捷启动暂不纳入本版。
- 不新增 Hook / Timer / DisplayLink，不修改 `%ctor` 安全初始化，只在既有候选评分与确认条件中做最小改动。

# RecordingSharingan 版本更新日志

## V5.7.9 — 2026-09-01
- V5.7.8 已确认 PreferenceLoader 主入口能够显示，但进入“录屏写轮眼”后页面空白。
- prefs 子工程显式声明 `RecordingSharinganPrefs_RESOURCE_DIRS = Resources`，确保 `Root.plist` 与 `Info.plist` 进入 PreferenceBundle。
- 新增设置主列表图标：使用现有写轮眼素材生成 58×58 图标，并随 PreferenceLoader entry 一起安装。
- 保留设置项目：总开关、两套素材、旋转速度、左/右 X、Y、左/右尺寸、恢复默认。
- 不再继续做用户可见 Bug 测试开关；后续诊断以“短录屏视频 + RecordingSharingan.log”为主。
- 左侧定位改为单一可调参数：移除按 17×22 / 19.67×19 容器尺寸额外叠加的隐藏左移值，默认 `leftXOffset=-1.0pt`。
- 不新增 Hook、Timer、DisplayLink；不修改 `%ctor` 安全初始化。
- V5.7.8 视频仍存在 Home 手势/Live Activity 切换时瞬时跳动；V5.7.9 先让调参面板可靠可用并减少隐藏偏移，后续继续根据视频收敛动画核心。

## V5.7.8 — 2026-09-01

### 修复
- 修复 V5.7.7 GitHub Actions 编译失败：`ld: framework 'Preferences' not found`。
- prefs 子工程不再强制链接 GitHub Theos SDK 中缺失的 `Preferences.framework` stub，改为运行时动态解析 Preferences 符号。
- PreferenceLoader 入口补回 `isController = 1`，确保点击“录屏写轮眼”时按控制器 Bundle 方式加载设置页。
- 保留 rootless 标准安装路径，由 Theos 自动映射到 `/var/jb`，不再手工混放两套路劲。

### 安全范围
- 本版只修编译/设置入口，不修改 SpringBoard 主插件 Hook、`%ctor`、录屏识别、动画 DisplayLink 或定位核心。
- 因此本版对写轮眼主体的白苹果/安全模式风险增量很低。

### V5.7.7 失败记录
- V5.7.7 源码在 GitHub runner 链接 `RecordingSharinganPrefs.bundle` 时失败，错误为 `framework 'Preferences' not found`，DEB 未生成。
- 原因不是用户 GitHub 操作错误，而是源码把私有 Preferences.framework 当成 SDK 中可直接链接的 framework。
- 后续禁止再次恢复 `RecordingSharinganPrefs_PRIVATE_FRAMEWORKS = Preferences`，除非构建环境明确提供对应 stub。

# CHANGELOG

## V5.7.7 — 2026-09-01（设置调参版，编译失败）

### 本版目标
- 不再继续开发 Bug 测试开关；诊断改用“录屏视频 + RecordingSharingan.log”。
- 把设置页真正做成长期调参入口，减少为了 0.5～1pt 的位置/大小调整反复改源码。

### 修改
1. 重做 PreferenceBundle：prefs 子工程显式启用 rootless scheme，并用 `Preferences` 私有框架标准链接方式，不再依赖 `dynamic_lookup`。
2. PreferenceLoader 入口改为最小标准结构，只声明 bundle / cell / label，由 PreferenceBundle 的 `NSPrincipalClass` 负责控制器。
3. 设置页新增总开关。
4. 设置页保留“素材 1 / 素材 2”切换。
5. 新增旋转速度滑杆，默认 1.0 倍，可调 0.25～3.0 倍。
6. 新增左侧 X、右侧 X、Y 坐标微调，范围 -8～+8pt。
7. 新增左侧大小、右侧大小滑杆；左右状态独立调整。
8. 新增“恢复默认参数”。
9. 调参通过现有 Darwin 通知即时通知 SpringBoard；不新增 Hook、Timer 或 DisplayLink。

### 风险控制
- `%ctor` 安全初始化保持不动。
- 设置模块和 SpringBoard 主逻辑继续分离；设置页加载失败不应影响录屏主体。
- V5.7.6 已确认仍有 Home 手势跳动/过渡不稳，本版不做大范围动画重构，优先先把可视化调参入口做稳定。

## V5.7.5 — 设置入口修复版
- 修复 V5.7.4 安装后 iOS 设置中没有“录屏写轮眼”入口的问题。
- PreferenceBundle 明确安装到 rootless `/var/jb/Library/PreferenceBundles`。
- PreferenceLoader 入口同时按 rootless 路径打包，避免 Dopamine rootless 下入口文件未被加载。
- 保留 V5.7.4 低风险 Bug 测试记录逻辑；默认关闭。
- 不新增 Timer / DisplayLink / 高频扫描 / 新 SpringBoard Hook，不改 `%ctor` 安全初始化。
- 测试要求：安装后注销 SpringBoard 一次，确认“设置 → 录屏写轮眼”出现；再开启 Bug 测试记录。

## v5.7.5（低风险测试记录版）
- 基于 v5.7.3 做最小改动，写轮眼识别、几何跟随、轮询周期、CADisplayLink 和安全初始化主逻辑保持不变。
- 设置页新增“Bug 测试记录（低风险）”，默认关闭。
- 开启后仅在既有事件点记录诊断快照：录屏开始/结束、录屏容器重新绑定、设置变化。
- 快照最多记录 12 个小型 `_SAUIProvidedViewContainerView` 候选的 bounds、alpha、hidden、红色分数、metadata 分数、总分和屏幕中心。
- 明确不增加新的 Timer、CADisplayLink、Hook 或后台线程；不做逐帧磁盘写日志。
- `%ctor` 保持延迟初始化策略，禁止同步访问 `UIScreen/mainScreen`。
- 测试记录代码全部有 `@try/@catch` 边界；诊断失败时优先放弃记录，不影响插件主体。
- 源码 ZIP 命名规范改为 `录屏写轮眼-V5.7.5.zip`；GitHub 编译 DEB/Artifact 改为 `录屏写轮眼-V5.7.5.deb` / `录屏写轮眼-V5.7.5`。

## v5.7.3
- 基于 v5.7.2 源码与最新实测日志做最小范围修复。
- 对候选容器增加 30pt 硬上限；42×36.67 等大容器直接记为无效，防止“大写轮眼素材飞进去”。
- Overlay 几何位置优先使用 `presentationLayer`，跟随系统正在屏幕上显示的实时动画位置，而不是提前使用 modelLayer 的最终位置。
- 新增 CADisplayLink，仅在录屏期间逐帧刷新写轮眼几何，改善左右滑动、音乐、高德和 Live Activity 状态切换时的卡顿/跳位。
- 删除 Overlay 自身 0.12/0.20 秒位移动画，避免与系统灵动岛动画叠加。
- 左侧保持 31pt、右侧独立圆保持 37pt；左侧内收量进一步减小。
- 保留候选稳定确认、身份连续性、单 Overlay、红色叶子隐藏、安全初始化等既有策略。
- 不修改 `%ctor`、SpringBoard 延迟初始化与注入入口。
- control、源码常量、README、设置页、PreferenceBundle、开发文档、GitHub Actions 和产物名同步为 5.7.3。

## v5.7.2
- 左侧写轮眼调整为 31pt，并按小容器尺寸族做静态内收。
- 首次安装 Overlay 直接落在最终尺寸/位置。
- 重扫间隔调整到 0.25 秒，并继续保留候选稳定确认与安全初始化。

## v5.7.1
- 增强录屏身份连续性和低分恢复，只允许 17×22、19.67×19、22×22 等小尺寸族恢复。
- 只隐藏确认的红色叶子，降低误隐藏音乐/导航图标的风险。

## v5.7
- 针对汽水音乐/歌词灵动岛场景增加候选容器稳定确认，避免写轮眼在临时容器间跳动。
- 高可信目标快速接管；中等可信目标需连续命中并稳定约 0.32 秒。
- 当前已锁定容器保持粘性，只有明显更可信且稳定的新目标才能交接。
- 左侧药丸 34pt、右侧独立圆 37pt。
- 增加设置 PreferenceBundle。
- 按最小改动原则，未修改 ctor、安全初始化和注入路径。

## v5.6.0
- 合并 v5.2 主动扫描与 v5.5 安全初始化。
- 修复停止第一次录屏后 Timer 被销毁、后续录屏不再自动扫描的生命周期问题。
- 录屏开始主动扫描，减少必须手动滑动灵动岛才能出现的问题。
- 增加候选容器评分，降低误抓音乐/其他 `_SAUIProvidedViewContainerView` 的概率。
- 写轮眼改为 UIWindow Overlay，视觉尺寸 37pt，解决 17x22 容器导致图案太小和父视图裁切的问题。
- 全局只保留一个 Overlay，减少双写轮眼。
- 新增设置入口、启用开关与两套素材切换。
- 保留 `%ctor` 安全规则，避免 SpringBoard 启动阶段直接访问 `UIScreen`。

## V5.7.6 — 2026-09-01

### 本版依据的真实测试
- 控制中心 3-2-1 启动录屏：左侧写轮眼静止时缺角。
- 02 分屏快捷启动录屏：同样缺角，说明不是启动方式特有问题。
- 手指按住灵动岛向左弹性拖动时写轮眼完整；松手回弹后重新缺角。
- App 上滑回桌面/Home 过渡时，写轮眼会瞬时“绕/跳”一下；右侧独立圆状态也会出现向左回缩感。
- 高德地图、汽水音乐、录屏并存时，左右活动切换过渡不稳定。
- 2026-09-01 日志确认录屏容器常见两种尺寸：约 19.67x19 和 17x22；左右中心约 x=142.50/143.83 与 x=307.17。

### 修改
1. 修复设置入口路径：PreferenceBundle 安装路径改回 `/Library/PreferenceBundles`，让 Theos rootless scheme 统一映射到 `/var/jb`；删除源码 layout 中手工写死的 `/var/jb/Library/PreferenceLoader` 重复路径，只保留标准 `/Library/PreferenceLoader/Preferences`。
2. 左侧静止位置校正方向由“向右靠中间”改为小幅“向左远离中间”，并降低偏移量，避免简单粗暴的大幅硬编码。
3. 修正动画期间 presentationLayer 坐标换算：不再用 presentation.position + model superLayer 混合坐标系，改为优先在 presentation layer 树中换算，降低 Home/灵动岛过渡时瞬时绕行/跳动。
4. 写轮眼创建改为 `initWithFrame:CGRectZero`，先完成最终几何再启动旋转，降低首次显示“大素材缩进去/飞进去”的风险。
5. 不修改 `%ctor` 安全初始化，不新增 Hook，不增加额外 Timer/DisplayLink。

### 风险控制
- 本版仍保留原有 0.10s 候选轮询和既有 geometry DisplayLink；没有增加新的高频机制。
- 由于现有日志已经证明 geometry DisplayLink 在运行，本版先修正它的坐标换算，不贸然整段删除，避免造成新的跟随延迟。
- 若出现安全模式/反复注销，应立即回退 V5.7.5/V5.7.4，并记录崩溃时间点。

### V5.7.8 候选
- 若 V5.7.6 仍存在 Home 过渡跳动，再基于新日志决定是否将 geometry DisplayLink 改为“仅系统动画期间启用”或完全移除，而不是盲目叠加补丁。
## V5.7.10 — 2026-09-01
- 修复 V5.7.9 GitHub/Theos 编译失败：`Tweak.xm` 中 `cw`、`ch` 声明后未使用，在 `-Werror` 环境被提升为错误。
- 删除两个无用变量，不改变写轮眼定位、动画、SpringBoard 初始化和设置页功能逻辑。
- V5.7.9 标记为“功能代码已完成但编译失败，不作为可用版本”；V5.7.10 继承其设置页/调参功能。
- 开发规范新增永久出包检查：unused variable/function、warning-as-error、Makefile/PreferenceBundle、资源打包、版本同步、ZIP 根目录与 DEB 产物名。

## V5.7.11 — 原生控制中心专项 + 设置空白重构
- 当前测试范围收敛为：**控制中心 → 屏幕录制 → 3、2、1 倒计时**。02 分屏快捷启动暂不作为本版修复目标；用户实测发现它与控制中心模块状态并不完全一致，先避免两套启动链路混在一起判断。
- 修复 V5.7.8～V5.7.10 “设置入口能打开但内容空白”：不再编译独立 PreferenceBundle，改用 PreferenceLoader 原生 `entry + items` 单文件方案，减少 Preferences.framework / Root.plist 资源定位故障点。
- 设置页保留：总开关、素材、旋转速度、左/右 X、Y、左/右大小、版本号。
- 设置主列表图标改为 rootless 实际路径 `/var/jb/Library/PreferenceLoader/Preferences/RecordingSharingan.png`。
- 日志确认右侧录屏容器会在 `19.67x19 center≈307` 与 `22x22 center≈304/307` 之间反复重建；本版对**同侧小范围重绑**增加 0.14 秒 smoothstep 平滑，避免 2～4pt 瞬时跳动。
- Home 手势/灵动岛弹簧动画期间，如果当前容器 presentationLayer 正在运动，暂时不抢绑临时候选，等系统动画稳定后再重新评估。
- 左侧 X 默认从 -1.0pt 调整为 -2.5pt；后续以设置页实机微调为主，不再靠每版硬编码试数值。
- 不新增 Hook、Timer、DisplayLink；不修改 `%ctor` 安全初始化原则。

## V5.7.24
- 根据高德 Live Activity 实机日志修复：右侧 22x22 录屏圆在 morph 中临时移动到 x≈166 时，不再被误判成真正左侧录屏。
- 新增会话 side 锁：一轮录屏首次确认 left/right 后，临时 morph 不允许改写 side 与稳定 anchor。
- 对“finalize 后极短时间同一容器又抖回 captured=YES”保留 2.2 秒最近右侧身份，避免同一容器立刻以 x≈166 重新安装到左侧。
- 当前会话锁为 right 时，拒绝所有临时 left 候选抢绑；不新增 Timer/Hook/DisplayLink。
