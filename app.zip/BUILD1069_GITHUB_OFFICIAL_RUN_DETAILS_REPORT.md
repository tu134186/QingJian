# Build1069 — GitHub 官方 Run Details 重构

- 基线：V7.5.6 Build1068。
- 仅重构 G / GitHub Actions 编译链；C / Codemagic 链未修改。
- workflow_dispatch 请求加入 `return_run_details: true`，并对该请求使用 GitHub REST API `2026-03-10`。
- 成功派发必须是 HTTP 200，并解析 `workflow_run_id`、`run_url`、`html_url`。
- 校验返回 URL 必须属于当前 owner/repo 和该 run ID。
- 编译状态只轮询 `GET /repos/{owner}/{repo}/actions/runs/{workflow_run_id}`。
- 产物继续只从同一 run ID 的 `/artifacts` 获取。
- G 主链不再调用 `latestWorkflowRun` / `waitForNewCompletedRun` 来猜测新 Run。
- 若 GitHub 不返回真实 Run 详情，立即失败，不允许 APP 显示伪成功。
