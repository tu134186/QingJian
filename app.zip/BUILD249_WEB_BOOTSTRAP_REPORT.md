# Build249 Web Bootstrap 修复报告

## 根因
Codemagic Build #122 的 source trace 已确认 app.zip 是 Build248（SHA-256 25c47daf...081a），但步骤 2.5 展示的命令仍是旧 RepairPlan 逻辑。这说明手工网页构建执行的是 GitHub 仓库根目录旧 codemagic.yaml；app.zip 内的新版模板不会在构建开始前自动覆盖根配置。

## 修复
1. 发布 Build249 源码包。
2. 同时发布根目录 codemagic.yaml，网页 bootstrap 时与 app.zip 一起更新。
3. Agent Patch Gate v249：RepairPlan 缺 SHA / SHA 不匹配 / 已知 Task ID 不匹配时一律跳过。
4. 保留同源码 Patch 的数量、路径、文件存在和唯一命中安全门。

## 验证目标
下一次 Codemagic 日志 2.5 必须出现 `RepairPlan Gate v249`；旧 plan 应显示 fail-closed 隔离，随后进入 3. XcodeGen 与 4. Xcode 正式编译。
