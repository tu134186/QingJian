# V7.4.6 · Build 1034

- 本地源码体检从 BuildMate 专用结构改为通用 iOS/Theos 工程识别。
- project.yml/project.yaml 或 .xcodeproj + Swift 可进入 iOS 体检；Theos Makefile + 源码/control 可进入 Theos 体检。
- Info.plist 不再作为所有工程硬门槛，因为 XcodeGen/Xcode 可自动生成。
- 四宫格 BMCompactAction 增加整块矩形 contentShape，首次导入源码后源码体检整块可点击。
- 未改 Codemagic/GitHub 编译主链、Build1033 单次 Artifact 抓取、中央动态素材。
