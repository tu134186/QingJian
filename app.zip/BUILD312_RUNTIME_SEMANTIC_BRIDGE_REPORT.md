# BuildMate V5.0.2 · Build 312 — Runtime Semantic Bridge

## Trigger
Build311 real-device AI tester session recorded 393 events / 15 pages / 8 scroll regions but 0 registered controls. Runtime UI observation and static UI manifest existed, but the exact real tap -> runtime semantic node -> manifest element bridge was missing. UIKit internals also caused false Back duplicates and hit-target warnings.

## Build312 closure
- Added fail-open UIApplication.sendEvent observer. UIKit original sendEvent is invoked first; tester only observes afterwards. No SwiftUI full-screen Gesture, Overlay, hit-test override, or synthetic action.
- Freezes semantic target at touch begin, rejects swipe/long-travel touches, then maps a true tap to the static UI manifest.
- Keeps scrolling measured only from real UIScrollView contentOffset changes.
- Canonicalizes runtime UI tree and removes internal UIButtonLabel / modern bar-button implementation leaves.
- Improves page inference from navigation title + visible semantic controls.
- Improves control matching with role compatibility, source-page candidates, unique global exact fallback, and ambiguity fail-closed.
- Adds secondary Toggle/value-change inference.
- Upgrades UI Manifest IDs to semantic IDs independent of raw source line numbers.

## Safety invariant
Tester telemetry may fail or under-count, but it must never modify product input behavior. Paid cloud builds, destructive actions, external writes and release remain human-approved.

## Local verification
- 146 Swift files parsed: PASS
- Release version gate: PASS
- UI manifest/relationship drift: PASS
- Duplicate top-level Swift type gate: PASS (466 declarations)
- Unified task pipeline: 8/8
- Task execution coordinator: 9/9
- Autonomous development loop: 10/10
- Provider execution bus: 10/10
- Build167 Xcode blocker regression: 7/7
- Build302 Run binding: 10/10
- Build309 interaction safety: 7/7
- Build311 Agent role unification: PASS
- Build312 runtime semantic bridge: 14/14

Real Xcode/iPhone execution is still required for final runtime validation.
