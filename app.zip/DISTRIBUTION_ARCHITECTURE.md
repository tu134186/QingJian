# Build143 回传桥与发布层

编译产物回传与商店发布继续分层。Git Relay 只负责把短时 Artifact 地址送回 BuildMate，不等同于 App Store/Google Play/AppGallery 发布凭证或上传通道。

## Build141 Codemagic receipt persistence
Codemagic post-publish receipt now attempts persistence through both workspace and `CM_EXPORT_DIR`. Secret values remain outside the receipt.

# V2.9.89 · Build 140 补充

发布/产物动作按钮统一使用“保存产物 / 下载产物 / 重抓产物”等平台中性命名，IPA/DEB/APK/AAB 等具体类型由状态详情展示。

# V2.9.88 · Build 139 补充

发布层复用 Artifact Return Provider 的服务器预检与回传证据链，为未来 IPA/APK/AAB/HarmonyOS 产物统一回传打基础。

## Build138 Artifact Return 安全接入

Codemagic `buildmate_secrets` 只在 CI 环境注入；Artifact 回传采用服务器 `CM_ARTIFACT_LINKS` 证据 + 手机端旧 API/v3 API 双链兼容。

# BuildMate 应用商店发布架构

## 目标
BuildMate 将“开发/编译平台”和“应用商店发布渠道”拆开。iOS/Android/HarmonyOS 负责工程识别、编译、测试、签名与产物；Distribution Provider 负责把已验证产物送往对应商店。

## 当前 Build136 预留
- Apple：App Store Connect / TestFlight Adapter
- Google：Google Play Console Adapter
- Huawei：AppGallery Connect Adapter，支持 HarmonyOS/Android 发布边界

这些 Adapter 当前全部默认关闭、`available=false`，不包含用户凭证，也不宣称已能真实上传；后续绑定开发者账号时再实现具体网络 Adapter。

## 标准发布链
需求 → Agent 开发 → 编译 → 测试/回归 → 签名 → Artifact → Distribution Provider → 测试渠道/商店元数据 → 主人批准 → 提交审核 → 主人批准/策略允许 → 正式上线 → 审核/版本状态回写黑匣子。

## 权限规则
Release Agent 默认可以：准备发布、上传构建、更新元数据、上传截图、读取审核状态。
必须主人批准：提交审核、正式上线。
永久拒绝：读取秘密明文、删除开发者账号、修改账号安全凭证。

## Secret Boundary
商店密钥进入独立秘密边界，只向 Agent 暴露引用 ID 和可执行权限，不暴露私钥/JSON 密钥/密码/Cookie。

## 扩展规则
新增商店只能新增 Distribution Adapter，不得修改 iOS/Android/HarmonyOS Core。删除任意可选商店 Adapter 后，现有 iOS 编译主链必须仍可独立工作。
