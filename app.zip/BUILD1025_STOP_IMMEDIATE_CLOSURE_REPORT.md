# Build1025 停止任务立即收口

- 新增 `activeCompileTask` 保存用户手动编译的顶层 Task。
- 首页所有“开始编译”入口统一经过 `launchSelectedCompile()`。
- 停止时取消顶层 Task、Codemagic 轮询和 Artifact 下载控制器。
- 无云端 Run：立即 `busy=false`、`workStage=.cancelled`，不再卡“正在停止”。
- 已有云端 Run：本地立即收口，后台向 GitHub Actions / Codemagic / Bitrise 发送取消。
- 远端取消失败仅提示，不会把工作台重新锁死。
