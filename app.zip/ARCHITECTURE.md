# BuildMate 当前架构

## 产品边界
六大核心：源码管理、源码体检、一键编译、产物管理、BUG诊断包+任务黑匣子、应用发布。

## 主链
源码 ZIP → 本地识别/体检 → Source SHA/Generation → 云端上传与回读校验 → Workflow/Run → 真实 Xcode/Theos → 错误或产物 → 黑匣子/诊断/产物持久化 → 发布。

## 云端 Provider
GitHub Actions、Codemagic、Bitrise、自托管 Mac/Mac Agent。Provider 只是执行层，不能各自复制一套业务状态机。

## 状态与可靠性
任务必须有 Task ID/Run ID/Source SHA/阶段/结果/失败原因/恢复点。成功、失败、取消、网络中断都必须可解释，禁止幽灵任务。

## 中央视觉系统（保护区）
`BMCentralEffectSettingsView.swift`、`BMCentralEffectRenderer.swift`、`CentralEffectMedia.swift`、`BMCentralWorkOrb.swift`、`BMCentralBuiltInEffectView.swift`、`BMCentralMotionEngine.swift`、`BMCentralTaskSpeedProfile.swift`、`BMSVGMaterialSpec.swift`、`SVGSourceStore.swift`、`CentralEffectLibraryStore.swift` 与 `SharinganProHD` 资源为保护区。

6 个内置动态素材必须保留；自定义素材支持 PNG/JPG/JPEG/GIF/APNG/SVG；SVG 原码保存为 SVG，由 WebKit 渲染；SVG 内部动画负责局部特效，BuildMate 外层旋转负责任务速度。跟随任务模式待机 5 码，编译最高 120 码，结束平滑回 5 码。

## 数据安全
Token/云凭据进入 Keychain；诊断导出必须脱敏。备份恢复只允许白名单配置和必要凭据，不恢复废弃实验状态、旧 Run 或页面瞬时状态。

## 禁止架构
不得恢复 Creator、DeepTakeover、AI Tester、AI开发工作台、网页预览、UI Manifest/关系图实验系统；不得安装全局 Gesture/Overlay/hit-test 拦截。
