# Build1052 全局中文导航收口

- 根因：SwiftUI 系统自动生成返回按钮，但工程未声明简体中文本地化。
- 修复：Info.plist 声明 zh-Hans/zh_CN；根 WindowGroup 注入 zh-Hans Locale；加入 zh-Hans.lproj。
- 目标：系统返回按钮统一按中文环境显示“返回”，保留系统侧滑返回。
- 边界：未修改编译、云端调度、产物回传和黑匣子逻辑。
