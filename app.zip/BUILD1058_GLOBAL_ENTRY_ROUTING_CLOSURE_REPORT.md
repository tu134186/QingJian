# Build1058 全局入口错位收口

- 基线：V7.4.29 · Build1057
- 修复：首页四按钮“编译设置”不再通过 selectedMainTab=3 间接跳转，改为直接打开 CloudCompilerSettingsView。
- 修复：设置 Tab 恢复源码平台、编译平台、中央素材、备份恢复、关于入口。
- 保留：Build1056 GitHub Actions 旧 GitHub Token/Owner/Repo 迁移。
- 冻结：Codemagic / GitHub Actions 云编译执行主链、Artifact Return Bridge、中央素材渲染主逻辑。
- 验证：只做本地静态检查与版本一致性检查，不发起云编译，不消耗云分钟。
