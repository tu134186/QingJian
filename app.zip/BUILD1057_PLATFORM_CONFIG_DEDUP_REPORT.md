# Build1057 Platform Config / UI Dedup

Build1057：修正编译平台配置入口的职责错位：GitHub Actions / Codemagic 分段按钮现在只切换“查看/编辑哪套配置”，不会再立即改变主编译平台；仅点击“设为当前”才切换下一次编译链。开发环境删除重复的“连接状态”卡片，源码与编译配置继续各自独立。待机工作台右下角动态按钮、本次已验证的 Codemagic/Artifact Return Bridge/工作台状态机均不改。
