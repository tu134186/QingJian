# BuildMate 可重建级开发手册

> 目的：即使未来完全重新建立一个工程，开发者/AI 也能依据本手册 + 当前源码，重做出功能、流程、数据边界和中央视觉行为一致的 BuildMate。

## 1. 产品定义
BuildMate 是 iPhone 上的源码与多云编译工作台，不是代码生成器。用户拿到外部 AI/开发者生成的源码 ZIP 后，在 BuildMate 内完成源码管理、体检、真实云编译、产物、诊断和发布。

六大核心固定为：源码管理；源码体检；一键编译；编译结果/产物管理；一键 BUG 诊断包 + 任务黑匣子；应用发布。

## 2. 不可删除的支撑能力
GitHub Actions/Codemagic/Bitrise/自托管 Mac/Mac Agent；iOS/Xcode、Theos/DEB 与已实现 Android 路由；Source SHA/Generation；源码锁；上传回读校验；防重复编译/分钟保护；任务取消/恢复；网络恢复；缓存与产物持久化；构建历史；诊断脱敏；签名/Provisioning/App Store Connect/TestFlight/Google Play；备份恢复。

## 3. 核心工作流
### 源码管理
导入 ZIP 后先验证结构与工程类型，计算 SHA-256，建立 Source Generation。运行中的源码不可被替换；新 ZIP 替换旧缓存；成功后可按策略清理，失败保留以便诊断。

### 源码体检
检查 ZIP、project.yml/工程结构、版本一致性、必需文件和已知错误模式。体检只代表“可以进入真实构建”，绝不能代表成功。

### 一键编译
选择 Provider → 上传源码 → 远端回读校验 SHA → 启动 Workflow/Build → 获取 Run/Build ID → 轮询状态 → 下载日志/产物。网络临时失败不能覆盖已确认的云端成功结果。

### 产物
成功产物要与 Task/Run/SHA 绑定并持久化，允许稍后保存。切换页面、退出 App、网络波动不能让已成功产物消失。

### 诊断与黑匣子
每个任务记录 Task ID、时间、任务类型、阶段、状态变化、Source SHA、Run/Build ID、Provider、网络结果、错误/取消原因、最后检查点与恢复。失败诊断优先给出第一个真实编译根错误及源码上下文；TXT/JSON/ZIP 导出必须脱敏。

### 发布
发布是编译之后的独立阶段。签名、Provisioning、App Store Connect/TestFlight/Google Play 等配置不得和普通编译状态混成一套 UI。

## 4. 中央视觉系统
中央区域不是装饰性可删代码，是产品保护区。必须保持 6 个内置动态素材、现有顺序/选择逻辑、写轮眼 Pro 与三勾玉效果、SharinganProHD 资源、自定义素材库（最多30）、PNG/JPG/JPEG/GIF/APNG/SVG、SVG 原码粘贴/剪贴板/安全检查/直接保存、WebKit SVG、SMIL/CSS 内部动画、AI SVG 制作规范复制、缩放/圆形校正、跟随任务/固定速度/仅素材自身动画三模式、外层旋转开关。

速度语义像汽车仪表：空闲 5；任务开始平滑加速；正式编译最高 120；阶段变化平滑升降；任务结束回 5。SVG 只负责内部动画，不应让根节点/整个素材做与 BuildMate 外层冲突的 360° 自转。

## 5. 关键文件索引
- `BuildMate/Views/ContentView.swift` + ContentView 扩展：主壳、导航、源码/执行/交付。
- `BuildMate/Models/CodemagicWorkflowTemplate.swift`、`BitriseWorkflowTemplate.swift`：云工作流模板。
- `BuildMate/Core/Distribution/`：分发 Provider 抽象。
- `BuildMate/Core/Agents/`：若仍被六核心任务协调使用，只作为底层执行抽象，不作为 AI 产品入口。
- `BuildMate/Services/BackupRestoreService.swift` + `Views/BackupRestoreView.swift`：加密备份恢复。
- 中央视觉关键文件见 `ARCHITECTURE.md`。
- `project.yml`：XcodeGen 工程与版本源。
- `codemagic.yaml`：Codemagic 构建配置。

## 6. 备份恢复契约
备份必须密码加密；当前实现使用 CryptoKit AES-GCM、随机盐和慢速派生。只备份白名单配置、必要 Keychain 凭据和最多30个自定义中央素材。不得恢复 Creator/DeepTakeover/旧 Run/任务缓存/页面状态。内置6素材无需备份，因为随 App 发布。

## 7. 版本发布规范
每个正式包统一更新 MARKETING_VERSION、CURRENT_PROJECT_VERSION、关于页当前更新、备份元数据、README、CHANGELOG、PROJECT_HISTORY。历史只记录当前产品仍有意义的演进，不再堆弃用实验报告。ZIP 根目录必须直接包含 project.yml 和工程内容，不允许多套一层文件夹。

## 8. 编译验证规范
Linux/本地可做文本扫描与 Swift parse，但不能宣称真实 iOS 编译成功。正式成功标准是目标 Xcode/Theos 云环境完成构建并产生有效产物。失败时验证 Source SHA 与目标包一致，然后按第一个根错误修；级联错误不要逐个乱补。

## 9. 永久禁区
不得重新引入 Creator/一句话造 App、DeepTakeover、AI Tester、网页预览、AI开发工作台、UI Manifest/关系图实验路线。不得因为旧符号缺失而恢复旧类型。不得用全局 Gesture、透明 Overlay、hit-test 修改、自动滚动/点击来做观察或测试。

## 10. 从零复刻顺序
先建 iOS 15+ SwiftUI 主壳与六核心导航 → 实现 Source/Task/Run/SHA 数据模型 → 实现源码导入/体检 → Provider 抽象与 GitHub/Codemagic/Bitrise/Mac → 真实构建状态机 → 产物持久化 → 黑匣子/诊断导出 → 发布模块 → 备份恢复 → 最后按保护区逐项复刻中央六素材/SVG/速度系统。每完成一层按 `REGRESSION_TESTS.md` 验收，不跨层堆功能。

## 11. 复刻一致性标准
“做出一模一样”不是只看 UI：六核心入口与页面层级一致；源码生命周期一致；同一源码的 SHA/Run/任务行为一致；成功/失败/恢复语义一致；诊断字段一致；中央素材种类、选择、SVG 行为和速度语义一致；安全边界一致；版本/发布规则一致。
