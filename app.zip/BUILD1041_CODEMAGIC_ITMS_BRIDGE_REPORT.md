# Build1041 Codemagic itms-services Bridge Report

- 新版本：V7.4.13 · Build 1041
- 证据：Build1040 实机任务 BM-A2FC842B 的 Codemagic Build 6aa4dda90f7bf8b117c520ae 已成功并生成 IPA；Artifact 端点返回 HTTP 302，Location/HTML 指向 `itms-services://?action=download-manifest&url=https://api.codemagic.io/artifacts/.<signed>`。
- 根因：URLSession 只能直接处理 HTTP/HTTPS 网络传输，`itms-services` 是安装调度 scheme，不应作为 IPA 网络下载 URL。
- 修复：从 302 Location 或 HTML fallback 中提取 `url=` 内嵌 HTTPS Artifact URL，并在同一抓取轮继续 GET。
- 保持：一次用户动作只执行 1 轮 Artifact 获取，不 sleep、不自动重试、不重新触发 Codemagic Build。
