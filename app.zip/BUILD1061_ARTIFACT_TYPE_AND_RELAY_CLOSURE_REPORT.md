# Build1061 Artifact Type & Relay Closure

- Codemagic publishing 不再递归混扫 IPA/DEB；Theos 任务只从 `src/packages/*.deb` 取 DEB，XcodeGen 任务只从 `src/*.ipa` 取 IPA。
- Artifact Return Bridge 的 GitHub push 失败（含 403）降级为“回传失败”，不再让已成功的真实编译被 Codemagic 标记为失败。
- `compile.log` / `compile-errors.txt` 继续作为 Codemagic 官方 artifacts 输出，保留真实编译证据。
- 未修改中央素材、六大功能 UI、源码导入和真实编译命令。
