# V7.4.8 · Build 1036 — Source Preflight Rewrite / Workbench Unlock

## 这次不是继续给旧体检打补丁

- 新增 `BuildMate/Services/BMSourcePreflightService.swift`，作为新的源码体检执行器。
- 当前“源码体检”与“开始编译前体检”全部改走新执行器。
- 新执行器只读取当前 ZIP：ZIP 完整性、工程定义、源码类型、单层 wrapper、诊断包标记。
- 不读取历史 Run、Source SHA 历史、Artifact Recovery、工作台终态或云平台配置。
- 正常源码支持 XcodeGen / `.xcodeproj` / Theos；诊断 ZIP 明确识别为“诊断包，不是源码包”。

## 工作台点击问题

- “开始编译”的首页按钮不再把 GitHub/Codemagic 配置状态作为 `.disabled` 条件；只要当前源码存在就能点击。
- 真正执行 Codemagic 时，从 Keychain 重新读取 Source GitHub Token，避免 App 划掉重开后内存状态未同步造成假禁用。
- 配置缺失会显示明确错误并停止，不会创建云端 Build。

## BUG 报告

- 失败报告允许 `reportURL == nil` 时先用当前失败文本渲染，杜绝首开空白 Sheet。
- 移除 BUG 报告右上角“完成”，保留下拉关闭。

## 保持不动

- Codemagic clean workflow / GitHub Actions 正式编译主链。
- IPA 单次抓取策略。
- Build1035 Artifact URL 路径正规化。
- DEB 与中央写轮眼素材。
- 本轮不进行 AI/Agent 批量删除。
