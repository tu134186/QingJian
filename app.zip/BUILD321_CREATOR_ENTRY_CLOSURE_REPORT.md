# Build321 Creator Entry Closure Report

## 目标
修复 Build320 Creator 完整体不可达入口，并统一最终用户路径。

## 最终路径
1. 首页/开发页：创建新 App。
2. 从一句话开始做 App。
3. 输入自然语言（可直接使用系统键盘语音）。
4. 生成实现级 AppSpec。
5. 自动打开可交互网页预览。
6. 边看边改；每次修改后自动打开更新预览。
7. 满意后锁定设计。
8. 生成真实 SwiftUI + project.yml + AppSpec + UI Contracts + ZIP。
9. 本地零分钟门禁。
10. 交给 Agent；真实 Xcode/Codemagic 必须人工批准。
11. 成功后交付 IPA。

## 保留/删除
- 保留 UI Manifest、稳定 Accessibility ID、质量门禁、黑匣子。
- 不恢复全局触摸监听/坐标猜控件/重扫描式 AI 内测员。
