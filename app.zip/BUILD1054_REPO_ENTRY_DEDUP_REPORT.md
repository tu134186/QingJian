# Build1054 仓库入口去重

Build1054：开发环境页删除重复“切换 / 管理仓库”入口。仓库切换/管理/删除只保留首页源码卡右侧“切换”这一条用户路径；开发环境页继续保留 GitHub 连接与权限、编译平台配置和连接状态。只改 UI 入口，不改仓库服务、Codemagic、GitHub Actions、Artifact Return Bridge 或编译执行链。
