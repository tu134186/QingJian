# Build1043 · Codemagic Build ID 类型修复

真实错误：`ContentView+Execution.swift:708:173: cannot convert value of type String to expected argument type Int64`。

根因：Codemagic Build ID（例如十六进制字符串）是 opaque `String`，而 `SmartBuildFingerprint.runID` 是为 GitHub Actions Run 设计的 `Int64?`。Build1042 在 Relay 成功收口路径错误地把 Codemagic buildID 直接传入该字段。

修复：Codemagic 的 SmartBuild 历史记录不再写 Int64 runID；真实 Build ID 继续由任务黑匣子、Relay receipt、Codemagic recovery 等 String 字段保存。Artifact Return Bridge、Codemagic workflow、IPA/DEB 与 GitHub Actions 主链均未改动。
