# 轻剪 QingJian V2.0.0

请先阅读根目录 `PROJECT_README.md`。任何 AI/开发者接手前必须阅读 `AI_DEVELOPMENT_RULES.md`、`ARCHITECTURE.md`、`KNOWN_PITFALLS.md`。
