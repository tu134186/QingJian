# AI 开发铁规

1. 先读文档再改代码。禁止只看报错行就盲改。
2. 非核心功能必须模块化、低耦合、可插拔、可删除。删除一个模块不得破坏时间轴、项目、预览、导出和其他模块。
3. 禁止把大量逻辑重新堆回 `EditorView`。页面只负责组合，业务进入 Core/Modules/Services。
4. 未经证据禁止改动已经验证工作的 `.github/workflows/buildmate.yml`。
5. 禁止未经评估提高 Deployment Target。目标 iOS 15.0；新 API 必须 availability 或兼容实现。
6. 禁止改变 Bundle ID `com.tu.qingjian`、PRODUCT_NAME/EXECUTABLE_NAME QingJian，除非产品负责人明确要求。
7. API Key/Token/私钥绝不写入 IPA。AI 服务必须通过 Provider/后端抽象。
8. 普通剪辑默认本地完成；AI 模块断网、停服、删除后，基础剪辑必须正常。
9. UI 必须使用 `QJTheme`/公共组件；禁止每页各写一套颜色、圆角、导航、弹窗。
10. 修改前检查调用链；修改后至少检查：编译、Info.plist、AppIcon、导入、时间轴、导出、保存相册、IPA Payload/主程序。
11. 不允许假按钮伪装完成。未实现能力必须明确 disabled/实验性，不能影响稳定主流程。
12. 每次正式变更同步更新 CHANGELOG、FEATURES、KNOWN_PITFALLS（如新增踩坑）。
