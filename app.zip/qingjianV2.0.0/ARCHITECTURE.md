# 架构

```text
App / Home
   ↓
Editor Shell ── DesignSystem
   ↓
Module Registry
   ├─ VideoEditing
   ├─ Audio
   ├─ Text / Subtitle
   ├─ Sticker
   ├─ Filter / Adjustment
   ├─ Effects / Transition
   ├─ Canvas / PIP / Keyframe
   ├─ AI (optional)
   └─ Export
   ↓
Core Project / Timeline / History / Playback
   ↓
AVFoundation / CoreImage / PhotoKit
```

原则：Core 只提供稳定数据与能力；模块通过公共状态/协议接入，不跨模块硬引用实现细节。编辑参数优先非破坏性保存，最终导出才渲染。V2.0 已建立模块注册与目录边界；后续继续把每个功能从共享 EditorProject 中逐步收敛到独立 State/Service。

AI：`AI` 是可选模块。未来 Provider 可接豆包或其他服务；删除 AI 目录不得影响普通剪辑。
