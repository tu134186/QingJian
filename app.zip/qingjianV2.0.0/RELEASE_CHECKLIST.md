# 发布/编译前检查

- [ ] `project.yml` Deployment Target = iOS 15.0
- [ ] Bundle ID = com.tu.qingjian
- [ ] PRODUCT_NAME / EXECUTABLE_NAME = QingJian
- [ ] Info.plist 有 CFBundleExecutable / CFBundlePackageType
- [ ] AppIcon asset 可被 Xcode 识别
- [ ] 照片读取与保存权限说明存在
- [ ] 冷启动/首页/进入编辑器正常
- [ ] 导入至少 2 段视频
- [ ] 分割/复制/移动/删除/撤销/重做
- [ ] 一级/二级菜单 UI 一致
- [ ] 720P/1080P 导出页可进入
- [ ] 导出进度真实变化
- [ ] 导出完成自动写入系统相册
- [ ] IPA 为 Payload/QingJian.app
- [ ] QingJian.app 内主程序存在
- [ ] TrollStore 真机安装测试
- [ ] CHANGELOG/FEATURES 与代码同步
