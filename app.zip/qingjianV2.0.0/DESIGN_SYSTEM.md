# QingJian Design System

- 全局深色剪辑工作台；强调色统一由 `QJTheme.accent` 管理。
- 一级页面导航、返回、关闭、右侧主要操作位置保持一致。
- 一级工具栏 → 二级功能面板 → 参数控制，层级固定。
- 圆角、间距、Surface、文字弱化色统一由 `QJTheme` 提供。
- Sheet、Alert、导出页、空状态、加载/成功/失败状态保持同一视觉语言。
- 新页面不得自行创造另一套“皮肤”。公共控件优先扩展 DesignSystem。
