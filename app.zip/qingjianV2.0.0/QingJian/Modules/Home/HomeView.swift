import SwiftUI

struct HomeView: View {
    @EnvironmentObject var project: EditorProject
    @State private var openEditor=false
    var body: some View { NavigationView { ZStack { QJTheme.background.ignoresSafeArea(); ScrollView { VStack(alignment:.leading,spacing:22) {
        HStack { VStack(alignment:.leading,spacing:4){Text("轻剪").font(.largeTitle.bold());Text("简单 · 专业 · 本地剪辑").foregroundColor(QJTheme.textSecondary)};Spacer();Image(systemName:"person.crop.circle").font(.title2) }
        Button { openEditor=true } label:{ HStack{Image(systemName:"plus.circle.fill").font(.title);VStack(alignment:.leading){Text("开始创作").font(.headline);Text("导入视频开始剪辑").font(.caption).opacity(0.75)};Spacer();Image(systemName:"chevron.right")}.padding(18).background(QJTheme.accent).foregroundColor(.white).clipShape(RoundedRectangle(cornerRadius:18)) }
        Text("最近项目").font(.headline)
        QJSectionCard { HStack { RoundedRectangle(cornerRadius:10).fill(Color.white.opacity(0.08)).frame(width:86,height:116).overlay(Image(systemName:"film")); VStack(alignment:.leading,spacing:8){Text(project.clips.isEmpty ? "还没有草稿" : project.projectName).font(.headline);Text(project.clips.isEmpty ? "创建项目后会自动保存在这里" : "\(project.clips.count) 段素材 · \(Int(project.totalDuration)) 秒").font(.caption).foregroundColor(QJTheme.textSecondary); if !project.clips.isEmpty { Button("继续编辑"){openEditor=true}.foregroundColor(QJTheme.accent) } };Spacer() } }
        HStack(spacing:12){ mini("草稿箱","tray.full"); mini("已导出","checkmark.circle"); mini("设置","gearshape") }
        Text("V2.0.0 · 本地优先，AI 模块可插拔").font(.caption2).foregroundColor(QJTheme.textSecondary).frame(maxWidth:.infinity)
    }.padding() } }.foregroundColor(.white).navigationBarHidden(true).fullScreenCover(isPresented:$openEditor){ EditorView() } } }
    func mini(_ t:String,_ i:String)->some View{QJSectionCard{VStack(spacing:8){Image(systemName:i).font(.title2);Text(t).font(.caption)}.frame(maxWidth:.infinity)}}
}
