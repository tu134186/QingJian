import SwiftUI
import Photos

struct ExportView: View {
 @EnvironmentObject var p:EditorProject; @Environment(\.dismiss) var dismiss
 @State var resolution="1080P"; @State var fps=30; @State var done=false
 var body:some View{ZStack{QJTheme.background.ignoresSafeArea();VStack(spacing:24){HStack{Button("取消"){dismiss()};Spacer();Text("导出").font(.headline);Spacer();Text("取消").opacity(0)}
 if p.isExporting { Spacer();Text("正在导出").font(.title2.bold());Text("\(Int(p.progress*100))%").font(.system(size:48,weight:.bold,design:.rounded));ProgressView(value:p.progress).progressViewStyle(.linear);Text("请保持轻剪在前台，完成后会自动保存到相册").font(.caption).foregroundColor(QJTheme.textSecondary);Spacer() }
 else if done { Spacer();Image(systemName:"checkmark.circle.fill").font(.system(size:72)).foregroundColor(.green);Text("导出成功").font(.title.bold());Text("视频已自动保存到系统相册").foregroundColor(QJTheme.textSecondary);Button("完成"){dismiss()}.buttonStyle(.borderedProminent);Spacer() }
 else { QJSectionCard{VStack(spacing:18){HStack{Text("分辨率");Spacer();Picker("",selection:$resolution){Text("720P").tag("720P");Text("1080P").tag("1080P")}.pickerStyle(.segmented).frame(width:190)};HStack{Text("帧率");Spacer();Picker("",selection:$fps){Text("24").tag(24);Text("30").tag(30);Text("60").tag(60)}.pickerStyle(.segmented).frame(width:190)}}};Spacer();Button("开始导出"){start()}.font(.headline).frame(maxWidth:.infinity).padding().background(QJTheme.accent).foregroundColor(.white).clipShape(RoundedRectangle(cornerRadius:14)) }
 }.padding().foregroundColor(.white)} }
 func start(){p.isExporting=true;p.progress=0;Task{do{let u=try await Exporter.export(clips:p.clips,text:p.titleText,fps:fps,resolution:resolution,progress:{v in Task{@MainActor in p.progress=v}});try await PhotoSaver.saveVideo(u);p.progress=1;done=true}catch{p.message="导出失败：\(error.localizedDescription)"};p.isExporting=false}}
}

enum PhotoSaver { static func saveVideo(_ url:URL) async throws { let s=PHPhotoLibrary.authorizationStatus(for:.addOnly); if s != .authorized && s != .limited { let n=await PHPhotoLibrary.requestAuthorization(for:.addOnly); guard n == .authorized || n == .limited else { throw NSError(domain:"QingJian",code:30,userInfo:[NSLocalizedDescriptionKey:"没有保存到相册的权限"]) } }; try await withCheckedThrowingContinuation { (c:CheckedContinuation<Void,Error>) in PHPhotoLibrary.shared().performChanges({PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL:url)},completionHandler:{ok,e in if let e=e{c.resume(throwing:e)}else if ok{c.resume()}else{c.resume(throwing:NSError(domain:"QingJian",code:31))}}) } } }
