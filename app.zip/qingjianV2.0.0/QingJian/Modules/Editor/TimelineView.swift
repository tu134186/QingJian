import SwiftUI

struct TimelineView: View {
    @EnvironmentObject private var project: EditorProject

    var body: some View {
        VStack(spacing: 5) {
            header
            clipTrack

            if !project.audios.isEmpty {
                track("音频", icon: "waveform", count: project.audios.count)
            }
            if !project.texts.isEmpty {
                track("文字", icon: "textformat", count: project.texts.count)
            }
            if !project.keyframes.isEmpty {
                track("关键帧", icon: "diamond", count: project.keyframes.count)
            }
        }
    }

    private var header: some View {
        HStack {
            Text(String(format: "%.1fs", project.totalDuration)).monospacedDigit()
            Spacer()
            Button(action: project.undo) { Image(systemName: "arrow.uturn.backward") }
            Button(action: project.redo) { Image(systemName: "arrow.uturn.forward") }
        }
        .font(.caption)
        .foregroundColor(QJTheme.textSecondary)
    }

    private var clipTrack: some View {
        GeometryReader { geometry in
            ZStack {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 2) {
                        ForEach(Array(project.clips.enumerated()), id: \.element.id) { index, clip in
                            Button(action: { project.selectedID = clip.id }) {
                                clipCell(index: index, clip: clip)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, max(0, geometry.size.width / 2 - 32))
                }

                Rectangle()
                    .fill(Color.white)
                    .frame(width: 2, height: 58)
                    .allowsHitTesting(false)
            }
        }
        .frame(height: 58)
    }

    private func clipCell(index: Int, clip: ClipItem) -> some View {
        let duration = (clip.end - clip.start) / Double(clip.rate)
        let width = max(76, min(180, CGFloat(duration) * 18))
        let selected = project.selectedID == clip.id

        return VStack(spacing: 4) {
            Image(systemName: "film.fill")
            Text("\(index + 1) · \(String(format: "%.1fs", duration))")
                .font(.caption2)
        }
        .frame(width: width, height: 48)
        .background(selected ? QJTheme.accent.opacity(0.45) : QJTheme.surfaceStrong)
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(selected ? QJTheme.accent : Color.clear, lineWidth: 2)
        )
        .clipShape(RoundedRectangle(cornerRadius: 6))
    }

    private func track(_ name: String, icon: String, count: Int) -> some View {
        HStack {
            Image(systemName: icon)
            Text(name)
            Spacer()
            Text("\(count)")
        }
        .font(.caption2)
        .foregroundColor(QJTheme.textSecondary)
        .padding(.horizontal, 8)
        .frame(height: 24)
        .background(QJTheme.surface)
        .clipShape(RoundedRectangle(cornerRadius: 5))
    }
}
