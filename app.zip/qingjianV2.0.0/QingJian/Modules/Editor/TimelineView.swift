import SwiftUI

struct TimelineView: View {
    @EnvironmentObject var p:EditorProject
    var body: some View { VStack(spacing:5){
        HStack{Text(String(format:"%.1fs",p.totalDuration)).monospacedDigit();Spacer();Button(action:p.undo){Image(systemName:"arrow.uturn.backward")};Button(action:p.redo){Image(systemName:"arrow.uturn.forward")}}.font(.caption).foregroundColor(QJTheme.textSecondary)
        ZStack { ScrollView(.horizontal,showsIndicators:false){HStack(spacing:2){ForEach(Array(p.clips.enumerated()),id:\.element.id){i,c in Button{p.selectedID=c.id}{VStack(spacing:4){Image(systemName:"film.fill");Text("\(i+1) · \(String(format:"%.1fs",(c.end-c.start)/Double(c.rate)))").font(.caption2)}.frame(width:max(76,min(180,CGFloat((c.end-c.start)/Double(c.rate))*18)),height:48).background(p.selectedID==c.id ? QJTheme.accent.opacity(0.45):QJTheme.surfaceStrong).overlay(RoundedRectangle(cornerRadius:6).stroke(p.selectedID==c.id ? QJTheme.accent:.clear,lineWidth:2)).clipShape(RoundedRectangle(cornerRadius:6))}}}.padding(.horizontal,UIScreen.main.bounds.width/2-32)}; Rectangle().fill(Color.white).frame(width:2,height:58).allowsHitTesting(false) }
        if !p.audios.isEmpty { track("音频",icon:"waveform",count:p.audios.count) }; if !p.texts.isEmpty { track("文字",icon:"textformat",count:p.texts.count) }; if !p.keyframes.isEmpty { track("关键帧",icon:"diamond",count:p.keyframes.count) }
    }}
    func track(_ name:String,icon:String,count:Int)->some View{HStack{Image(systemName:icon);Text(name);Spacer();Text("\(count)")}.font(.caption2).foregroundColor(QJTheme.textSecondary).padding(.horizontal,8).frame(height:24).background(QJTheme.surface).clipShape(RoundedRectangle(cornerRadius:5))}
}
