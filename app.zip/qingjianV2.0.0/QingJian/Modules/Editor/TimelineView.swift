import SwiftUI
import AVFoundation

struct TimelineView: View {
    @EnvironmentObject private var project: EditorProject

    var body: some View {
        VStack(spacing: 7) {
            HStack {
                Text(time(project.totalDuration)).font(.caption2).monospacedDigit()
                Spacer()
                Button(action: project.undo) { Image(systemName:"arrow.uturn.backward") }
                Button(action: project.redo) { Image(systemName:"arrow.uturn.forward") }
            }.foregroundColor(QJTheme.textSecondary)

            GeometryReader { geo in
                ZStack {
                    ScrollView(.horizontal, showsIndicators:false) {
                        HStack(spacing:0) {
                            ForEach(Array(project.clips.enumerated()), id:\.element.id) { index, clip in
                                clipView(clip)
                                if index < project.clips.count - 1 {
                                    transitionButton(index)
                                }
                            }
                        }
                        .padding(.horizontal, max(16, geo.size.width/2 - 55))
                    }
                    Rectangle().fill(Color.white).frame(width:1.5,height:70)
                    VStack(spacing:0) {
                        Image(systemName:"triangle.fill").font(.system(size:7)).rotationEffect(.degrees(180))
                        Spacer()
                    }.foregroundColor(.white).frame(height:70)
                }
            }.frame(height:70)

            if !project.texts.isEmpty { miniTrack("文字", "textformat", "\(project.texts.count)") }
            if !project.audios.isEmpty { miniTrack("音频", "waveform", "\(project.audios.count)") }
        }
    }

    private func clipView(_ clip:ClipItem) -> some View {
        let d=max(0.1,(clip.end-clip.start)/Double(clip.rate))
        let w=max(88,min(210,CGFloat(d)*20))
        return Button { project.selectedID=clip.id; project.selectedTransitionID=nil } label: {
            ZStack {
                ThumbnailStrip(url:clip.url)
                LinearGradient(colors:[.clear,.black.opacity(0.28)],startPoint:.top,endPoint:.bottom)
                VStack { Spacer(); HStack { Text(String(format:"%.1fs",d)).font(.system(size:9,weight:.medium)); Spacer() }.padding(5) }
            }
            .frame(width:w,height:58).clipped()
            .overlay(RoundedRectangle(cornerRadius:5).stroke(project.selectedID==clip.id ? QJTheme.accent:.clear,lineWidth:2))
            .clipShape(RoundedRectangle(cornerRadius:5))
        }.buttonStyle(.plain)
    }

    private func transitionButton(_ index:Int) -> some View {
        let t=project.transitions.first(where:{$0.leftClipID==project.clips[index].id && $0.rightClipID==project.clips[index+1].id})
        return Button {
            if let t { project.selectTransition(t.id) }
        } label: {
            ZStack {
                Circle().fill(Color(red:0.12,green:0.13,blue:0.15)).frame(width:28,height:28)
                Image(systemName:(t?.style ?? "无")=="无" ? "bowtie":"bowtie.fill").font(.system(size:12,weight:.semibold))
            }
            .overlay(Circle().stroke(project.selectedTransitionID==t?.id ? QJTheme.accent:Color.white.opacity(0.18),lineWidth:1))
        }
        .buttonStyle(.plain).frame(width:32).zIndex(3)
    }

    private func miniTrack(_ title:String,_ icon:String,_ value:String)->some View {
        HStack(spacing:7){Image(systemName:icon);Text(title);Spacer();Text(value)}
            .font(.caption2).foregroundColor(QJTheme.textSecondary)
            .padding(.horizontal,9).frame(height:22).background(QJTheme.surface).clipShape(RoundedRectangle(cornerRadius:5))
    }
    private func time(_ d:Double)->String { String(format:"%02d:%02d.%01d",Int(d)/60,Int(d)%60,Int((d-floor(d))*10)) }
}

private struct ThumbnailStrip: View {
    let url:URL
    @State private var image:UIImage?
    var body: some View {
        ZStack {
            Color.white.opacity(0.08)
            if let image {
                Image(uiImage:image).resizable().scaledToFill()
                HStack(spacing:0) {
                    ForEach(0..<4,id:\.self){ _ in Image(uiImage:image).resizable().scaledToFill().frame(maxWidth:.infinity).clipped() }
                }
            } else { Image(systemName:"film").foregroundColor(.white.opacity(0.35)) }
        }.task { image = await makeThumb() }
    }
    private func makeThumb() async -> UIImage? {
        await withCheckedContinuation { c in
            DispatchQueue.global(qos:.userInitiated).async {
                let a=AVURLAsset(url:url); let g=AVAssetImageGenerator(asset:a); g.appliesPreferredTrackTransform=true; g.maximumSize=CGSize(width:180,height:100)
                let cg=try? g.copyCGImage(at:CMTime(seconds:0.15,preferredTimescale:600),actualTime:nil)
                c.resume(returning:cg.map(UIImage.init(cgImage:)))
            }
        }
    }
}
