import SwiftUI
import PhotosUI

struct LegacyMediaPicker: UIViewControllerRepresentable {
    let onURLs: ([URL]) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(onURLs:onURLs) }
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var c=PHPickerConfiguration(photoLibrary:.shared()); c.filter = .videos; c.selectionLimit=20
        let vc=PHPickerViewController(configuration:c); vc.delegate=context.coordinator; return vc
    }
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    final class Coordinator:NSObject,PHPickerViewControllerDelegate {
        let onURLs:([URL])->Void; init(onURLs:@escaping([URL])->Void){self.onURLs=onURLs}
        func picker(_ picker:PHPickerViewController,didFinishPicking results:[PHPickerResult]) { picker.dismiss(animated:true); let g=DispatchGroup(); var urls:[URL]=[]; let lock=NSLock(); for r in results where r.itemProvider.hasItemConformingToTypeIdentifier("public.movie") { g.enter(); r.itemProvider.loadFileRepresentation(forTypeIdentifier:"public.movie") { u,_ in defer{g.leave()}; guard let u=u else{return}; let dst=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension(u.pathExtension.isEmpty ? "mov":u.pathExtension); try? FileManager.default.copyItem(at:u,to:dst); lock.lock();urls.append(dst);lock.unlock() } }; g.notify(queue:.main){self.onURLs(urls)} }
    }
}
