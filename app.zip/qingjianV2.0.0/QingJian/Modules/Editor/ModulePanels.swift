import SwiftUI

struct ModulePanel: View {
 @EnvironmentObject var p:EditorProject
 var body: some View { Group { switch p.selectedModule {
 case .edit: edit
 case .audio: simple("音频", ["提取音频","本地音乐","音量","淡入淡出"])
 case .text: text
 case .sticker: simple("贴纸", ["表情","箭头","标记","形状"])
 case .effects: simple("特效", ["闪白","抖动","缩放","故障 RGB"])
 case .filter: filter
 case .adjust: adjust
 case .transition: transition
 case .canvas: canvas
 case .pip: simple("画中画", ["添加画中画","替换","层级","透明度"])
 case .keyframe: keyframe
 case .ai: simple("AI 剪辑（接口预留）", ["自动字幕","智能粗剪","文案","AI配音"])
 } }.frame(height:105) }
 var edit:some View{ScrollView(.horizontal,showsIndicators:false){HStack{QJToolButton(title:"分割",icon:"scissors"){p.splitSelected(at:1)};QJToolButton(title:"复制",icon:"doc.on.doc"){p.duplicateSelected()};QJToolButton(title:"前移",icon:"arrow.left"){p.moveSelected(-1)};QJToolButton(title:"后移",icon:"arrow.right"){p.moveSelected(1)};QJToolButton(title:"删除",icon:"trash"){p.deleteSelected()}; if let i=p.selectedIndex { QJToolButton(title:"镜像",icon:"arrow.left.and.right.righttriangle.left.righttriangle.right"){p.clips[i].mirrored.toggle()}; QJToolButton(title:"旋转",icon:"rotate.right"){p.clips[i].rotation += 90} } }.padding(.horizontal)}}
 var text:some View{VStack{TextField("输入文字",text:$p.titleText).textFieldStyle(.roundedBorder);HStack{Button("添加文字轨"){p.texts.append(TextOverlay(text:p.titleText.isEmpty ? "文字":p.titleText))};Spacer();Text("字幕轨独立于视频轨").font(.caption2).foregroundColor(QJTheme.textSecondary)}}.padding(.horizontal)}
 var filter:some View{HStack{ForEach(["原片","黑白","暖色","冷色","电影","复古"],id:\.self){x in Button(x){p.filterName=x}.buttonStyle(.bordered).tint(p.filterName==x ? QJTheme.accent:.gray)}}.padding(.horizontal)}
 var adjust:some View{VStack{if let i=p.selectedIndex { HStack{Text("亮度");Slider(value:$p.clips[i].brightness,in:-1...1)};HStack{Text("饱和度");Slider(value:$p.clips[i].saturation,in:0...2)}} else {Text("请先选择片段")}}.font(.caption).padding(.horizontal)}
 var transition:some View{HStack{ForEach(["无","淡化","叠化","黑场","白场","缩放"],id:\.self){x in Button(x){p.transitionName=x}.buttonStyle(.bordered).tint(p.transitionName==x ? QJTheme.accent:.gray)}}.padding(.horizontal)}
 var canvas:some View{HStack{ForEach(CanvasRatio.allCases,id:\.self){r in Button(r.rawValue){p.canvas=r}.buttonStyle(.borderedProminent).tint(p.canvas==r ? QJTheme.accent:.gray)}}.padding(.horizontal)}
 var keyframe:some View{HStack{Button("＋ 添加关键帧"){p.keyframes.append(KeyframeItem(time:p.totalDuration/2))}.buttonStyle(.borderedProminent);Text("位置 / 缩放 / 旋转 / 透明度").font(.caption).foregroundColor(QJTheme.textSecondary)}.padding(.horizontal)}
 func simple(_ title:String,_ items:[String])->some View{VStack(alignment:.leading){Text(title).font(.caption).foregroundColor(QJTheme.textSecondary);ScrollView(.horizontal,showsIndicators:false){HStack{ForEach(items,id:\.self){x in Button(x){}.buttonStyle(.bordered)}}}}.padding(.horizontal)}
}
