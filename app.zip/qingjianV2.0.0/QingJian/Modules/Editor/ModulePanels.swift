import SwiftUI

struct ModulePanel: View {
    @EnvironmentObject var p:EditorProject
    var body: some View {
        VStack(spacing:0) {
            Divider().overlay(Color.white.opacity(0.08))
            Group {
                switch p.selectedModule {
                case .edit: edit
                case .audio: coming("音频", "waveform", ["提取音频","本地音乐","音量","淡入淡出"])
                case .text: text
                case .sticker: coming("贴纸", "face.smiling", ["表情","标记","形状"])
                case .effects: coming("特效", "sparkles", ["画面特效","人物特效","氛围"])
                case .filter: filter
                case .adjust: adjust
                case .transition: transition
                case .canvas: canvas
                case .pip: coming("画中画", "pip", ["添加画中画","混合模式","层级"])
                case .keyframe: keyframe
                case .ai: ai
                }
            }.frame(height:112)
        }
    }

    private var edit:some View {
        toolScroll([
            ("分割","scissors",{p.splitSelected(at:1)}),("复制","plus.square.on.square",{p.duplicateSelected()}),
            ("前移","arrow.left",{p.moveSelected(-1)}),("后移","arrow.right",{p.moveSelected(1)}),
            ("镜像","arrow.left.and.right",{if let i=p.selectedIndex {p.checkpoint();p.clips[i].mirrored.toggle()}}),
            ("旋转","rotate.right",{if let i=p.selectedIndex {p.checkpoint();p.clips[i].rotation += 90}}),
            ("删除","trash",{p.deleteSelected()})
        ])
    }

    private var text:some View {
        VStack(spacing:10) {
            HStack { TextField("输入文字",text:$p.titleText).textFieldStyle(.plain).padding(10).background(QJTheme.surfaceStrong).clipShape(RoundedRectangle(cornerRadius:9))
                Button("添加"){p.texts.append(TextOverlay(text:p.titleText.isEmpty ? "文字":p.titleText))}.font(.subheadline.bold()).foregroundColor(QJTheme.accent) }
            HStack { Text("文字样式").foregroundColor(QJTheme.textSecondary); Spacer(); Text("字体 · 描边 · 背景 · 动画  开发中").foregroundColor(QJTheme.textSecondary) }.font(.caption2)
        }.padding(.horizontal,6)
    }

    private var filter:some View {
        ScrollView(.horizontal,showsIndicators:false){HStack(spacing:14){
            ForEach(["原片","黑白","暖色","冷色","电影","复古"],id:\.self){x in
                Button { p.filterName=x } label:{
                    VStack(spacing:6){RoundedRectangle(cornerRadius:8).fill(filterColor(x)).frame(width:48,height:48).overlay(Image(systemName:"photo").opacity(0.7));Text(x).font(.caption2)}
                        .foregroundColor(p.filterName==x ? QJTheme.accent:.white)
                }.buttonStyle(.plain)
            }
        }.padding(.horizontal,8)}
    }

    private var adjust:some View {
        VStack(spacing:10) {
            if let i=p.selectedIndex {
                control("亮度",value:$p.clips[i].brightness,range:-1...1)
                control("饱和度",value:$p.clips[i].saturation,range:0...2)
            } else { empty("请先选择视频片段") }
        }.padding(.horizontal,6)
    }

    private var transition:some View {
        VStack(spacing:8) {
            if let id=p.selectedTransitionID, let i=p.transitions.firstIndex(where:{$0.id==id}) {
                ScrollView(.horizontal,showsIndicators:false){HStack(spacing:10){
                    ForEach(["无","叠化","淡黑","淡白","推入","缩放"],id:\.self){x in
                        Button { p.setTransition(style:x) } label:{
                            VStack(spacing:5){RoundedRectangle(cornerRadius:8).fill(QJTheme.surfaceStrong).frame(width:48,height:44).overlay(Image(systemName:x=="无" ? "nosign":"bowtie.fill"));Text(x).font(.caption2)}
                                .foregroundColor(p.transitions[i].style==x ? QJTheme.accent:.white)
                        }.buttonStyle(.plain)
                    }
                }}
                HStack{Text("时长").font(.caption2);Slider(value:Binding(get:{p.transitions[i].duration},set:{p.setTransitionDuration($0)}),in:0.2...2.0);Text(String(format:"%.1fs",p.transitions[i].duration)).font(.caption2).monospacedDigit()}
            } else { empty("点击两个视频中间的 ◇ 添加转场") }
        }.padding(.horizontal,6)
    }

    private var canvas:some View {
        ScrollView(.horizontal,showsIndicators:false){HStack(spacing:18){ForEach(CanvasRatio.allCases,id:\.self){x in Button{x == p.canvas ? () : (p.canvas=x)}label:{VStack(spacing:7){Image(systemName:"rectangle").font(.title3);Text(x.rawValue).font(.caption2)}.foregroundColor(p.canvas==x ? QJTheme.accent:.white)}.buttonStyle(.plain)}}.padding(.horizontal,8)}
    }

    private var keyframe:some View {
        VStack(spacing:12) {
            HStack { Image(systemName:"diamond.fill").foregroundColor(QJTheme.accent); Text("基础关键帧"); Spacer(); Text("\(p.keyframes.count) 个").foregroundColor(QJTheme.textSecondary) }
            Button { p.keyframes.append(KeyframeItem(time:p.totalDuration/2)) } label:{Label("在当前时间添加关键帧",systemImage:"plus").font(.subheadline.bold()).frame(maxWidth:.infinity).padding(.vertical,9).background(QJTheme.surfaceStrong).clipShape(RoundedRectangle(cornerRadius:9))}
            Text("位置 / 缩放 / 旋转 / 透明度动画渲染正在完善").font(.caption2).foregroundColor(QJTheme.textSecondary)
        }.padding(.horizontal,8)
    }

    private var ai:some View { coming("AI 创作","wand.and.stars",["AI智能剪辑","自动字幕","AI配音","智能抠像"]) }

    private func coming(_ title:String,_ icon:String,_ items:[String])->some View {
        VStack(alignment:.leading,spacing:9){
            HStack{Image(systemName:icon);Text(title).font(.subheadline.bold());Spacer();Text("开发中").font(.caption2).padding(.horizontal,7).padding(.vertical,3).background(QJTheme.accent.opacity(0.18)).foregroundColor(QJTheme.accent).clipShape(Capsule())}
            ScrollView(.horizontal,showsIndicators:false){HStack(spacing:10){ForEach(items,id:\.self){x in Button{p.message="「\(x)」正在开发中"}label:{VStack(spacing:6){Image(systemName:"sparkles");Text(x).font(.caption2)}.frame(width:74,height:58).background(QJTheme.surface).clipShape(RoundedRectangle(cornerRadius:10))}.buttonStyle(.plain)}}}
        }.padding(.horizontal,8)
    }

    private func toolScroll(_ items:[(String,String,()->Void)])->some View {
        ScrollView(.horizontal,showsIndicators:false){HStack(spacing:14){ForEach(Array(items.enumerated()),id:\.offset){_,x in Button(action:x.2){VStack(spacing:7){Image(systemName:x.1).font(.system(size:20));Text(x.0).font(.caption2)}.frame(width:52,height:64).foregroundColor(x.0=="删除" ? .red:.white)}.buttonStyle(.plain)}}.padding(.horizontal,6)}
    }
    private func control(_ title:String,value:Binding<Double>,range:ClosedRange<Double>)->some View {HStack{Text(title).font(.caption).frame(width:42,alignment:.leading);Slider(value:value,in:range);Text(String(format:"%.0f",value.wrappedValue*100)).font(.caption2).monospacedDigit().frame(width:34)}}
    private func empty(_ text:String)->some View {VStack{Spacer();Text(text).font(.caption).foregroundColor(QJTheme.textSecondary);Spacer()}.frame(maxWidth:.infinity)}
    private func filterColor(_ x:String)->Color { switch x {case "黑白":return .gray;case "暖色":return .orange.opacity(0.55);case "冷色":return .blue.opacity(0.55);case "电影":return .indigo.opacity(0.55);case "复古":return .brown.opacity(0.55);default:return QJTheme.surfaceStrong} }
}
