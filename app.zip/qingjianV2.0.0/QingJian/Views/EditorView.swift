import SwiftUI

struct EditorView: View {
 @EnvironmentObject var p:EditorProject; @Environment(\.dismiss) var dismiss
 @State private var showPicker=false; @State private var showExport=false; @State private var playing=false
 var body:some View{ZStack{QJTheme.background.ignoresSafeArea();VStack(spacing:8){
  HStack{Button{dismiss()}{Image(systemName:"chevron.left")};Spacer();VStack(spacing:1){Text("轻剪").font(.headline);Text(p.projectName).font(.caption2).foregroundColor(QJTheme.textSecondary)};Spacer();Button("导出"){showExport=true}.font(.subheadline.bold()).padding(.horizontal,14).padding(.vertical,7).background(QJTheme.accent).clipShape(Capsule())}
  ZStack{Color.black;PlayerView(url:p.selectedIndex.map{p.clips[$0].url});if !p.titleText.isEmpty{Text(p.titleText).font(.title2.bold()).shadow(radius:4).padding()}}.aspectRatio(p.canvas.value,contentMode:.fit).clipShape(RoundedRectangle(cornerRadius:10)).frame(maxHeight:360)
  HStack{Spacer();Button{playing.toggle()}{Image(systemName:playing ? "pause.fill":"play.fill")};Text(String(format:"00:00 / %02d:%02d",Int(p.totalDuration)/60,Int(p.totalDuration)%60)).font(.caption).monospacedDigit();Spacer()}
  TimelineView().frame(maxHeight:125)
  ModulePanel()
  ScrollView(.horizontal,showsIndicators:false){HStack(spacing:5){QJToolButton(title:"添加",icon:"plus.circle"){showPicker=true};ForEach(QJModuleRegistry.editorModules){m in QJToolButton(title:m.title,icon:m.icon,active:p.selectedModule==m.id){if m.enabled{p.selectedModule=m.id}else{p.message="AI 模块接口已预留，当前版本默认关闭，不影响本地剪辑。"}}}}.padding(.horizontal)}.frame(height:60).background(Color.black.opacity(0.35))
 }.padding(.horizontal,10).foregroundColor(.white)}
 .statusBar(hidden:true).sheet(isPresented:$showPicker){LegacyMediaPicker{urls in Task{for u in urls{await p.add(url:u)}}}}.fullScreenCover(isPresented:$showExport){ExportView()}.alert("提示",isPresented:Binding(get:{p.message != nil},set:{if !$0{p.message=nil}})){Button("好"){p.message=nil}}message:{Text(p.message ?? "")}
 }
}
