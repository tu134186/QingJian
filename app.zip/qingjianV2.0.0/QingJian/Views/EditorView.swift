import SwiftUI

struct EditorView: View {
    @EnvironmentObject private var project:EditorProject
    @Environment(\.dismiss) private var dismiss
    @State private var showPicker=false
    @State private var showExport=false
    @State private var playing=false

    var body:some View {
        ZStack {
            QJTheme.background.ignoresSafeArea()
            VStack(spacing:0) {
                topBar.padding(.horizontal,14).frame(height:46)
                preview.padding(.horizontal,12).padding(.top,5)
                playback.frame(height:42)
                TimelineView().padding(.horizontal,10)
                Spacer(minLength:5)
                ModulePanel().padding(.horizontal,8)
                mainTools
            }.foregroundColor(.white)
        }
        .statusBar(hidden:true)
        .sheet(isPresented:$showPicker){LegacyMediaPicker{urls in Task{for u in urls{await project.add(url:u)}}}}
        .fullScreenCover(isPresented:$showExport){ExportView()}
        .alert("轻剪",isPresented:messagePresented){Button("知道了"){project.message=nil}}message:{Text(project.message ?? "")}
    }

    private var topBar:some View {
        HStack(spacing:12) {
            Button{dismiss()}label:{Image(systemName:"chevron.left").font(.system(size:17,weight:.semibold)).frame(width:32,height:32)}
            Spacer()
            Text(project.projectName).font(.subheadline.weight(.semibold)).lineLimit(1)
            Spacer()
            Button{ if project.clips.isEmpty {project.message="请先添加视频"} else {showExport=true} }label:{Text("导出").font(.subheadline.bold()).padding(.horizontal,16).padding(.vertical,7).background(QJTheme.accent).clipShape(Capsule())}
        }
    }

    private var preview:some View {
        ZStack {
            Color.black
            PlayerView(url:project.selectedIndex.map{project.clips[$0].url})
            if project.clips.isEmpty {
                VStack(spacing:10){Image(systemName:"film.stack").font(.system(size:34)).foregroundColor(.white.opacity(0.35));Text("添加视频开始创作").font(.caption).foregroundColor(QJTheme.textSecondary)}
            }
            if !project.titleText.isEmpty {Text(project.titleText).font(.title3.bold()).shadow(radius:4).padding()}
        }
        .aspectRatio(project.canvas.value,contentMode:.fit).frame(maxHeight:300)
        .clipShape(RoundedRectangle(cornerRadius:8))
    }

    private var playback:some View {
        HStack {
            Text("00:00.0").font(.caption2).monospacedDigit().foregroundColor(QJTheme.textSecondary)
            Spacer()
            Button{playing.toggle()}label:{Image(systemName:playing ? "pause.fill":"play.fill").font(.system(size:18)).frame(width:42,height:34)}
            Spacer()
            Text(total).font(.caption2).monospacedDigit().foregroundColor(QJTheme.textSecondary)
        }.padding(.horizontal,16)
    }

    private var mainTools:some View {
        VStack(spacing:0) {
            Divider().overlay(Color.white.opacity(0.08))
            ScrollView(.horizontal,showsIndicators:false) {
                HStack(spacing:12) {
                    QJToolButton(title:"添加",icon:"plus"){showPicker=true}
                    ForEach(QJModuleRegistry.editorModules){m in
                        QJToolButton(title:m.title,icon:m.icon,active:project.selectedModule==m.id){project.selectedModule=m.id}
                    }
                }.padding(.horizontal,10)
            }.frame(height:68).background(Color.black.opacity(0.18))
        }
    }

    private var total:String {String(format:"%02d:%02d.%01d",Int(project.totalDuration)/60,Int(project.totalDuration)%60,Int((project.totalDuration-floor(project.totalDuration))*10))}
    private var messagePresented:Binding<Bool>{Binding(get:{project.message != nil},set:{if !$0{project.message=nil}})}
}
