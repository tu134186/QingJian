import SwiftUI

struct EditorView: View {
    @EnvironmentObject private var project: EditorProject
    @Environment(\.dismiss) private var dismiss

    @State private var showPicker = false
    @State private var showExport = false
    @State private var playing = false

    var body: some View {
        ZStack {
            QJTheme.background.ignoresSafeArea()

            VStack(spacing: 8) {
                navigationBar
                preview
                playbackBar
                TimelineView().frame(maxHeight: 125)
                ModulePanel()
                toolBar
            }
            .padding(.horizontal, 10)
            .foregroundColor(.white)
        }
        .statusBar(hidden: true)
        .sheet(isPresented: $showPicker) {
            LegacyMediaPicker { urls in
                Task {
                    for url in urls {
                        await project.add(url: url)
                    }
                }
            }
        }
        .fullScreenCover(isPresented: $showExport) {
            ExportView()
        }
        .alert("提示", isPresented: messagePresented) {
            Button("好") { project.message = nil }
        } message: {
            Text(project.message ?? "")
        }
    }

    private var navigationBar: some View {
        HStack {
            Button(action: { dismiss() }) {
                Image(systemName: "chevron.left")
            }
            Spacer()
            VStack(spacing: 1) {
                Text("轻剪").font(.headline)
                Text(project.projectName)
                    .font(.caption2)
                    .foregroundColor(QJTheme.textSecondary)
            }
            Spacer()
            Button("导出") { showExport = true }
                .font(.subheadline.bold())
                .padding(.horizontal, 14)
                .padding(.vertical, 7)
                .background(QJTheme.accent)
                .clipShape(Capsule())
        }
    }

    private var preview: some View {
        ZStack {
            Color.black
            PlayerView(url: project.selectedIndex.map { project.clips[$0].url })
            if !project.titleText.isEmpty {
                Text(project.titleText)
                    .font(.title2.bold())
                    .shadow(radius: 4)
                    .padding()
            }
        }
        .aspectRatio(project.canvas.value, contentMode: .fit)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .frame(maxHeight: 360)
    }

    private var playbackBar: some View {
        HStack {
            Spacer()
            Button(action: { playing.toggle() }) {
                Image(systemName: playing ? "pause.fill" : "play.fill")
            }
            Text(durationText)
                .font(.caption)
                .monospacedDigit()
            Spacer()
        }
    }

    private var toolBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 5) {
                QJToolButton(title: "添加", icon: "plus.circle") {
                    showPicker = true
                }
                ForEach(QJModuleRegistry.editorModules) { module in
                    QJToolButton(
                        title: module.title,
                        icon: module.icon,
                        active: project.selectedModule == module.id
                    ) {
                        if module.enabled {
                            project.selectedModule = module.id
                        } else {
                            project.message = "AI 模块接口已预留，当前版本默认关闭，不影响本地剪辑。"
                        }
                    }
                }
            }
            .padding(.horizontal)
        }
        .frame(height: 60)
        .background(Color.black.opacity(0.35))
    }

    private var durationText: String {
        String(format: "00:00 / %02d:%02d", Int(project.totalDuration) / 60, Int(project.totalDuration) % 60)
    }

    private var messagePresented: Binding<Bool> {
        Binding(
            get: { project.message != nil },
            set: { newValue in if !newValue { project.message = nil } }
        )
    }
}
