import SwiftUI
import AVKit
struct PlayerView: View {
    let url: URL?
    @State private var player=AVPlayer()
    var body: some View { VideoPlayer(player:player).onAppear{reload()}.onChange(of:url){_ in reload()} }
    private func reload(){ player.pause(); if let url { player.replaceCurrentItem(with:AVPlayerItem(url:url)) } else { player.replaceCurrentItem(with:nil) } }
}
