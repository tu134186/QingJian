import Foundation

enum QJModuleID: String, CaseIterable, Codable {
    case edit, audio, text, sticker, effects, filter, adjust, transition, canvas, pip, keyframe, ai
}
struct QJModuleDescriptor: Identifiable { let id: QJModuleID; let title: String; let icon: String; let enabled: Bool }
enum QJModuleRegistry {
    static let editorModules: [QJModuleDescriptor] = [
        .init(id:.edit,title:"剪辑",icon:"scissors",enabled:true), .init(id:.audio,title:"音频",icon:"music.note",enabled:true),
        .init(id:.text,title:"文字",icon:"textformat",enabled:true), .init(id:.sticker,title:"贴纸",icon:"face.smiling",enabled:true),
        .init(id:.effects,title:"特效",icon:"sparkles",enabled:true), .init(id:.filter,title:"滤镜",icon:"camera.filters",enabled:true),
        .init(id:.adjust,title:"调节",icon:"slider.horizontal.3",enabled:true), .init(id:.transition,title:"转场",icon:"rectangle.2.swap",enabled:true),
        .init(id:.canvas,title:"画布",icon:"aspectratio",enabled:true), .init(id:.pip,title:"画中画",icon:"pip",enabled:true),
        .init(id:.keyframe,title:"关键帧",icon:"diamond",enabled:true), .init(id:.ai,title:"AI",icon:"wand.and.stars",enabled:true)
    ]
}
