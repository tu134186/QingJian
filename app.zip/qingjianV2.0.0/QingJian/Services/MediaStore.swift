import Foundation

enum MediaStore {
    static func copyVideo(data: Data, ext: String = "mov") throws -> URL {
        let dir = FileManager.default.urls(for:.cachesDirectory,in:.userDomainMask)[0].appendingPathComponent("QingJianMedia",isDirectory:true)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        let url=dir.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
        try data.write(to:url,options:.atomic); return url
    }
}
