import AVFoundation
import UIKit

struct Exporter {
    static func export(
        clips: [ClipItem],
        text: String,
        fps: Int = 30,
        progress: @escaping (Double) -> Void = { _ in }
    ) async throws -> URL {
        guard !clips.isEmpty else {
            throw NSError(domain: "QingJian", code: 2, userInfo: [NSLocalizedDescriptionKey: "请先添加视频"])
        }

        let composition = AVMutableComposition()
        guard let videoTrack = composition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid
        ) else {
            throw NSError(domain: "QingJian", code: 3)
        }
        let audioTrack = composition.addMutableTrack(
            withMediaType: .audio,
            preferredTrackID: kCMPersistentTrackID_Invalid
        )

        var cursor = CMTime.zero
        var instructions: [AVMutableVideoCompositionInstruction] = []
        var renderSize = CGSize(width: 1080, height: 1920)

        for clip in clips {
            let asset = AVURLAsset(url: clip.url)
            guard let sourceVideo = try await asset.loadTracks(withMediaType: .video).first else { continue }

            let range = CMTimeRange(
                start: CMTime(seconds: clip.start, preferredTimescale: 600),
                end: CMTime(seconds: clip.end, preferredTimescale: 600)
            )
            let scaledDuration = CMTimeMultiplyByFloat64(range.duration, multiplier: 1 / Double(clip.rate))

            try videoTrack.insertTimeRange(range, of: sourceVideo, at: cursor)
            videoTrack.scaleTimeRange(
                CMTimeRange(start: cursor, duration: range.duration),
                toDuration: scaledDuration
            )

            if let sourceAudio = try await asset.loadTracks(withMediaType: .audio).first,
               let audioTrack {
                try? audioTrack.insertTimeRange(range, of: sourceAudio, at: cursor)
                audioTrack.scaleTimeRange(
                    CMTimeRange(start: cursor, duration: range.duration),
                    toDuration: scaledDuration
                )
            }

            let naturalSize = try await sourceVideo.load(.naturalSize)
            let preferredTransform = try await sourceVideo.load(.preferredTransform)
            let transformedRect = CGRect(origin: .zero, size: naturalSize).applying(preferredTransform)
            let sourceSize = CGSize(width: abs(transformedRect.width), height: abs(transformedRect.height))
            if cursor == .zero { renderSize = sourceSize }

            let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack)
            layerInstruction.setTransform(preferredTransform, at: cursor)
            let instruction = AVMutableVideoCompositionInstruction()
            instruction.timeRange = CMTimeRange(start: cursor, duration: scaledDuration)
            instruction.layerInstructions = [layerInstruction]
            instructions.append(instruction)
            cursor = cursor + scaledDuration
        }

        let videoComposition = AVMutableVideoComposition()
        videoComposition.instructions = instructions
        videoComposition.renderSize = renderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: CMTimeScale(fps))

        if !text.isEmpty {
            let parentLayer = CALayer()
            let videoLayer = CALayer()
            parentLayer.frame = CGRect(origin: .zero, size: renderSize)
            videoLayer.frame = parentLayer.frame
            parentLayer.addSublayer(videoLayer)

            let label = CATextLayer()
            label.string = text
            label.alignmentMode = .center
            label.foregroundColor = UIColor.white.cgColor
            label.fontSize = max(32, renderSize.width / 22)
            label.contentsScale = 2.0
            label.frame = CGRect(x: 40, y: 80, width: renderSize.width - 80, height: 100)
            parentLayer.addSublayer(label)
            videoComposition.animationTool = AVVideoCompositionCoreAnimationTool(
                postProcessingAsVideoLayer: videoLayer,
                in: parentLayer
            )
        }

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("QingJian-\(UUID().uuidString).mp4")
        guard let session = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
            throw NSError(domain: "QingJian", code: 4)
        }
        session.outputURL = outputURL
        session.outputFileType = .mp4
        session.videoComposition = videoComposition
        session.shouldOptimizeForNetworkUse = true

        let monitor = Task {
            while !Task.isCancelled {
                let status = session.status
                if status != .waiting && status != .exporting { break }
                progress(Double(session.progress))
                try? await Task.sleep(nanoseconds: 150_000_000)
            }
        }

        await session.export()
        monitor.cancel()
        progress(1)

        if let error = session.error { throw error }
        guard session.status == .completed else {
            throw NSError(domain: "QingJian", code: 5, userInfo: [NSLocalizedDescriptionKey: "导出未完成"])
        }
        return outputURL
    }
}
