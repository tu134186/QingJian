import SwiftUI

enum QJTheme {
    static let background = Color(red: 0.035, green: 0.039, blue: 0.047)
    static let surface = Color.white.opacity(0.075)
    static let surfaceStrong = Color.white.opacity(0.12)
    static let accent = Color(red: 0.20, green: 0.56, blue: 1.0)
    static let textSecondary = Color.white.opacity(0.62)
    static let radius: CGFloat = 14
    static let spacing: CGFloat = 12
}

struct QJToolButton: View {
    let title: String; let icon: String; var active = false; let action: () -> Void
    var body: some View { Button(action: action) { VStack(spacing: 6) { Image(systemName: icon).font(.system(size: 19, weight: .medium)); Text(title).font(.caption2).lineLimit(1) }.foregroundColor(active ? QJTheme.accent : .white).frame(minWidth: 54, minHeight: 50) }.buttonStyle(.plain) }
}

struct QJSectionCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View { content.padding(12).background(QJTheme.surface).clipShape(RoundedRectangle(cornerRadius: QJTheme.radius, style: .continuous)) }
}
