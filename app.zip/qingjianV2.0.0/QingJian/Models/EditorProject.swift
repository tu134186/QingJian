import SwiftUI
import AVFoundation

struct ClipItem: Identifiable, Equatable {
    var id = UUID(); var url: URL; var duration: Double; var start: Double = 0; var end: Double
    var volume: Float = 1; var rate: Float = 1; var rotation: Double = 0; var mirrored = false
    var brightness: Double = 0; var contrast: Double = 1; var saturation: Double = 1
}
struct TextOverlay: Identifiable, Equatable { var id=UUID(); var text="文字"; var start=0.0; var duration=3.0; var scale=1.0; var opacity=1.0 }
struct AudioItem: Identifiable, Equatable { var id=UUID(); var url:URL; var start=0.0; var volume:Float=1 }
struct KeyframeItem: Identifiable, Equatable { var id=UUID(); var time=0.0; var scale=1.0; var rotation=0.0; var opacity=1.0 }

enum CanvasRatio: String, CaseIterable { case vertical="9:16", horizontal="16:9", square="1:1", classic="4:3", portrait="3:4"; var value:CGFloat { switch self { case .vertical:return 9/16; case .horizontal:return 16/9; case .square:return 1; case .classic:return 4/3; case .portrait:return 3/4 } } }

@MainActor final class EditorProject: ObservableObject {
    @Published var clips:[ClipItem]=[]; @Published var selectedID:UUID?; @Published var texts:[TextOverlay]=[]; @Published var audios:[AudioItem]=[]; @Published var keyframes:[KeyframeItem]=[]
    @Published var titleText=""; @Published var canvas:CanvasRatio = .vertical; @Published var isExporting=false; @Published var progress=0.0; @Published var message:String?; @Published var selectedModule:QJModuleID = .edit
    @Published var filterName="原片"; @Published var transitionName="无"; @Published var projectName="未命名草稿"; @Published var updatedAt=Date()
    private var undoStack:[[ClipItem]]=[]; private var redoStack:[[ClipItem]]=[]
    var selectedIndex:Int? { clips.firstIndex{$0.id==selectedID} }; var totalDuration:Double { clips.reduce(0){$0+max(0,($1.end-$1.start)/Double($1.rate))} }
    func checkpoint(){ undoStack.append(clips); if undoStack.count>40{undoStack.removeFirst()}; redoStack.removeAll(); updatedAt=Date() }
    func undo(){guard let s=undoStack.popLast() else{return}; redoStack.append(clips); clips=s; selectedID=clips.first?.id}
    func redo(){guard let s=redoStack.popLast() else{return}; undoStack.append(clips); clips=s; selectedID=clips.first?.id}
    func add(url:URL) async { let a=AVURLAsset(url:url); do { let d=try await a.load(.duration).seconds; guard d.isFinite && d>0 else{return}; checkpoint(); let c=ClipItem(url:url,duration:d,end:d); clips.append(c); selectedID=c.id } catch { message="读取视频失败：\(error.localizedDescription)" } }
    func deleteSelected(){guard let i=selectedIndex else{return};checkpoint();clips.remove(at:i);selectedID=clips.first?.id}
    func duplicateSelected(){guard let i=selectedIndex else{return};checkpoint();var c=clips[i];c.id=UUID();clips.insert(c,at:i+1);selectedID=c.id}
    func splitSelected(at seconds:Double){guard let i=selectedIndex else{return};let c=clips[i],p=min(max(c.start+seconds*Double(c.rate),c.start+0.1),c.end-0.1);guard p>c.start,p<c.end else{return};checkpoint();var a=c,b=c;a.id=UUID();b.id=UUID();a.end=p;b.start=p;clips.remove(at:i);clips.insert(contentsOf:[a,b],at:i);selectedID=b.id}
    func moveSelected(_ d:Int){guard let i=selectedIndex else{return};let j=i+d;guard clips.indices.contains(j) else{return};checkpoint();clips.swapAt(i,j)}
}
