# 已知踩坑

## TrollStore 303
曾出现 `Unable to locate main binary inside app bundle`。IPA 内实际存在 arm64 主程序，根因是 Info.plist 缺 `CFBundleExecutable`。
必须保留：
- `CFBundleExecutable = $(EXECUTABLE_NAME)`
- `CFBundlePackageType = APPL`
- `PRODUCT_NAME = QingJian`
- `EXECUTABLE_NAME = QingJian`

## PhotosPicker / 最低系统
V1 使用 SwiftUI `PhotosPicker` 会把实现绑到较新系统。V2 为 iOS 15 使用 `PHPickerViewController` 包装层。不要为了选择素材把最低系统抬高。

## SwiftUI type-check
巨大 `body` 曾触发 compiler unable to type-check。页面必须拆成小 View/模块，不要把所有表达式塞一个 body。

## Workflow
V4 GitHub Actions 已验证可以 Xcode 编译、寻找 .app、打包 Payload、验证主程序、上传 IPA 和失败日志。没有 workflow 证据时不要重写。

## 导出
预览与最终导出应分离。最终视频使用 AVFoundation；保存相册使用 PhotoKit，并处理授权失败。
