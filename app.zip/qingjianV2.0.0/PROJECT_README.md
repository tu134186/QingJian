# 轻剪 QingJian V2.0.0

这是轻剪从功能验证版进入正式产品架构的基线。目标：本地优先、模块化、统一 UI、最低 iOS 15.0、同时保留 TrollStore 测试与未来 App Store 正式发布能力。

## 接手顺序
任何 AI/开发者修改前必须依次阅读：`AI_DEVELOPMENT_RULES.md` → `ARCHITECTURE.md` → `KNOWN_PITFALLS.md` → `DESIGN_SYSTEM.md` → `RELEASE_CHECKLIST.md` → `CHANGELOG.md`。

## 固定身份
- App：轻剪 / QingJian
- Bundle ID：`com.tu.qingjian`
- 当前版本：2.0.0 (Build 200)
- Deployment Target：iOS 15.0
- 当前重点真机：iOS 16.5（测试环境，不是最低系统）
- 构建：XcodeGen + GitHub Actions

## V2 方向
多轨时间轴、非破坏性编辑、模块注册、撤销/重做、画中画/关键帧架构、滤镜/特效/转场/调节、正式导出页、真实导出进度、自动保存相册、AppIcon、统一 Design System、AI 可插拔接口。
