# Build1062 · Codemagic Official Artifact Rebuild

- 移除 Codemagic publishing 阶段自制 Git Artifact Return Bridge；不再 git push 产物回 GitHub。
- Codemagic `artifacts:` 成为唯一云端产物发布源：IPA、DEB、compile.log、compile-errors.txt、task manifest。
- App 端只按当前 Codemagic Build ID 查询并下载官方 Artifact；手动“重抓产物”也只读取原 Build ID，不创建新 Build。
- 修复 v3 Artifact 解析把 `.deb` 硬编码成 `ipa` 的类型错误。
- 保留 IPA/DEB 真实编译命令、首页、中央素材、六大功能和任务黑匣子。
- 目标：同一 Build ID 内产物和日志天然隔离，不再通过 GitHub 中转，不再出现 403 回传把任务染红。
