# V2.9.47 · Build 98：iOS 16.5 SwiftUI 泛型元数据启动崩溃

特征：EXC_BAD_ACCESS、STACK GUARD、libswiftCore `_gatherGenericParameterCounts` / `decodeMangledType`、AttributeGraph `LayoutDescriptor`。根因类别：首屏 SwiftUI 泛型类型树过深。处理：禁止继续往 ContentView 首屏直接嵌入重型泛型 NavigationLink destination；使用独立 View + AnyView 类型擦除隔离。

# V2.9.46 · Build 97 · 真实根因诊断强化（2026-09-05）

- 依据 Build96 Codemagic `compile-errors.txt` 真实失败，删除 Bitrise/Codemagic 停止接口重复声明。
- 诊断 TXT 新增“自动根因提炼”：首要根因、真实错误数、级联错误数、Warning、文件与行号。
- 编译错误解析增加去重，质量中心突出首错，避免把级联 `3 failures` 当成三个独立 Bug。
- 新增“云编译 API 禁止重复声明”回归规则；保留 Build96 APP 内云编译控制台和 Build79 iOS 16.5 启动安全边界。

# V2.9.45 · Build 96

## 云编译控制台新增风险防线
- 停止云端任务后不能立即把本机 busy 清零，否则用户可能在远端仍停止中的几秒内启动第二个构建；Build96 改为等待下一次远端状态轮询确认。
- Codemagic 取消接口采用 `/builds/:id/cancel`；已结束任务可能返回 208，按已完成处理。
- Bitrise 停止接口采用 `/apps/{app-slug}/builds/{build-slug}/abort`。
- 平台详情链接只用于异常排错，不作为日常编译路径。

# V2.9.44 · Build 95

新增工程经验：云端“分钟用完/额度限制/付款预算/认证/服务网络”属于平台失败，允许自动调度切换备用平台；只有带真实 Xcode/Swift/Theos 证据的源码错误才停止跨平台重试。Codemagic 分钟耗尽时优先转 Bitrise，避免把平台额度问题误当源码 Bug。

# V2.9.43 · Build 94

## UI 回归：中央状态圆覆盖四宫格文字
- 现象：右上“AI 编译·自动”左侧文字被中央 128pt 圆形遮挡；动态标题较长时更明显。
- 根因：四宫格内容默认居中，而中央视觉层覆盖两列内侧区域，按钮内容没有中央安全边距。
- 修复：四个槽位统一向外偏移 28pt，并增加单行/最小缩放保护；按钮和中央圆尺寸不变。
- 回归要求：四个按钮任一动态标题都不得进入中央圆覆盖区；中间视觉层继续 `allowsHitTesting(false)`，不得抢占按钮点击。

# V2.9.42 · Build 93

开发闭环继续坚持“真实 Xcode 错误优先”：平台失败不得触发源码 AI 修复；高风险 Patch 必须进入 Diff 审核。

# V2.9.41 · Build 92 — AI 修改安全门补充

## 新增防线
AI 结构化 RepairPatch 即使自身 `risk=low` 且置信度 >=80%，只要命中 ContentView、BuildMateApp、Info.plist、project.yml、GitHubService、Codemagic 或 DeepTakeover 关键路径，就停止自动写入并转“待审核”任务。

## 原因
这些文件曾直接影响 iOS 16.5 首屏稳定、云编译链、版本生成或深度接管状态，不能只依赖模型自报风险等级。

# V2.9.40 · Build 91 — 连接与 UI 兼容补充

- iOS 16.5 对部分较新的 SF Symbol 可能无法正常显示；设置页关键图标优先使用已验证兼容符号，例如 `checkmark.shield.fill`。
- 自动调度 UI 不应写死 GitHub；平台名称应在真正选择/运行后再显示。

# Build90 新增自动诊断规则

- Codemagic 构建失败且无 IPA：优先在 Artifact 中寻找 `compile-errors.txt`、`build-result.txt`、`compile.log`。
- 标准 Swift 错误格式 `*.swift:line:column: error:` 会解析为真实错误，不把 `status code 65` 或 `CompileSwift failed` 连带结论当作多个独立 Bug。
- 平台额度/付款/Runner/认证错误仍归平台类，不允许自动 AI 改源码。
- IPA 产物必须通过 >100KB、PK/ZIP 文件头和 SHA-256 基础验证。

## V2.9.38 · Build 89 · 真实 Xcode 错误定点修复（2026-09-05）

### 已验证真实错误：顶部 UI 引用未声明分支变量

- 证据：Codemagic Build88 artifacts / `src/compile-errors.txt`。
- Xcode 16.4：`ContentView.swift:735:54: error: cannot find 'branch' in scope`。
- 错误代码：`Text(repo.isEmpty ? "未选项目" : branch)`。
- 根因：Build87 顶部轻量化 UI 新增状态栏时直接引用了当前 `ContentView` 不存在的 `branch` 状态。
- 修复：新增 `heroBranchLabel`，从 `savedProjects` 当前项目记录读取 branch；若暂无记录则从 `repoState` 读取；最终回退 `main`。
- 同一日志中的 `DeepTakeoverModels.swift:210` 为 warning：`no async operations occur within await expression`，Build89 同步移除无效 `await`。
- 教训：Codemagic 页面显示 `(3 failures)` 不等于 3 个独立源码 Bug；应优先读取 `compile-errors.txt` 的第一条 `error:`。

## V2.9.37 · Build 88 · 顶部 UI Xcode 兼容修复（2026-09-05）

- 依据 Codemagic Build87 真实 Xcode 16.4 编译失败，对首页顶部轻量化 UI 做兼容性定点修复。
- 三处条件颜色改为显式 `Color.primary` / `Color.secondary`，避免 SwiftUI 泛型/ShapeStyle 重载推断歧义。
- 状态点背景描边改为 `Color(uiColor: .systemBackground)`，明确 UIKit/SwiftUI 颜色桥接。
- 保留 Build87 顶部轻量布局以及 Build86 智能编译中枢、多云调度、AI 修复和源码保险箱。

## V2.9.36 · Build 87 · 首页顶部轻量化 UI（2026-09-05）

- 工作台顶部从四个独立状态胶囊改为单条轻量状态栏，解决 iPhone 窄屏拥挤、断行与信息密度过高。
- 状态栏只展示当前分支、云编译调度和 AI 就绪状态；最新 Run 编号移动到项目卡副标题。
- BuildMate 图标增加状态点，连接就绪时为绿色，未就绪时为灰色。
- 保留 Build86 智能编译中枢、多云调度、AI 修复、源码保险箱与 Build79 iOS 16.5 首屏安全结构。
- 本版为 UI 信息架构调整，不改编译/AI 核心逻辑。

## V2.9.35 · Build 86 · 智能编译中枢（2026-09-05）

- 自动调度升级为真实故障切换：Codemagic → Bitrise → GitHub 按配置与本机健康状态选择；平台额度/付款/认证/网络/Runner/未知平台异常可切备用平台，真实源码编译错误禁止跨平台盲目重跑。
- 新增平台健康记录与 30 分钟冷却，设置 → 智能编译中枢可查看最近成功/失败并手动清除冷却。
- 新增源码保险箱：本地体检通过后自动复制当前源码 ZIP 到 BuildMate Documents，按 SHA-256 去重，最多保留 6 份；AI Repair 启动前也补建恢复点，并支持一键恢复为待编译源码。
- 新增本机错误经验库：记录 Provider、错误分类、摘要；同 Provider 后续成功后自动标记最近失败为“已恢复”。
- 智能省额度页升级为“智能编译中枢”，整合五段流水线、平台健康、统计、恢复点、错误经验、源码指纹与重复源码强制开关。
- 版本发布门继续由 Linux Preflight + `scripts/check_release_version.py` 承担；预检通过不等于 Xcode 成功。
- 保持 Build79 iOS 16.5 启动稳定边界：首屏仍不加载 Codemagic/Bitrise Token、恢复点或健康数据库。

## V2.9.34 · Build 85 · SwiftUI State 声明编译修复（2026-09-05)

- 依据 Codemagic Build84 的真实 Xcode 16.4 日志继续修复 3 个编译失败。
- 根因：CloudCompilerSettingsView 将多个 `@State` 属性写在同一条逗号声明中；Swift 属性包装器只能绑定单个变量，Xcode 因此产生 3 个 failure，并进一步提示 `self is immutable / mark method mutating`。
- 修复：Codemagic、Bitrise、自托管 Mac、loaded/checking 等所有状态拆成独立 `@State` 声明，不改变现有 UI、Keychain、API 调度逻辑。
- 保留 Build79 的 iOS 16.5 启动安全结构与 Build83/84 多云调度架构。

## V2.9.33 · Build 84 · 多云设置编译修复（2026-09-05）
- 修复 Build83 在 Xcode 16.4 中的 3 个真实编译错误：同步 Button action 闭包中错误使用 `await saveCM()` / `await saveBR()` / `await saveSH()`。
- 三个保存/连接测试函数内部原本就通过 `Task` 异步执行，因此移除外层 `await` 不改变网络测试逻辑，也不会阻塞 UI。
- 完整保留 Build83 多云调度中心、Build82 本地源码深度体检、Build81 Codemagic 工作流自维护及 Build79 iOS 16.5 启动稳定结构。


## V2.9.32 · Build 83 · 多云编译调度中心（2026-09-05）
- 新增自动调度、Bitrise REST API 编译闭环、自托管 Mac 配置/检测适配层；GitLab macOS 预留。
- 多云设置继续独立于 ContentView 首屏，保持 iOS 16.5 启动安全边界。
- 保留 GitHub/Codemagic、AI Patch、深度工作台、本地/Linux 预检和源码指纹链。

## V2.9.31 · Build 82 — 本地源码深度体检
- 本地预检新增 ZIP Central Directory 解析，不解压、不联网即可读取源码文件清单。
- 上传前检查 ZIP 根目录 project.yml/project.yaml、BuildMate/、Swift 源码与 BuildMate/Info.plist；自动拦截“多包一层目录”等高频错误。
- 开发文档完整性给出提示，保留 SHA-256/重复源码拦截；同一 SHA 在不同云平台的历史记录 ID 已去冲突。
- 保留 Build81 Codemagic 工作流自维护、Build80 智能省额度、Build79 iOS 16.5 启动结构修复。

## V2.9.29 · Build 80：无效正式编译与额度/计费错误混淆

**问题**：相同源码可以被重复派发 macOS；简单 ZIP/结构/版本/Swift 语法问题也要等到昂贵正式 Runner 才发现；GitHub 额度/付款/Runner 未启动类错误容易被错误归入“源码编译失败”。

**固定方案**：本地 SHA-256 指纹门 → GitHub Linux Preflight → macOS/Xcode；相同源码成功/失败默认拦截，仅允许一次性强制重跑。AI Patch 每轮同样先走 Linux 修复预检。

**分类原则**：源码 `error:` 与平台额度、billing/payment/spending limit、Runner 未启动、网络超时必须分开记录。Linux 预检只代表静态/结构门通过，不得宣称等价于真实 Xcode 编译。

## V2.9.28 · Build 79：Build77 iOS 16.5 启动主线程 SwiftUI/AttributeGraph 崩溃

**实机证据**：`BuildMate-2026-09-05-073429.000`，版本 2.9.26 Build77；启动约 0.23 秒后主线程 `EXC_BAD_ACCESS / SIGSEGV / KERN_PROTECTION_FAILURE`。

**调用栈特征**：大量 Swift Runtime `resolveOpaqueType / decodeMangledType`，随后进入 SwiftUI/AttributeGraph 类型布局访问；与“点图标后白屏/轻微阴影、首屏未完整出现即退出”一致。

**修复策略**：不再只延迟 Keychain。把 Build77 新增的 Codemagic 设置 UI、状态与持久化完全拆出巨型 `ContentView`；首屏只保留轻量平台枚举，Codemagic 配置在设置页/实际动作时才加载。

**验证标准**：Build79 安装后必须先通过冷启动：首页完整出现且不闪退；通过后再测试设置 → 云编译平台与 Codemagic 编译。若仍闪退，获取 Build79 新 `.ips` 并对比 Thread 0。

## V2.9.27 · Build 78：Build77 启动白屏后闪退

**现象**：TrollStore 安装成功，点击 BuildMate 后约 1 秒无完整 UI，仅白屏/轻微阴影后退出。

**当前处置**：先隔离 Build77 新增的 Codemagic 冷启动配置读取。Codemagic Keychain/UserDefaults 改为进入云编译设置或明确启动 Codemagic 操作时再读取。

**注意**：当前没有系统 crash log，因此这是基于 Build76/Build77 差异做的最小风险隔离，不把原因写死为已证实。若 Build78 仍闪退，必须取得 crash log 后继续。

## 2026-09-04：真实编译失败但 BUG 报告没有原始 error
**现象**：报告只出现某个源码片段或文件末尾，没有 Xcode/Theos 的真实 `error:`。

**根因**：GitHub Actions bash 的 errexit 会在 `xcodebuild | tee` / `make | tee` 非 0 时提前结束 step，导致后续 `PIPESTATUS` 和 `compile-errors.txt` 逻辑未执行。

**固定方案**：失败可能发生的 pipeline 前使用 `set +e`，立即保存 `PIPESTATUS[0]`，再恢复 `set -e`；之后提取错误上下文并用原状态码退出。报告生成阶段必须以 `compile.log` 作为最终兜底。

---

## V2.7.8 / Build 40（2026年9月3日）

- 修复现有空仓库没有 `main`/默认分支时，BuildMate 只重试却永远 404 的问题。
- 初始化阶段先调用 GitHub Contents API 写入 `README.md`，产生第一个 commit，再等待默认分支并部署 Workflow。
- 新建仓库继续使用 `auto_init: true`；对旧版本遗留的空仓库自动补初始化。
- 若同名仓库已存在但 Fine-grained Token 的 Repository access 未包含它，GitHub 可能“读取 404、创建 422”。现在会明确提示改为 All repositories 或把仓库加入允许列表，并开启 Contents / Workflows Read and write。
- 编译、AI 修复、Artifact 下载核心逻辑未改。

## V2.7.7 / Build 39（2026年9月3日）

- 修复“GitHub 仓库已创建成功，但初始化 Workflow 时 HTTP 404”。
- 创建/接管仓库后自动等待默认分支可访问，再写入 `.github/workflows/buildmate.yml`。
- 同名仓库已经存在时不再报重名或重复创建，而是直接继续补初始化。
- 对 Workflow 写入 404 增加精确诊断：优先提示 Fine-grained Token 的 Repository access、Contents Read and write、Workflows Read and write。
- 保持核心编译、AI 修复、Artifact 下载链路不变。

## V2.7.6 / Build 38（2026年9月3日）

- 修复“新建项目点击后看起来没反应”的问题：失败信息现在直接在新建项目窗口弹出。
- 新增 GitHub HTTP 401 / 403 / 404 / 422 分类提示，明确 Token 失效、权限不足、访问限制、仓库重名或名称不可用。
- 新建项目增加 4 阶段进度：验证账号 → 创建仓库 → 部署 workflow → 写入 build-config。
- 仓库已经创建但 workflow/config 初始化失败时，不再误报为完全创建失败；会保留仓库并自动切换到该项目。
- GitHub 错误解析增加 API errors 细节，方便直接判断真实失败原因。
- 保持现有编译、AI 修复、Artifact 下载等核心链路不变。

## V2.7.5 / Build 37（2026年9月3日）
### completed Run 前台恢复导致终态状态卡回流
- 症状：任务完成后工作台已恢复，切前台或自动刷新后“当前状态”卡再次出现。
- 根因：foreground refresh 将 completed Run 重新映射为 workStage success/failed，UI 条件又允许所有非 idle 状态显示 statusCard。
- 修复：refreshRunStatus 增加 updateTerminalStage 控制；前台恢复传 false；工作台 statusCard 排除 idle/success/failed。
- 规则：终态信息归档到报告/历史，不把历史 completed Run 当作实时任务重新展示。


## V2.7.4 / Build 36（2026年9月3日）
- 工作台只保留右上角 BuildMate 品牌锤子。
- 当前项目/项目切换改用文件夹，直接编译改用启动图标，工作台 Tab 改用闪电。
- 中央工作圆改为纯动态能量核心，保留真实阶段驱动的动态特效。
- 不改 GitHub/Xcode/AI 修复核心链。

## V2.7.3 / Build 35（2026年9月3日）
- 工作台中央圆统一为 BuildMate 锤子主视觉，真实阶段通过轻量动态特效表达：上传粒子、旋转环、Xcode 轻敲、AI 星芒、打包收束、下载粒子、完成勾。
- 删除工作台重复的九阶段“真实编译流水线”大卡；真实阶段、Run ID、运行详情与正计时继续由上方工作状态条显示。
- 动画使用 SwiftUI TimelineView，不引入 GIF/视频资源，不改 GitHub/Xcode/AI Patch/Artifact 核心链。


## V2.7.2 / Build 34（2026年9月3日）
- 修复“GitHub 仓库管理可见多个仓库，但切换项目只显示本地项目”的双数据源问题；切换项目改为直接使用 GitHub 可访问仓库列表。
- 切换页支持搜索、刷新、私有仓库标记、当前项目勾选；首次选择仓库自动保存为 BuildMate 项目配置。
- 当前项目卡紧凑化，新建/切换改为小按钮；仓库管理删除操作收进更多菜单，降低误触和视觉噪音。
- 不改动已验证的 GitHub/Xcode 编译、AI 修复、Run 匹配与 Artifact 核心链。
## V2.7.0 / Build 32（2026-09-03）
- GitHub 权限/网络体检、API Rate Limit 展示、网络错误中文分层、403 所需权限响应头诊断。
- 删除仓库 Administration write 已由用户在 V2.6.13 实测授权后成功；不再把 403 当仓库名 Bug。
- 保留 V2.6.9 固定 9 错误复杂测试三轮 AI 修复成功基线。

## V2.6.13 · Build 31 · 2026年9月3日
- 修复 GitHub 仓库名本身为单个 `-` 时无法点击删除的问题：`-` 不再被当作占位符。
- 删除目标直接采用 GitHub 仓库列表 API 返回的真实 `owner / name / fullName`，因此 `-`、`-ledger`、`-ledger-app` 等特殊名称均可进入确认流程。
- 安全规则不放宽：空 owner/name 仍阻止；必须输入真实仓库名；真正 DELETE 前继续通过 `repoInfo()` 核对 fullName。
- HTTP 403 继续明确提示 Fine-grained Token 的 Repository permissions → Administration 需为 Read and write。


## V2.6.8 / Build 26 · 2026年9月3日
- 修复 AI repair-context 视野过窄：小文件（≤220 行）直接提供完整源码，大文件在错误窗口之外补充相关声明。
- 记录 V2.6.7 Run #33738211541：DeepSeek 最后一轮因 `ChallengeBuildMode` 原定义被片段裁掉而误判“类型缺失”，说明失败点在上下文采集而非模型不会修。
- AI 在新建 enum/struct/class/function 前必须检查已提供完整上下文，优先修改已有声明。
- 继续使用同一 9-Bug 压力测试包；真实 GitHub/Xcode 成功需用户实测确认。

## AI 多轮闭环能运行但 3 轮仍失败（V2.6.6 实测）
- 现象：复杂 9-Bug 测试 Run #33735208274 跑满 3/3 轮，仍未通过。
- 已验证：AI JSON 可解析、Patch 可累计、repair workflow 可真实重编译；不属于协议层失败。
- 原因：提示词含 “Prefer 1”，模型倾向每轮只修一个错误，导致修复吞吐不足。
- 修复：V2.6.7 改为证据充分时一轮最多同时修 3 个独立低风险错误，同时保留每轮 3 Patch / 3 轮 / 累计 9 Patch 安全门。

## V2.6.4 / Build 22 · 2026-09-03

### KB-AI-004：AI 返回修复计划无法解析
**现象**：真实 Xcode 编译失败、repair-context 已生成，AI 第 1 轮开始，但随后提示“AI 返回的修复计划经过自动清洗和二次格式化后仍无法解析”。

**不要误判**：这不是“AI 一定不会修代码”。只要 Patch 尚未应用、没有触发 repair Run，就属于 AI Provider/协议解析层失败。

**V2.6.4 处理**：
1. 去除 Markdown JSON 围栏和前后说明；
2. 尝试修正中文引号/标点、尾逗号、字符串内原始换行；
3. confidence 支持数字或字符串等常见兼容形式；
4. 第一次仍失败时让 AI 在同一轮内部重新格式化为严格 JSON；
5. 最终仍失败时在诊断报告保存“AI 原始回复 + 二次格式化回复”，禁止把格式失败记成一次真实代码修复失败。

### KB-GH-003：仓库删除入口与安全规则
删除 GitHub Repository 是不可逆高风险动作。必须由用户主动进入仓库管理、选中目标并输入完整仓库名确认。Token 权限不足时显示 GitHub 真实错误；禁止自动删除、禁止 AI 触发删除、禁止显示假成功。

## V2.6.3 / Build 21 · 2026-09-03

- 三页架构：工作台 / 报告 / 设置。
- 中央圆形 AI 编译控制台 + 四周辅助操作。
- DeepSeek 修复计划 JSON 容错解析与自动二次格式化。
- 继续以同一复杂 9 Bug 测试包验证闭环。



## V2.6.2 / Build 20 · 2026-09-03
- 编译工作区增加高对比动态状态卡：上传、排队、Xcode 编译、打包、下载、AI 修复均显示真实阶段。
- AI 自动修复显示第 1/2/3 轮；每轮失败有明确提示，3 轮失败后停止并弹出提醒。
- 新增诊断 TXT 导出，包含 Run、真实编译报告与最后 AI 修复计划，不包含 GitHub Token/API Key。
- repair-context 提取增强：标准错误路径匹配失败时从完整 compile.log、源码文件名与有限源码头部回退取证；App 端最多等待 45 秒同步上下文。
- 验收目标：同一个故障测试包必须出现“首次失败 → AI 读取上下文 → AI 修复 → 新 Run”；最终成功才算闭环通过。
BuildMate V2.6.1 / Build 19（2026年9月3日）：修复 DeepSeek 余额查询；Run 跟踪锁定 workflow_dispatch；约 5 秒自动轮询；修复 AI 自动接管 Run 竞争；新增锤子+齿轮真实工作动画。

BuildMate V2.6.0 / Build 18（2026年9月3日）：AI 多提供商独立配置、DeepSeek 官方余额查询、官方 Key/充值入口、编译历史折叠与历史中心。

# BuildMate 编译错误知识库

## E001 SwiftUI property wrapper 多变量
签名：`property wrapper can only apply to a single variable`
处理：把每个 @State/@Binding/@StateObject 等拆成独立声明。
预防：发布前扫描 property wrapper 行中多个逗号声明。

## E002 TrollStore 303 / 主程序缺失
签名：`Unable to locate main binary inside app bundle` 或 `CFBundleExecutable`/主程序不存在。
处理：检查 PRODUCT_NAME、EXECUTABLE_NAME、CFBundleExecutable 和实际 .app 可执行文件。

## E003 AI Repair 无真实上下文
签名：App 找不到 `.buildmate/repair-context.json` 或 files=[]。
处理：必须先用 V2.0 工作流产生一次真实 Xcode 失败；不能拿旧版报告假修。

## E004 AI Patch 非唯一命中
签名：`AI Patch 必须精确命中 1 次`
处理：停止自动修复，让 AI 用更完整的精确 search；不能替换多处相同代码。

## E005 AI Patch 越权
签名：非 .swift 路径、`..`、绝对路径、超过 3 Patch、risk!=low 或 confidence<80。
处理：云端直接拒绝。工程配置/签名/依赖问题只诊断，不自动修改。

## BM006 - iOS 16.5 源码 ZIP 选择按钮无响应
- 现象：点“选择源码 ZIP”没有弹出文件选择器。
- V2.0 实现：SwiftUI `.fileImporter` 挂在外层 NavigationView。
- V2.1 修复：使用 `UIDocumentPickerViewController(forOpeningContentTypes:asCopy:true)` 的 UIKit 包装器，并通过 `.sheet` 展示。
- 规则：iOS 16.5 / TrollStore 实机文件选择优先走 UIKit Document Picker，SwiftUI fileImporter 只作为次选。

## BM007 - AI 多轮修复不累计
- 现象：第 1 轮 Patch 在 Runner 临时目录生效，但第 2 轮重新从原始 app.zip 解压，只应用第 2 轮 Patch，导致第 1 轮修复丢失。
- 根因：repair-plan.json 每轮被新计划覆盖，而 Runner 的 src 不持久化。
- V2.1 修复：App 端累计各轮安全 Patch；每次 repair 从原始 app.zip 重放累计 Patch。
- 限制：每轮 AI 最多 3 Patch，总累计最多 9 Patch；仍只允许 `.swift` 精确 search/replace。

## BM008 - 旧图标覆盖残留
- 现象：之前上传过 override-icon.png，后来用户不选新图标，仓库旧文件仍存在并继续覆盖。
- 修复：未选择新图标时主动删除远端 override-icon.png。


## BM009 - 已选择源码但稍后 no such file
- 现象：界面仍显示 ZIP 名称和绿色勾，但点击预检/直接编译时报 `The file ... couldn’t be opened because there is no such file.`
- 根因：UIDocumentPicker 的 `asCopy=true` 仍不能把 picker 返回 URL 当作 App 的长期持久路径保存；临时文件生命周期结束后 URL 失效。
- V2.4.2 修复：选择后立即复制到 App 私有 Application Support/BuildMate/Imported，并只保存私有副本文件名。
- 防护：启动恢复和编译前都用 FileManager 校验真实存在；缺失时清空绿色状态并要求重新选择。


## BM010 - Preflight success 被误当成编译成功
- 现象：GitHub Run 为 success，但 Xcode 正式编译、IPA 打包、Artifact 上传步骤均 skipped；App 却显示“编译成功”并提供 Artifact 入口。
- 根因：UI 只看 GitHub conclusion，没有结合 report phase / runID / artifactUploaded。
- V2.4.1 修复：预检只显示“工程预检通过（未执行编译）”；报告必须属于当前 Run；只有真实 Artifact 上传后才显示 IPA/DEB 入口。
- 规则：Job success != Build product success。

## BM011 - 旧报告串到新 Run
- 现象：新 Run 刚结束但 latest-report 尚未同步，App 可能读取上一 Run 的成功报告。
- 根因：报告和 latestRunID 没有强一致校验。
- V2.4.1 修复：只有 `report.runID == latestRunID` 才信任；不匹配时显示“等待本次报告同步”。

## BM012 - 版本历史丢失/AI 重复踩坑
- 现象：后续开发只看当前源码，不知道旧版本为什么这么写，把已修过的问题重新引入。
- V2.4.3 修复：增加 `PROJECT_HISTORY.md`，要求每版把成功、失败、根因、修法、验证和遗留问题追加进去；交给任何 AI 前先读长期历史。
- 规则：历史只追加，不删除失败记录，不把未验证写成成功。


### GitHub Run succeeded 但没有 IPA Artifact
- 现象：Run 顶部成功，但正式编译/打包/上传步骤是 skipped。
- 优先检查：本次 mode 是否实际为 `preflight`，或者是否是重跑了旧的 preflight Run。
- V2.4.4 处理：网页 mode 改为下拉选择并统一规范化；空值/异常值回退 `full`。
- 判定成功标准：Xcode 编译 + IPA 打包 + Artifact 上传步骤均真实执行成功。

## V2.5.1：AI 提供商配置串台 / 自动编译误触 / Artifact 文件名固定
日期：2026年9月3日

现象：OpenAI 分段被选中时可能仍显示 DeepSeek/兼容接口 Endpoint 与模型；切换到兼容接口又可能残留 GPT 配置。自动编译主按钮误触后会直接触发真实 GitHub Actions。Artifact 下载后文件名固定，保存到“文件”时需要手工改名。

根因：V2.5.0 及以前 Endpoint、Model、AI Key 共用同一套持久化键；主自动编译入口没有二次确认；下载 Artifact 后直接使用 GitHub Artifact 名称保存临时 ZIP。

V2.5.1 修复：按提供商分别保存 Endpoint / Model / Key；新增 AI 自动接管开关并默认关闭；自动编译前二次确认；Artifact 可自定义文件名并按项目分类缓存后再交给系统保存/分享。


## V2.6.5 · Build 23 · 2026年9月3日
- 覆盖安装后自动从 Keychain 恢复 GitHub 登录、仓库列表与当前仓库。
- AI 自动接管增加前台恢复：后台挂起/返回后按 Run 状态继续；普通 GitHub 编译本身始终在云端继续。
- 修复 AI 安全停止后仍停留紫色工作栏、没有诊断导出的问题；`No input provided` 等停止原因进入统一失败收尾。
- 所有真实编译失败都生成可导出的诊断 TXT；AI 模式额外记录 AI 原始回复、二次格式化回复、计划与 Patch。
- 编译产物成功后自动准备，移除重复的“下载并准备保存”主按钮，仅保留“保存到文件 / 分享”；失败时显示重新下载。
- 重要边界：iOS 后台不能保证 App 持续执行网络/AI 任务，本版实现的是自动恢复继续，不宣称真正后台常驻；完整云端 AI 闭环仍是后续架构目标。


## V2.6.6 · Build 24 · 2026年9月3日
- 复杂 9-Bug 实测 Run #33733017151：真实 Xcode 失败与 repair-context 已成功，DeepSeek `deepseek-v4-pro` 在 JSON Output 阶段返回空 content，未进入 Patch。
- 按 DeepSeek 官方 JSON Output 文档处理：JSON 模式空 content 时，同一修复轮次自动改用普通输出重试；该协议重试不消耗 1/3 代码修复轮次。
- DeepSeek 结构化修复计划请求关闭 thinking，避免 reasoning_content 与最终 content 的协议差异影响 Patch JSON。
- 产物 UI 规则固定：自动准备中不要求用户操作；准备成功只显示保存/分享；只有自动准备失败才显示重新下载。
- 继续使用同一 9-Bug 测试包，不更换挑战内容，直到 Patch 真正应用并触发后续真实 Xcode Run。


## V2.6.9 · Build 27 · 2026年9月3日
- V2.6.8 实测发现：完整上下文后 AI 会一次识别超过 3 个修复，旧安全阀整轮拒绝。V2.6.9 改为仅执行按确定性/最小改动排序的前 3 个 Patch，其余等待下一次真实编译重新判断；仍保持每轮最多 3 个实际 Patch。
- 报告页移除重复“当前状态”，工作台保留状态；报告页专注真实报告、AI 决策、产物和历史。
- 项目源码卡改为直接点击左侧图标替换 PNG，并原位预览；移除单独“替换图标”行。
- 版本显示继续以 Bundle 为单一真源。


## V2.9.30 · Build 81 — Codemagic 工作流自维护

- Codemagic 编译前自动同步 BuildMate 内置的最新 `codemagic.yaml`，避免仓库长期停留在旧 Build76/Build77 显示名称。
- Workflow ID 继续使用 `buildmate-ios-build76` 作为稳定兼容 ID，不要求已经配置好的设备重新填写。
- 工作流显示名称固定为 `BuildMate Auto · iOS IPA`，真实 App 版本继续从 `app.zip` 内部 `project.yml` / Info.plist 读取。
- 编译阶段改为 6 段状态，明确区分源码上传、工作流同步、Codemagic 启动、Xcode 编译和 IPA 验证。
- Build79 启动结构修复与 Build80 智能省额度主链路保持不动。

## KB-SWIFT-INTERFACE-001 · View 接口/类型不同步（Build134）
- 症状：`cannot find 'section' in scope`、`Cannot find type 'AIDoctorReport' in scope`、`Extra argument 'section' in call`。
- 根因：中枢拆分时调用方已增加 section 参数，但 View 本体未声明；项目医生类型名与模型真实定义 `BMProjectDoctorReport` 不一致。
- 漏诊原因：`swiftc -parse` 只验证语法结构，无法替代完整项目类型检查/Xcode 构建。
- 修复：给 `AIDevelopmentCenterView` 增加默认 `.all` 的 section 属性并统一调用；`DevelopmentHubView` 使用 `BMProjectDoctorReport`。
- 防复发：公共 View initializer / Model 类型变更必须扫描所有调用点；真实 Xcode 错误需要写入 Black Box + errorFingerprint，并在编译成功后才把本案例晋升为“已验证”。
- 状态：Build135 已修源码；等待真实 Codemagic/Xcode 编译验证后标记验证结果。
