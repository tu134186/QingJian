# Build 1038 · Codemagic Artifact Return Rewrite

- Evidence: cloud Build finished and IPA existed, while Build1036 selected a `/artifacts/.<signed-token>` URL and received HTTP 404.
- Root regression: Build1033 changed extraction priority to `short_lived_download_url` first; `buildState` also skipped the legacy Builds API whenever v3 already exposed any Artifact, so a temporary/broken signed URL could hide the stable authenticated URL.
- Fix: always merge v3 + legacy Artifact metadata, preserve all official URL forms, deduplicate and rank stable `/artifacts/<id>/<id>/<file>` before signed `/artifacts/.<token>`.
- Stable route: POST `<authenticated-artifact-url>/public-url` with `x-auth-token`, then GET the returned public URL.
- Signed/public URLs are opaque and are no longer path-normalized.
- One user action remains one acquisition round; no sleep, no automatic second round, no new cloud build.
