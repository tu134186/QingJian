# BuildMate V5.1.0 · Build 316 — Accessibility Identity

## Evidence
Build315 真机报告：6 页面 / 3 控件 / 2 滑动区域；4 次已映射、33 次未映射。性能主观反馈已明显改善。

## Build316 changes
1. 252/252 direct standard interactive controls (Button / NavigationLink / Toggle / Menu / Link / Picker) are stamped with stable Manifest accessibilityIdentifier values; runtime nodes also record identifier and selected state.
2. Resolver exact-matches identifier before semantic fuzzy matching.
3. Touch mapping uses Accessibility actionable node, UIKit hitTest ancestry, visible semantic geometry, end-state recapture, then unique relationship page-transition inference.
4. State fingerprint includes value/selected/identifier. Picker/Segment/Toggle value or selected changes close pending ActionContract and prevent false Dead Tap.
5. All fallbacks are read-only. No Gesture/Overlay, no hit-test mutation, no synthetic tap, no contentOffset mutation.
6. Uncertain interactions remain unmapped/manual-review instead of fabricated coverage.

## Target
Standard SwiftUI interaction mapping >=80% in representative real-user sessions; special custom-drawn/WebView cases may require manual evidence.
