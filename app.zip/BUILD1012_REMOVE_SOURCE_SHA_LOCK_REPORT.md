# Build1012 Remove Source SHA Lock

- Removed duplicate-build blocking based on identical Source SHA and historical success/failure.
- Removed persisted same-SHA Unified Task reuse/cold-resume from explicit compile entry.
- Source import lifecycle events now close immediately instead of remaining “in progress”.
- Existing artifacts remain visible but never short-circuit an explicit rebuild.
- Same SHA may be rebuilt repeatedly.
- The normal in-memory `busy` guard remains to prevent one rapid double tap from creating two simultaneous cloud POSTs.
- Real cloud Run recovery/cancel support remains; this is not a Source-SHA lock.
