# BuildMate V5.0.3 · Build 313 — MainActor Compile Closure

## Real evidence
- Build312 Codemagic Run: `6aa0f45309734fce4902bf91`
- First Xcode error: `BMTesterPassiveTouchObserver.swift:61` — `call to main actor-isolated static method resolve(point:nodes:) in a synchronous nonisolated context`

## Closure
- `BMTesterPassiveTouchObserver` is now `@MainActor`.
- `UIApplication` swizzled observation selector is explicitly `@MainActor`.
- UITouch objects are consumed synchronously in the UI execution domain instead of being captured into a `DispatchQueue.main.async` closure.
- `BMTesterRuntimeSurfaceModifier` and `.bmTesterRuntimeSurface()` are `@MainActor`.
- No full-screen gesture/overlay/hit-test interception was reintroduced.

## New regression gate
`scripts/check_build313_mainactor_boundary.py` checks the required actor boundary and interaction-safety invariants before cloud build.
