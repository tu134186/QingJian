# 回归验收

## 发布前必须通过
- 版本号：MARKETING_VERSION、CURRENT_PROJECT_VERSION、关于页、备份元数据、文档一致。
- 源码：ZIP 根结构、project.yml、必需文件、Source SHA、源码切换与运行中锁定。
- 体检：错误源码能在云编译前被拦截；体检成功不显示为编译成功。
- 编译：至少用目标云 Provider 做一次真实 Xcode/Theos 构建；Run 与源码 SHA 可追踪。
- 产物：成功后 IPA/DEB 等产物可下载/缓存/再次打开，失败不伪造产物。
- 诊断：失败包包含 Task/Run/SHA/首要错误/上下文/黑匣子，且无 Token/API Key/密码/Cookie。
- 黑匣子：成功/失败/取消/中断都有时间线；无幽灵任务。
- 发布：签名/Provisioning/App Store Connect/TestFlight/Google Play 相关入口按平台配置工作。
- 备份恢复：导出加密备份；干净安装后恢复白名单配置、云凭据和自定义中央素材。
- 中央视觉：6 内置素材均可选；写轮眼 Pro/三勾玉正常；SVG 源码粘贴/校验/保存/动画正常；任务转速待机5、编译最高120、结束平滑回5。
- 交互安全：无全局 Gesture/Overlay/hit-test 拦截；Button/Navigation/List/Scroll/Toggle 正常。
- 废弃路线：正式 UI/路由不得重新出现 Creator/DeepTakeover/AI Tester/网页预览等入口。
