# BuildMate Git Binary Relay 设置

Build147 之后的稳定 IPA 回传使用任务专属 Git 分支。Codemagic 官方说明其构建 VM 对 GitHub 仓库默认只有读取权限，因此若需要 Codemagic 主动把 IPA 写回 GitHub，必须显式授予写权限。

在 Codemagic 的 `buildmate_secrets` 环境变量组新增 Secret：

- 名称：`BUILDMATE_RELAY_GITHUB_TOKEN`
- 推荐：GitHub Fine-grained personal access token
- Repository access：只选择 BuildMate 仓库
- Repository permissions：Contents = Read and write
- 必须勾选 Secret

不要把 Token 写入源码、聊天、日志、诊断包或 README。`CODEMAGIC_API_TOKEN` 与该 GitHub Relay Token 用途不同，不能互相替代。

未配置 Relay Token 时，云端编译本身仍可成功，BuildMate 会继续尝试 Codemagic Artifact API；但无法保证 Git Binary Relay 可用。
