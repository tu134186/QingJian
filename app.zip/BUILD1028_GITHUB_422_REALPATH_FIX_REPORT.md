# Build1028 GitHub Actions 422 真实调用路径修复报告

## 真实故障证据

Build1027 诊断包 `BuildMate-Diagnostic-BM-F7314046.zip` 显示：

- Source SHA 上传前后完全一致；
- GitHub Token 已通过认证；
- `workflow_dispatch` 首次调用返回 HTTP 422 `Unexpected inputs provided`；
- Run ID 为空，说明 GitHub 没有创建 Run；
- Build1027 的兼容降级没有实际执行。

## 根因

旧兼容判断同时依赖 `NSError.code == 422` 和错误文本。真实设备 async/bridging 路径里，错误文本完整保留 422，但错误 code 不保证稳定透传，因此直接进入上层失败收口。

## 修复

`GitHubService.dispatch` 改为显式三阶段兼容：

1. 完整源码指纹 inputs；
2. 仅 `mode`；
3. 无 inputs。

只要前两步属于 workflow_dispatch HTTP 422/Unexpected inputs，就进入下一阶段。401/403/404/网络错误不降级，原样抛出。

## 保持不变

- iOS IPA 主链；
- Theos DEB 主链；
- Codemagic 主链；
- Build1025 停止/取消逻辑；
- 无 AI 纯编译路线。
