# BuildMate V7.5.3 G compile restore (V2.9.18 chain)

Baseline: V7.5.3 Build1065 stable source.

Changed only GitHub Actions G compile path:
- G uses the same source GitHub owner/repo/token as V2.9.18.
- Dispatch is fixed to `.github/workflows/buildmate.yml`.
- Dispatch body is only `ref` + `inputs.mode`, matching V2.9.18.
- Before dispatch, read current latest `buildmate.yml` workflow_dispatch Run ID.
- After dispatch, `waitForNewCompletedRun` accepts only a different real Run returned by GitHub for `buildmate.yml`.
- Status/artifact logic remains bound to that real Run ID.

Frozen / intentionally untouched:
- Codemagic C compile implementation.
- Codemagic workflow and Artifact Return Bridge.
- IPA/DEB C return path.
