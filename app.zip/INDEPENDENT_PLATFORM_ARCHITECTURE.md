# BuildMate 独立平台架构（Build149）

BuildMate 是总控平台，不是 GitHub 客户端，也不是 Codemagic/Bitrise 外壳。

## 五类可替换能力

1. 源码平台：GitHub（当前正式）、GitLab/Gitea/本地文件/通用 Git（预留）
2. 编译平台：Codemagic、Bitrise、GitHub Actions、自托管 Mac、未来 Provider
3. AI Provider：OpenAI / DeepSeek / 其他兼容接口
4. 产物回传：Provider API、Git Relay、未来对象存储/私人节点
5. 发布平台：App Store Connect / TestFlight / Google Play / AppGallery

## Core 永久拥有

- Workspace / Project 身份
- Task ID 与状态机
- Task Black Box
- 检查点与恢复
- Source SHA / Artifact 校验
- 诊断包
- Provider 调度与熔断
- 质量回归与发布门禁

## Build149 迁移

- 顶部不再用 `main` 或 GitHub 仓库暗示 BuildMate 身份；改为“工作空间 + 源码 + 编译 + AI”。
- 设置页新增“平台总览”和“编译平台”，GitHub 被明确降级为“源码平台”的当前适配器。
- “GitHub 仓库管理”改为“源码仓库管理”；“GitHub 连接”改为“源码平台”。
- 新增 BMWorkspaceIdentity / BMSourceProviderRegistry / BMArchitectureBoundary。
- 保留 owner/repo/UserDefaults 旧键做兼容迁移，避免升级后丢失现有连接。
- 当前 Codemagic/Bitrise 的源码传输仍由 GitHub Source Adapter 完成；这是当前能力限制，不再被表达成 BuildMate 核心依赖。
