# Build1008 正式资料清单

当前源码包只把以下文档作为现行开发依据：
- README.md
- DEVELOPMENT_MANUAL.md
- DEVELOPMENT.md
- ARCHITECTURE.md
- REGRESSION_TESTS.md
- CHANGELOG.md
- PROJECT_HISTORY.md
- AI_HANDOVER.md

旧 Creator / Tester / DeepTakeover / AI Engineering 等专项 BUILD 报告已从正式源码包移除，不再作为未来开发依据。
