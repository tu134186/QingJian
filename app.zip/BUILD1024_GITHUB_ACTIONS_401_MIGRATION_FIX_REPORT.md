# Build1024 GitHub Actions 401 回归修复

- 基线：V7.3.5 Build1023。
- 根因：GitHub Actions 独立凭据槽位可能保存了无效/过期 Token，而旧 `github-token` 仍然有效。
- 修复：首次 `repoInfo()` 返回 HTTP 401 时，若旧 Token 与新 Token 不同且源码仓库信息完整，则用旧 Token 验证；验证成功后迁移到 `github-actions-*` 独立配置并继续当前编译。
- 安全边界：只对 401 做回退；403/404/网络错误不会盲目切换；不恢复自动调度或 AI 修复。
- IPA / DEB 工作流未改动。
