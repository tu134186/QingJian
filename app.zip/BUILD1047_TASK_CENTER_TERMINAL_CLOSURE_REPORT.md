# Build1047 · 任务中心终态与展示收口

- 只修改任务黑匣子展示归一、任务中心 UI 与产物中心定位展示。
- `artifact.relay.completed` 且已完成 SHA/格式校验时，任务中心直接显示“已完成”，不再出现“回传成功 + 进行中”。
- 任务卡正文改为简短结论：成功显示 IPA/DEB + 文件大小；异常显示人话原因；停止显示不会自动续跑。
- 异常任务点击后默认进入“诊断”；成功任务详情新增“打开本次产物”。
- 任务首页保留最近 10 条，其余进入“历史任务”；黑匣子原始事件不删除。
- `codemagic.yaml`、GitHub Actions workflow、CodemagicService、Artifact Return Bridge、ContentView+Execution 均未修改。
