# Build1067 · GitHub Existing Repository Workflow Restore

- Version: V7.5.5 Build1067.
- Base: V7.5.4 Build1066.
- Scope: GitHub Actions (G 编译) only. Stable C/Codemagic compile path is unchanged.
- Before every G compile dispatch, BuildMate now deploys/repairs `.github/workflows/buildmate.yml` using the same full macOS-15 Xcode/Theos workflow embedded in `SmartBuildWorkflow`.
- The app immediately reads the remote workflow back and requires byte-for-byte equality before uploading/dispatching. If verification fails, dispatch is stopped instead of reporting a false compile start/success.
- Existing repositories are therefore repaired too; V7.5.4 only guaranteed this deployment during repository initialization.
- The active GitHub Actions branch is used consistently after credential fallback.
- Existing source ZIP upload+SHA verification, workflow_dispatch compatibility fallback, new Run detection, IPA/DEB artifact upload and return logic remain intact.
