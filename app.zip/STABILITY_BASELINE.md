## V3.4.0 · Build 246 — Agent 确定性失败证据交接 + Creator 完整体收口

- 修复连续实测中 Codemagic failed 后 repair-context 无法被 BuildMate 取得的问题：Xcode step 先生成并落盘诊断，再正常结束该 step；独立终态 step 最后恢复原始 Xcode 非零退出码。
- 新增 `.codemagic/xcode-exit-status` 证据 Artifact；保留 repair-context、compile-errors、Export Artifact、Direct Relay、receipt Relay 多通道。
- 不改变安全原则：没有真实编译错误和源码片段时 Agent 不允许猜 Patch，不自动创建第二次云编译。
- Creator 完整体继续以 AppSpec 为唯一规格源，覆盖需求讨论、版本/撤销、Web 交互预览、设计锁定、SwiftUI 工程、本地门禁、Agent 接管、人工批准云编译与后续项目迭代。

## V3.3.0 · Build 245 — Creator 完整体与 Agent 失败诊断多通道闭环

- Creator 升级为可长期迭代项目：最近项目、项目进度、AppSpec 版本快照、撤销上一次方案修改、设计锁定、正式源码生成、本地门禁结果与 Agent 交接统一在同一页面。
- 生成工程新增 BuildMateCreatorManifest、TEST_PLAN、PRIVACY、AGENT_GOAL，锁定 AppSpec 作为 Web 预览与 SwiftUI 唯一规格源，生成后自动设为当前源码。
- Codemagic 真实失败诊断新增 Export Artifact 通道：repair-context 与 compile-errors 在失败退出前复制到 CM_EXPORT_DIR，同时保留 Direct Relay / receipt Relay / Task 固定路径，避免 Relay Secret 缺失时只剩 status=failed。
- 真实云编译继续人工批准；Creator 讨论、预览、源码生成与本地门禁不自动消耗 Codemagic 分钟。

## V3.2.0 · Build 244 — AI 造 App 完整体一期 + Agent Direct Diagnostic Relay v4

- 修复 4-Bug 真机测试暴露的最后诊断断点：Xcode 失败后在 compile step 内直接回传 repair-context，避免依赖 failed build 的 post-publish 时序。
- BuildMate 诊断获取升级为三层：Codemagic Artifact → Relay receipt → Task 固定路径 Direct Relay；三条都没有真实证据才停止，禁止 AI 猜代码。
- “从想法创建 App”升级为可执行完整链：协作/自主模式 → AI AppSpec → 可交互 Web 预览 → 修改 → 锁定 → SwiftUI 源码 → ZIP → 本地零分钟门禁 → 自动设为当前源码。
- AppSpec 新增首版数据实体/字段/userFlows；网页预览和生成的真实 SwiftUI App 使用同一规格。
- 生成 App 自带 iOS 15+ SwiftUI、Tab、表单录入、本地持久化、最近记录、基础统计和设置/清空数据能力。
- 真实云编译仍必须人工批准；讨论、网页预览、源码生成、本地门禁不自动消耗 Codemagic 分钟。

## V3.1.0 · Build 243 — Agent 真实失败诊断闭环 + 从想法创建 App
- 修复 4-Bug 真机验证暴露的关键断点：Codemagic failed 构建即使 Builds API 不直接暴露 repair-context，post-publish 也会把任务专属 repair-context 经 Git Relay v3 主动回传；BuildMate 绑定同 Task/Build/SHA 读取诊断后进入 Agent AI Patch，不创建第二个 Run。
- 每次新编译开始清空上一轮 Agent repair-context，防止旧诊断污染新任务；失败诊断 Relay 50 秒超时即停止并保留证据，禁止无真实错误时让 AI 猜代码。
- 首页失败态四宫格去重：只保留一个“智能处理”入口，右下角恢复为“源码体检”。
- 新增“从想法创建 App”工作室：自然语言需求 → AI/本地 AppSpec → 页面方案 → 可交互 WebKit 高保真预览 → 边聊边改 → 锁定设计 → 导出 AppSpec + HTML。预览阶段不触发 Codemagic。
- AppSpec 成为网页预览与未来 SwiftUI 生成的统一规格源；智能体在没有源码时也可进入“创建新 App”。

# V3.0.9 · Build 240（2026-09-08）

- 智能体入口彻底收口：云编译控制台移除重复 AI 编译按钮；真实失败统一“交给智能体”；AI 开发中心移除重复 DeepTakeover 卡片。
- Agent 页面按当前源码 SHA 绑定任务，切换 ZIP 后不显示上一源码任务；阻断/停止可基于当前源码一键重新生成计划。
- 旧 AI Repair / DeepTakeover 执行代码保留为兼容层，不再作为主流程新增入口；Build238/239 的真实失败 repair-context 与安全 RepairPlan 闭环保持不动。
- 本版目标是减少一次真实编译前仍存在的重复入口与任务串线风险，不扩大 GitHub/Codemagic/Artifact 稳定执行主链。

# V3.0.8 · Build239（2026-09-08）

- Build239 修复全屏智能体缺少退出入口：导航栏提供明确“返回”，退出只关闭智能体界面，不取消或重建正在运行的 Task/Run。

智能体入口收口、全屏精简、Codemagic repair-context 真实失败续跑与安全 RepairPlan 应用。Build237 作为上一真实编译成功基线保留。


## V3.0.6 · Build237（2026-09-08）
- 首页视觉封板：基于 Build236 真机反馈，将当前源码卡紧凑化；长 ZIP 名称改为版本/Build 摘要，IPA 后清理与清除操作压缩为单行。
- 不改 Build235/236 已验证的动态下一步状态、GitHub/Codemagic/AI/Agent/Artifact/任务/发布执行主链。

# V3.0.4 · Build 235 — 产物交付后动态按钮状态机修正

## V3.0.5 · Build236（2026-09-08）
- 首页视觉收口：品牌 BuildMate 只保留顶部主标题；副标题缩短为“AI 开发 · 编译 · 发布”；环境状态条不再重复项目名；项目卡保留当前项目名。
- 缩小右上品牌图标与工作台中央圆盘，压缩无效高度；仅改 Presentation/UI，不改 Build235 已真机验证的动态下一步状态机和稳定执行主链。

- 修正 Build234 对“保存产物”反馈的误解：首页右下角是动态“下一步”槽位，不是固定产物入口。
- 未交付 IPA 继续显示“保存产物”；系统分享/保存成功后立刻退出交付态，按钮继续按上下文恢复“源码体检 / 深度接管 / 下载产物 / 重抓产物 / 云端运行”等状态。
- 已保存/分享 IPA 仍保留在产物中心，可再次分享，但不再长期占用首页工作台按钮。
- Build233 真实 Xcode/Codemagic 稳定主链保持不动；Build234 未进行真实云编译即被 Build235 覆盖。
- 新增 Build235 动态按钮回归门禁，防止以后再次把“历史本机产物存在”误判成“仍待用户保存”。

# V3.0.3 · Build 234 — V3 完全体交互收口与全局扫描

- Build233 已完成真实 Codemagic/Xcode 编译并在真机安装运行，作为本版稳定执行基线。
- 首页工作台去重：无报告时左下角从重复的“任务中心”改为“智能体”，底部“任务”Tab 继续作为统一任务入口。
- 本机已有验证产物时右下角统一显示“产物中心”，不再持续显示“保存产物”；BuildMate 不伪造“IPA 是否已被巨魔/系统安装”的不可观测状态。
- 产物中心统一使用“本机可用 / 已分享 / 分享或导出 / 再次分享”，云编译控制台使用“分享 IPA”，把缓存、导出、安装三个概念分开。
- 项目卡历史构建编号明确显示为“最近 Run”，避免清空源码后把旧 Run 误认为当前运行。
- 根据 Build233 真机录屏复查首页、中枢、Provider Center、Task Black Box、设置与关于页；保留 GitHub/Codemagic/AI/Artifact/Apple 发布稳定执行器。
- 新增 Build234 UI 收口回归门禁；源码包打包前清理 `__pycache__` 与 `.pyc`。

# V3.0.2 · Build 233 — V3 智能体 iOS 15 真实 Xcode 兼容闭环修复

- Build232 真实 Codemagic/Xcode 编译失败，唯一首因：`AgentCenterView.swift` 使用 `TextField(_:text:axis:)`，该重载仅 iOS 16+ 可用，而工程 deployment target 为 iOS 15。
- Build233 改为 iOS 15 可用的 `TextField(_:text:)`，不修改 V3 Agent 编排、GitHub、Codemagic、AI、Artifact、Apple 发布执行链。
- 新增 iOS 15 API 兼容回归门禁，防止同类“单文件语法可过、真实 Xcode deployment availability 才失败”的问题再次进入云编译。
- Build232 的 BMAgentPolicy 重名修复继续保留。

# V3.0.1 · Build 232 — V3 智能体真实 Xcode 编译闭环修复

- Build231 已完成真实 Codemagic/Xcode 验证并发现首因：`BMAgentPolicy` 在 `AgentV3Models.swift` 与 `BMAgentCore.swift` 重名，导致类型歧义、重复声明和字段解析失败。
- Build232 将 V3 会话/运行时治理策略重命名为 `BMAgentRuntimePolicy`，保留 Core 多智能体角色权限策略 `BMAgentPolicy`，避免两个不同职责共用同一 Swift 顶层类型名。
- 新增跨文件顶层类型重名检查，补上“单文件 Swift parse 通过但 Xcode 全模块编译失败”的门禁缺口。
- 不改 GitHub/Codemagic/Apple Upload/Artifact/AI 主执行链，仅修真实 Xcode 首因并加强回归门。

# V3.0.0 · Build 231 — BuildMate 智能体完全体

- Build230 已完成真实 Codemagic/Xcode 编译、IPA 保存与真机启动，作为 V3.0.0 稳定基线。
- 新增 `BuildMate Agent V3`：目标 → 计划 → 执行 → 观察 → 修复 → 验证 → 交付。用户可选择“编译 IPA / 自动修复直到成功 / 全面体检后编译 / App Store 发布准备 / 自定义目标”。
- Agent 计划统一串联源码指纹、恢复点、真实诊断、AI Patch、本地零分钟门禁、唯一云 Run、后台恢复、Artifact 续航、真机交付与发布准备。
- 新增真正 Agent 执行入口：先跑一次真实编译获取证据；仅当失败类型确认为源码错误且 AI 已配置时，自动进入 AI Repair；网络/认证/额度/Artifact 失败不会让 AI 猜代码。
- AI Patch 通过本地门禁后自动停在云编译批准点；智能体中心可“批准并继续这一次云编译”，批准绑定真实 Run 后立即消费。
- 冷启动任务去重升级：内存 activeTaskID 丢失时仍按 Workspace + Source SHA 复用持久父任务，防止 App 被系统杀掉后生成第二个 Task/Run。
- Agent Session 持久保存并绑定 Source SHA / Unified Task / Run / Artifact；前台恢复会自动对账，禁止后台回来创建第二个 Run。
- 同 SHA 已有验证 IPA 时优先复用产物，自动跳过重复云编译。
- 安全边界保持不可绕过：真实云编译、高风险 Patch、App Store 最终提交必须人工批准；Token/API Key/JWT 不进入 Agent Session 或黑匣子。
- 智能体预算与既有 Autonomous Loop / AI Repair Governance 同步，避免多个设置源产生冲突。
- 开发中枢首入口升级为“智能体”；普通编译、AI 编译、质量、任务、产物、发布能力全部保留。
- V3 采用编排层覆盖已验证执行器，不重写 GitHub/Codemagic/Apple Upload 主链，降低一次性大升级风险。

# V2.26.0 · Build 230 — 长期维护稳定版

- Build229 已完成真实 Codemagic/Xcode 编译、IPA 下载验证与真机启动，作为本版稳定基线。
- 新增长时间后台恢复：回前台自动执行本地任务对账，再继续同一个 Codemagic Run；不会因为 iOS 挂起而创建第二个云 Run。
- 新增幽灵任务自动收口：历史 FinalStabilityAudit 补完成终态；同 SHA 已有验证 IPA 时，无真实 Run 的旧体检/审批任务标记为被后续成功链路取代；有真实 Run 的任务保留给 Provider 权威状态确认。
- 任务中心新增“重新对账并收口”，不删历史，只补齐正确终态。
- 新增成功/异常本地通知；Artifact Delivery Store 与产物中心继续保证 IPA 在返回待机、后台和重启后可恢复。
- 网络、凭据、Run、Artifact、AI、Apple 发布主链保持既有稳定实现，不做架构性重写。

# V2.25.0 · Build 229 · 2026年9月8日

- Build228 已完成真实 Codemagic/Xcode 编译并确认 IPA 产物可用；Build227 保持已确认安装启动稳定锚点。
- 修复“编译成功后未点保存，返回待机/切后台后右下角变回源码体检”的真机问题：产物状态不再依赖 `workStage == .success`。
- 新增统一 Artifact Delivery Store：Codemagic 已验证 IPA 改为持久保存到 Application Support，并记录 Provider、Run/Build、Source SHA、文件名、大小、原构建链接和交付状态。
- 新增产物中心：返回待机、前后台切换、App 重启后仍可再次保存/分享最近 IPA；本机删除不影响云端构建。
- GitHub/Codemagic/AI/Apple 发布执行主链保持冻结；本版集中完成真机终态/Artifact 续航维护。

# V2.24.0 稳定基线候选

Build227 为真实编译/安装/启动稳定基线；Build228 只在其上完成发布真链与状态终态收口。Build228 通过真实 Xcode/Codemagic 后停止连续大改。

# Build227 收官基线说明

当前已真实验证稳定锚点为 V2.22.0 · Build226。Build227 仅在该基线上增加最终稳定审计与一次性云编译批准，不重写 GitHub/Codemagic/Apple Build Upload/Artifact 主链。Build227 需一次真实 Codemagic/Xcode 编译、IPA 安装启动后才可提升为新长期稳定锚点。

# V2.9.96 · Build 147 稳定基线

稳定性硬约束：一个 Task 只能绑定一个正在恢复的 Codemagic buildId；网络未知不是失败；`finished` 与 Artifact Ready 独立；真实终态不可被迟到异步回写覆盖；Artifact-only 故障不得触发跨平台重编译；Git Relay 必须任务分支隔离且不得记录 Secret；诊断必须区分执行端/目标源码并导出 01～09。

# V2.9.95 · Build 146 稳定基线

终态不可逆；真实 Build failed/cancelled 高于 Artifact 状态；Artifact/Relay 仅属于成功构建后的回传阶段。

## V2.9.94 · Build 145

稳定性基线新增：GitHub Contents 写入遇到未知结果时不得盲目重发；必须先以远端真实字节/SHA-256 判断是否已完成目标写入。CodemagicCompile 的错误 Provider/Stage 必须对应真实故障位置；诊断必须区分执行 App 版本与目标源码版本。

## V2.9.93 · Build 144

稳定性基线新增：Codemagic 启动超时不得盲目重发；必须先按 Task ID + Source SHA 反查，避免重复 Run/幽灵任务。

# 当前稳定基线：V2.9.92 · Build 143

Build142 已真实验证 Xcode 云编译与 IPA 产出成功。Build143 只在 Artifact 返回层增加 Git Relay，不改变 Xcode 编译、源码 SHA 锁定、AI 修复和任务黑匣子核心链。

## V2.9.91 · Build 142

- 修复 Build141 最终源码包在 Codemagic 的 AboutView current release 版本校验失败。
- 版本检查改为解析 AboutView 发布列表第一条 version/build，减少格式脆弱性。
- 发布前新增最终 ZIP 解压后二次版本校验，工作目录与交付包必须同时通过。
- 保留 Build141 回传收据实验与 Build140 UI/素材修复。

## V2.9.90 · Build 141 基线补充
不修改 Xcode 编译、GitHub、AI 主链；仅增强 Codemagic Artifact 回传证据持久化。

# V2.9.89 · Build 140 稳定性基线

Build139 的 Artifact 回传可观测链继续作为编译/回传基线；Build140 只修改工作台按钮展示映射和素材整理动画范围，不改变 Xcode/Codemagic/GitHub/AI 主链。

# V2.9.88 · Build 139 稳定性基线

Build138 的真实 Xcode 编译成功作为主线基线；Build139 只扩展 Artifact 回传观测和诊断证据，不改变 Xcode 构建参数与 IPA 打包流程。

## Build138 稳定基线追加

- Build137 已真实 Xcode 编译成功；Build138 只围绕 Artifact 回传链和 Secret 注入扩展。
- Build138 尚未真实 Codemagic 验证，禁止提前标记“IPA 自动回传已修复”。
- `CODEMAGIC_API_TOKEN` 不得写入源码、诊断包、黑匣子或控制台明文。

## Build137 稳定基线追加
- Build135 已有真实 Codemagic/Xcode 编译成功证据。
- Build137 新增 Artifact Return 抽象与服务器侧证据脚本，尚需真实 Codemagic 运行验证，不提前标记“回传已修通”。

## V2.9.85 · Build 136 基线
Build135 已有真实 Codemagic Xcode 编译成功证据；Build136 在其上仅新增独立发布架构骨架和权限/凭证抽象，不接入真实商店网络调用。实际 App Store / Google Play / Huawei 上传能力在真实账号 Adapter 完成并经过端到端测试前不得标记为可用。


## V2.9.84 · Build 135（2026-09-06）
- 建立模块注册、Feature Flag、Agent 权限/预算、Tool Gateway、协同总线、工程知识库与多平台 Provider 骨架。
- iOS 保持当前主平台；Android/HarmonyOS 只预留 Adapter 接口，默认关闭，不引入额外 SDK。
- 修复 Build134 AI 开发中枢真实 Swift 接口错误；黑匣子扩展 platform/node/parent/correlation/errorFingerprint 证据字段。
- 新增 `MODULAR_ARCHITECTURE.md`，第三方公司/平台必须可拔插，不得反向污染 Core。

## 当前稳定候选：V2.9.83 · Build 134

Build134 为 UI 基础设施候选：Design System / Theme Engine 与素材整理交互。编译、网络、AI、任务黑匣子主链保持 Build133 业务逻辑。
新增 SVG AI 规范复制入口，不改动编译 Provider 主链。

## V2.9.80 · Build 131

## V2.9.81 · Build 132
素材批量删除复用单项删除状态收敛逻辑，不改变中央渲染、编译链和任务链。


- Build130 四栏导航与开发中枢保持稳定基线。
- 本版仅增加自定义素材显式删除入口，不改编译、AI、GitHub/Codemagic、任务黑匣子链路。

## V2.9.79 · Build 130

- 主 Tab 固定：首页 / 中枢 / 任务 / 设置。
- 中枢只聚合导航，继续复用既有编译/AI/质量承重逻辑。
- Codemagic Artifact 自动抓取仅一次，手动恢复仍绑定原 Build ID / Source SHA。

## V2.9.78 · Build 129 稳定基线增量

中央素材校正只影响视觉渲染，不得改变源码、GitHub、Codemagic、AI、任务黑匣子主链。

## V2.9.77 · Build 128 稳定基线增量
- 圆形校正只作用于中央视觉渲染层，不修改素材文件本身，不改 GitHub/Codemagic/AI/Task Black Box 主链。
- 自定义素材颜色不得因任务状态被 colorMultiply/hue/saturation；圆形校正只允许几何 fit/fill、同心缩放与 Circle 裁切。

## V2.9.76 · Build 127 稳定基线增量
- 6 套 BMCentralTheme 均为受支持内置主题；设置页与工作台共用同一渲染路径。


## V2.9.75 · Build 126 — 2026-09-06
- 合并保留近期中央高清素材仓库、SVG 三模式/缩放、GitHub 大文件 raw 回读、诊断 ZIP 首次分享修复。
- GitHub app.zip PUT 遇到 409 / does not match 时，重新读取最新远端 SHA 后安全重试 1 次；再次冲突即停止，避免错误覆盖。
- Codemagic IPA 自动回传仍按官方 Artifact API 流程并限制 2 次；404 是否解决必须由真实 Codemagic/iOS 实测确认。

## V2.9.74 · Build 125
受保护基线：仅收紧诊断 ZIP 生成/分享时序，不修改诊断包内容结构、Task Black Box、GitHub/Codemagic 编译主链、素材仓库和 Artifact 重试策略。

## V2.9.73 · Build 124
受保护基线：GitHub Actions 与 Codemagic 主编译链不重写。本版仅修改 GitHubService 的 app.zip 上传后远端读取/校验策略。

## V2.9.72 · Build 123 稳定边界
中央素材仓库与视觉层不得改写 GitHub/Codemagic 编译主链。媒体文件只保存在 Application Support，最多 30 个；异常素材不得影响任务状态机。

## V2.9.71 · Build 122 稳定基线追加
SVG 仅作为中央视觉层，不得影响编译/AI/黑匣子主链；禁止 SVG 脚本、foreignObject 与远程资源。Artifact 两次重试和立即停止为保护基线。

## V2.9.70 · Build 121

稳定边界：GitHub Actions 主链、Codemagic POST /builds 与轮询主链、Task Black Box、一键诊断包均保持冻结。仅调整 Artifact 自动重试次数/取消传播、默认写轮眼视觉几何，并移除 AI repair loop 的 sourceURL 强制解包。



## V2.9.69 · Build 120

GitHub Actions 稳定 Provider 不改；Codemagic 仅增强 Artifact 本机取消链；中央特效不触碰编译状态机。
- 修复 Codemagic IPA Artifact 重试期间“停止不立即生效”：一次停止取消当前网络请求、等待和后续重试。
- Artifact 下载阶段只停止本机抓取，不误取消已完成的云端 Build；Recovery 保留。
- cancelled 任务继续保留当前 Task 诊断入口和一键诊断 ZIP。
- 依据 Task BM-1D721A44 实测：Build119 IPA 已生成，旧链路因 Artifact URL 404 连续重试 8 次后才记录停止。
# V2.9.68 · Build 119 · 状态

- 基线：Build118 功能设计 + Build49 真实 Xcode 编译错误定点修复。
- 本版仅修改诊断 ZIP 的 DOS 时间戳计算与版本/历史文档，不重构 Provider 主链。
- 本地可验证版本一致性、Swift 语法、独立 DOS 时间函数类型检查、YAML 和 ZIP 结构；最终 iOS 全模块类型检查仍以 Codemagic/Xcode 结果为准。

# V2.9.67 · Build 118 · 状态

- 基线：Build117 功能设计 + Build118 类型错误修复与诊断 UI 收口。
- 已确认 Build117 Codemagic 真实 Xcode 编译失败根因仅为 3 个 Swift 类型错误，本版逐项修正。
- 新增纯 Swift Stored-ZIP 诊断打包器，不引入第三方库，不触碰编译 Provider 主链。
- GitHub Actions 继续作为受保护稳定 Provider。
- Build118 本地可做版本一致性、Swift parse、YAML、ZIP 结构校验；真实 Xcode 类型检查仍以云端/真机结果为最终证据。

# V2.9.66 · Build 117 · 状态

- GitHub Actions：稳定闭环，受保护，不因 Codemagic/UI 修复重构。
- Codemagic：Artifact 事实优先逻辑保持；工作台 Recovery 增加 Source SHA 隔离。
- 中央特效：同一 renderer、素材原色原则、连续角速度过渡为稳定基线。
- 清空源码：必须解绑当前工作台的 Recovery/Source 状态，但不得删除历史任务记录。

# V2.9.65 · Build 116 · 状态

- GitHub Actions：稳定受保护，本版未改主链。
- Codemagic：云端真实编译与网页 IPA 已实机验证；Build116 修正 status 与 Artifact 不同步时的客户端判定。
- Codemagic 成功事实：同一 buildId 出现有效 IPA Artifact 优先于 terminal status 文本。
- Artifact 恢复：只允许重抓原 Build，不允许因为回传失败自动重编译。

# V2.9.64 · Build 115 · 状态

**受保护稳定基线：GitHub Actions Provider。** 已验证的 GitHub 上传、Workflow、Run、Artifact 主链默认冻结；Codemagic/Bitrise/未来 Mac Agent 的修复不得通过重写 GitHubService 或 GitHub Actions 状态机实现。公共 Task Core 可以扩展，但必须保持旧 Provider 兼容。Build98/99 的 iOS 16.5 首屏稳定边界继续有效。

# V2.9.63 · Build 114 · 状态

Build114 仅调整 BUG 报告与任务黑匣子的操作入口职责，删除跨页面重复导出，不改编译/AI/Provider/Artifact/黑匣子记录主链。Build113 的中央特效所见即所得改动继续保留。

# V2.9.62 · Build 113 · 状态

- 基于 V2.9.61 Build112。
- 本版只收口中央特效视觉层：设置预览与工作台统一渲染，删除工作台固定附加特效。
- 编译/AI/Provider/Artifact/任务黑匣子主链保持冻结。
- 待真实 Xcode 编译与 iOS 16.5 实机验证。

# V2.9.61 · Build 112 · 状态

- 基线仍为 Build104 iOS 16.5 首屏稳定边界 + Build101 编译/停止状态机。
- Build111 已安装启动；6 套动态核心与 Build112 自身尚待真实 Xcode/实机验证。
- Artifact 自动回传不得在未由新版客户端真实跑通前标记为已验证。

# V2.9.60 · Build 111 · 状态

继承 Build104 首屏稳定边界、Build101 编译停止状态机、Build107 连续旋转、Build109 三套核心及 Build110 Artifact 回传恢复。本轮仅调整中央核心视觉渲染，待实机验证。

# V2.9.59 · Build 110 · 状态（Artifact 闭环待实机验证）

Build109 已由 App 内 Codemagic 真实编译成功并完成 iOS 16.5 实机安装启动。Build110 仅修改 Codemagic Artifact 下载恢复与诊断，不改变首屏重型 SwiftUI 结构、正常编译停止状态机或中央动画引擎。Build110 只有在“App 内发起 Build → Xcode 成功 → IPA 自动回到 BuildMate → 保存 IPA”全链路实机通过后，才能提升 Artifact 闭环为稳定基线。

# V2.9.58 · Build 109 · 状态（待实机验证）

Build108 已由用户实机安装运行；Build109 仅重构中央内置视觉层。继续遵守 Build104 iOS 16.5 启动稳定边界、Build101 编译/停止状态机与 Build107 连续角速度边界。Build109 未经过真实 Xcode/实机验证前，不提升稳定基线。

# V2.9.57 · Build 108 · 状态（待实机验证）

Build108 继承 Build104 启动稳定边界、Build101 编译/停止状态机及 Build107 编译链修复；本版只新增隔离的中央视觉素材层。未经过真实 Xcode/实机验证前，不提升稳定基线。

---

# V2.9.56 · Build 107 · 状态（待实机验证）

继承 Build104 iOS 16.5 启动稳定边界、Build101 编译/停止状态机，以及 Build105/106 已实机证明的 Codemagic dispatch/buildId/polling/Xcode 编译/IPA 检出主干。本版只在 Artifact 下载重定向、诊断导出 UI 与中央动画连续性上改动。

# V2.9.55 · Build 106 · 状态（待最终 Artifact 闭环实测）

Build104 已实机验证 iOS 16.5 可稳定启动；Build105 已实机验证 App 内 Codemagic 可成功创建 buildId、轮询真实云端 Build 并检测到 IPA，且第一层 Artifact URL 正规化成功。Build106 只继续修 public-url 第二层相对地址、主工作台重复编译确认与运行齿轮动画，不改变 Build104 启动稳定边界和 Build101 编译/停止状态机。

# V2.9.54 · Build 105 · 状态（待 Artifact 闭环实测）

Build104 已在 iOS 16.5 实机成功启动，任务黑匣子正常工作；App 内 Codemagic 正常编译已真实跑到云端 Build 成功并检测到 IPA，证明源码/派发/轮询链正常。Build104 唯一已确认阻塞点是 Artifact 下载。Build105 仅修改 Codemagic Artifact 下载策略和对应黑匣子检查点，继续保护 Build98/99/104 的启动稳定边界与 Build101 的编译/停止状态机。

# V2.9.53 · Build 104 · 状态（待真实 Xcode/实机验证）

Build103：Codemagic 网页端真实 Xcode 编译成功并产出 IPA，但 iOS 16.5 实机启动 STACK GUARD，故不稳定。Build104 仅针对首屏 SwiftUI 泛型树/黑匣子首屏观察做启动稳定修复，并保留 Build103 功能。当前仍以 Build101 的编译/停止实机链和 Build98/99 的启动结构原则作为不可破坏基线。

# Build103 状态（待真实 Xcode/实机验证）
Build103 本地静态检查通过后仍不宣称正式稳定。当前可确认的真实证据是：Build102 V2.9.51 已在 iOS 16.5 启动；同一 Build102 源码在 Codemagic 网页端真实编译成功；BuildMate App 内 Codemagic `unsupported URL` 可稳定复现。Build103 需重点验证 App 内 Codemagic buildId→轮询→Artifact→IPA 完整闭环和任务黑匣子。

# Stability Baseline

## 当前真实设备稳定基线
V2.9.50 · Build101：已由用户完成真实 Xcode 编译、IPA 安装与 iOS 16.5 启动验证。

已实机确认：正常编译可启动；运行中主按钮切换“停止编译”；停止成功；停止后可返回待机；编译中源码切换/清除被锁定；停止不会误删源码；源码体检后可继续编译。

## 继承的关键基线
- Build79：iOS 16.5 启动崩溃修复基线。
- Build98/99：重型 SwiftUI destination 类型擦除/首屏复杂度边界。
- Build101：编译门禁、Provider 隔离、停止状态机和源码操作收口。

## Build102 状态
Build102 本地静态检查通过不等于真实 Xcode/真机通过。安装启动、质量中心 UI、编译→停止→待机链路必须由真实设备再次确认后才能升级为 Build102 实机稳定基线。
