# Build1039 全局“去自嗨”审计

- 现行源码体检继续移除。
- 历史 SmartBuildStore.localPreflight 改为永久停用：即使旧 Agent 误调用也不会返回通过。
- 历史 BMLocalPreflightCenter 不再生成多个 passed=true 的伪门禁。
- Git Relay 历史注册项改为 disabled/unverified。
- Codemagic finished 但 IPA 未可见：workStage 改为 artifactPending，不再误标 failed。
- Codemagic finished 但 IPA 下载失败：只记录 artifactPending，不增加完整 successes。
- 只有 IPA 下载、BuildGuard 验证、持久化产物中心后才记录 success。
- Artifact 签名 URL 不再完整写入黑匣子/诊断包。
- Build1038 官方 Artifact API 主链不改：authenticated URL -> POST /public-url -> GET；签名短链仅同轮兜底。
