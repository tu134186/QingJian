#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
base=root/'BuildMate'
# Conservative source-level gate: catches duplicate named type declarations across files.
pat=re.compile(r'(?m)^(?:public\s+|internal\s+|private\s+|fileprivate\s+)?(?:final\s+)?(enum|struct|class|protocol|actor)\s+([A-Za-z_][A-Za-z0-9_]*)\b')
seen={}
for p in base.rglob('*.swift'):
    # AppSourceGenerator contains generated-app Swift source inside multiline strings; it is not BuildMate module declarations.
    if p.name == 'AppSourceGenerator.swift': continue
    text=p.read_text(errors='ignore')
    for kind,name in pat.findall(text):
        seen.setdefault(name,[]).append((kind,str(p.relative_to(root))))
# Same-name declarations in the same physical file can be nested/conditional; cross-file duplicates are the dangerous module collision.
bad={k:v for k,v in seen.items() if len({path for _,path in v})>1}
if bad:
    print('DUPLICATE TOP-LEVEL TYPE CHECK FAILED')
    for name,locs in sorted(bad.items()): print(name, ' -> ', '; '.join(f'{k}:{p}' for k,p in locs))
    sys.exit(1)
print(f'DUPLICATE TOP-LEVEL TYPE CHECK OK: {len(seen)} named declarations scanned')
