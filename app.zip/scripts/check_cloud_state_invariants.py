#!/usr/bin/env python3
from pathlib import Path
import sys
r=Path(__file__).resolve().parents[1]
cm=(r/'BuildMate/Services/CodemagicService.swift').read_text()
gh=(r/'BuildMate/Services/GitHubService.swift').read_text()
cv=(r/'BuildMate/Views/ContentView.swift').read_text()
yml=(r/'codemagic.yaml').read_text()
diag=(r/'BuildMate/Models/DiagnosticPackageBuilder.swift').read_text()
checks=[
('Codemagic v3 authoritative status', 'https://codemagic.io/api/v3/builds/' in cm and 'authoritativeStatus' in cm),
('network error != business terminal', 'network_unknown' in cm and 'networkFailures' in cm),
('persistent Run + restart recovery', 'CodemagicRunRecoveryStore.save' in cv and 'resumePendingCodemagicRunIfNeeded' in cv),
('Build/Artifact state separation', 'BMArtifactAuthority' in (r/'BuildMate/Models/CodemagicRunRecovery.swift').read_text() and 'final.succeeded' in cv),
('terminal before Artifact', '["failed", "canceled", "timeout", "skipped"]' in cv),
('no duplicate cloud builds', 'kind == .source || kind == .artifact' in cv and '!run.isBuildTerminal' in cv),
('GitHub weak-network handling', 'waitsForConnectivity = true' in gh and 'readGETAllow404' in gh),
('Git Relay explicit secret + per-task branch', 'BUILDMATE_RELAY_GITHUB_TOKEN' in yml and 'buildmate-git-binary-relay-v2' in yml and 'buildmate-relay/\\(blackBoxTaskID.lowercased())' in cv),
('diagnostics + runtime/target evidence', 'runtime.target' in cv and '09-恢复记录.txt' in diag),
('embedded Codemagic workflow includes relay', 'buildmate-git-binary-relay-v2' in (r/'BuildMate/Models/CodemagicWorkflowTemplate.swift').read_text()),
]
failed=[]
for i,(name,ok) in enumerate(checks,1):
    print(f'{i:02d}. {"OK" if ok else "FAIL"} - {name}')
    if not ok: failed.append(name)
if failed:
    print('CLOUD STATE INVARIANTS FAILED:', ', '.join(failed)); sys.exit(1)
print('CLOUD STATE INVARIANTS OK: 10/10')
