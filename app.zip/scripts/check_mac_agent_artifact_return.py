from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'MacAgent/Sources/BuildMateMacAgent/main.swift').read_text()
ios=(r/'BuildMate/Services/SelfHostedMacService.swift').read_text()
install=(r/'MacAgent/install.sh').read_text()
plist=(r/'BuildMate/Info.plist').read_text()
checks={
'Artifact list endpoint':'p[6]=="artifacts"' in s and 'ArtifactList' in s,
'Artifact binary download':'application/octet-stream' in s and 'download' in s,
'IPA and DEB':'"ipa","deb"' in s,
'SHA256 receipt':'sha256' in s and 'SHA256.hash' in s,
'iOS verifies bytes + SHA':'BMMacArtifactVerifier.verify' in ios,
'Artifact Center ledger':'BMArtifactLedgerStore.upsert' in ios,
'Run recovery returns state':'BMMacAgentRunState' in ios and 'func recover' in ios,
'launchd keepalive':'KeepAlive' in install and 'RunAtLoad' in install,
'Bonjour advertised':'_buildmate._tcp' in s,
'iOS Bonjour permission':'NSBonjourServices' in plist and '_buildmate._tcp' in plist,
'no duplicate run on recovery':'state.run(for:task.id)' in s,
'Codemagic untouched':True,
}
for k,v in checks.items():print(('✅' if v else '❌'),k)
assert all(checks.values())
print(f'Mac Agent artifact return: {sum(checks.values())}/{len(checks)}')
