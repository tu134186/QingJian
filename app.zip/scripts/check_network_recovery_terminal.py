from pathlib import Path
root=Path(__file__).resolve().parents[1]
c=(root/'BuildMate/Views/ContentView.swift').read_text()
s=(root/'BuildMate/Services/CodemagicService.swift').read_text()
work=(root/'BuildMate/Views/BMWorkStatusViews.swift').read_text()
checks=[
('resume timer uses createdAt','workStartedAt = recovery.createdAt' in c),
('network polling cap','maxConsecutiveNetworkFailures' in s and '已暂停主动轮询' in s),
('network error not compile failure','network.polling.paused' in c),
('terminal recovery checkpoint clear','recovery.terminal.' in c and 'CodemagicRunRecoveryStore.clear()' in c),
('main terminal checkpoint clear','远端终态已经确认' in c),
('finished separates artifact recovery','Run Recovery 不再负责恢复' in c),
('manual resync button','Text("重新同步")' in work),
('same run promise','不会新建编译' in c),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL'), name)
if not all(ok for _,ok in checks): raise SystemExit(1)
print(f'network recovery terminal: {sum(ok for _,ok in checks)}/{len(checks)}')
