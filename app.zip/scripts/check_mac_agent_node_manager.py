from pathlib import Path
checks = {
"node manager model": "BMMacAgentNodeManager" in Path("BuildMate/Models/MacAgentNodeManager.swift").read_text(),
"scheduler": "BMMacAgentScheduler" in Path("BuildMate/Models/MacAgentNodeManager.swift").read_text(),
"capacity score": "freeSlots * 100" in Path("BuildMate/Models/MacAgentNodeManager.swift").read_text(),
"node UI": "struct MacAgentNodesView" in Path("BuildMate/Views/MacAgentNodesView.swift").read_text(),
"heartbeat refresh": "discoverCapabilities" in Path("BuildMate/Models/MacAgentNodeManager.swift").read_text() and "heartbeat" in Path("BuildMate/Models/MacAgentNodeManager.swift").read_text(),
"manual selection": "BMMacAgentSelectionStore" in Path("BuildMate/Models/MacAgentNodeManager.swift").read_text(),
"core navigation": "MacAgentNodesView" in Path("BuildMate/Views/PlatformCoreCenterView.swift").read_text(),
"compiler navigation": "MacAgentNodesView" in Path("BuildMate/Views/CompilerPlatformsView.swift").read_text(),
"no duplicate run policy": "不会因为断线创建第二个云编译任务" in Path("BuildMate/Views/MacAgentNodesView.swift").read_text(),
"secret boundary": "Token 仅存 Keychain" in Path("BuildMate/Views/MacAgentNodesView.swift").read_text(),
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(("PASS" if v else "FAIL"), k)
print(f"Mac Agent node manager: {len(checks)-len(failed)}/{len(checks)}")
raise SystemExit(1 if failed else 0)
