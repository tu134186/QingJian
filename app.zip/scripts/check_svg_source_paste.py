from pathlib import Path
root=Path(__file__).resolve().parents[1]
c=(root/'BuildMate/Views/BMCentralEffectSettingsView.swift').read_text()
m=(root/'BuildMate/Views/CentralEffectMedia.swift').read_text()
store=(root/'BuildMate/Services/SVGSourceStore.swift').read_text()
checks=[
 ('SVG source paste UI','直接粘贴 SVG 代码' in c and '从剪贴板粘贴' in c),
 ('source validator','inspect(text:' in m and 'SVG 代码不完整' in m),
 ('atomic svg write','BMSVGSourceStore.save' in c and 'data.write(to: destination, options: [.atomic])' in store),
 ('no PNG conversion','Pasted-SVG-' in store and '.svg"' in store),
 ('dynamic mode','customMotionMode = .intrinsic' in c),
 ('security filter','<script' in m and '<foreignobject' in m and 'javascript:' in m),
]
failed=[name for name,ok in checks if not ok]
if failed:
    raise SystemExit('SVG SOURCE PASTE FAILED: '+', '.join(failed))
print(f'SVG SOURCE PASTE OK: {len(checks)}/{len(checks)}')
