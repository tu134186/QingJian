#!/usr/bin/env python3
from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
errors=[]
project=(root/"project.yml").read_text()
vm=re.search(r"(?m)^\s*MARKETING_VERSION:\s*([^\s#]+)\s*$", project)
bm=re.search(r"(?m)^\s*CURRENT_PROJECT_VERSION:\s*(\d+)\s*$", project)
if not vm: errors.append("project.yml MARKETING_VERSION")
if not bm: errors.append("project.yml CURRENT_PROJECT_VERSION")
if errors:
    print("RELEASE VERSION CHECK FAILED:", ", ".join(errors)); sys.exit(1)
version=vm.group(1); build=bm.group(1); tag="V"+version
about=(root/"BuildMate/Views/AboutView.swift").read_text()
release_block=re.search(r"(?:private\s+)?let\s+buildMateReleases[^=]*=\s*\[([\s\S]*?)\]", about)
if not release_block:
    errors.append("AboutView release list")
else:
    first=re.search(r"\.init\(\s*version:\s*\"([^\"]+)\"\s*,\s*build:\s*(\d+)", release_block.group(1))
    if not first or first.group(1)!=tag or first.group(2)!=build:
        errors.append("AboutView current release")
# Documentation version mismatch should not block release builds.
# These files are informational only.
for name in ["CHANGELOG.md","DEVELOPMENT.md","PROJECT_HISTORY.md","README.md"]:
    text=(root/name).read_text()
    if tag not in text or f"Build {build}" not in text:
        print(f"RELEASE VERSION WARNING: {name} is not synchronized")

if errors:
    print("RELEASE VERSION CHECK FAILED:", ", ".join(errors)); sys.exit(1)
print(f"RELEASE VERSION CHECK OK: {tag} · Build {build}")
