from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'MacAgent/Sources/BuildMateMacAgent/main.swift').read_text()
checks={
'Swift Package':(r/'MacAgent/Package.swift').exists(),
'handshake':'/buildmate/v1/handshake' in s,
'heartbeat':'/buildmate/v1/heartbeat' in s,
'task dispatch':'/buildmate/v1/tasks' in s,
'run recovery':'runs' in s and 'RunState' in s,
'token auth':'Bearer' in s and 'BUILDMATE_AGENT_TOKEN' in s,
'no arbitrary command field':'command:String' not in s and 'shellCommand' not in s,
'project build hook':'scripts/build-mac-agent.sh' in s,
'local persistence':'Application Support/BuildMateAgent' in s,
'installer':(r/'MacAgent/install.sh').exists(),
}
for k,v in checks.items(): print(('✅' if v else '❌'),k)
assert all(checks.values())
print(f'Mac Agent server: {sum(checks.values())}/{len(checks)}')
