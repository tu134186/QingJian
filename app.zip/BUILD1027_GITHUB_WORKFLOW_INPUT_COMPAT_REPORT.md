# Build1027 GitHub Actions Workflow 输入兼容修复

- 症状：GitHub API 返回 HTTP 422 `Unexpected inputs provided`，Run ID 为空。
- 根因：APP 新版派发 `expected_source_sha256 / expected_source_bytes / source_name / expected_head_sha`，而用户仓库中的旧版 `buildmate.yml` 只声明较少 inputs。
- 修复：完整 inputs 优先；只在 GitHub 明确返回 unknown/unexpected inputs 的 422 时回退到 `mode`；若极老 workflow 连 `mode` 都未声明，再使用空 inputs。
- 安全性：422 dispatch 不创建 Run，所以兼容回退不会重复触发编译。
