# Build 1063 · Codemagic 官方 DEB Artifact 收口

- 唯一回程仍为 Codemagic 官方 Build ID + Artifact API。
- 不恢复 Git Relay，不 git push，不扫描源码目录。
- Codemagic 若把 `.deb` 收入官方 `{project}_{build}_artifacts.zip`，BuildMate 直接下载该官方 ZIP，并只从其中提取本次 `.deb/.ipa`。
- IPA 仍按官方独立 IPA Artifact 获取。
- BuildMate/main 继续作为统一编译仓库；导入 ZIP 决定 Xcode/Theos。
