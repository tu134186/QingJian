# BuildMate V5.1.2 · Build 318 — 内测员导航卡顿热修

## 真机问题
Build317 在 AI 内测员开启时，从任务列表进入任务详情有可感知卡顿。根因集中在主线程导航转场期间的触摸后全量 UI 树重采样和完整视觉/Accessibility 审计。

## 本版最小修复
1. touch-ended 合并观察延迟从 180ms 调整到 700ms。
2. touch-ended 观察仍更新页面、fingerprint、ActionContract/被动推断，但跳过完整 BMTesterVisualRuntimeAuditor 审计。
3. 未映射触摸的关系图/语义兜底捕获从 240ms 调整到 700ms，避开 push 动画。
4. 不改变 sendEvent 原始分发顺序，不安装 Gesture/Overlay，不改变 hit-testing，不自动点击/滚动。
5. Build316 Accessibility Identity 和 Build317 UIKit 类型修复完整保留。

## 目标
先把 Build317 真机“点任务卡片→任务详情”的转场卡顿压下去；下一大版再做识别率与后台调度架构升级。
