# Build1055 Workbench / Sheet / Central Motion

- 四宫格按钮间距从 8pt 提升为 14pt，中间核心留白增大。
- 中央素材本体可点击，打开统一可下滑关闭 Sheet；设置首页不再重复提供中央特效入口。
- 云端运行由外部 UIApplication.open 改为应用内 SFSafariViewController Sheet。
- 开始编译、产物中心、报告、中央素材、云端运行统一为可下滑关闭的 Sheet 交互。
- 高速阶段切入待机/终态时使用约 2.35 秒缓动减速，其余降速 1.45 秒，避免“急刹”。
- 编译与产物回传核心冻结。
