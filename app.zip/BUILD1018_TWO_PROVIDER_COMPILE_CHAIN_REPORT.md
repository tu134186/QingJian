# Build1018 · Two Provider Compile Chain

- 正式编译平台只保留 GitHub Actions 与 Codemagic。
- GitHub Actions 恢复为手动可选正式编译链：上传并校验 app.zip → workflow_dispatch → 绑定本次 Run → 读取报告/Artifact。
- Codemagic 保持当前主编译链。
- 删除设置页“平台总览”和旧“云编译控制台”入口，统一为一个“编译平台”页面。
- Bitrise / 自托管 Mac 仅保留源码兼容类型，不进入 UI、不被自动选择、不参与正式调度。
- 禁止自动跨平台切换。
- GitHub/Codemagic 最终统一进入现有产物管理与黑匣子记录。
