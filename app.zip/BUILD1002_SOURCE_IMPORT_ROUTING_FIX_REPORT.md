# Build1002 Source Import Routing Fix

- Normal source card import: select/persist source only; does NOT open ExistingAppTakeoverView.
- Explicit Development Hub "导入 App": sets takeover intent before opening picker; successful import opens ExistingAppTakeoverView.
- Picker cancel/error clears takeover intent to prevent sticky routing.
- No changes to Creator, Agent, cloud approval, task black box, or existing takeover feature itself.
