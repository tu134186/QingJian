# Build1046 · Codemagic 启动结果安全确认

- 实机证据：BM-4BCC8A09 在 `POST /builds` 后约 30 秒返回 `cannot parse response`。
- 根因边界：客户端无法解析响应，不等于服务端一定没有创建 Build。
- 修复：将 timeout、cannot parse response、connection lost 等归为“启动结果不确定”。
- 安全策略：不自动再次 POST；先用 Task ID + Source SHA 只读反查最近 Builds，找到则接管原 Build；找不到则停止并要求用户确认云端后手动重试。
- 冻结保护：未修改 codemagic.yaml、Artifact Return Bridge、IPA/DEB 回传、GitHub Actions 工作流。
