# Build1040 Codemagic Artifact Redirect Transport Rewrite

- 基线：V7.4.11 · Build1039
- 新版本：V7.4.12 · Build1040
- 实机证据：Build1039 已拿到正确 `https://api.codemagic.io/artifacts/.../*.ipa` 稳定地址，但所有下载路线在 iOS 16.5 进入重定向后统一报 NSURLErrorUnsupportedURL(-1002)，旧错误日志甚至丢失失败 URL path。
- 处理：彻底删除 Artifact GET 的 no-redirect + 手工逐跳新建 URLSession 方案。
- 新链：一个 ephemeral URLSession 负责完整重定向链；redirect delegate 只对 Location 做 http/https 约束与相对地址解析。
- 安全：x-auth-token 只保留在 api.codemagic.io，进入公共签名/CDN 主机立即移除。
- 诊断：-1002 时记录脱敏失败 host/地址类型，避免再出现“路径为空”的无效证据。
- 行为约束：单次用户动作仍只有 1 轮 Artifact 获取，不 sleep、不自动二次重抓、不新建云 Build。
