# Build1001 Home Layout Closure

- Baseline: V7.0.0 Build1000
- Result: 首页恢复经典排版。
- Home tab now renders: Hero → Project → Source → Action Workbench → Current Run (when applicable).
- Creator / Import Existing App / Continue Task moved to Development Hub only.
- No duplicate journey card remains on Home.
- Core AI/compile/task architecture unchanged.
