#!/bin/zsh
set -euo pipefail
launchctl bootout "gui/$(id -u)/com.tu.buildmate.macagent" >/dev/null 2>&1 || true
rm -f "$HOME/Library/LaunchAgents/com.tu.buildmate.macagent.plist" "$HOME/.local/bin/buildmate-mac-agent"
echo "BuildMate Mac Agent 已停止并移除程序；任务/日志/Token 数据保留。"
