// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "BuildMateMacAgent",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "buildmate-mac-agent", targets: ["BuildMateMacAgent"])],
    targets: [.executableTarget(name: "BuildMateMacAgent")]
)
