# BuildMate Mac Agent · Build162

私人 Mac 编译节点。`install.sh` 会编译 Agent、生成随机 Token、安装 LaunchAgent 并后台常驻。

项目若提供 `scripts/build-mac-agent.sh`，应把 IPA/DEB 写入 `$BUILDMATE_ARTIFACT_DIR`。Agent 也会在构建后扫描源码目录中的 IPA/DEB 并复制到该目录。

接口：handshake、heartbeat、task dispatch、原 Run state recovery、artifact list、artifact binary download。Artifact receipt 包含 bytes 与 SHA256。

Bonjour 服务类型：`_buildmate._tcp`。Token 文件：`~/Library/Application Support/BuildMateAgent/token`，不要提交、截图或写入诊断。
