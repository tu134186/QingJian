#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
echo "== BuildMate Mac Agent Build162 =="
command -v swift >/dev/null || { echo "需要安装 Xcode / Swift"; exit 1; }
swift build -c release
mkdir -p "$HOME/.local/bin" "$HOME/Library/LaunchAgents" "$HOME/Library/Application Support/BuildMateAgent"
cp .build/release/buildmate-mac-agent "$HOME/.local/bin/buildmate-mac-agent"
TOKEN_FILE="$HOME/Library/Application Support/BuildMateAgent/token"
if [ ! -f "$TOKEN_FILE" ]; then
  TOKEN="$(openssl rand -hex 32)"
  umask 077; printf '%s' "$TOKEN" > "$TOKEN_FILE"
fi
TOKEN="$(cat "$TOKEN_FILE")"
PLIST="$HOME/Library/LaunchAgents/com.tu.buildmate.macagent.plist"
cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>com.tu.buildmate.macagent</string>
<key>ProgramArguments</key><array><string>$HOME/.local/bin/buildmate-mac-agent</string></array>
<key>EnvironmentVariables</key><dict><key>BUILDMATE_AGENT_TOKEN</key><string>$TOKEN</string><key>BUILDMATE_AGENT_PORT</key><string>8765</string></dict>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>StandardOutPath</key><string>$HOME/Library/Application Support/BuildMateAgent/agent.stdout.log</string>
<key>StandardErrorPath</key><string>$HOME/Library/Application Support/BuildMateAgent/agent.stderr.log</string>
</dict></plist>
PLIST
launchctl bootout "gui/$(id -u)/com.tu.buildmate.macagent" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
echo "已安装并后台常驻: $HOME/.local/bin/buildmate-mac-agent"
echo "Bonjour 服务: _buildmate._tcp · 端口 8765"
echo "配对 Token 保存在: $TOKEN_FILE（不要写入源码/日志/截图）"
