import Foundation
import Network
import CryptoKit

let protocolVersion = "buildmate-mac-agent-v1"
let agentVersion = "1.2.0-build165"
let env = ProcessInfo.processInfo.environment
let port = UInt16(env["BUILDMATE_AGENT_PORT"] ?? "8765") ?? 8765
let token = env["BUILDMATE_AGENT_TOKEN"] ?? ""
let root = URL(fileURLWithPath: env["BUILDMATE_AGENT_ROOT"] ?? (NSHomeDirectory() + "/Library/Application Support/BuildMateAgent"), isDirectory: true)
try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)

struct Capability: Codable { let id:String; let value:String }
struct Handshake: Codable { let protocolVersion:String; let nodeID:String; let nodeName:String; let agentVersion:String; let macOSVersion:String; let xcodeVersions:[String]; let capabilities:[Capability]; let maxConcurrentTasks:Int }
struct Heartbeat: Codable { let protocolVersion:String; let nodeID:String; let state:String; let activeTaskIDs:[String]; let freeDiskBytes:Int64?; let sentAt:Date }
struct TaskEnvelope: Codable { let id:String; let workspaceID:String; let sourceSHA256:String; let sourceLocator:String; let branch:String; let requestedXcode:String?; let artifactKinds:[String]; let checkpointToken:String? }
struct RunReceipt: Codable { let protocolVersion:String; let taskID:String; let nodeID:String; let runID:String; let acceptedSourceSHA256:String; let acceptedAt:Date }
struct RunState: Codable { let protocolVersion:String; let taskID:String; let runID:String; let state:String; let exitCode:Int32?; let logPath:String; let updatedAt:Date }
struct ArtifactReceipt: Codable { let protocolVersion:String; let taskID:String; let runID:String; let artifactID:String; let fileName:String; let bytes:Int64; let sha256:String }
struct ArtifactList: Codable { let protocolVersion:String; let taskID:String; let runID:String; let artifacts:[ArtifactReceipt] }

final class State {
    let lock=NSLock(); private var active:[String:String]=[:]
    func snapshot()->[String]{lock.lock();defer{lock.unlock()};return Array(active.keys)}
    func run(for task:String)->String?{lock.lock();defer{lock.unlock()};return active[task]}
    func put(_ task:String,_ run:String){lock.lock();active[task]=run;lock.unlock()}
    func remove(_ task:String){lock.lock();active.removeValue(forKey:task);lock.unlock()}
}
let state=State()

func shell(_ args:[String])->String { let p=Process();p.executableURL=URL(fileURLWithPath:"/usr/bin/env");p.arguments=args;let pipe=Pipe();p.standardOutput=pipe;p.standardError=pipe;try? p.run();p.waitUntilExit();return String(data:pipe.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8)?.trimmingCharacters(in:.whitespacesAndNewlines) ?? "" }
func nodeID()->String { let host=Host.current().localizedName ?? "mac";return String(SHA256.hash(data:Data(host.utf8)).map{String(format:"%02x",$0)}.joined().prefix(16)) }
func xcodes()->[String]{let v=shell(["xcodebuild","-version"]);return v.isEmpty ? []:[v.replacingOccurrences(of:"\n",with:" · ")]}
func json<T:Encodable>(_ v:T)->Data{let e=JSONEncoder();e.dateEncodingStrategy = .iso8601;return (try? e.encode(v)) ?? Data("{}".utf8)}
func decode<T:Decodable>(_ t:T.Type,_ d:Data)->T?{let x=JSONDecoder();x.dateDecodingStrategy = .iso8601;return try? x.decode(t,from:d)}
func safe(_ s:String)->String{s.filter{$0.isLetter || $0.isNumber || "-_.".contains($0)}}
func sha256(_ url:URL)->String?{guard let d=try? Data(contentsOf:url) else{return nil};return SHA256.hash(data:d).map{String(format:"%02x",$0)}.joined()}
func response(_ code:Int,_ data:Data,_ type:String="application/json")->Data{let reason=[200:"OK",202:"Accepted",400:"Bad Request",401:"Unauthorized",404:"Not Found"][code] ?? "Error";var h="HTTP/1.1 \(code) \(reason)\r\nContent-Type: \(type)\r\nContent-Length: \(data.count)\r\nConnection: close\r\n\r\n";var out=Data(h.utf8);out.append(data);return out}
func taskDir(_ task:String)->URL{root.appendingPathComponent("tasks/\(safe(task))",isDirectory:true)}
func artifactDir(_ task:String,_ run:String)->URL{taskDir(task).appendingPathComponent("artifacts/\(safe(run))",isDirectory:true)}

func discover_build_target(_ source:URL)->(String,String?){
    let fm=FileManager.default
    if fm.fileExists(atPath:source.appendingPathComponent("scripts/build-mac-agent.sh").path){return ("customScript",nil)}
    let items=(try? fm.contentsOfDirectory(at:source,includingPropertiesForKeys:nil)) ?? []
    if let w=items.first(where:{$0.pathExtension=="xcworkspace"}){return ("workspace",w.lastPathComponent)}
    if let p=items.first(where:{$0.pathExtension=="xcodeproj"}){return ("project",p.lastPathComponent)}
    if fm.fileExists(atPath:source.appendingPathComponent("project.yml").path){return ("xcodegen",nil)}
    if fm.fileExists(atPath:source.appendingPathComponent("Makefile").path){return ("theos",nil)}
    return ("unknown",nil)
}
func extract_diagnostics(_ log:URL)->[[String:Any]]{
    guard let text=try? String(contentsOf:log) else{return []}
    let rx=try? NSRegularExpression(pattern:#"^(.+?):([0-9]+):([0-9]+):\s*(error|warning):\s*(.+)$"#,options:.anchorsMatchLines)
    guard let rx else{return []};let ns=text as NSString
    return rx.matches(in:text,range:NSRange(location:0,length:ns.length)).prefix(80).map{m in
        ["file":ns.substring(with:m.range(at:1)),"line":Int(ns.substring(with:m.range(at:2))) ?? 0,"column":Int(ns.substring(with:m.range(at:3))) ?? 0,"severity":ns.substring(with:m.range(at:4)),"message":ns.substring(with:m.range(at:5))]
    }
}
func writeBuildManifest(task:TaskEnvelope,runID:String,log:URL,source:URL,artifacts:URL){
    let target=discover_build_target(source);let d=extract_diagnostics(log)
    let obj:[String:Any]=["schema":"buildmate-mac-build-manifest-v1","taskID":task.id,"runID":runID,"sourceSHA256":task.sourceSHA256,"projectKind":target.0,"projectPath":target.1 ?? "","requestedXcode":task.requestedXcode ?? "","artifactKinds":task.artifactKinds,"diagnostics":d,"createdAt":ISO8601DateFormatter().string(from:Date())]
    if let data=try? JSONSerialization.data(withJSONObject:obj,options:[.prettyPrinted,.sortedKeys]){try? data.write(to:artifacts.appendingPathComponent("build-manifest.json"),options:.atomic)}
}

func artifactReceipts(taskID:String,runID:String)->[ArtifactReceipt]{
    let dir=artifactDir(taskID,runID);guard let files=try? FileManager.default.contentsOfDirectory(at:dir,includingPropertiesForKeys:[.fileSizeKey],options:[.skipsHiddenFiles]) else{return []}
    return files.filter{["ipa","deb"].contains($0.pathExtension.lowercased())}.compactMap{u in
        guard let size=(try? u.resourceValues(forKeys:[.fileSizeKey]).fileSize).map(Int64.init),let hash=sha256(u) else{return nil}
        let aid=String(SHA256.hash(data:Data((taskID+"|"+runID+"|"+u.lastPathComponent+"|"+hash).utf8)).map{String(format:"%02x",$0)}.joined().prefix(24))
        return ArtifactReceipt(protocolVersion:protocolVersion,taskID:taskID,runID:runID,artifactID:aid,fileName:u.lastPathComponent,bytes:size,sha256:hash)
    }
}

func execute(_ task:TaskEnvelope,runID:String){
    DispatchQueue.global(qos:.utility).async{
        let dir=taskDir(task.id);try? FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        let artifacts=artifactDir(task.id,runID);try? FileManager.default.createDirectory(at:artifacts,withIntermediateDirectories:true)
        let log=dir.appendingPathComponent("\(safe(runID)).log"),status=dir.appendingPathComponent("\(safe(runID)).json")
        func save(_ st:String,_ code:Int32?=nil){try? json(RunState(protocolVersion:protocolVersion,taskID:task.id,runID:runID,state:st,exitCode:code,logPath:log.path,updatedAt:Date())).write(to:status,options:.atomic)}
        save("running")
        let q: (String) -> String = {"'"+$0.replacingOccurrences(of:"'",with:"'\\''")+"'"}
        let script="""
        set -euo pipefail
        cd \(q(dir.path))
        rm -rf source
        git clone --depth 1 --branch \(q(task.branch)) \(q(task.sourceLocator)) source
        cd source
        if [ -f project.yml ] && command -v xcodegen >/dev/null 2>&1; then xcodegen generate; fi
        export BUILDMATE_TASK_ID=\(q(task.id))
        export BUILDMATE_RUN_ID=\(q(runID))
        export BUILDMATE_SOURCE_SHA256=\(q(task.sourceSHA256))
        export BUILDMATE_ARTIFACT_DIR=\(q(artifacts.path))
        mkdir -p "$BUILDMATE_ARTIFACT_DIR"
        if [ -x ./scripts/build-mac-agent.sh ]; then ./scripts/build-mac-agent.sh
        elif [ -d "$(find . -maxdepth 1 -name '*.xcworkspace' -print -quit)" ]; then xcodebuild -workspace "$(find . -maxdepth 1 -name '*.xcworkspace' -print -quit)" -list
        elif [ -d "$(find . -maxdepth 1 -name '*.xcodeproj' -print -quit)" ]; then xcodebuild -project "$(find . -maxdepth 1 -name '*.xcodeproj' -print -quit)" -list
        else echo 'BuildMate Agent: no build-mac-agent.sh or Xcode project found'; exit 2; fi
        find . -maxdepth 8 -type f \\( -name '*.ipa' -o -name '*.deb' \\) -exec cp -n {} "$BUILDMATE_ARTIFACT_DIR/" \\; 2>/dev/null || true
        """
        let p=Process();p.executableURL=URL(fileURLWithPath:"/bin/zsh");p.arguments=["-lc",script];FileManager.default.createFile(atPath:log.path,contents:nil);let fh=try? FileHandle(forWritingTo:log);p.standardOutput=fh;p.standardError=fh
        do{try p.run();p.waitUntilExit();try? fh?.close();save(p.terminationStatus==0 ? "finished":"failed",p.terminationStatus)}catch{try? fh?.write(Data("\n\(error)".utf8));try? fh?.close();save("failed",127)}
        writeBuildManifest(task:task,runID:runID,log:log,source:dir.appendingPathComponent("source"),artifacts:artifacts)
        state.remove(task.id)
    }
}

func handle(_ raw:Data)->Data{
    guard let split=raw.range(of:Data("\r\n\r\n".utf8)),let head=String(data:raw[..<split.lowerBound],encoding:.utf8) else{return response(400,Data("{}".utf8))}
    let body=Data(raw[split.upperBound...]);let lines=head.components(separatedBy:"\r\n");let first=lines.first?.split(separator:" ") ?? [];guard first.count>=2 else{return response(400,Data("{}".utf8))}
    let method=String(first[0]),path=String(first[1]);let auth=lines.first{$0.lowercased().hasPrefix("authorization:")}?.split(separator:":",maxSplits:1).last?.trimmingCharacters(in:.whitespaces) ?? ""
    if !token.isEmpty && auth != "Bearer \(token)"{return response(401,Data("{\"error\":\"unauthorized\"}".utf8))}
    let id=nodeID()
    if method=="GET" && path=="/buildmate/v1/handshake"{return response(200,json(Handshake(protocolVersion:protocolVersion,nodeID:id,nodeName:Host.current().localizedName ?? "Mac",agentVersion:agentVersion,macOSVersion:ProcessInfo.processInfo.operatingSystemVersionString,xcodeVersions:xcodes(),capabilities:[.init(id:"xcodebuild",value:"true"),.init(id:"git",value:"true"),.init(id:"task-recovery",value:"true"),.init(id:"artifact-return",value:"ipa,deb"),.init(id:"bonjour",value:"_buildmate._tcp")],maxConcurrentTasks:1)))}
    if method=="GET" && path=="/buildmate/v1/heartbeat"{let a=state.snapshot();let free=(try? root.resourceValues(forKeys:[.volumeAvailableCapacityForImportantUsageKey]).volumeAvailableCapacityForImportantUsage).flatMap{Int64($0)};return response(200,json(Heartbeat(protocolVersion:protocolVersion,nodeID:id,state:a.isEmpty ? "在线":"忙碌",activeTaskIDs:a,freeDiskBytes:free,sentAt:Date())))}
    if method=="POST" && path=="/buildmate/v1/tasks",let task=decode(TaskEnvelope.self,body){if let run=state.run(for:task.id){return response(200,json(RunReceipt(protocolVersion:protocolVersion,taskID:task.id,nodeID:id,runID:run,acceptedSourceSHA256:task.sourceSHA256,acceptedAt:Date())))};let run="MAC-"+UUID().uuidString.uppercased();state.put(task.id,run);execute(task,runID:run);return response(202,json(RunReceipt(protocolVersion:protocolVersion,taskID:task.id,nodeID:id,runID:run,acceptedSourceSHA256:task.sourceSHA256,acceptedAt:Date())))}
    let p=path.split(separator:"/").map(String.init)
    if method=="GET",p.count==6,p[0]=="buildmate",p[1]=="v1",p[2]=="tasks",p[4]=="runs"{let f=taskDir(p[3]).appendingPathComponent("\(safe(p[5])).json");if let d=try? Data(contentsOf:f){return response(200,d)};if state.run(for:p[3])==p[5]{return response(200,json(RunState(protocolVersion:protocolVersion,taskID:p[3],runID:p[5],state:"running",exitCode:nil,logPath:"",updatedAt:Date())))}}
    if method=="GET",p.count==7,p[0]=="buildmate",p[1]=="v1",p[2]=="tasks",p[4]=="runs",p[6]=="artifacts"{return response(200,json(ArtifactList(protocolVersion:protocolVersion,taskID:p[3],runID:p[5],artifacts:artifactReceipts(taskID:p[3],runID:p[5]))))}
    if method=="GET",p.count==9,p[0]=="buildmate",p[1]=="v1",p[2]=="tasks",p[4]=="runs",p[6]=="artifacts",p[8]=="download"{if let receipt=artifactReceipts(taskID:p[3],runID:p[5]).first(where:{$0.artifactID==p[7]}){let u=artifactDir(p[3],p[5]).appendingPathComponent(receipt.fileName);if let d=try? Data(contentsOf:u){return response(200,d,"application/octet-stream")}}}
    return response(404,Data("{\"error\":\"not_found\"}".utf8))
}

guard let nwPort=NWEndpoint.Port(rawValue:port) else{fatalError("invalid port")}
let listener=try NWListener(using:.tcp,on:nwPort)
listener.service=NWListener.Service(name:"BuildMate-\(Host.current().localizedName ?? "Mac")",type:"_buildmate._tcp")
listener.newConnectionHandler={c in c.start(queue:.global());c.receive(minimumIncompleteLength:1,maximumLength:8_000_000){data,_,_,_ in let out=handle(data ?? Data());c.send(content:out,completion:.contentProcessed{_ in c.cancel()})}}
listener.start(queue:.main)
print("BuildMate Mac Agent \(agentVersion) listening on 0.0.0.0:\(port) · Bonjour _buildmate._tcp")
print("Root: \(root.path) · Token: \(token.isEmpty ? "未设置（仅建议可信局域网临时测试）":"已启用")")
dispatchMain()
