# Build1045 功能收口报告

- 版本：V7.4.17 · Build 1045
- 基线：Build1044（已编译成功）
- 保护区：Codemagic → IPA / DEB 编译、publishing、Artifact Return Bridge 不改。
- 备份：ZIP/.bmbak 直接识别；恢复前预览；白名单迁移；旧 AI/中枢/自动调度/Bitrise 数据忽略；旧 Codemagic workflow 迁移；恢复前快照与回滚。
- UI：关于页与版本更新页减法；技术流水账退出普通界面。
- GitHub Actions：Billing API 只读用量展示；优先官方 included_minutes，Enhanced Billing 无额度时只显示已用，不猜剩余。
- 自托管 Mac：继续仅预留，不自动参与调度。
