# Build252 Source Generation & State Convergence Report

Release: V3.6.1 Build 252
Date: 2026-09-09

## Fixed
- New source import / Creator generation creates a new Source Generation ID, even when SHA-256 is identical.
- Old active unified tasks are archived/cancelled as superseded and kept only as historical black-box evidence.
- Current homepage inline Agent panel requires both Source SHA and Source Generation to match.
- Terminal completed/failed/cancelled historical tasks are no longer injected into the new source homepage.
- Old Patch diff, cloud approval lease, duplicate confirmation, diagnostic context and Agent repair context are cleared on source replacement.
- Cloud approval and resumed validation compile require both Source SHA and Source Generation to match.
- Provider child failure no longer terminal-closes a parent task that has already entered diagnostic/AI repair flow.
- Manual ZIP import and Creator/automatic code generation share the same atomic source lifecycle boundary.

## Validation
- Release version consistency: PASS
- Build252 source-generation regression gate: 12/12 PASS
- Unified Task Pipeline: 8/8 PASS
- Task Execution Coordinator: 9/9 PASS
- Autonomous Development Loop: 10/10 PASS
- Build246 diagnostic handoff regression: PASS
- Build167 Xcode blocker regression: 7/7 PASS
- Full Swift syntax parse: PASS

Historical version-specific scripts for Build249/250/251 contain hard-coded old release numbers and therefore are not used as current-release version gates; their underlying functional regressions are covered by current shared gates and Build252 checks.
