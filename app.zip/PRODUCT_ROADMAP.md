## V3.4.0 · Build 246 — Agent 确定性失败证据交接 + Creator 完整体收口

- 修复连续实测中 Codemagic failed 后 repair-context 无法被 BuildMate 取得的问题：Xcode step 先生成并落盘诊断，再正常结束该 step；独立终态 step 最后恢复原始 Xcode 非零退出码。
- 新增 `.codemagic/xcode-exit-status` 证据 Artifact；保留 repair-context、compile-errors、Export Artifact、Direct Relay、receipt Relay 多通道。
- 不改变安全原则：没有真实编译错误和源码片段时 Agent 不允许猜 Patch，不自动创建第二次云编译。
- Creator 完整体继续以 AppSpec 为唯一规格源，覆盖需求讨论、版本/撤销、Web 交互预览、设计锁定、SwiftUI 工程、本地门禁、Agent 接管、人工批准云编译与后续项目迭代。

## V3.3.0 · Build 245 — Creator 完整体与 Agent 失败诊断多通道闭环

- Creator 升级为可长期迭代项目：最近项目、项目进度、AppSpec 版本快照、撤销上一次方案修改、设计锁定、正式源码生成、本地门禁结果与 Agent 交接统一在同一页面。
- 生成工程新增 BuildMateCreatorManifest、TEST_PLAN、PRIVACY、AGENT_GOAL，锁定 AppSpec 作为 Web 预览与 SwiftUI 唯一规格源，生成后自动设为当前源码。
- Codemagic 真实失败诊断新增 Export Artifact 通道：repair-context 与 compile-errors 在失败退出前复制到 CM_EXPORT_DIR，同时保留 Direct Relay / receipt Relay / Task 固定路径，避免 Relay Secret 缺失时只剩 status=failed。
- 真实云编译继续人工批准；Creator 讨论、预览、源码生成与本地门禁不自动消耗 Codemagic 分钟。

## V3.2.0 · Build 244 — AI 造 App 完整体一期 + Agent Direct Diagnostic Relay v4

- 修复 4-Bug 真机测试暴露的最后诊断断点：Xcode 失败后在 compile step 内直接回传 repair-context，避免依赖 failed build 的 post-publish 时序。
- BuildMate 诊断获取升级为三层：Codemagic Artifact → Relay receipt → Task 固定路径 Direct Relay；三条都没有真实证据才停止，禁止 AI 猜代码。
- “从想法创建 App”升级为可执行完整链：协作/自主模式 → AI AppSpec → 可交互 Web 预览 → 修改 → 锁定 → SwiftUI 源码 → ZIP → 本地零分钟门禁 → 自动设为当前源码。
- AppSpec 新增首版数据实体/字段/userFlows；网页预览和生成的真实 SwiftUI App 使用同一规格。
- 生成 App 自带 iOS 15+ SwiftUI、Tab、表单录入、本地持久化、最近记录、基础统计和设置/清空数据能力。
- 真实云编译仍必须人工批准；讨论、网页预览、源码生成、本地门禁不自动消耗 Codemagic 分钟。

## V3.1.0 · Build 243 — Agent 真实失败诊断闭环 + 从想法创建 App
- 修复 4-Bug 真机验证暴露的关键断点：Codemagic failed 构建即使 Builds API 不直接暴露 repair-context，post-publish 也会把任务专属 repair-context 经 Git Relay v3 主动回传；BuildMate 绑定同 Task/Build/SHA 读取诊断后进入 Agent AI Patch，不创建第二个 Run。
- 每次新编译开始清空上一轮 Agent repair-context，防止旧诊断污染新任务；失败诊断 Relay 50 秒超时即停止并保留证据，禁止无真实错误时让 AI 猜代码。
- 首页失败态四宫格去重：只保留一个“智能处理”入口，右下角恢复为“源码体检”。
- 新增“从想法创建 App”工作室：自然语言需求 → AI/本地 AppSpec → 页面方案 → 可交互 WebKit 高保真预览 → 边聊边改 → 锁定设计 → 导出 AppSpec + HTML。预览阶段不触发 Codemagic。
- AppSpec 成为网页预览与未来 SwiftUI 生成的统一规格源；智能体在没有源码时也可进入“创建新 App”。

# V3.0.9 · Build 240（2026-09-08）

- 智能体入口彻底收口：云编译控制台移除重复 AI 编译按钮；真实失败统一“交给智能体”；AI 开发中心移除重复 DeepTakeover 卡片。
- Agent 页面按当前源码 SHA 绑定任务，切换 ZIP 后不显示上一源码任务；阻断/停止可基于当前源码一键重新生成计划。
- 旧 AI Repair / DeepTakeover 执行代码保留为兼容层，不再作为主流程新增入口；Build238/239 的真实失败 repair-context 与安全 RepairPlan 闭环保持不动。
- 本版目标是减少一次真实编译前仍存在的重复入口与任务串线风险，不扩大 GitHub/Codemagic/Artifact 稳定执行主链。

# V3.0.8 · Build239（2026-09-08）

- Build239 修复全屏智能体缺少退出入口：导航栏提供明确“返回”，退出只关闭智能体界面，不取消或重建正在运行的 Task/Run。

智能体入口收口、全屏精简、Codemagic repair-context 真实失败续跑与安全 RepairPlan 应用。Build237 作为上一真实编译成功基线保留。


## V3.0.6 · Build237（2026-09-08）
- 首页视觉封板：基于 Build236 真机反馈，将当前源码卡紧凑化；长 ZIP 名称改为版本/Build 摘要，IPA 后清理与清除操作压缩为单行。
- 不改 Build235/236 已验证的动态下一步状态、GitHub/Codemagic/AI/Agent/Artifact/任务/发布执行主链。

# V3.0.4 · Build 235 — 产物交付后动态按钮状态机修正

## V3.0.5 · Build236（2026-09-08）
- 首页视觉收口：品牌 BuildMate 只保留顶部主标题；副标题缩短为“AI 开发 · 编译 · 发布”；环境状态条不再重复项目名；项目卡保留当前项目名。
- 缩小右上品牌图标与工作台中央圆盘，压缩无效高度；仅改 Presentation/UI，不改 Build235 已真机验证的动态下一步状态机和稳定执行主链。

- 修正 Build234 对“保存产物”反馈的误解：首页右下角是动态“下一步”槽位，不是固定产物入口。
- 未交付 IPA 继续显示“保存产物”；系统分享/保存成功后立刻退出交付态，按钮继续按上下文恢复“源码体检 / 深度接管 / 下载产物 / 重抓产物 / 云端运行”等状态。
- 已保存/分享 IPA 仍保留在产物中心，可再次分享，但不再长期占用首页工作台按钮。
- Build233 真实 Xcode/Codemagic 稳定主链保持不动；Build234 未进行真实云编译即被 Build235 覆盖。
- 新增 Build235 动态按钮回归门禁，防止以后再次把“历史本机产物存在”误判成“仍待用户保存”。

# V3.0.3 · Build 234 — V3 完全体交互收口与全局扫描

- Build233 已完成真实 Codemagic/Xcode 编译并在真机安装运行，作为本版稳定执行基线。
- 首页工作台去重：无报告时左下角从重复的“任务中心”改为“智能体”，底部“任务”Tab 继续作为统一任务入口。
- 本机已有验证产物时右下角统一显示“产物中心”，不再持续显示“保存产物”；BuildMate 不伪造“IPA 是否已被巨魔/系统安装”的不可观测状态。
- 产物中心统一使用“本机可用 / 已分享 / 分享或导出 / 再次分享”，云编译控制台使用“分享 IPA”，把缓存、导出、安装三个概念分开。
- 项目卡历史构建编号明确显示为“最近 Run”，避免清空源码后把旧 Run 误认为当前运行。
- 根据 Build233 真机录屏复查首页、中枢、Provider Center、Task Black Box、设置与关于页；保留 GitHub/Codemagic/AI/Artifact/Apple 发布稳定执行器。
- 新增 Build234 UI 收口回归门禁；源码包打包前清理 `__pycache__` 与 `.pyc`。

# V3.0.0 · Build 231 — BuildMate 智能体完全体

- Build230 已完成真实 Codemagic/Xcode 编译、IPA 保存与真机启动，作为 V3.0.0 稳定基线。
- 新增 `BuildMate Agent V3`：目标 → 计划 → 执行 → 观察 → 修复 → 验证 → 交付。用户可选择“编译 IPA / 自动修复直到成功 / 全面体检后编译 / App Store 发布准备 / 自定义目标”。
- Agent 计划统一串联源码指纹、恢复点、真实诊断、AI Patch、本地零分钟门禁、唯一云 Run、后台恢复、Artifact 续航、真机交付与发布准备。
- 新增真正 Agent 执行入口：先跑一次真实编译获取证据；仅当失败类型确认为源码错误且 AI 已配置时，自动进入 AI Repair；网络/认证/额度/Artifact 失败不会让 AI 猜代码。
- AI Patch 通过本地门禁后自动停在云编译批准点；智能体中心可“批准并继续这一次云编译”，批准绑定真实 Run 后立即消费。
- 冷启动任务去重升级：内存 activeTaskID 丢失时仍按 Workspace + Source SHA 复用持久父任务，防止 App 被系统杀掉后生成第二个 Task/Run。
- Agent Session 持久保存并绑定 Source SHA / Unified Task / Run / Artifact；前台恢复会自动对账，禁止后台回来创建第二个 Run。
- 同 SHA 已有验证 IPA 时优先复用产物，自动跳过重复云编译。
- 安全边界保持不可绕过：真实云编译、高风险 Patch、App Store 最终提交必须人工批准；Token/API Key/JWT 不进入 Agent Session 或黑匣子。
- 智能体预算与既有 Autonomous Loop / AI Repair Governance 同步，避免多个设置源产生冲突。
- 开发中枢首入口升级为“智能体”；普通编译、AI 编译、质量、任务、产物、发布能力全部保留。
- V3 采用编排层覆盖已验证执行器，不重写 GitHub/Codemagic/Apple Upload 主链，降低一次性大升级风险。

# V2.26.0 · Build 230 — 长期维护稳定版

- Build229 已完成真实 Codemagic/Xcode 编译、IPA 下载验证与真机启动，作为本版稳定基线。
- 新增长时间后台恢复：回前台自动执行本地任务对账，再继续同一个 Codemagic Run；不会因为 iOS 挂起而创建第二个云 Run。
- 新增幽灵任务自动收口：历史 FinalStabilityAudit 补完成终态；同 SHA 已有验证 IPA 时，无真实 Run 的旧体检/审批任务标记为被后续成功链路取代；有真实 Run 的任务保留给 Provider 权威状态确认。
- 任务中心新增“重新对账并收口”，不删历史，只补齐正确终态。
- 新增成功/异常本地通知；Artifact Delivery Store 与产物中心继续保证 IPA 在返回待机、后台和重启后可恢复。
- 网络、凭据、Run、Artifact、AI、Apple 发布主链保持既有稳定实现，不做架构性重写。

# V2.25.0 · Build 229 · 2026年9月8日

- Build228 已完成真实 Codemagic/Xcode 编译并确认 IPA 产物可用；Build227 保持已确认安装启动稳定锚点。
- 修复“编译成功后未点保存，返回待机/切后台后右下角变回源码体检”的真机问题：产物状态不再依赖 `workStage == .success`。
- 新增统一 Artifact Delivery Store：Codemagic 已验证 IPA 改为持久保存到 Application Support，并记录 Provider、Run/Build、Source SHA、文件名、大小、原构建链接和交付状态。
- 新增产物中心：返回待机、前后台切换、App 重启后仍可再次保存/分享最近 IPA；本机删除不影响云端构建。
- GitHub/Codemagic/AI/Apple 发布执行主链保持冻结；本版集中完成真机终态/Artifact 续航维护。

# V2.24.0 最终完善状态

Build227 为真实编译/安装/启动稳定基线；Build228 只在其上完成发布真链与状态终态收口。Build228 通过真实 Xcode/Codemagic 后停止连续大改。

# Build227 之后：稳定维护模式

连续大开发在 V2.23.0 · Build227 收官。后续路线由“继续重构”切换为“真实 Bug 修复、必要新能力、系统兼容、Provider/API 变化适配与发布维护”。任何新增高风险能力必须从稳定基线副本开始，并在最终节点做一次真实 Xcode/Codemagic 验收。

## Build141 · V2.9.90 当前补充
Codemagic ArtifactReturnProvider 正在验证 post-publish receipt 经 CM_EXPORT_DIR 持久化；若平台不保留 publishing 后生成文件，将切换日志/Relay 通道。

# Build103 新增基础设施
- Task Black Box / Checkpoint / Recovery：统一任务时间线、异常原因、恢复检查点与诊断导出。
- Codemagic Provider 先完成 URL/Artifact/错误分类闭环，再继续自动 Patch/重编执行器。

# Product Roadmap — 软件开发智能体

## Phase 1：地基（当前）
核心模块边界、Provider 标准、任务生命周期、质量回归、项目知识、AI 接管、稳定基线。

## Phase 2：智能开发闭环
自然语言需求 → 任务拆解 → 代码修改 → 本地体检 → 云/私人 Mac 编译 → 真实错误 → 自动修复 → 回归 → Artifact。

## Phase 3：多 Agent 编排
Requirements/Product/UI/Coding/Testing/Diagnostic/Repair/Build/Release Agent 通过统一任务协议协作，支持依赖、暂停、审批、恢复、失败隔离。

## Phase 4：私人执行节点
BuildMate Agent 运行于用户 Mac，接收受控任务并执行 Xcode；iPhone 负责控制，Mac 负责真实构建。

## Phase 5：平台与商业化
独立 Account/Auth、设备/项目同步、会员/许可、AI/编译额度、团队权限、订单/订阅、服务端调度。先接口后服务，避免早期空壳和核心耦合。

## Phase 6：生态
第三方 AI、Build Provider、Agent/扩展按照 BuildMate 标准接入。产品价值由 BuildMate Core、项目记忆和编排能力承载，而非绑定某一家模型。
