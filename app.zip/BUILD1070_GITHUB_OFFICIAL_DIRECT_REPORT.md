# Build1070 / V7.5.8 — GitHub 官方直连版

G 编译主链只保留 GitHub 官方 REST API 行为：

1. 使用“编译 GitHub”保存的 owner/repo/token/branch。
2. 上传 app.zip。
3. 单次 POST `/repos/{owner}/{repo}/actions/workflows/buildmate.yml/dispatches`，body 包含 `return_run_details: true`。
4. 只接受 HTTP 200 返回的 `workflow_run_id`、`run_url`、`html_url`。
5. 使用同一个 run_id 查询 `/actions/runs/{run_id}` 直到 completed。
6. Artifact 继续使用 `/actions/runs/{run_id}/artifacts`。

删除/退出 G 主流程：
- dispatch 后扫描最新 Run
- 422 输入降级重试
- 强制绑定“源码 GitHub”仓库
- 旧 Token 自动迁移
- 每次编译自动覆盖 `.github/workflows/buildmate.yml`

C/Codemagic 编译链未修改。
