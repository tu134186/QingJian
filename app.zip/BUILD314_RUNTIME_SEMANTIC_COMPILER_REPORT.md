# BuildMate V5.0.4 · Build 314 — Runtime Semantic Compiler

## Real-device evidence used
Build313 AI Tester report captured 20 real taps but mapped 0 Manifest controls. Runtime could see segmented labels “进行中 / 异常 / 已完成”, proving touch observation worked while source-map semantics did not.

## Closure
- UI manifest schema upgraded to v5 with aliases, ownerPageID and origin metadata.
- Static segmented Picker choices become independent PickerOption semantic controls.
- Reusable free-function interaction wrappers generate page-owned semantic call-site controls.
- Direct control title extraction scans trailing label/accessibility content instead of only the source line.
- Relationship generator uses canonical ownerPageID and refuses fake/nonexistent generic destinations.
- Runtime matching scores title + aliases + role + page/component scope and keeps ambiguity rejection.
- Passive touch observer re-resolves at touch end and may use a bounded nearest actionable semantic node; it never injects a gesture or overlay.
- Segmented-control implementation nodes are excluded from the 44pt false-positive audit.

## Static result
Generated manifest: 90 View pages, 285 interactive semantic controls, 46 scrollable areas. All 285 interactive controls have semantic aliases; only 4 fallback placeholders remain. Relationship graph has 0 unknown source relationships and 0 missing registered destination pages.

## Safety invariant
Tester observation must fail open. No global DragGesture, no overlay hit-test interception, no synthetic tap, no autonomous scroll mutation, no paid cloud action.
