# Build1022 · Remove AI Runtime/UI

- 首页 AI 状态灯、AI 快捷入口：删除。
- 设置页 AI 配置：删除。
- AI 配置 Sheet：删除。
- Agent / AI 自动修复 Feature Flag：关闭。
- 备份：不再导出/恢复任何 AI API Key；旧备份中的 AI Key 自动忽略。
- 四宫格右上角：保持纯任务辅助动态行为：编译中=编译状态；失败且可恢复产物=重抓产物；其他=产物管理。
- 失败处理：BUG 报告 + 云端运行详情，用户可复制/导出故障信息给外部 ChatGPT/豆包/DeepSeek 等处理。
- 普通编译、源码体检、GitHub Actions/Codemagic、黑匣子、产物、发布均保留。
