# BuildMate V4.7.0 · Build 308

本版目标：一次性把 AI 智能内测员从“静态地图 + 计划器”推进到“离线地图 + 关系图 + 运行时 UI 树 + 自动视觉巡检 + 空闲长页扫视 + 可信覆盖门禁”的可用闭环，并保持真实云编译/删除/外部写入必须人工批准。

## 已实现
- 全局运行时 UI 树采集与当前页面识别。
- Root 级真实点按 / 滑动观察，不要求每个新按钮逐个手工埋点才能看到事件。
- 运行时控件与离线 Manifest / Relationship Graph 自动语义匹配。
- 已映射 / 未映射操作分开统计，未映射不计覆盖率。
- 运行时页面变化用于验证 Navigation 关系；同页 UI 变化用于验证普通 Action 的可见反馈。
- 自动视觉审计：44pt 点击区、部分越界、同屏重复入口、页面复杂度。
- 空闲 6 秒后自动扫描当前长页面主要滚动视口并恢复原位置，不触发按钮。
- 架构自检：未知来源关系、缺失目标页面、重复能力候选、安全 Autopilot 候选。
- 报告新增 runtime-ui-tree.json / visual-audit.json / architecture-audit.json。
- Creator 生成 App 自动附带 BUILD_MATE_AI_TEST_SPEC.json。
- UI Manifest v3 增加页面 displayTitle，用于运行时页面映射。
- 新增 Build308 19 项回归门禁。

## 安全边界
自主执行器不调用 Codemagic、GitHub、URLSession、删除仓库、云审批或真实编译；只做运行时观察和当前滚动区域的视觉扫视。高风险动作仍要求人工批准。

## 本地验证
- 全 Swift 源文件 swiftc -parse：0 失败。
- Release Version Gate：PASS。
- UI Manifest / Relationship Drift Gate：PASS。
- Unified Task Pipeline：8/8。
- Task Execution Coordinator：9/9。
- Autonomous Development Loop：10/10。
- Provider Execution Bus：10/10。
- Build167 Xcode blocker regression：7/7。
- Build302 Run Binding：10/10。
- Build308 Intelligent Tester MAX：19/19。

注意：Linux 环境无法替代真实 Xcode/UIKit 全模块编译，因此最终仍需要一次真实 Xcode 编译验收；本版的目的正是把需要花云分钟之前能做的静态/本地检查尽量全部做完。
