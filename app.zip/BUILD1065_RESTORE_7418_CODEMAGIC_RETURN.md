# Build1065 · Restore V7.4.18 Codemagic Artifact Return

- Base: V7.5.2 Build1064
- Restored from verified stable reference: V7.4.18 Build1046
- Restored Codemagic publishing Artifact Return Bridge for IPA/DEB.
- Restored BM_RELAY_REPO / BM_RELAY_BRANCH / BM_RELAY_PATH dispatch variables.
- Restored BuildMate receive path: Relay receipt first, official Codemagic Artifact API fallback.
- Preserved the rest of the V7.5.2 source tree.
- Version: V7.5.3 Build1065.

This package is source-level restored for cloud verification; no claim of a new real Codemagic run is made until tested.
