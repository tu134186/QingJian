QingJian / BuildMate V7.5.3 GitHub Actions 修复包

必须覆盖 GitHub 仓库中的：
.github/workflows/buildmate.yml

原因：
当前仓库被初始化成 “BuildMate Linux Preflight”，它要求 expected_source_sha256 /
expected_source_bytes 为必填，并且只检查 BuildMate 自身源码目录，和 QingJian 编译不匹配。

本包 buildmate.yml 来自 BuildMate V7.5.3 配套的 Multi Builder：
- workflow_dispatch 接受 mode
- expected_source_sha256 / expected_source_bytes / source_name / expected_head_sha 均兼容
- macos-15
- 支持正式 Xcode/IPA 编译
