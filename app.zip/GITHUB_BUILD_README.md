# GitHub 自动编译说明

本源码包已经内置 `.github/workflows/build.yml`，不需要手工创建 workflow。

- 支持 `master` / `main` push 自动触发，也支持 Actions 页面手动 Run workflow。
- macOS runner + Theos + iOS SDK。
- 构建 `arm64 + arm64e`、rootless DEB。
- 成功 Artifact：`RecordingSharingan-V6.2-DEB`。
- 无论成功失败都会上传：`RecordingSharingan-Compile-Logs`，其中包含 `compile.log`、`compile-errors.txt`、`build-summary.txt`。
- 如果失败，把整个 `RecordingSharingan-Compile-Logs.zip` 发回分析，不要先改 Tweak.xm。
