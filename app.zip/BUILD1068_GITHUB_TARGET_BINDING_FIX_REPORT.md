# Build1068 / V7.5.6

## 根因
V7.5.5 的 GitHub Actions 编译读取独立 `github-actions-owner/repo`。这些字段可能残留旧仓库，因此 API 可以在另一个仓库拿到真实 Run ID 并成功完成，而首页当前源码仓库的 Actions 页面没有任何新 Run。

## 修复
- G 编译 owner/repo 强制绑定当前首页源码 GitHub owner/repo。
- 独立 GitHub Actions Token 继续保留。
- Token 401 fallback 只更换 Token，不再切换 owner/repo。
- 黑盒新增 `target.locked`，明确记录本次 G 编译实际目标仓库。
- Workflow、app.zip、dispatch、Run 查询、Artifact 均使用同一 GitHubService。
- C/Codemagic 编译链未修改。
