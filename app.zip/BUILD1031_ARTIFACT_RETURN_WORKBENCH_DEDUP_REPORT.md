# Build 1031 · Artifact Return / Workbench Dedup Closure

- Source baseline: V7.4.2 Build1030, proven real Codemagic Xcode build success.
- Artifact download follows Codemagic official protected artifact -> POST public-url -> signed GET flow.
- Same build retries at 0/5/10/20/30 seconds; no new cloud build is created.
- Git Relay is no longer required after a successful Codemagic build.
- Artifact failure becomes success/pending and retry failure also preserves success/pending.
- Workbench slots are compileAction / artifactAction / report / nextStep with unique responsibilities.
- Current cloud URL is derived from active Codemagic build ID or matching artifact recovery before generic runURL fallback.
- Xcode/Codemagic compile workflow, GitHub Actions, DEB path and central Sharingan assets are unchanged.
