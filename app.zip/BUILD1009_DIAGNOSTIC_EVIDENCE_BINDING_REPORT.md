# Build1009 诊断证据强绑定报告

- 基线：Build1008。
- 真实问题：Build1008 失败任务的 manifest 已正确绑定 Codemagic Build `6aa16bd2031146e7ff6c8a8c` 与 Source SHA，但 BUG 报告的“自动根因提炼”调用全局 `latestDiagnostic()`，因此可能混入上一 Build 的缓存错误。
- 修复：新增 `BuildGuardStore.diagnostic(forBuildID:)`，仅 Build ID 完全一致才允许进入根因提炼。
- 防线：若存在旧缓存但 Build ID 不匹配，报告只输出“诊断证据隔离”，明确显示旧 Build 与当前 Build，不再输出旧根因。
- 未改变：六大核心、中央 6 素材、SVG、5→120→5 码、备份恢复、云编译主链。
