# Build319 Final Tester Closure

## Goal
One final architecture pass before deciding whether the in-app tester is worth keeping. Target: >=80% conclusion rate for real actionable interactions on-device, with no perceptible navigation lag.

## Evidence behind the design
- Apple UI automation is accessibility-driven: element type, label, value, frame and identifier are automation evidence; accessibilityIdentifier is the preferred stable unique identity.
- Stateful controls expose value/state; this is positive action evidence even when navigation does not occur.
- Accessibility trees are not one-to-one with visible pixels. Empty/static touches must not be treated as failed control recognition.
- Query work should stop as soon as a high-confidence identity is found; Build319 mirrors this with identifier-first resolution and no full tree traversal on touch critical paths.

## Build317 real-report root causes closed
1. `resolve()` returned a non-nil BMRuntimeResolvedElement even when `manifestID` was nil, prematurely blocking stronger fallbacks. Build319 returns nil until a semantic match exists.
2. Full accessibility capture could still run synchronously on touch begin/end. Build319 forbids full AX traversal on those critical paths.
3. Every physical touch was counted as an unmapped control. Build319 separates non-actionable touches from actionable-but-unresolved interactions.
4. Heavy audits now run only from idle/full snapshots, never from touch-driven lightweight observations.

## Acceptance
- On-device actionable-interaction conclusion rate >=80%.
- Navigation and scrolling subjectively as responsive with tester enabled as disabled.
- No global Gesture/Overlay/hit-test interception or autonomous UI mutation.
- Unresolved actionable interactions remain explicit human-confirmation items; no fake pass.
