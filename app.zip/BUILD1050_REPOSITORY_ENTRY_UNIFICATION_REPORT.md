# Build1050 仓库入口统一报告

- 首页“切换项目”保留为唯一仓库选择/管理 UI。
- 开发环境“切换 / 管理仓库”改为打开同一个项目选择器。
- 每个仓库增加删除菜单；删除前读取 GitHub 仓库再次校验 fullName，并要求输入仓库名确认。
- 删除当前仓库后清理本地当前仓库选择与对应运行/产物指针。
- Codemagic 编译、Artifact Return Bridge、workflow、ContentView+Execution 未修改。
