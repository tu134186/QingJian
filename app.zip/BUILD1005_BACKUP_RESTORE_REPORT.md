# BuildMate V7.1.3 Build1006 — Backup & Restore

- 新增独立 BackupRestoreService / BackupRestoreView 模块。
- 加密备份 GitHub、Codemagic、Bitrise、自托管 Mac 的凭据和必要连接配置。
- 备份中央特效设置及最多 30 个自定义 SVG/图片素材；6 个内置素材仍随 App 自带，不需要写入备份。
- 安全恢复白名单明确排除 Creator、DeepTakeover、旧 Run、任务缓存和页面状态，避免纯净安装后重新带回旧 AI 残留。
- 备份使用 AES-GCM 加密，密码经带随机 salt 的慢哈希派生；备份中不保存明文密码。
- 设置页新增“备份与恢复”独立入口，保持模块化边界。
