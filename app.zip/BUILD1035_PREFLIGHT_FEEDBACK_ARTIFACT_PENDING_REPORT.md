# V7.4.7 · Build 1035

## 本轮收口

- 源码体检成功增加独立 `preflightPassed` 状态，避免成功后瞬间回到 idle，造成“点不了”的假象。
- Codemagic Artifact 绝对 URL 会规范化重复路径斜杠，修复 `https://api.codemagic.io//artifacts/...`。
- 云端编译成功但 IPA 抓取失败使用独立 `artifactPending` 状态。
- Artifact pending 时首页左下直接提供 BUG 报告，诊断绑定当前任务。
- 黑匣子对编译成功/IPA待获取写 `completed` 终态，任务中心不再长期显示进行中。
- 自动/手动抓取仍保持一次动作一轮，不自动重复。
- 未改 Codemagic clean workflow、GitHub Actions、IPA/DEB 主链、中央素材或 AI 历史模块。
