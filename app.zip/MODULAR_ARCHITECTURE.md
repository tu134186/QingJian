# V3.0.4 · Build 235 — 产物交付后动态按钮状态机修正

- 修正 Build234 对“保存产物”反馈的误解：首页右下角是动态“下一步”槽位，不是固定产物入口。
- 未交付 IPA 继续显示“保存产物”；系统分享/保存成功后立刻退出交付态，按钮继续按上下文恢复“源码体检 / 深度接管 / 下载产物 / 重抓产物 / 云端运行”等状态。
- 已保存/分享 IPA 仍保留在产物中心，可再次分享，但不再长期占用首页工作台按钮。
- Build233 真实 Xcode/Codemagic 稳定主链保持不动；Build234 未进行真实云编译即被 Build235 覆盖。
- 新增 Build235 动态按钮回归门禁，防止以后再次把“历史本机产物存在”误判成“仍待用户保存”。

# V3.0.3 · Build 234 — V3 完全体交互收口与全局扫描

- Build233 已完成真实 Codemagic/Xcode 编译并在真机安装运行，作为本版稳定执行基线。
- 首页工作台去重：无报告时左下角从重复的“任务中心”改为“智能体”，底部“任务”Tab 继续作为统一任务入口。
- 本机已有验证产物时右下角统一显示“产物中心”，不再持续显示“保存产物”；BuildMate 不伪造“IPA 是否已被巨魔/系统安装”的不可观测状态。
- 产物中心统一使用“本机可用 / 已分享 / 分享或导出 / 再次分享”，云编译控制台使用“分享 IPA”，把缓存、导出、安装三个概念分开。
- 项目卡历史构建编号明确显示为“最近 Run”，避免清空源码后把旧 Run 误认为当前运行。
- 根据 Build233 真机录屏复查首页、中枢、Provider Center、Task Black Box、设置与关于页；保留 GitHub/Codemagic/AI/Artifact/Apple 发布稳定执行器。
- 新增 Build234 UI 收口回归门禁；源码包打包前清理 `__pycache__` 与 `.pyc`。

# V3.0.0 · Build 231 — BuildMate 智能体完全体

- Build230 已完成真实 Codemagic/Xcode 编译、IPA 保存与真机启动，作为 V3.0.0 稳定基线。
- 新增 `BuildMate Agent V3`：目标 → 计划 → 执行 → 观察 → 修复 → 验证 → 交付。用户可选择“编译 IPA / 自动修复直到成功 / 全面体检后编译 / App Store 发布准备 / 自定义目标”。
- Agent 计划统一串联源码指纹、恢复点、真实诊断、AI Patch、本地零分钟门禁、唯一云 Run、后台恢复、Artifact 续航、真机交付与发布准备。
- 新增真正 Agent 执行入口：先跑一次真实编译获取证据；仅当失败类型确认为源码错误且 AI 已配置时，自动进入 AI Repair；网络/认证/额度/Artifact 失败不会让 AI 猜代码。
- AI Patch 通过本地门禁后自动停在云编译批准点；智能体中心可“批准并继续这一次云编译”，批准绑定真实 Run 后立即消费。
- 冷启动任务去重升级：内存 activeTaskID 丢失时仍按 Workspace + Source SHA 复用持久父任务，防止 App 被系统杀掉后生成第二个 Task/Run。
- Agent Session 持久保存并绑定 Source SHA / Unified Task / Run / Artifact；前台恢复会自动对账，禁止后台回来创建第二个 Run。
- 同 SHA 已有验证 IPA 时优先复用产物，自动跳过重复云编译。
- 安全边界保持不可绕过：真实云编译、高风险 Patch、App Store 最终提交必须人工批准；Token/API Key/JWT 不进入 Agent Session 或黑匣子。
- 智能体预算与既有 Autonomous Loop / AI Repair Governance 同步，避免多个设置源产生冲突。
- 开发中枢首入口升级为“智能体”；普通编译、AI 编译、质量、任务、产物、发布能力全部保留。
- V3 采用编排层覆盖已验证执行器，不重写 GitHub/Codemagic/Apple Upload 主链，降低一次性大升级风险。

# Build227 模块化收官边界

大规模模块化已结束。Build227 新增 FinalStabilityClosure / FinalStabilityCenterView 仅用于安全审计与维护收口，不作为继续拆分 ContentView 的理由。未来优先真实功能、Bug 与兼容性维护。


## V2.20.0 · Build 224（2026-09-08）
- 以 Build223 真实 Codemagic/Xcode/IPA 安装成功为稳定基线。
- 新增 App Store 发布工作台：结构化元数据、本机校验、凭据引用、TestFlight/App Store 发布计划、主人批准记录与无秘密交接单。
- 凭据层只保存引用和非秘密提示，不保存 .p8 私钥、Token、密码、Cookie 明文。
- 真实 App Store Connect 上传 Adapter 仍未伪装可用；提交审核/正式上线继续要求主人批准。
- 不重写 GitHub/Codemagic/AI/Artifact/恢复/任务黑匣子稳定主链。
## V2.19.0 · Build 223 · 2026-09-08
- 功能收口大版：新增发布准备中心，本机零分钟检查版本身份、Provider 唯一性、发布权限边界、回归规则、真实 IPA、稳定基线、云编译熔断与 App Store 资料准备，并可复制发布准备报告。
- 修复质量回归中心旧 Build105 硬编码以及 Build102/103 陈旧失败/待验证状态，改为当前 Bundle 身份 + Build221/222 真实验收证据。
- 发布 Provider 继续保持真实能力边界：未接入商店真实 Adapter 时明确显示“预留”，提交审核/正式上线必须主人批准；不伪造可发布状态。
- Build222 已真实 Codemagic/Xcode 编译、IPA 安装启动通过，本版不重写 GitHub/Codemagic/AI/Artifact/恢复/黑匣子主链。

# V2.18.2 · Build 222

## 模块化状态：已收官
Build221 已真实编译安装通过。Build222 起模块化不再作为版本推进目标；ContentView 剩余部分按业务协调层保留，只有出现明确职责边界或功能需求时才拆。

# V2.18.1 · Build 221

## Build221 · 收官编译修复
- 仅修复 Build220 跨文件类型边界，不新增拆分。
- 模块化收官状态保持不变。


## Build220 · 模块化收官
- Build219 已经真实 Xcode/Codemagic 编译、安装、启动通过，作为本轮回滚锚点。
- Build220 完成源码生命周期/中央核心/工作台动作展示边界收口，并修复清除源码布局残影。
- ContentView 约 2498 行，剩余部分视为业务协调层；禁止为了“继续减行”强拆 Codemagic、GitHub、AI、Artifact/Relay、恢复和黑匣子。
# Build143 Relay Adapter

新增 Git Relay 作为 Artifact Return Adapter 的实装路径；它不进入 Core，不保存长期 Secret，可被未来 HTTP Relay / Private Mac Relay 替换。

## Build141 模块化补充
Artifact Return Provider 增加“服务器收据持久化”验证，不向 Core 泄漏 Codemagic Token 或平台专有 Secret。

# V2.9.89 · Build 140 补充

UI 动作层继续保持 Provider-neutral：云端运行只依赖统一 runURL/Provider 状态，不在按钮标题绑定第三方平台名称。

# V2.9.88 · Build 139 补充

Artifact Return Observability 作为 Tool/Adapter 层能力，不反向侵入平台 Core。

## Build138 Artifact Return 安全接入

Codemagic `buildmate_secrets` 只在 CI 环境注入；Artifact 回传采用服务器 `CM_ARTIFACT_LINKS` 证据 + 手机端旧 API/v3 API 双链兼容。

## Build137：Artifact Return Layer
编译 Provider 与产物回传 Provider 分离。iOS/Android/HarmonyOS 统一通过 ArtifactReturnProvider 输出 Receipt；外部 Relay 必须作为可拔插 Adapter，不能反向污染 Core。

# 应用商店发布层（Build136 新增）

发布渠道与编译平台严格解耦。`BMDistributionProvider` 统一描述账号校验、产物上传、元数据/截图、测试发布、提交审核、正式上线与审核状态读取。当前预留 `distribution.apple`、`distribution.googlePlay`、`distribution.huawei` 三个 Adapter，默认关闭且 `available=false`，表示只搭接口骨架，不声称已绑定真实开发者账号。

安全边界：Agent 只拿 `credentialReferenceID`，不读取 App Store Connect 私钥、Google Service Account、华为服务账号密钥等明文。Release Agent 可自动准备和上传，但“提交审核”“正式上线”默认 `askOwner`；修改账号安全设置永久禁止。平台与商店不一一绑定：Android 可走 Google Play 或华为 AppGallery，未来增加三星、小米、OPPO、vivo 等商店时只新增 Distribution Adapter。

发布证据链继续继承 Task ID / parentTaskID / correlationID / Source SHA / artifactID，后续所有商店动作都应写入任务黑匣子。

# BuildMate 模块化总架构 · Build135

## 核心原则
第三方平台、AI 公司、云编译服务、执行节点都属于可替换 Adapter。BuildMate 自己拥有 Task、Black Box、Knowledge、Permission、Approval、Budget、Design System 与项目历史。任何单一外部公司退出、涨价、改 API 或停服，都不得要求重写 BuildMate Core。

## 六层结构
1. Core：Task / State / Source / Diagnostic / Artifact / Release。
2. Intelligence：Agent / Orchestrator / Knowledge Base / Research。
3. Security：Role / Permission / Approval / Budget / Secret Boundary。
4. Collaboration：Capability Registry / Collaboration Bus / Execution Node。
5. Platform：iOS / Android / HarmonyOS 统一 PlatformProvider。
6. Adapter：GitHub / Codemagic / AI Provider / Private Mac / Future Platform。

## 可删除规则
- Android 与 HarmonyOS 当前仅有接口和识别规则，默认 disabled，不引入各自 SDK。
- 外部研究、私人 Mac、第三方 Agent 均通过 Feature Flag + Adapter 接入。
- 可选模块不得成为 iOS 主链的编译依赖。
- 删除可选模块目录后，Core / iOS 主链的协议边界必须保持完整。

## Agent 组织
Owner → Orchestrator → Research / UI / Coding / Diagnostic / Repair / Build / Testing / Release。
每个 Agent 只拿岗位权限；权限值固定为 allow / askOwner / deny，并独立受轮数、构建次数、时间和 Token 预算约束。

## 错题库
黑匣子记录“发生了什么”；Knowledge Base 记录“为什么、怎么修、哪些办法失败、最后如何验证”。历史方案只有在真实编译/回归后才能晋升为“已验证”。

## 协同协议
跨设备/跨 Agent 任务必须保留 Task ID；子步骤使用 parentTaskID + correlationID + sourceSHA + diagnosticID。Agent 之间的重要结果必须结构化交付，不以聊天文本作为唯一事实来源。

## 多平台
PlatformProvider 统一描述项目识别、预检、依赖、构建、测试、签名、产物、发布能力。iOS 当前启用；Android/HarmonyOS 当前只预留“插座”，未来安装 Adapter 即可接入。


## 2026-09-08 · Build209 模块化阶段
Build204 已由用户完成真实 Codemagic/Xcode 编译、IPA 安装与启动验证，可作为上一稳定锚点。Build205–209 仅抽离 ContentView 顶层系统 Dialog/Alert 到 `BMContentDialogs`，真实编译、GitHub 写操作、AI 深度接管、Artifact 重抓、恢复与任务黑匣子主链未重写。Build209 为下一真实 Xcode/Codemagic 验收候选。
