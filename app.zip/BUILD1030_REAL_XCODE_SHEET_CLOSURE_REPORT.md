# Build1030 Real Xcode Sheet Closure

## Evidence
Codemagic artifact `BuildMate_2_artifacts.zip` reported only two Swift compile errors:
- `ContentView.swift:258:14` — `instance member presentationDetents cannot be used on type View`
- `ContentView.swift:265:14` — same error.

## Fix
- Wrap conditional report sheet contents in `Group`.
- Apply sheet presentation behavior through `bmReportSheetPresentation()`.
- Guard `presentationDetents` / `presentationDragIndicator` with `#available(iOS 16.0, *)` while preserving deployment target iOS 15.0.

## Scope
No changes to Codemagic workflow selection, GitHub Actions dispatch, IPA/DEB routes, six-core product scope, or central visual assets.
