import SwiftUI
import AVFoundation

struct ClipItem: Identifiable, Equatable {
    let id = UUID()
    var url: URL
    var duration: Double
    var start: Double = 0
    var end: Double
    var volume: Float = 1
    var rate: Float = 1
}

@MainActor final class EditorProject: ObservableObject {
    @Published var clips: [ClipItem] = []
    @Published var selectedID: UUID?
    @Published var titleText = ""
    @Published var aspect: CGFloat = 9/16
    @Published var isExporting = false
    @Published var progress: Double = 0
    @Published var message: String?
    var selectedIndex: Int? { clips.firstIndex { $0.id == selectedID } }
    var totalDuration: Double { clips.reduce(0) { $0 + max(0, ($1.end-$1.start)/Double($1.rate)) } }

    func add(url: URL) async {
        let asset = AVURLAsset(url: url)
        do {
            let d = try await asset.load(.duration).seconds
            guard d.isFinite && d > 0 else { return }
            let c = ClipItem(url: url, duration: d, end: d)
            clips.append(c); selectedID = c.id
        } catch { message = "读取视频失败：\(error.localizedDescription)" }
    }
    func deleteSelected() { guard let i = selectedIndex else { return }; clips.remove(at:i); selectedID = clips.first?.id }
    func splitSelected(at seconds: Double) {
        guard let i = selectedIndex else { return }
        let c = clips[i], p = min(max(c.start + seconds * Double(c.rate), c.start + 0.1), c.end - 0.1)
        guard p > c.start, p < c.end else { return }
        var a=c,b=c; a.end=p; b.start=p
        clips.remove(at:i); clips.insert(contentsOf:[a,b],at:i); selectedID=b.id
    }
    func moveSelected(_ delta:Int) { guard let i=selectedIndex else{return}; let j=i+delta; guard clips.indices.contains(j) else{return}; clips.swapAt(i,j) }
}
