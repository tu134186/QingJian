import SwiftUI
import PhotosUI

struct EditorView: View {
 @EnvironmentObject var p:EditorProject
 @State private var picker:[PhotosPickerItem]=[]
 @State private var shareURL:URL?
 @State private var showShare=false
 var body: some View {
  NavigationStack { VStack(spacing:10) {
   ZStack { Color.black; PlayerView(url:p.selectedIndex.map{p.clips[$0].url}); if !p.titleText.isEmpty { Text(p.titleText).font(.title2.bold()).shadow(radius:4).padding() } }.aspectRatio(p.aspect,contentMode:.fit).clipShape(RoundedRectangle(cornerRadius:12)).padding(.horizontal)
   HStack { Text(String(format:"%.1fs",p.totalDuration)).monospacedDigit(); Spacer(); Text("\(p.clips.count) 段素材") }.font(.caption).foregroundStyle(.secondary).padding(.horizontal)
   ScrollView(.horizontal,showsIndicators:false){ HStack(spacing:8){ ForEach(Array(p.clips.enumerated()),id:\.element.id){ i,c in Button { p.selectedID=c.id } label:{ VStack{ Image(systemName:"film").font(.title2); Text("\(i+1) · \(String(format:"%.1fs",(c.end-c.start)/Double(c.rate)))") }.frame(width:90,height:64).background(p.selectedID==c.id ? Color.white.opacity(0.2):Color.white.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius:8)) } } }.padding(.horizontal) }.frame(height:72)
   if let i=p.selectedIndex { let c=p.clips[i]; VStack { HStack { Text("裁剪"); Spacer(); Text(String(format:"%.1f – %.1f 秒",c.start,c.end)).monospacedDigit() }; HStack { Slider(value:Binding(get:{p.clips[i].start},set:{p.clips[i].start=min($0,p.clips[i].end-0.1)}),in:0...max(0.1,c.duration)); Slider(value:Binding(get:{p.clips[i].end},set:{p.clips[i].end=max($0,p.clips[i].start+0.1)}),in:0.1...max(0.1,c.duration)) }; HStack { Text("速度"); Slider(value:Binding(get:{Double(p.clips[i].rate)},set:{p.clips[i].rate=Float($0)}),in:0.25...3); Text(String(format:"%.2fx",p.clips[i].rate)).frame(width:55) } }.font(.caption).padding(.horizontal) }
   TextField("添加标题/字幕",text:$p.titleText).textFieldStyle(.roundedBorder).padding(.horizontal)
   HStack(spacing:18){ PhotosPicker(selection:$picker,maxSelectionCount:20,matching:.videos){ tool("添加","plus") }; Button{p.splitSelected(at:1)}label:{tool("分割1秒","scissors")}; Button{p.moveSelected(-1)}label:{tool("前移","arrow.left")}; Button{p.moveSelected(1)}label:{tool("后移","arrow.right")}; Button(role:.destructive){p.deleteSelected()}label:{tool("删除","trash")} }.font(.caption)
   Spacer(minLength:0)
   Button { export() } label:{ Label(p.isExporting ? "正在导出…":"导出 MP4",systemImage:"square.and.arrow.up").frame(maxWidth:.infinity).padding().background(Color.accentColor).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius:12)) }.disabled(p.clips.isEmpty || p.isExporting).padding()
  }.navigationTitle("轻剪").navigationBarTitleDisplayMode(.inline)
   .onChange(of:picker){items in Task { for item in items { do { let u=try await MediaStore.copyVideo(from:item); await p.add(url:u) } catch { p.message=error.localizedDescription } }; picker=[] }}
   .alert("提示",isPresented:Binding(get:{p.message != nil},set:{if !$0{p.message=nil}})){Button("好") {p.message=nil}} message:{Text(p.message ?? "")}
   .sheet(isPresented:$showShare){ if let u=shareURL { ShareSheet(items:[u]) } }
  }
 }
 func tool(_ t:String,_ icon:String)->some View { VStack{Image(systemName:icon).font(.title3);Text(t)}.frame(minWidth:48) }
 func export(){ p.isExporting=true; Task { do { let u=try await Exporter.export(clips:p.clips,text:p.titleText); shareURL=u; showShare=true } catch { p.message="导出失败：\(error.localizedDescription)" }; p.isExporting=false } }
}

struct ShareSheet:UIViewControllerRepresentable { let items:[Any]; func makeUIViewController(context:Context)->UIActivityViewController{UIActivityViewController(activityItems:items,applicationActivities:nil)}; func updateUIViewController(_ uiViewController:UIActivityViewController,context:Context){} }
