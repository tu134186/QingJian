import AVFoundation
import UIKit

struct Exporter {
    static func export(clips:[ClipItem], text:String) async throws -> URL {
        guard !clips.isEmpty else { throw NSError(domain:"QingJian",code:2,userInfo:[NSLocalizedDescriptionKey:"请先添加视频"]) }
        let composition = AVMutableComposition()
        guard let vTrack = composition.addMutableTrack(withMediaType:.video,preferredTrackID:kCMPersistentTrackID_Invalid),
              let aTrack = composition.addMutableTrack(withMediaType:.audio,preferredTrackID:kCMPersistentTrackID_Invalid) else { throw NSError(domain:"QingJian",code:3) }
        var cursor=CMTime.zero
        var instructions:[AVMutableVideoCompositionInstruction]=[]
        var renderSize=CGSize(width:1080,height:1920)
        for clip in clips {
            let asset=AVURLAsset(url:clip.url)
            guard let srcV=try await asset.loadTracks(withMediaType:.video).first else { continue }
            let range=CMTimeRange(start:CMTime(seconds:clip.start,preferredTimescale:600),end:CMTime(seconds:clip.end,preferredTimescale:600))
            let scaled=CMTimeMultiplyByFloat64(range.duration,multiplier:1/Double(clip.rate))
            try vTrack.insertTimeRange(range,of:srcV,at:cursor)
            vTrack.scaleTimeRange(CMTimeRange(start:cursor,duration:range.duration),toDuration:scaled)
            if let srcA=try await asset.loadTracks(withMediaType:.audio).first {
                try? aTrack.insertTimeRange(range,of:srcA,at:cursor)
                aTrack.scaleTimeRange(CMTimeRange(start:cursor,duration:range.duration),toDuration:scaled)
            }
            let natural=try await srcV.load(.naturalSize); let pref=try await srcV.load(.preferredTransform)
            let rect=CGRect(origin:.zero,size:natural).applying(pref); let size=CGSize(width:abs(rect.width),height:abs(rect.height)); if cursor == .zero { renderSize=size }
            let layer=AVMutableVideoCompositionLayerInstruction(assetTrack:vTrack)
            layer.setTransform(pref,at:cursor)
            let ins=AVMutableVideoCompositionInstruction(); ins.timeRange=CMTimeRange(start:cursor,duration:scaled); ins.layerInstructions=[layer]; instructions.append(ins)
            cursor = cursor + scaled
        }
        let vc=AVMutableVideoComposition(); vc.instructions=instructions; vc.renderSize=renderSize; vc.frameDuration=CMTime(value:1,timescale:30)
        if !text.isEmpty {
            let parent=CALayer(); let video=CALayer(); parent.frame=CGRect(origin:.zero,size:renderSize); video.frame=parent.frame; parent.addSublayer(video)
            let label=CATextLayer(); label.string=text; label.alignmentMode = .center; label.foregroundColor=UIColor.white.cgColor; label.fontSize=max(32,renderSize.width/22); label.contentsScale=UIScreen.main.scale; label.frame=CGRect(x:40,y:80,width:renderSize.width-80,height:100); parent.addSublayer(label)
            vc.animationTool=AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer:video,in:parent)
        }
        let out=FileManager.default.temporaryDirectory.appendingPathComponent("QingJian-\(UUID().uuidString).mp4")
        guard let session=AVAssetExportSession(asset:composition,presetName:AVAssetExportPresetHighestQuality) else { throw NSError(domain:"QingJian",code:4) }
        session.outputURL=out; session.outputFileType = .mp4; session.videoComposition=vc; session.shouldOptimizeForNetworkUse=true
        await session.export()
        if let e=session.error { throw e }; guard session.status == .completed else { throw NSError(domain:"QingJian",code:5,userInfo:[NSLocalizedDescriptionKey:"导出未完成"]) }; return out
    }
}
