import Foundation

struct MediaStore {
    static func copyVideo(data: Data) throws -> URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Imports", isDirectory: true)
        try FileManager.default.createDirectory(
            at: dir,
            withIntermediateDirectories: true,
            attributes: nil
        )
        let url = dir
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("mov")
        try data.write(to: url, options: Data.WritingOptions.atomic)
        return url
    }
}
