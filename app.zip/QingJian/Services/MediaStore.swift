import Foundation
import PhotosUI

struct MediaStore {
    static func copyVideo(from item: PhotosPickerItem) async throws -> URL {
        guard let data = try await item.loadTransferable(type: Data.self) else { throw NSError(domain:"QingJian",code:1,userInfo:[NSLocalizedDescriptionKey:"无法读取视频"]) }
        let dir = FileManager.default.urls(for:.cachesDirectory,in:.userDomainMask)[0].appendingPathComponent("Imports",isDirectory:true)
        try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
        let url = dir.appendingPathComponent(UUID().uuidString).appendingPathExtension("mov")
        try data.write(to:url,options:.atomic); return url
    }
}
