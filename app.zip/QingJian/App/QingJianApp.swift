import SwiftUI

@main
struct QingJianApp: App {
    @StateObject private var project = EditorProject()
    var body: some Scene {
        WindowGroup {
            EditorView().environmentObject(project)
                .preferredColorScheme(.dark)
        }
    }
}
