# Build1042 Artifact Return Bridge

版本：V7.4.14 · Build 1042

- 恢复 Codemagic publishing + CM_ARTIFACT_LINKS 的官方产物完成时机。
- 恢复任务专属 Git Binary Relay；只回传 artifact + receipt，不参与调度。
- IPA / DEB 使用同一 receipt schema 与 SHA-256/字节数验证。
- App 优先 Relay，失败才回退同一 Build 的 Artifact API；绝不创建第二个 Build。
- 手动“重抓产物”同样优先读取原 Task Relay。
- Codemagic 环境组恢复 buildmate_secrets；需要其中存在 BUILDMATE_RELAY_GITHUB_TOKEN（Contents Read and write）。
