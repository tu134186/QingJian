# Build1033 产物单次抓取 / 源码会话隔离报告

- 版本：V7.4.5 · Build 1033
- Codemagic Artifact：每个用户动作只执行一轮，不 sleep、不自动重复。
- v3 短时地址：优先识别 short_lived_download_url / shortLivedDownloadUrl；短时公共地址直接 GET。
- 手动重新导入源码：清除当前工作台 Run/Artifact Recovery checkpoint，不删除历史/黑匣子/产物中心记录。
- 首次导入：sourceURL 建立后源码体检立即可用。
- 编译主链与 clean codemagic.yaml 未改。
