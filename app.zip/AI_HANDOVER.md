# AI 接手说明

你正在维护 BuildMate。不要从旧历史猜产品方向。唯一现行依据是当前源码、`README.md`、`DEVELOPMENT_MANUAL.md`、`ARCHITECTURE.md`、`REGRESSION_TESTS.md`。

目标：维护六大核心及其直接基础设施，并保持中央视觉系统。

若发现 Creator、DeepTakeover、AI Tester、AI开发工作台、网页预览、UI Manifest/关系图等旧名：先判断是否只是兼容残留；不得把它们恢复成产品功能。

收到真实诊断包时先验证 Source SHA，再修第一个真实 Xcode/Theos 根错误。


## Build1012 诊断证据隔离
诊断根因必须与当前 Codemagic Build ID 完全一致。禁止使用 BuildGuardStore 的旧缓存诊断解释新的 Build；不匹配的证据只能标记为已隔离，不能作为修复依据。
