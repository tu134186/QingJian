# Build1041 Codemagic itms-services + DEB closure

版本：V7.4.13 · Build 1041

## 实机证据
Build1040 的真实 Codemagic Build 已成功并生成 IPA。Artifact API 返回稳定 URL；`POST /public-url`/认证直下进一步返回 HTTP 302，Location 指向 `itms-services://?action=download-manifest&url=https://api.codemagic.io/artifacts/.<signed>`。旧下载器拒绝非 http/https 重定向，因此停在 302。

## 修复
- Redirect delegate 对 `itms-services` 包装只做协议桥接：提取 query `url` 里的 HTTPS signed artifact，继续同一 URLSession / 同一抓取轮次。
- signed artifact 不携带 `x-auth-token`。
- Codemagic workflow 增加 Theos 检测、官方 Theos 安装、ldid 与 DEB 打包。
- Codemagic Artifact 模型/下载/恢复支持 IPA 与 DEB。

## 不变约束
- 不自动发起第二个 Build。
- Artifact 自动抓取仍是一轮。
- GitHub Actions IPA/DEB 主链不改。
