# Build248 RepairPlan Source SHA 修复报告

- 现场：Codemagic Build #121 在步骤 2.5 失败，旧 RepairPlan 搜索 DeepTakeoverWorkspaceView 文本 count=0，XcodeGen/Xcode 未执行。
- 根因：`.buildmate/repair-plan.json` 持久化在仓库，但旧格式没有绑定 app.zip Source SHA；替换新源码后旧 Patch 被错误应用。
- 修复：AIRepairPlan 新增 `sourceSHA256` / `taskID`；写入累计 RepairPlan 时绑定当前 `sourceLocalSHA256`。
- Codemagic / GitHub repair / SmartBuild：应用 Patch 前计算当前 app.zip SHA。RepairPlan 缺 SHA 或 SHA 不匹配 => stale，隔离跳过且允许新源码继续编译；SHA 匹配 => 保留原有最多 9 Patch、路径、文件存在、唯一命中等安全门。
- 验证：Swift 全量 parse 通过；release version gate 通过；Build243 Agent/Creator 回归通过；Codemagic YAML 可解析；内置 Codemagic 模板与根 YAML 一致；Build248 专项断言通过。
