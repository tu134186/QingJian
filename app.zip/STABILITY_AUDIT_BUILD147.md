# Build147 十轮稳定性总审计

1. Codemagic v3 `data.status` 权威映射。
2. 网络错误与业务终态分离。
3. Task/buildId 持久化与 App 重启恢复。
4. Build/Artifact 双状态机。
5. 真实终态优先，禁止 Artifact 覆盖。
6. 自动调度分钟保护与幂等策略。
7. GitHub Contents 串行/SHA/弱网读取。
8. Git Binary Relay 写权限、任务分支并发隔离、SHA 校验。
9. 诊断 01～09、执行端/目标源码、首因与恢复证据。
10. 发布门禁：版本、Swift、YAML、shell、不变量、ZIP 解包二次验证。

自动审计脚本：`scripts/check_cloud_state_invariants.py`。
