# Build1029 Real Xcode Missing Types Closure

## Evidence
Codemagic clean workflow reached real Xcode compilation. The complete error set collapsed to two missing active product primitives: `BMCloudCompiler` and `CodemagicStoredConfig`; secondary inference/type-check errors were consequences of those missing symbols.

## Fix
- Restored the two primitives in `CloudCompilerSettingsView.swift`.
- Kept legacy enum values hidden only for existing task/history compatibility.
- Changed the Codemagic default to `buildmate-clean-v1` and automatically migrates the retired `buildmate-ios-build76` value.
- Synchronized repository and embedded Codemagic workflow templates to `buildmate-clean-v1`.
- No AI/Agent/DeepTakeover functionality was restored.
