# Build1037 · Remove Preflight / Direct Compile

- Removed active source-preflight UI and BMSourcePreflightService.
- Compile no longer blocks on local project-structure heuristics.
- Source preparation now only reads ZIP, computes SHA-256, and saves recovery data.
- Idle fourth workbench action is now Compile Settings.
- Real source validity is determined by GitHub Actions / Codemagic / Xcode / Theos logs.
- Kept artifact one-shot retrieval, diagnostics, black box, publish path and central visual.
