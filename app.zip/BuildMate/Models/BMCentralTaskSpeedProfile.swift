import Foundation

/// Build1004：中央素材“任务转速表”配置模块。
/// 只负责把真实工作阶段映射成 5～120 的视觉速度，不创建/停止任何任务。
enum BMCentralTaskSpeedProfile {
    static let idleSpeed: Double = 18
    static let maximumSpeed: Double = 480

    static func speed(for stage: BuildWorkStage) -> Double {
        let value: Double
        switch stage {
        case .idle: value = 18
        case .preparing: value = 120
        case .uploading: value = 180
        case .syncingWorkflow: value = 240
        case .dispatching: value = 300
        case .queued: value = 180
        case .compiling: value = 480
        case .packaging: value = 360
        case .downloading: value = 300
        case .recovering: value = 120
        // 旧状态仍安全映射，避免历史任务恢复时出现视觉跳变；不代表重新启用旧 AI 功能。
        case .aiReading: value = 180
        case .aiAnalyzing: value = 240
        case .aiPatching: value = 300
        case .aiRebuilding: value = 420
        case .aiRetrying: value = 120
        case .artifactPending, .success, .failed, .cancelled: value = 18
        }
        return min(max(value, idleSpeed), maximumSpeed)
    }
}
