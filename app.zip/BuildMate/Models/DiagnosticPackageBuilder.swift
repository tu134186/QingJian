import Foundation

struct BMDiagnosticPackageBuilder {
    struct Entry {
        let name: String
        let data: Data
    }

    @MainActor
    static func build(taskID: String?, reportURL: URL? = nil, fallbackText: String = "") throws -> URL {
        let store = BMTaskBlackBox.shared
        let resolvedTaskID = taskID ?? store.latestTaskID
        let task = resolvedTaskID.flatMap { id in store.taskSummaries.first(where: { $0.taskID == id }) }
        let events = resolvedTaskID.map { store.events(for: $0) } ?? []
        let reportText: String = {
            if let reportURL, let text = try? String(contentsOf: reportURL, encoding: .utf8), !text.isEmpty { return text }
            return fallbackText.isEmpty ? "BuildMate 暂无独立 BUG 报告文本。" : fallbackText
        }()

        var entries: [Entry] = []
        entries.append(.init(name: "01-诊断摘要.txt", data: Data(summaryText(task: task, events: events, reportText: reportText).utf8)))
        entries.append(.init(name: "02-BUG报告.txt", data: Data(reportText.utf8)))

        if let id = resolvedTaskID {
            let timelineURL = try store.exportText(taskID: id)
            let jsonURL = try store.exportJSON(taskID: id)
            entries.append(.init(name: "03-任务时间线.txt", data: try Data(contentsOf: timelineURL)))
            entries.append(.init(name: "04-任务黑匣子.json", data: try Data(contentsOf: jsonURL)))
        }

        // Build146：诊断包直接携带网络、终态、失败上下文和恢复证据，减少再次去平台网页取证。
        let networkEvents = events.filter { e in
            let x = (e.stage + " " + e.message).lowercased()
            return x.contains("github") || x.contains("codemagic") || x.contains("http") || x.contains("network") || x.contains("timeout") || x.contains("relay")
        }
        let failureEvents = events.filter { $0.level == "ERROR" || $0.stage.contains("failureContext") || $0.stage.contains("sourceFailure") }
        let recoveryEvents = events.filter { e in let x=e.stage.lowercased(); return x.contains("recover") || x.contains("retry") || x.contains("relay") || x.contains("checkpoint") || x.contains("ghost") }
        func eventText(_ list: [BMBlackBoxEvent]) -> String {
            list.map { "#\($0.sequence) [\($0.date)] [\($0.provider ?? "BuildMate")] [\($0.stage)] \($0.message)" }.joined(separator: "\n")
        }
        func jsonValue(_ value: String?) -> Any { value ?? NSNull() }
        entries.append(.init(name: "06-网络请求摘要.txt", data: Data(eventText(networkEvents).utf8)))
        entries.append(.init(name: "07-状态快照.json", data: try JSONSerialization.data(withJSONObject: ["task_id": jsonValue(resolvedTaskID), "state": task?.stateTitle ?? "unknown", "last_stage": task?.lastStage ?? "unknown", "run_id": jsonValue(task?.runID), "captured_at": ISO8601DateFormatter().string(from: Date())], options: [.prettyPrinted, .sortedKeys])))
        entries.append(.init(name: "08-失败上下文.txt", data: Data(eventText(failureEvents).utf8)))
        entries.append(.init(name: "09-恢复记录.txt", data: Data(eventText(recoveryEvents).utf8)))

        let manifest: [String: Any] = [
            "schema": "buildmate-diagnostic-package-v1",
            "exported_at": ISO8601DateFormatter().string(from: Date()),
            "task_id": jsonValue(resolvedTaskID),
            "task_type": jsonValue(task?.taskType),
            "provider": jsonValue(task?.provider),
            "run_id": jsonValue(task?.runID),
            "source_sha256": jsonValue(task?.sourceSHA256),
            "source_label": jsonValue(task?.sourceLabel),
            "last_stage": jsonValue(task?.lastStage),
            "event_count": events.count,
            "files": entries.map(\.name) + ["05-manifest.json"],
            "redaction": "Token/API Key/Authorization/Cookie 等敏感字段由任务黑匣子记录层脱敏。"
        ]
        let manifestData = try JSONSerialization.data(withJSONObject: manifest, options: [.prettyPrinted, .sortedKeys])
        entries.append(.init(name: "05-manifest.json", data: manifestData))

        let suffix = resolvedTaskID ?? "Current"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("BuildMate-Diagnostic-\(suffix).zip")
        try? FileManager.default.removeItem(at: url)
        try BMStoredZipWriter.write(entries: entries, to: url)
        return url
    }

    private static func summaryText(task: BMTaskSummary?, events: [BMBlackBoxEvent], reportText: String) -> String {
        var lines: [String] = [
            "BuildMate 本次任务诊断摘要",
            "导出时间：\(Date().formatted(date: .numeric, time: .standard))"
        ]
        if let task {
            lines += [
                "Task ID：\(task.taskID)",
                "任务类型：\(task.taskType)",
                "状态：\(task.stateTitle)",
                "Provider：\(task.provider ?? "BuildMate")",
                "Run ID：\(task.runID ?? "无")",
                "Source SHA-256：\(task.sourceSHA256 ?? "无")",
                "源码：\(task.sourceLabel ?? "未知")",
                "最后阶段：\(task.lastStage)",
                "最后消息：\(task.lastMessage)"
            ]
        }
        let errors = events.filter { $0.level == "ERROR" }
        if !errors.isEmpty {
            lines.append("错误事件：\(errors.count)")
            for e in errors.suffix(8) { lines.append("- [\(e.stage)] \(e.message)") }
        }
        lines += ["", "原始 BUG/编译报告摘要：", String(reportText.prefix(6000))]
        return lines.joined(separator: "\n")
    }
}

private enum BMStoredZipWriter {
    private struct CentralRecord {
        let name: Data
        let crc32: UInt32
        let size: UInt32
        let offset: UInt32
        let time: UInt16
        let date: UInt16
    }

    static func write(entries: [BMDiagnosticPackageBuilder.Entry], to url: URL) throws {
        var archive = Data()
        var central: [CentralRecord] = []
        let (dosTime, dosDate) = dosDateTime(Date())

        for entry in entries {
            let name = Data(entry.name.utf8)
            let payload = entry.data
            let crc = crc32(payload)
            let offset = UInt32(archive.count)
            let size = UInt32(payload.count)

            archive.appendLE(UInt32(0x04034b50))
            archive.appendLE(UInt16(20))
            archive.appendLE(UInt16(0x0800))
            archive.appendLE(UInt16(0))
            archive.appendLE(dosTime)
            archive.appendLE(dosDate)
            archive.appendLE(crc)
            archive.appendLE(size)
            archive.appendLE(size)
            archive.appendLE(UInt16(name.count))
            archive.appendLE(UInt16(0))
            archive.append(name)
            archive.append(payload)
            central.append(.init(name: name, crc32: crc, size: size, offset: offset, time: dosTime, date: dosDate))
        }

        let centralOffset = UInt32(archive.count)
        for item in central {
            archive.appendLE(UInt32(0x02014b50))
            archive.appendLE(UInt16(20))
            archive.appendLE(UInt16(20))
            archive.appendLE(UInt16(0x0800))
            archive.appendLE(UInt16(0))
            archive.appendLE(item.time)
            archive.appendLE(item.date)
            archive.appendLE(item.crc32)
            archive.appendLE(item.size)
            archive.appendLE(item.size)
            archive.appendLE(UInt16(item.name.count))
            archive.appendLE(UInt16(0))
            archive.appendLE(UInt16(0))
            archive.appendLE(UInt16(0))
            archive.appendLE(UInt16(0))
            archive.appendLE(UInt32(0))
            archive.appendLE(item.offset)
            archive.append(item.name)
        }
        let centralSize = UInt32(archive.count) - centralOffset
        archive.appendLE(UInt32(0x06054b50))
        archive.appendLE(UInt16(0))
        archive.appendLE(UInt16(0))
        archive.appendLE(UInt16(central.count))
        archive.appendLE(UInt16(central.count))
        archive.appendLE(centralSize)
        archive.appendLE(centralOffset)
        archive.appendLE(UInt16(0))

        try archive.write(to: url, options: Data.WritingOptions.atomic)
    }

    private static func dosDateTime(_ date: Date) -> (UInt16, UInt16) {
        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)

        let clampedYear = max(1980, min(2107, components.year ?? 1980))
        let yearOffset = UInt16(clampedYear - 1980)
        let month = UInt16(max(1, min(12, components.month ?? 1)))
        let day = UInt16(max(1, min(31, components.day ?? 1)))
        let hour = UInt16(max(0, min(23, components.hour ?? 0)))
        let minute = UInt16(max(0, min(59, components.minute ?? 0)))
        let second = UInt16(max(0, min(59, components.second ?? 0)))

        let dateYearBits = yearOffset << 9
        let dateMonthBits = month << 5
        let dosDate = dateYearBits | dateMonthBits | day

        let timeHourBits = hour << 11
        let timeMinuteBits = minute << 5
        let timeSecondBits = second / 2
        let dosTime = timeHourBits | timeMinuteBits | timeSecondBits

        return (dosTime, dosDate)
    }

    private static func crc32(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data {
            var x = (crc ^ UInt32(byte)) & 0xff
            for _ in 0..<8 { x = (x & 1) == 1 ? (x >> 1) ^ 0xedb88320 : x >> 1 }
            crc = (crc >> 8) ^ x
        }
        return crc ^ 0xffffffff
    }
}

private extension Data {
    mutating func appendLE<T: FixedWidthInteger>(_ value: T) {
        var little = value.littleEndian
        Swift.withUnsafeBytes(of: &little) { append(contentsOf: $0) }
    }
}
