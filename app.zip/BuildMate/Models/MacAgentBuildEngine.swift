import Foundation

// Build165 consolidated 163-165: secure pairing + Xcode build engine + AI/local-Mac closed-loop guardrails.
enum BMMacProjectKind: String, Codable, CaseIterable { case workspace, project, xcodegen, theos, customScript, unknown }

struct BMMacBuildTarget: Codable, Equatable, Identifiable {
    var id: String { path }
    let kind: BMMacProjectKind
    let path: String
    let schemes: [String]
    let preferredScheme: String?
}

struct BMMacBuildDiagnostic: Codable, Equatable, Identifiable {
    let id: String
    let file: String?
    let line: Int?
    let column: Int?
    let severity: String
    let message: String
    let context: String?
}

struct BMMacBuildManifest: Codable, Equatable {
    let taskID: String
    let runID: String
    let sourceSHA256: String
    let projectKind: BMMacProjectKind
    let scheme: String?
    let xcodeVersion: String?
    let artifactKinds: [String]
    let diagnostics: [BMMacBuildDiagnostic]
    let createdAt: Date
}

enum BMMacAgentPairingStore {
    private static let prefix = "buildmate-mac-agent-pairing-v1-"
    static func isTrusted(nodeID: String) -> Bool { UserDefaults.standard.bool(forKey: prefix + nodeID) }
    static func trust(nodeID: String) { UserDefaults.standard.set(true, forKey: prefix + nodeID) }
    static func revoke(nodeID: String) { UserDefaults.standard.removeObject(forKey: prefix + nodeID) }
}

enum BMMacClosedLoopPolicy {
    static let maxAIRounds = 3
    static let maxRealBuilds = 2
    static func canDispatch(node: BMMacAgentNodeSnapshot, task: BMUnifiedTaskRecord) -> (Bool, String) {
        guard BMMacAgentPairingStore.isTrusted(nodeID: node.nodeID) else { return (false, "Mac Agent 尚未完成可信配对") }
        guard node.mayAcceptTask else { return (false, "Mac Agent 当前离线、过期或无空闲容量") }
        guard task.runID.isEmpty else { return (false, "已有 Run，只允许恢复原 Run，禁止重复编译") }
        guard BMUnifiedTaskPolicy.canStartCloudBuild(task) else { return (false, "必须先通过本地门禁并取得本次真实编译批准") }
        return (true, "允许派发一次私人 Mac 真编译")
    }

    static func shouldRepairAgain(aiRound: Int, realBuildCount: Int, sourceUnchanged: Bool, hasRealDiagnostic: Bool) -> (Bool, String) {
        guard sourceUnchanged else { return (false, "Source SHA 已变化，停止旧任务自动循环") }
        guard hasRealDiagnostic else { return (false, "没有真实 Xcode/编译诊断，不允许盲修") }
        guard aiRound < maxAIRounds else { return (false, "达到 AI 修复轮次上限") }
        guard realBuildCount < maxRealBuilds else { return (false, "达到真实编译预算上限") }
        return (true, "可进入下一轮 AI Patch；下一次真实编译仍需批准")
    }
}
