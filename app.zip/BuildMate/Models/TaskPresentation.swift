import Foundation

enum BMTaskPresentation {
    /// The black box intentionally records both a unified parent task and provider child tasks.
    /// The task center is a user-facing surface, so summaries sharing one real Run are collapsed
    /// into one card. Raw events remain untouched for diagnostics and export.
    static func grouped(_ summaries: [BMTaskSummary]) -> [BMTaskSummary] {
        let groups = Dictionary(grouping: summaries) { summary -> String in
            if let runID = summary.runID?.trimmingCharacters(in: .whitespacesAndNewlines), !runID.isEmpty {
                return "run:\(runID)"
            }
            return "task:\(summary.taskID)"
        }

        return groups.values.compactMap(representative).sorted { $0.updatedAt > $1.updatedAt }
    }

    private static func representative(_ values: [BMTaskSummary]) -> BMTaskSummary? {
        values.max { lhs, rhs in
            let l = priority(lhs)
            let r = priority(rhs)
            if l != r { return l < r }
            if lhs.updatedAt != rhs.updatedAt { return lhs.updatedAt < rhs.updatedAt }
            return lhs.startedAt < rhs.startedAt
        }
    }

    private static func priority(_ summary: BMTaskSummary) -> Int {
        var score = 0
        // Prefer the concrete provider execution over the UnifiedDevelopment envelope because
        // its timeline contains the real build/download diagnostics.
        if summary.taskType != "UnifiedDevelopment" { score += 100 }
        if let provider = summary.provider, !provider.isEmpty, provider != "BuildMate" { score += 30 }
        if summary.completed || summary.cancelled || summary.hasError { score += 10 }
        return score
    }
}
