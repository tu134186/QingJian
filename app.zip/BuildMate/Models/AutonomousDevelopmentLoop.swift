import Foundation

// Build157：AI 自主开发循环治理层。
// 自动化只覆盖“诊断 → AI 方案 → Patch → 本地门禁 → 是否值得申请云编译”。
// 真正消耗云编译分钟仍必须经过明确审批；Artifact 失败永远不能进入新编译。
enum BMAutonomousLoopStage: String, Codable, CaseIterable {
    case idle = "待命"
    case diagnosing = "读取真实错误"
    case planning = "AI 生成 Patch"
    case patching = "应用安全 Patch"
    case localGate = "本地门禁"
    case cloudCandidate = "申请云编译"
    case waitingApproval = "等待云编译批准"
    case cloudRunning = "真实云编译"
    case readingNewFailure = "读取新错误"
    case artifactRecovery = "产物恢复"
    case completed = "闭环完成"
    case stopped = "安全停止"
}

enum BMAutonomousStopReason: String, Codable {
    case maxRounds = "达到 AI 修复轮次上限"
    case cloudBudget = "达到云编译预算上限"
    case localGateFailed = "本地门禁未通过"
    case patchRisk = "Patch 风险过高或证据不足"
    case sourceChanged = "Source SHA 已变化"
    case artifactOnly = "当前只允许恢复 Artifact"
    case approvalRequired = "等待用户批准真实云编译"
    case noRealDiagnostic = "没有真实失败诊断"
}

struct BMAutonomousLoopPolicy: Codable, Equatable {
    var enabled: Bool
    var maxRepairRounds: Int
    var maxCloudBuildsPerTask: Int
    var minimumConfidence: Int
    var allowOnlyLowRiskPatch: Bool
    var requireCloudApprovalEveryTime: Bool

    static let safeDefault = BMAutonomousLoopPolicy(
        enabled: true,
        maxRepairRounds: 3,
        maxCloudBuildsPerTask: 2,
        minimumConfidence: 80,
        allowOnlyLowRiskPatch: true,
        requireCloudApprovalEveryTime: true
    )
}

struct BMAutonomousLoopRecord: Codable, Identifiable, Equatable {
    var id: String { taskID }
    var taskID: String
    var workspaceID: String
    var sourceSHA256: String
    var stage: BMAutonomousLoopStage
    var repairRound: Int
    var cloudBuildCount: Int
    var pendingCloudApproval: Bool
    var lastConfidence: Int?
    var lastRisk: String?
    var lastDecision: String
    var stopReason: BMAutonomousStopReason?
    var updatedAt: Date
}

enum BMAutonomousLoopStore {
    private static let policyKey = "buildmate-autonomous-loop-policy-v1"
    private static let recordsKey = "buildmate-autonomous-loop-records-v1"

    static var policy: BMAutonomousLoopPolicy {
        get {
            guard let data = UserDefaults.standard.data(forKey: policyKey),
                  let value = try? JSONDecoder().decode(BMAutonomousLoopPolicy.self, from: data) else { return .safeDefault }
            return value
        }
        set { if let data = try? JSONEncoder().encode(newValue) { UserDefaults.standard.set(data, forKey: policyKey) } }
    }

    static func load() -> [BMAutonomousLoopRecord] {
        guard let data = UserDefaults.standard.data(forKey: recordsKey),
              let value = try? JSONDecoder().decode([BMAutonomousLoopRecord].self, from: data) else { return [] }
        return value.sorted { $0.updatedAt > $1.updatedAt }
    }

    static func upsert(_ record: BMAutonomousLoopRecord) {
        var all = load(); all.removeAll { $0.taskID == record.taskID }; all.append(record)
        if let data = try? JSONEncoder().encode(all) { UserDefaults.standard.set(data, forKey: recordsKey) }
    }

    static func record(for task: BMUnifiedTaskRecord) -> BMAutonomousLoopRecord {
        if let existing = load().first(where: { $0.taskID == task.id }) { return existing }
        return .init(taskID: task.id, workspaceID: task.workspaceID, sourceSHA256: task.sourceSHA256, stage: .idle, repairRound: task.repairRound, cloudBuildCount: task.runID.isEmpty ? 0 : 1, pendingCloudApproval: false, lastConfidence: nil, lastRisk: nil, lastDecision: "等待真实诊断", stopReason: nil, updatedAt: Date())
    }
}

struct BMAutonomousCloudDecision: Equatable {
    let allowedToRequestApproval: Bool
    let reason: String
    let stopReason: BMAutonomousStopReason?
}

enum BMAutonomousLoopCoordinator {
    static func evaluatePatch(task: BMUnifiedTaskRecord, confidence: Int, risk: String, localGatePassed: Bool) -> BMAutonomousCloudDecision {
        let policy = BMAutonomousLoopStore.policy
        guard policy.enabled else { return .init(allowedToRequestApproval: false, reason: "自主循环已关闭。", stopReason: .approvalRequired) }
        guard task.stage != .artifact, task.artifactID == nil else { return .init(allowedToRequestApproval: false, reason: "任务已进入 Artifact 阶段，只允许恢复产物。", stopReason: .artifactOnly) }
        guard task.repairRound <= policy.maxRepairRounds else { return .init(allowedToRequestApproval: false, reason: "已达到 AI 修复轮次上限。", stopReason: .maxRounds) }
        guard localGatePassed else { return .init(allowedToRequestApproval: false, reason: "本地门禁未通过，不值得消耗云编译分钟。", stopReason: .localGateFailed) }
        guard confidence >= policy.minimumConfidence else { return .init(allowedToRequestApproval: false, reason: "AI 置信度低于 \(policy.minimumConfidence)%，停止申请云编译。", stopReason: .patchRisk) }
        if policy.allowOnlyLowRiskPatch && risk.lowercased() != "low" { return .init(allowedToRequestApproval: false, reason: "只允许 low-risk Patch 自动进入候选。", stopReason: .patchRisk) }
        let record = BMAutonomousLoopStore.record(for: task)
        guard record.cloudBuildCount < policy.maxCloudBuildsPerTask else { return .init(allowedToRequestApproval: false, reason: "该 Task 已达到 \(policy.maxCloudBuildsPerTask) 次真实云编译预算。", stopReason: .cloudBudget) }
        return .init(allowedToRequestApproval: true, reason: "Patch 与本地门禁满足条件；仅申请一次云编译批准，不会自动烧分钟。", stopReason: nil)
    }

    @MainActor
    static func requestCloudApproval(task: BMUnifiedTaskRecord, confidence: Int, risk: String) -> BMAutonomousLoopRecord {
        var record = BMAutonomousLoopStore.record(for: task)
        let decision = evaluatePatch(task: task, confidence: confidence, risk: risk, localGatePassed: task.localGatePassed)
        record.lastConfidence = confidence; record.lastRisk = risk; record.updatedAt = Date()
        record.lastDecision = decision.reason; record.stopReason = decision.stopReason
        record.pendingCloudApproval = decision.allowedToRequestApproval
        record.stage = decision.allowedToRequestApproval ? .waitingApproval : .stopped
        BMAutonomousLoopStore.upsert(record)
        BMTaskBlackBox.shared.record(taskID: task.id, taskType: "AutonomousDevelopment", stage: "autonomous.cloud.candidate", message: decision.reason, sourceSHA256: task.sourceSHA256, runID: task.runID.isEmpty ? nil : task.runID, provider: task.providerID, round: task.repairRound)
        return record
    }

    @MainActor
    static func approveOneCloudBuild(task: BMUnifiedTaskRecord) -> BMAutonomousLoopRecord {
        var record = BMAutonomousLoopStore.record(for: task)
        guard record.pendingCloudApproval else { return record }
        record.pendingCloudApproval = false; record.cloudBuildCount += 1; record.stage = .cloudRunning
        record.lastDecision = "用户已批准本 Task 的第 \(record.cloudBuildCount) 次真实云编译。"; record.updatedAt = Date()
        BMAutonomousLoopStore.upsert(record)
        BMTaskBlackBox.shared.record(taskID: task.id, taskType: "AutonomousDevelopment", stage: "autonomous.cloud.approved", message: record.lastDecision, sourceSHA256: task.sourceSHA256, runID: task.runID.isEmpty ? nil : task.runID, provider: task.providerID, round: task.repairRound)
        return record
    }

    @MainActor
    static func markNewFailure(task: BMUnifiedTaskRecord, hasRealDiagnostic: Bool) -> BMAutonomousLoopRecord {
        var record = BMAutonomousLoopStore.record(for: task); record.updatedAt = Date()
        if hasRealDiagnostic && record.repairRound < BMAutonomousLoopStore.policy.maxRepairRounds {
            record.repairRound += 1; record.stage = .readingNewFailure; record.stopReason = nil
            record.lastDecision = "读取本次真实失败的新错误，进入下一轮 AI 分析；不会复用旧错误。"
        } else {
            record.stage = .stopped; record.stopReason = hasRealDiagnostic ? .maxRounds : .noRealDiagnostic
            record.lastDecision = hasRealDiagnostic ? "达到修复轮次上限，安全停止。" : "没有新的真实诊断，禁止 AI 猜测修复。"
        }
        BMAutonomousLoopStore.upsert(record); return record
    }
}
