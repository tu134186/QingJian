import Foundation

// Build159: BuildMate Mac Agent v1 protocol. Transport-neutral contract for private macOS build nodes.
enum BMMacAgentProtocol {
    static let version = "buildmate-mac-agent-v1"
    static let minimumHeartbeatSeconds: TimeInterval = 15
    static let staleAfterSeconds: TimeInterval = 90
}

enum BMAgentNodeState: String, Codable, CaseIterable {
    case online = "在线"
    case busy = "忙碌"
    case degraded = "降级"
    case offline = "离线"
    case unknown = "未知"
}

struct BMAgentCapability: Codable, Hashable, Identifiable {
    let id: String
    let value: String
}

struct BMMacAgentHandshake: Codable {
    let protocolVersion: String
    let nodeID: String
    let nodeName: String
    let agentVersion: String
    let macOSVersion: String
    let xcodeVersions: [String]
    let capabilities: [BMAgentCapability]
    let maxConcurrentTasks: Int
}

struct BMMacAgentHeartbeat: Codable {
    let protocolVersion: String
    let nodeID: String
    let state: BMAgentNodeState
    let activeTaskIDs: [String]
    let freeDiskBytes: Int64?
    let sentAt: Date
}

struct BMMacAgentTaskEnvelope: Codable, Identifiable {
    let id: String // Task ID
    let workspaceID: String
    let sourceSHA256: String
    let sourceLocator: String
    let branch: String
    let requestedXcode: String?
    let artifactKinds: [String]
    let checkpointToken: String?
}

struct BMMacAgentRunReceipt: Codable {
    let protocolVersion: String
    let taskID: String
    let nodeID: String
    let runID: String
    let acceptedSourceSHA256: String
    let acceptedAt: Date
}

struct BMMacAgentArtifactReceipt: Codable {
    let protocolVersion: String
    let taskID: String
    let runID: String
    let artifactID: String
    let fileName: String
    let bytes: Int64
    let sha256: String
}

struct BMMacAgentNodeSnapshot: Codable, Identifiable {
    var id: String { nodeID }
    let nodeID: String
    let nodeName: String
    let endpoint: String
    let agentVersion: String
    let macOSVersion: String
    let xcodeVersions: [String]
    let capabilities: [BMAgentCapability]
    let maxConcurrentTasks: Int
    let state: BMAgentNodeState
    let activeTaskIDs: [String]
    let lastHeartbeatAt: Date

    var isStale: Bool { Date().timeIntervalSince(lastHeartbeatAt) > BMMacAgentProtocol.staleAfterSeconds }
    var mayAcceptTask: Bool { !isStale && state == .online && activeTaskIDs.count < max(1, maxConcurrentTasks) }
}

enum BMMacAgentNodeStore {
    private static let key = "buildmate-mac-agent-nodes-v1"
    static func load() -> [BMMacAgentNodeSnapshot] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([BMMacAgentNodeSnapshot].self, from: data)) ?? []
    }
    static func save(_ nodes: [BMMacAgentNodeSnapshot]) {
        guard let data = try? JSONEncoder().encode(nodes) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
    static func upsert(_ node: BMMacAgentNodeSnapshot) {
        var nodes = load().filter { $0.nodeID != node.nodeID }
        nodes.append(node); save(nodes)
    }
}

// Public boundary for future third-party/private Provider adapters.
protocol BMProviderPluginSDK {
    var pluginID: String { get }
    var displayName: String { get }
    var capabilities: Set<String> { get }
    func health() async throws -> String
}
