import Foundation

// Build159：Provider 执行总线。Core/AI 只表达能力请求；Mac Agent v1 也通过同一总线接入。
enum BMProviderAvailability: String, Codable {
    case verified = "已验证"
    case ready = "可用"
    case unverified = "未验证"
    case quotaBlocked = "额度受限"
    case disabled = "已停用"
    case legacy = "兼容保留"
}

struct BMProviderExecutionProfile: Codable, Identifiable, Equatable {
    let id: String
    let displayName: String
    let availability: BMProviderAvailability
    let supportsIOS: Bool
    let supportsArtifactReturn: Bool
    let supportsDiagnostics: Bool
    let priority: Int
    let note: String

    var mayReceiveNewAutonomousBuild: Bool {
        supportsIOS && supportsDiagnostics && (availability == .verified || availability == .ready)
    }
}

enum BMProviderExecutionRegistry {
    // Codemagic 是当前唯一真实验证过“编译 + IPA 自动回传”的执行器。
    // GitHub Actions 额度不可用，因此只保留兼容信息，不能被自主循环自动选中。
    static let profiles: [BMProviderExecutionProfile] = [
        .init(id: "codemagic", displayName: "Codemagic", availability: .verified, supportsIOS: true, supportsArtifactReturn: true, supportsDiagnostics: true, priority: 100, note: "当前已验证主 Provider；Codemagic → Git Relay → IPA 自动回传链冻结。"),
        .init(id: "self-hosted-mac", displayName: "私人 Mac Agent", availability: .unverified, supportsIOS: true, supportsArtifactReturn: true, supportsDiagnostics: true, priority: 80, note: "BuildMate Mac Agent v1 已定义握手/能力/心跳/恢复协议；节点验证前不自动派发。"),
        .init(id: "bitrise", displayName: "Bitrise", availability: .unverified, supportsIOS: true, supportsArtifactReturn: true, supportsDiagnostics: true, priority: 60, note: "预留 Provider，验证前不自动派发。"),
        .init(id: "github-actions", displayName: "GitHub Actions", availability: .quotaBlocked, supportsIOS: true, supportsArtifactReturn: true, supportsDiagnostics: true, priority: 10, note: "Legacy CI：额度受限，保留兼容但退出 AI 自主修复默认路径。")
    ]

    static func profile(id: String) -> BMProviderExecutionProfile? {
        let normalized = id == "github" ? "github-actions" : id
        return profiles.first { $0.id == normalized }
    }

    static func preferredAutonomousProvider(requestedID: String?) -> BMProviderExecutionProfile? {
        if let requestedID, let requested = profile(id: requestedID), requested.mayReceiveNewAutonomousBuild { return requested }
        return profiles.filter(\.mayReceiveNewAutonomousBuild).sorted { $0.priority > $1.priority }.first
    }
}

struct BMProviderDispatchDecision: Equatable {
    let allowed: Bool
    let providerID: String?
    let reason: String
}



// Build227：一次批准只允许创建一次真实 Run，并且批准自动过期。
// 防止 App 长时间挂后台、恢复旧任务或重复点击后继续沿用陈旧批准烧云分钟。
struct BMCloudApprovalLease: Codable, Equatable {
    let taskID: String
    let grantedAt: Date
    let expiresAt: Date
    var consumedAt: Date?

    var isValid: Bool { consumedAt == nil && Date() < expiresAt }
}

enum BMCloudApprovalLeaseStore {
    private static let key = "buildmate-cloud-approval-leases-v1"
    static let ttl: TimeInterval = 10 * 60

    private static func load() -> [String: BMCloudApprovalLease] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let value = try? JSONDecoder().decode([String: BMCloudApprovalLease].self, from: data) else { return [:] }
        return value
    }
    private static func save(_ value: [String: BMCloudApprovalLease]) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: key) }
    }
    static func grant(taskID: String, now: Date = Date()) {
        var all = load()
        all[taskID] = .init(taskID: taskID, grantedAt: now, expiresAt: now.addingTimeInterval(ttl), consumedAt: nil)
        save(all)
    }
    static func isValid(taskID: String, now: Date = Date()) -> Bool {
        guard let lease = load()[taskID] else { return false }
        return lease.consumedAt == nil && now < lease.expiresAt
    }
    static func consume(taskID: String, now: Date = Date()) {
        var all = load(); guard var lease = all[taskID] else { return }
        lease.consumedAt = now; all[taskID] = lease; save(all)
    }
    static func revoke(taskID: String) {
        var all = load(); all.removeValue(forKey: taskID); save(all)
    }
    static func activeCount(now: Date = Date()) -> Int {
        load().values.filter { $0.consumedAt == nil && now < $0.expiresAt }.count
    }
}

enum BMProviderExecutionBus {
    static func evaluateNewCloudBuild(task: BMUnifiedTaskRecord, requestedProviderID: String? = nil) -> BMProviderDispatchDecision {
        guard BMUnifiedTaskPolicy.canStartCloudBuild(task) else {
            return .init(allowed: false, providerID: nil, reason: "统一任务尚未通过本地门禁、有效的一次性云编译批准，或批准已经过期。")
        }
        guard task.runID.isEmpty else {
            return .init(allowed: false, providerID: task.providerID, reason: "已有 Run，必须恢复同一 Run，Execution Bus 禁止重新派发。")
        }
        guard !BMUnifiedTaskPolicy.artifactFailureMustNotRebuild(task) else {
            return .init(allowed: false, providerID: task.providerID, reason: "任务已进入 Artifact 阶段，只允许恢复产物。")
        }
        guard let provider = BMProviderExecutionRegistry.preferredAutonomousProvider(requestedID: requestedProviderID ?? task.providerID) else {
            return .init(allowed: false, providerID: nil, reason: "没有已验证且可接受新自主编译的 Provider。")
        }
        return .init(allowed: true, providerID: provider.id, reason: "已通过 Provider 能力层；实际创建 Run 前仍必须执行分钟预算与 Provider Adapter 自身校验。")
    }
}
