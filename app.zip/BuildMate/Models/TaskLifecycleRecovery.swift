import Foundation
import UserNotifications

struct BMTaskLifecycleRecoveryReport: Hashable {
    var closedAudits: Int = 0
    var closedSupersededTasks: Int = 0
    var closedArtifactTasks: Int = 0
    var preservedRemoteRuns: Int = 0
    var backgroundSeconds: Int = 0

    var changedCount: Int { closedAudits + closedSupersededTasks + closedArtifactTasks }
    var summary: String {
        var parts: [String] = []
        if backgroundSeconds >= 60 { parts.append("后台 \(backgroundSeconds / 60) 分钟") }
        if closedAudits > 0 { parts.append("收口审计 \(closedAudits)") }
        if closedArtifactTasks > 0 { parts.append("补齐成功任务 \(closedArtifactTasks)") }
        if closedSupersededTasks > 0 { parts.append("清理旧任务 \(closedSupersededTasks)") }
        if preservedRemoteRuns > 0 { parts.append("保留远端 Run \(preservedRemoteRuns)") }
        return parts.isEmpty ? "任务状态已对账，无需修复。" : parts.joined(separator: " · ")
    }
}

@MainActor
enum BMTaskLifecycleRecovery {
    private static let backgroundDateKey = "buildmate-last-background-date-v1"
    private static let lastReconcileKey = "buildmate-last-task-reconcile-v1"

    static func markBackground() {
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: backgroundDateKey)
    }

    static func secondsSinceBackground(now: Date = Date()) -> Int {
        let value = UserDefaults.standard.double(forKey: backgroundDateKey)
        guard value > 0 else { return 0 }
        return max(0, Int(now.timeIntervalSince1970 - value))
    }

    @discardableResult
    static func reconcileLocalState(now: Date = Date()) -> BMTaskLifecycleRecoveryReport {
        BMTaskExecutionCoordinator.reconcileFromBlackBox()
        var report = BMTaskLifecycleRecoveryReport()
        report.backgroundSeconds = secondsSinceBackground(now: now)

        let summaries = BMTaskBlackBox.shared.taskSummaries
        let artifacts = BMArtifactDeliveryStore.load().filter { $0.verified }

        // 历史 FinalStabilityAudit 在旧版本可能停在 closure.ready/attention；
        // 审计本身不创建云 Run，可安全补写 completed 终态。
        for summary in summaries where summary.taskType == "FinalStabilityAudit" && !summary.completed && !summary.cancelled && !summary.hasError {
            guard summary.lastStage.hasPrefix("closure.") else { continue }
            BMTaskBlackBox.shared.record(
                taskID: summary.taskID,
                taskType: summary.taskType,
                stage: "completed",
                message: "前台恢复对账：历史稳定审计已有最终结果，自动补齐完成终态。",
                sourceSHA256: summary.sourceSHA256,
                runID: summary.runID,
                provider: summary.provider ?? "BuildMate"
            )
            report.closedAudits += 1
        }

        let refreshed = BMTaskBlackBox.shared.taskSummaries
        for summary in refreshed where !summary.completed && !summary.cancelled && !summary.hasError {
            guard let sha = summary.sourceSHA256, !sha.isEmpty else { continue }
            let matchingArtifacts = artifacts.filter { $0.sourceSHA256 == sha }
            guard let newestArtifact = matchingArtifacts.max(by: { $0.updatedAt < $1.updatedAt }), newestArtifact.updatedAt >= summary.updatedAt else {
                if let run = summary.runID, !run.isEmpty { report.preservedRemoteRuns += 1 }
                continue
            }

            if let run = summary.runID, !run.isEmpty {
                if run == newestArtifact.runID {
                    BMTaskBlackBox.shared.record(
                        taskID: summary.taskID,
                        taskType: summary.taskType,
                        stage: "completed",
                        message: "前台恢复对账：同 Run 已存在已验证 IPA，自动补齐成功终态。",
                        sourceSHA256: sha,
                        runID: run,
                        provider: summary.provider
                    )
                    report.closedArtifactTasks += 1
                } else {
                    // 不擅自结束另一个真实远端 Run；继续保留并由 Provider 权威状态对账。
                    report.preservedRemoteRuns += 1
                }
                continue
            }

            // 没有真实 Run ID 的本地体检/审批/包装任务，如果其后同 SHA 已有成功 IPA，
            // 说明它已经被后续成功链路取代。用 cancelled 终态收口，避免永久“进行中”。
            BMTaskBlackBox.shared.record(
                taskID: summary.taskID,
                taskType: summary.taskType,
                level: "WARN",
                stage: "cancelled",
                message: "前台恢复对账：同 Source SHA 已有后续已验证 IPA，本地旧任务已被成功链路取代并自动收口。",
                sourceSHA256: sha,
                provider: summary.provider ?? "BuildMate"
            )
            report.closedSupersededTasks += 1
        }

        // 同步 UnifiedDevelopment 持久状态：无 Run 的旧任务若已有同 SHA 成功 Artifact，标记 cancelled；
        // 有 Run 的任务保持给远端恢复，不制造假终态。
        for task in BMUnifiedTaskStore.load() where ![BMUnifiedTaskStage.completed, .failed, .cancelled].contains(task.stage) {
            guard !task.sourceSHA256.isEmpty else { continue }
            guard let artifact = artifacts.first(where: { $0.sourceSHA256 == task.sourceSHA256 && $0.updatedAt >= task.updatedAt }) else { continue }
            if !task.runID.isEmpty {
                if task.runID == artifact.runID {
                    BMTaskExecutionCoordinator.close(task, success: true, message: "前台恢复对账：同 Run 已存在已验证 IPA，统一父任务自动收口。")
                }
            } else {
                BMTaskExecutionCoordinator.cancel(task, message: "前台恢复对账：同 Source SHA 已有后续成功 IPA，旧本地任务已被取代。")
            }
        }

        UserDefaults.standard.set(now.timeIntervalSince1970, forKey: lastReconcileKey)
        return report
    }
}

enum BMBuildNotificationCenter {
    private static let requestedKey = "buildmate-notification-permission-requested-v1"

    static func requestAuthorizationIfNeeded() {
        guard !UserDefaults.standard.bool(forKey: requestedKey) else { return }
        UserDefaults.standard.set(true, forKey: requestedKey)
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    static func send(title: String, body: String, identifier: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }
}
