import Foundation

struct SmartRecoveryPoint: Codable, Identifiable {
    var id: String { sha256 }
    var sha256: String
    var sourceName: String
    var savedName: String
    var createdAt: Date
    var byteCount: Int
}

struct SmartKnowledgeEvent: Codable, Identifiable {
    var id: String
    var date: Date
    var provider: String
    var kind: String
    var message: String
    var recoveredBySuccess: Bool
}

enum SmartBuildSupportStore {
    private static let recoveryKey = "smart-recovery-points-v1"
    private static let knowledgeKey = "smart-build-knowledge-v1"

    static func recordSuccess(provider: String) {
        markLatestFailureRecovered(provider: provider)
    }

    static func recordFailure(provider: String, kind: BuildFailureKind, message: String) {
        appendKnowledge(provider: provider, kind: kind, message: message)
    }

    static func saveRecovery(data: Data, sourceName: String, sha256: String) throws -> SmartRecoveryPoint {
        var points = recoveryPoints()
        if let existing = points.first(where: { $0.sha256 == sha256 }), FileManager.default.fileExists(atPath: recoveryURL(for: existing).path) {
            return existing
        }
        let directory = try recoveryDirectory()
        let short = String(sha256.prefix(12))
        let safeBase = sourceName.replacingOccurrences(of: "/", with: "-")
        let saved = "\(short)-\(safeBase.hasSuffix(".zip") ? safeBase : safeBase + ".zip")"
        let url = directory.appendingPathComponent(saved)
        try data.write(to: url, options: .atomic)
        let point = SmartRecoveryPoint(sha256: sha256, sourceName: sourceName, savedName: saved, createdAt: Date(), byteCount: data.count)
        points.removeAll { $0.sha256 == sha256 }
        points.insert(point, at: 0)
        if points.count > 6 {
            for old in points.dropFirst(6) { try? FileManager.default.removeItem(at: recoveryURL(for: old)) }
            points = Array(points.prefix(6))
        }
        if let encoded = try? JSONEncoder().encode(points) { UserDefaults.standard.set(encoded, forKey: recoveryKey) }
        return point
    }

    static func recoveryPoints() -> [SmartRecoveryPoint] {
        guard let data = UserDefaults.standard.data(forKey: recoveryKey),
              let values = try? JSONDecoder().decode([SmartRecoveryPoint].self, from: data) else { return [] }
        return values.filter { FileManager.default.fileExists(atPath: recoveryURL(for: $0).path) }
    }

    static func recoveryURL(for point: SmartRecoveryPoint) -> URL {
        let base = (try? recoveryDirectory()) ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent(point.savedName)
    }

    static func knowledge() -> [SmartKnowledgeEvent] {
        guard let data = UserDefaults.standard.data(forKey: knowledgeKey),
              let values = try? JSONDecoder().decode([SmartKnowledgeEvent].self, from: data) else { return [] }
        return values
    }

    private static func recoveryDirectory() throws -> URL {
        let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = root.appendingPathComponent("BuildMateRecovery", isDirectory: true)
        if !FileManager.default.fileExists(atPath: dir.path) {
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        return dir
    }

    private static func appendKnowledge(provider: String, kind: BuildFailureKind, message: String) {
        var values = knowledge()
        let event = SmartKnowledgeEvent(id: UUID().uuidString, date: Date(), provider: provider, kind: kind.rawValue, message: String(message.prefix(360)), recoveredBySuccess: false)
        values.insert(event, at: 0)
        if values.count > 30 { values = Array(values.prefix(30)) }
        if let data = try? JSONEncoder().encode(values) { UserDefaults.standard.set(data, forKey: knowledgeKey) }
    }

    private static func markLatestFailureRecovered(provider: String) {
        var values = knowledge()
        if let i = values.firstIndex(where: { $0.provider == provider && !$0.recoveredBySuccess }) {
            values[i].recoveredBySuccess = true
            if let data = try? JSONEncoder().encode(values) { UserDefaults.standard.set(data, forKey: knowledgeKey) }
        }
    }
}
