import Foundation

// Build154：统一任务流水。AI、门禁、云编译、产物、黑匣子共享同一 Task ID / Source SHA。
enum BMUnifiedTaskStage: String, Codable, CaseIterable {
    case created = "任务已创建"
    case diagnostic = "提取真实错误"
    case aiPlanning = "AI 分析"
    case patchReady = "Patch 待审核"
    case patchApproved = "Patch 已批准"
    case localGate = "本地门禁"
    case cloudApproval = "等待云编译批准"
    case cloudRunning = "云编译中"
    case artifact = "产物回收"
    case verified = "产物已校验"
    case completed = "闭环完成"
    case blocked = "已阻断"
    case failed = "失败"
    case cancelled = "已取消"
}

struct BMUnifiedTaskRecord: Codable, Identifiable, Equatable {
    var id: String
    var workspaceID: String
    var sourceName: String
    var sourceSHA256: String
    var providerID: String
    var aiProviderID: String
    var runID: String
    var stage: BMUnifiedTaskStage
    var repairRound: Int
    var patchSummary: String
    var localGatePassed: Bool
    var cloudApproved: Bool
    var artifactID: String?
    var firstError: String?
    var checkpoint: String
    var createdAt: Date
    var updatedAt: Date
    // Build252：同一 ZIP 即使 SHA 相同，重新导入也属于新的源码代际；旧 Task 不得自动复活。
    var sourceGenerationID: String?
}

enum BMUnifiedTaskStore {
    private static let key = "buildmate-unified-task-pipeline-v1"
    static func load() -> [BMUnifiedTaskRecord] {
        guard let data = UserDefaults.standard.data(forKey: key), let items = try? JSONDecoder().decode([BMUnifiedTaskRecord].self, from: data) else { return [] }
        return items.sorted { $0.updatedAt > $1.updatedAt }
    }
    static func save(_ items: [BMUnifiedTaskRecord]) { if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: key) } }
    static func upsert(_ item: BMUnifiedTaskRecord) { var all = load(); all.removeAll { $0.id == item.id }; all.append(item); save(all) }
    static func latest() -> BMUnifiedTaskRecord? { load().first }
}

enum BMUnifiedTaskPolicy {
    static func canStartCloudBuild(_ task: BMUnifiedTaskRecord) -> Bool {
        task.localGatePassed && task.cloudApproved && BMCloudApprovalLeaseStore.isValid(taskID: task.id) && !task.sourceSHA256.isEmpty && task.stage != .artifact && task.stage != .verified && task.stage != .completed
    }
    static func canRunAIRepair(_ task: BMUnifiedTaskRecord) -> Bool {
        task.repairRound < BMAIRepairGovernanceStore.maxRounds && task.stage != .artifact && task.stage != .verified && task.stage != .completed
    }
    static func artifactFailureMustNotRebuild(_ task: BMUnifiedTaskRecord) -> Bool {
        task.stage == .artifact || task.artifactID != nil
    }
}

struct BMUnifiedTaskCoordinator {
    static func create(workspaceID: String, sourceName: String, sourceSHA: String, providerID: String, aiProviderID: String, sourceGenerationID: String? = nil) -> BMUnifiedTaskRecord {
        let now = Date(); let id = "BM-" + UUID().uuidString.prefix(8).uppercased()
        let item = BMUnifiedTaskRecord(id:String(id), workspaceID:workspaceID, sourceName:sourceName, sourceSHA256:sourceSHA, providerID:providerID, aiProviderID:aiProviderID, runID:"", stage:.created, repairRound:0, patchSummary:"", localGatePassed:false, cloudApproved:false, artifactID:nil, firstError:nil, checkpoint:"created", createdAt:now, updatedAt:now, sourceGenerationID:sourceGenerationID)
        BMUnifiedTaskStore.upsert(item); return item
    }
    static func transition(_ task: BMUnifiedTaskRecord, to stage: BMUnifiedTaskStage, checkpoint: String) -> BMUnifiedTaskRecord {
        var next = task; next.stage = stage; next.checkpoint = checkpoint; next.updatedAt = Date(); BMUnifiedTaskStore.upsert(next); return next
    }
    static func approvePatch(_ task: BMUnifiedTaskRecord, summary: String) -> BMUnifiedTaskRecord {
        var next = task; next.patchSummary = summary; next.stage = .patchApproved; next.updatedAt = Date(); BMUnifiedTaskStore.upsert(next); return next
    }
    static func finishLocalGate(_ task: BMUnifiedTaskRecord, passed: Bool, message: String) -> BMUnifiedTaskRecord {
        var next = task; next.localGatePassed = passed; next.stage = passed ? .cloudApproval : .blocked; next.checkpoint = message; next.updatedAt = Date(); BMUnifiedTaskStore.upsert(next); return next
    }
    static func approveCloud(_ task: BMUnifiedTaskRecord) -> BMUnifiedTaskRecord {
        var next = task; guard next.localGatePassed else { return next }; next.cloudApproved = true; next.stage = .cloudApproval; next.checkpoint = "user-approved-cloud-build"; next.updatedAt = Date(); BMCloudApprovalLeaseStore.grant(taskID: next.id); BMUnifiedTaskStore.upsert(next); return next
    }
    static func bindRun(_ task: BMUnifiedTaskRecord, runID: String) -> BMUnifiedTaskRecord {
        var next = task; next.runID = runID; next.stage = .cloudRunning; next.checkpoint = "remote-run-bound"; next.updatedAt = Date(); BMCloudApprovalLeaseStore.consume(taskID: next.id); BMUnifiedTaskStore.upsert(next); return next
    }
    static func bindArtifact(_ task: BMUnifiedTaskRecord, artifactID: String) -> BMUnifiedTaskRecord {
        var next = task; next.artifactID = artifactID; next.stage = .artifact; next.checkpoint = "artifact-recovery"; next.updatedAt = Date(); BMUnifiedTaskStore.upsert(next); return next
    }
}


// Build155：所有用户可见开发入口统一进入同一个 Coordinator；底层已验证 Provider 实现保持冻结。
enum BMExecutionEntry: String, Codable, CaseIterable {
    case normalCompile = "普通编译"
    case aiCompile = "AI 编译"
    case aiRepair = "AI 自动修复"
    case deepTakeover = "AI 深度接管"
    case artifactRecovery = "产物恢复"
}

@MainActor
enum BMTaskExecutionCoordinator {
    private static var activeTaskID: String?

    static func enter(_ entry: BMExecutionEntry, workspaceID: String, sourceName: String, sourceSHA: String, providerID: String, aiProviderID: String, sourceGenerationID: String? = nil) -> BMUnifiedTaskRecord {
        // Build1012: remove the historical same Workspace + Source SHA task lock.
        // Every explicit user entry receives a fresh local Task identity. This prevents a stale/non-terminal
        // persisted task from permanently hijacking the Compile button after reinstall, crash or double tap.
        // Actual double cloud dispatch is still prevented by ContentView.busy while the current request is running.
        // Build1013: clean up orphan local tasks that never obtained a real cloud Run ID.
        // They are safe to cancel because no provider execution was created; this prevents repeated taps from filling
        // the task center with permanent "进行中" shells while preserving any task that already owns a real Run.
        for stale in BMUnifiedTaskStore.load() where
            stale.workspaceID == workspaceID &&
            stale.sourceSHA256 == sourceSHA &&
            stale.runID.isEmpty &&
            ![BMUnifiedTaskStage.completed, .failed, .cancelled].contains(stale.stage) {
            cancel(stale, message: "新的显式编译请求已取代未创建云端 Run 的旧本地任务；旧任务自动收口。")
        }

        var task = BMUnifiedTaskCoordinator.create(workspaceID: workspaceID, sourceName: sourceName, sourceSHA: sourceSHA, providerID: providerID, aiProviderID: aiProviderID, sourceGenerationID: sourceGenerationID)
        activeTaskID = task.id
        task.checkpoint = "entry:\(entry.rawValue)"
        BMUnifiedTaskStore.upsert(task)
        BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", stage: "coordinator.enter", message: "入口=\(entry.rawValue)；已创建新的显式任务，不按 Source SHA 复用旧任务。", sourceSHA256: sourceSHA, provider: providerID, sourceLabel: sourceName)
        return task
    }


    // Build252：源码“重新导入/Creator 重生成/手动切换”是原子边界。
    // 即使新 ZIP 的 SHA 与旧 ZIP 完全一致，也通过 generation 隔离，旧任务只保留黑匣子证据，不再注入首页。
    static func archiveForSourceReplacement(newSourceSHA: String, newGenerationID: String, sourceName: String) {
        for var task in BMUnifiedTaskStore.load() where ![BMUnifiedTaskStage.completed, .failed, .cancelled].contains(task.stage) {
            let sameGeneration = task.sourceSHA256 == newSourceSHA && task.sourceGenerationID == newGenerationID
            guard !sameGeneration else { continue }
            BMCloudApprovalLeaseStore.revoke(taskID: task.id)
            task.cloudApproved = false
            task.stage = .cancelled
            task.checkpoint = "source-generation-superseded"
            task.updatedAt = Date()
            BMUnifiedTaskStore.upsert(task)
            BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", level: "INFO", stage: "source.superseded", message: "源码已切换到新代际；旧 Task 已归档，仅保留历史 Run/Patch 证据，不再参与当前工作台。", sourceSHA256: task.sourceSHA256, runID: task.runID.isEmpty ? nil : task.runID, provider: task.providerID, sourceLabel: task.sourceName)
            if activeTaskID == task.id { activeTaskID = nil }
        }
        BMTaskBlackBox.shared.record(taskID: "SOURCE-" + String(newGenerationID.prefix(8)), taskType: "SourceLifecycle", stage: "source.generation.created", message: "新源码代际已建立：\(sourceName)。同 SHA 重新导入也不会复活旧 Task。", sourceSHA256: newSourceSHA, sourceLabel: sourceName)
    }

    static func bindExistingBlackBox(_ task: BMUnifiedTaskRecord, blackBoxTaskID: String) {
        activeTaskID = task.id
        BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", stage: "coordinator.provider.bound", message: "Provider 子任务 \(blackBoxTaskID) 已绑定统一任务。", sourceSHA256: task.sourceSHA256, provider: task.providerID, parentTaskID: task.id, correlationID: blackBoxTaskID)
    }

    static func stage(_ task: BMUnifiedTaskRecord, _ stage: BMUnifiedTaskStage, checkpoint: String) -> BMUnifiedTaskRecord {
        let next = BMUnifiedTaskCoordinator.transition(task, to: stage, checkpoint: checkpoint)
        BMTaskBlackBox.shared.record(taskID: next.id, taskType: "UnifiedDevelopment", stage: "pipeline.\(stage.rawValue)", message: checkpoint, sourceSHA256: next.sourceSHA256, runID: next.runID.isEmpty ? nil : next.runID, provider: next.providerID, round: next.repairRound)
        return next
    }

    static func bindRun(_ task: BMUnifiedTaskRecord, runID: String) -> BMUnifiedTaskRecord {
        let next = BMUnifiedTaskCoordinator.bindRun(task, runID: runID)
        BMTaskBlackBox.shared.record(taskID: next.id, taskType: "UnifiedDevelopment", stage: "pipeline.run.bound", message: "真实云端 Run 已绑定；后续恢复只允许继续此 Run。", sourceSHA256: next.sourceSHA256, runID: runID, provider: next.providerID)
        return next
    }

    static func close(_ task: BMUnifiedTaskRecord, success: Bool, message: String) {
        let terminal: BMUnifiedTaskStage = success ? .completed : .failed
        let next = BMUnifiedTaskCoordinator.transition(task, to: terminal, checkpoint: message)
        BMCloudApprovalLeaseStore.revoke(taskID: next.id)
        BMTaskBlackBox.shared.record(taskID: next.id, taskType: "UnifiedDevelopment", level: success ? "INFO" : "ERROR", stage: success ? "completed" : "failed", message: message, sourceSHA256: next.sourceSHA256, runID: next.runID.isEmpty ? nil : next.runID, provider: next.providerID, sourceLabel: next.sourceName)
        if activeTaskID == task.id { activeTaskID = nil }
    }

    static func cancel(_ task: BMUnifiedTaskRecord, message: String) {
        let next = BMUnifiedTaskCoordinator.transition(task, to: .cancelled, checkpoint: message)
        BMCloudApprovalLeaseStore.revoke(taskID: next.id)
        BMTaskBlackBox.shared.record(taskID: next.id, taskType: "UnifiedDevelopment", level: "WARN", stage: "cancelled", message: message, sourceSHA256: next.sourceSHA256, runID: next.runID.isEmpty ? nil : next.runID, provider: next.providerID, sourceLabel: next.sourceName)
        if activeTaskID == task.id { activeTaskID = nil }
    }

    // Build172：兼容修复历史父任务。若同一真实 Run 的 Provider 子任务已有权威终态，
    // UnifiedDevelopment 必须同步收口，绝不能继续显示“进行中”或提供“恢复原 Run”。
    static func reconcileFromBlackBox() {
        let summaries = BMTaskBlackBox.shared.taskSummaries
        for task in BMUnifiedTaskStore.load() where ![BMUnifiedTaskStage.completed, .failed, .cancelled].contains(task.stage) {
            guard !task.runID.isEmpty else { continue }
            let related = summaries.first { summary in
                summary.taskID != task.id && summary.runID == task.runID && (summary.completed || summary.cancelled || summary.hasError)
            }
            guard let related else { continue }
            if related.completed {
                close(task, success: true, message: "同 Run \(task.runID) 已由 Provider 确认完成；历史统一父任务自动收口。")
            } else if related.cancelled {
                cancel(task, message: "同 Run \(task.runID) 已由 Provider 确认取消；历史统一父任务自动收口。")
            } else {
                if [.diagnostic, .aiPlanning, .patchReady, .patchApproved, .localGate, .cloudApproval].contains(task.stage) || task.repairRound > 0 {
                    BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", stage: "provider.failure.preserved", message: "Provider Run 已失败，但父 Task 已进入诊断/AI 修复链；失败 Run 保留为证据，不把父 Task 错收口为失败。", sourceSHA256: task.sourceSHA256, runID: task.runID, provider: task.providerID, round: task.repairRound)
                } else {
                    close(task, success: false, message: "同 Run \(task.runID) 已由 Provider 确认失败；历史统一父任务自动收口。")
                }
            }
        }
    }
}
