import Foundation

enum BMGhostTaskKind: String, Codable {
    case interrupted = "疑似系统中断"
    case remoteRun = "远程 Run 待恢复"
    case artifact = "产物待恢复"
    case approval = "等待人工操作"
}

struct BMGhostTask: Identifiable {
    let id: String
    let task: BMUnifiedTaskRecord
    let kind: BMGhostTaskKind
    let reason: String
    let age: TimeInterval
}

enum BMTaskResumeAction: String, Codable {
    case resumeRemoteRun = "恢复原 Run"
    case recoverArtifact = "只恢复产物"
    case reviewPatch = "继续审核 Patch"
    case approveCloud = "继续云编译审批"
    case rerunLocalGate = "重新运行本地门禁"
    case resumePipeline = "从检查点继续"
    case none = "无需恢复"
}

struct BMTaskResumePlan: Hashable {
    let action: BMTaskResumeAction
    let title: String
    let detail: String
    let safeWithoutNewBuild: Bool
}

enum BMTaskRecoveryCenter {
    static let staleInterval: TimeInterval = 10 * 60

    static func plan(for task: BMUnifiedTaskRecord) -> BMTaskResumePlan {
        switch task.stage {
        case .cloudRunning where !task.runID.isEmpty:
            return .init(action: .resumeRemoteRun, title: "恢复原 Run", detail: "继续查询 Run \(task.runID)，禁止创建第二个云编译。", safeWithoutNewBuild: true)
        case .artifact, .verified:
            return .init(action: .recoverArtifact, title: "只恢复产物", detail: "构建结果已经存在，只恢复 IPA/DEB/诊断产物，绝不重新编译。", safeWithoutNewBuild: true)
        case .patchReady:
            return .init(action: .reviewPatch, title: "继续审核 Patch", detail: "回到 AI Diff 审核，不会自动修改或触发云编译。", safeWithoutNewBuild: true)
        case .cloudApproval:
            return .init(action: .approveCloud, title: "批准修复并验证编译", detail: "一次点击完成恢复与明确批准；BuildMate 校验 Source SHA 后继续同一 Task，重复点击不会重复创建 Run。", safeWithoutNewBuild: false)
        case .localGate, .blocked:
            return .init(action: .rerunLocalGate, title: "重新运行本地门禁", detail: "先重新做本地检查，不触发真实云编译。", safeWithoutNewBuild: true)
        case .completed, .failed, .cancelled:
            return .init(action: .none, title: "任务已终止", detail: "该任务已有终态，不自动复活。", safeWithoutNewBuild: true)
        default:
            return .init(action: .resumePipeline, title: "从检查点继续", detail: "从 \(task.checkpoint) 恢复统一任务状态。", safeWithoutNewBuild: true)
        }
    }

    static func ghostTasks(now: Date = Date()) -> [BMGhostTask] {
        BMUnifiedTaskStore.load().compactMap { task in
            guard ![BMUnifiedTaskStage.completed, .failed, .cancelled].contains(task.stage) else { return nil }
            let age = now.timeIntervalSince(task.updatedAt)
            let plan = plan(for: task)
            if task.stage == .cloudRunning && !task.runID.isEmpty {
                return .init(id: task.id, task: task, kind: .remoteRun, reason: plan.detail, age: age)
            }
            if task.stage == .artifact || task.artifactID != nil {
                return .init(id: task.id, task: task, kind: .artifact, reason: plan.detail, age: age)
            }
            if task.stage == .patchReady || task.stage == .cloudApproval {
                return .init(id: task.id, task: task, kind: .approval, reason: plan.detail, age: age)
            }
            guard age >= staleInterval else { return nil }
            return .init(id: task.id, task: task, kind: .interrupted, reason: "任务超过 10 分钟没有新检查点，可能因 App 被杀、崩溃、断网或系统中断而停留。", age: age)
        }.sorted { $0.task.updatedAt > $1.task.updatedAt }
    }

    @MainActor
    static func prepareResume(taskID: String) -> BMTaskResumePlan? {
        guard var task = BMUnifiedTaskStore.load().first(where: { $0.id == taskID }) else { return nil }
        let plan = plan(for: task)
        guard plan.action != .none else { return plan }

        // Build251：审批动作一次完成“恢复 + 明确批准 + 一次性 Lease + 通知主工作台续跑”。
        if plan.action == .approveCloud {
            if BMCloudApprovalLeaseStore.isValid(taskID: task.id) {
                BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", stage: "approval.idempotent", message: "云编译批准已存在；重复点击不重复授权、不重复创建 Run。", sourceSHA256: task.sourceSHA256, runID: task.runID.isEmpty ? nil : task.runID, provider: task.providerID)
            } else {
                let previousRun = task.runID
                task.runID = ""
                task.cloudApproved = true
                task.stage = .cloudApproval
                task.checkpoint = "user-approved-repair-validation"
                task.updatedAt = Date()
                BMCloudApprovalLeaseStore.grant(taskID: task.id)
                BMUnifiedTaskStore.upsert(task)
                _ = BMAutonomousLoopCoordinator.approveOneCloudBuild(task: task)
                BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", stage: "approval.granted", message: previousRun.isEmpty ? "用户已批准一次 Patch 后真实验证编译；等待工作台续跑。" : "用户已批准 Patch 后真实验证编译；上一失败 Run \(previousRun) 保留为历史证据，新验证 Run 继续绑定同一 Task。", sourceSHA256: task.sourceSHA256, runID: previousRun.isEmpty ? nil : previousRun, provider: task.providerID, round: task.repairRound)
            }
            NotificationCenter.default.post(name: .bmCloudApprovalGranted, object: task.id)
            return .init(action: .approveCloud, title: "已批准并继续云编译", detail: "批准已生效；工作台会校验当前 Source SHA 后自动续跑同一 Task。", safeWithoutNewBuild: false)
        }

        task.checkpoint = "resume-prepared:\(plan.action.rawValue)"
        task.updatedAt = Date()
        BMUnifiedTaskStore.upsert(task)
        BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", stage: "recovery.prepared", message: "已恢复到安全检查点：\(plan.title)。\(plan.detail)", sourceSHA256: task.sourceSHA256, runID: task.runID.isEmpty ? nil : task.runID, provider: task.providerID)
        return plan
    }

    @MainActor
    static func invalidateApprovalsForSourceChange(newSourceSHA: String) {
        guard !newSourceSHA.isEmpty else { return }
        for var task in BMUnifiedTaskStore.load()
        where ![BMUnifiedTaskStage.completed, .failed, .cancelled].contains(task.stage) && task.sourceSHA256 != newSourceSHA {
            guard task.stage == .cloudApproval || task.stage == .patchReady || task.cloudApproved else { continue }
            BMCloudApprovalLeaseStore.revoke(taskID: task.id)
            task.cloudApproved = false
            task.stage = .blocked
            task.checkpoint = "source-sha-changed-old-approval-invalidated"
            task.updatedAt = Date()
            BMUnifiedTaskStore.upsert(task)
            BMTaskBlackBox.shared.record(taskID: task.id, taskType: "UnifiedDevelopment", level: "WARN", stage: "source.changed", message: "当前源码已变化；旧 Patch / 云编译审批自动失效，禁止跨 Source SHA 续跑。", sourceSHA256: task.sourceSHA256, runID: task.runID.isEmpty ? nil : task.runID, provider: task.providerID, round: task.repairRound)
        }
    }
}

extension Notification.Name {
    static let bmCloudApprovalGranted = Notification.Name("BuildMate.CloudApprovalGranted")
}

struct BMPatchDiffItem: Codable, Identifiable, Hashable {
    var id: String
    var path: String
    var before: String
    var after: String
    var reason: String
}

struct BMPatchDiffSnapshot: Codable, Hashable {
    var createdAt: Date
    var items: [BMPatchDiffItem]
}

enum BMPatchDiffStore {
    private static let key = "ai-development-patch-diff-v1"
    private static func clipped(_ text: String) -> String { String(text.prefix(6000)) }
    static func save(plan: AIRepairPlan) {
        let items = plan.patches.prefix(30).enumerated().map { index, patch in
            BMPatchDiffItem(id: "\(index)-\(patch.path)", path: patch.path, before: clipped(patch.search), after: clipped(patch.replace), reason: patch.reason ?? "AI Patch")
        }
        let snapshot = BMPatchDiffSnapshot(createdAt: Date(), items: items)
        if let data = try? JSONEncoder().encode(snapshot) { UserDefaults.standard.set(data, forKey: key) }
    }
    static func load() -> BMPatchDiffSnapshot? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(BMPatchDiffSnapshot.self, from: data)
    }
    static func clear() { UserDefaults.standard.removeObject(forKey: key) }
}
