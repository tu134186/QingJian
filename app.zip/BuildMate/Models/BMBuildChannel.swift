import Foundation

enum BMBuildChannel: String, Codable {
    case beta
    case release
    static var current: BMBuildChannel { .beta } // Release 通道预留：正式发布时由构建配置替换。
    static var intelligentTesterAvailable: Bool { current == .beta }
}
