import Foundation

enum BMAppStoreReleasePhase: String, Codable {
    case idle = "待准备"
    case metadataReady = "元数据已同步"
    case buildAttached = "Build 已绑定"
    case screenshotsReady = "截图已上传"
    case reviewDraft = "审核草稿已创建"
    case submitted = "已提交审核"
}

struct BMAppStoreReleaseDraft: Codable, Hashable {
    var locale: String
    var descriptionText: String
    var keywords: String
    var promotionalText: String
    var whatsNew: String
    var screenshotDisplayType: String
    var lastVersionID: String
    var lastLocalizationID: String
    var lastReviewSubmissionID: String
    var phase: BMAppStoreReleasePhase
    var updatedAt: Date

    static let empty = BMAppStoreReleaseDraft(
        locale: "zh-Hans",
        descriptionText: "",
        keywords: "",
        promotionalText: "",
        whatsNew: "",
        screenshotDisplayType: "APP_IPHONE_67",
        lastVersionID: "",
        lastLocalizationID: "",
        lastReviewSubmissionID: "",
        phase: .idle,
        updatedAt: Date()
    )
}

enum BMAppStoreReleaseDraftStore {
    private static let key = "buildmate-app-store-release-draft-v2"
    static func load() -> BMAppStoreReleaseDraft {
        guard let data = UserDefaults.standard.data(forKey: key),
              let value = try? JSONDecoder().decode(BMAppStoreReleaseDraft.self, from: data) else { return .empty }
        return value
    }
    static func save(_ value: BMAppStoreReleaseDraft) {
        var next = value; next.updatedAt = Date()
        if let data = try? JSONEncoder().encode(next) { UserDefaults.standard.set(data, forKey: key) }
    }
}

struct BMASCVersionSummary: Identifiable, Hashable {
    let id: String
    let versionString: String
    let state: String
}

struct BMASCLocalizationSummary: Identifiable, Hashable {
    let id: String
    let locale: String
}

struct BMASCReviewSubmissionSummary: Identifiable, Hashable {
    let id: String
    let state: String
}
