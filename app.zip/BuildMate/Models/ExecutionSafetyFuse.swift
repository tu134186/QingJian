import Foundation

// Build1021：幽灵任务熔断器。
// 只禁止恢复器/AI/Legacy 自动创建 Run；用户明确点击 GitHub Actions / Codemagic 编译仍允许。
enum BMExecutionSafetyFuse {
    static let policyVersion = "buildmate-execution-fuse-v1"
    static let githubActionsExecutionEnabled = true
    static let automaticAICloudDispatchEnabled = false
    static let recoveryMayCreateRun = false

    private static let installedKey = "execution-safety-fuse-installed-v1"
    private static let blockedCountKey = "execution-safety-fuse-blocked-count-v1"
    private static let lastReasonKey = "execution-safety-fuse-last-reason-v1"

    static func installEmergencyFuse() {
        UserDefaults.standard.set(true, forKey: installedKey)
        // 历史自动接管标记会在 App 启动/前台恢复时触发旧路径；Build168 永久清除。
        UserDefaults.standard.set(false, forKey: "autopilot-pending-v1")
    }

    static func recordBlockedGitHubDispatch(reason: String) {
        let next = UserDefaults.standard.integer(forKey: blockedCountKey) + 1
        UserDefaults.standard.set(next, forKey: blockedCountKey)
        UserDefaults.standard.set(reason, forKey: lastReasonKey)
    }

    static var isInstalled: Bool { UserDefaults.standard.bool(forKey: installedKey) }
    static var blockedCount: Int { UserDefaults.standard.integer(forKey: blockedCountKey) }
    static var lastReason: String { UserDefaults.standard.string(forKey: lastReasonKey) ?? "" }

    static func mayCreateNewRun(providerID: String, isRecovery: Bool, initiatedByAI: Bool) -> Bool {
        if isRecovery { return false }
        if initiatedByAI { return false }
        return true
    }
}
