import Foundation

enum BuildWorkStage: String {
    case idle
    case preparing
    case uploading
    case syncingWorkflow
    case dispatching
    case queued
    case compiling
    case packaging
    case downloading
    case recovering
    case aiReading
    case aiAnalyzing
    case aiPatching
    case aiRebuilding
    case aiRetrying
    case artifactPending
    case success
    case failed
    case cancelled

    var title: String {
        switch self {
        case .idle: return "等待开始"
        case .preparing: return "正在准备工程"
        case .uploading: return "正在上传源码"
        case .syncingWorkflow: return "正在同步工作流"
        case .dispatching: return "正在启动云端 Run"
        case .queued: return "已进入云端队列"
        case .compiling: return "Xcode 云端编译中"
        case .packaging: return "正在打包产物"
        case .downloading: return "正在读取/下载产物"
        case .recovering: return "网络恢复中"
        case .aiReading: return "AI 正在读取真实错误"
        case .aiAnalyzing: return "AI 正在分析并生成修复"
        case .aiPatching: return "正在应用 AI 修复"
        case .aiRebuilding: return "AI 修复后重新编译"
        case .aiRetrying: return "AI 准备下一轮修复"
        case .artifactPending: return "编译成功 · IPA待获取"
        case .success: return "工作完成"
        case .failed: return "工作失败"
        case .cancelled: return "工作已停止"
        }
    }

    var pipelineIndex: Int {
        switch self {
        case .idle: return 0
        case .preparing: return 1
        case .uploading: return 2
        case .syncingWorkflow: return 3
        case .dispatching, .queued: return 4
        case .compiling, .recovering: return 5
        case .aiReading, .aiAnalyzing, .aiPatching, .aiRebuilding, .aiRetrying: return 6
        case .packaging: return 7
        case .downloading: return 8
        case .artifactPending: return 8
        case .success: return 9
        case .failed, .cancelled: return 0
        }
    }

    var icon: String {
        switch self {
        case .aiReading, .aiAnalyzing, .aiPatching, .aiRetrying: return "brain.head.profile"
        case .uploading, .syncingWorkflow, .dispatching, .queued: return "icloud.and.arrow.up.fill"
        case .recovering: return "arrow.clockwise.icloud.fill"
        case .packaging: return "shippingbox.fill"
        case .downloading: return "square.and.arrow.down.fill"
        case .artifactPending: return "arrow.down.circle.fill"
        case .success: return "checkmark.circle.fill"
        case .failed: return "xmark.octagon.fill"
        case .cancelled: return "stop.circle.fill"
        default: return "bolt.circle.fill"
        }
    }
}
