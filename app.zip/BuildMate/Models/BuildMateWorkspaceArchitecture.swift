import Foundation

// Build149：BuildMate 独立平台边界。
// BuildMate 自己拥有“工作空间/任务/状态/产物/诊断”；GitHub、Codemagic、Bitrise 等只是可替换适配器。
enum BMIntegrationRole: String, Codable, CaseIterable {
    case source = "源码平台"
    case compiler = "编译平台"
    case intelligence = "AI Provider"
    case artifact = "产物回传"
    case distribution = "发布平台"
}

enum BMSourceProviderID: String, Codable, CaseIterable, Identifiable {
    case github = "github"
    case gitlab = "gitlab"
    case gitea = "gitea"
    case localFiles = "local-files"
    case genericGit = "generic-git"
    var id: String { rawValue }
}

struct BMIntegrationDescriptor: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let role: BMIntegrationRole
    let icon: String
    let enabled: Bool
    let available: Bool
    let note: String
}

enum BMSourceProviderRegistry {
    static let current: BMSourceProviderID = .github

    static let providers: [BMIntegrationDescriptor] = [
        .init(id: BMSourceProviderID.github.rawValue, name: "GitHub", role: .source, icon: "chevron.left.forwardslash.chevron.right", enabled: true, available: true, note: "当前正式源码适配器"),
        .init(id: BMSourceProviderID.gitlab.rawValue, name: "GitLab", role: .source, icon: "shippingbox", enabled: false, available: false, note: "预留源码适配器"),
        .init(id: BMSourceProviderID.gitea.rawValue, name: "Gitea", role: .source, icon: "server.rack", enabled: false, available: false, note: "预留私有 Git 适配器"),
        .init(id: BMSourceProviderID.localFiles.rawValue, name: "本地文件", role: .source, icon: "folder", enabled: false, available: false, note: "未来支持无需 Git 托管的直接源码输入"),
        .init(id: BMSourceProviderID.genericGit.rawValue, name: "通用 Git", role: .source, icon: "point.3.connected.trianglepath.dotted", enabled: false, available: false, note: "未来通用 Git Remote 适配层")
    ]

    static var currentDescriptor: BMIntegrationDescriptor {
        providers.first { $0.id == current.rawValue } ?? providers[0]
    }
}

/// BuildMate 自己的工作空间身份，不再把 GitHub 仓库当成 App 身份。
/// 当前版本仍从已有 owner/repo 迁移，未来切换源码平台时 Workspace ID 不需要变化。
struct BMWorkspaceIdentity: Codable, Equatable {
    var workspaceID: String
    var displayName: String
    var sourceProviderID: String
    var sourceLocator: String
    var branch: String
    var updatedAt: Date
}

enum BMWorkspaceIdentityStore {
    private static let key = "buildmate-workspace-identity-v1"

    static func load(owner: String, repo: String, branch: String) -> BMWorkspaceIdentity {
        if let data = UserDefaults.standard.data(forKey: key),
           let value = try? JSONDecoder().decode(BMWorkspaceIdentity.self, from: data) {
            var migrated = value
            // 兼容旧版：用户在 GitHub 内切换仓库后，工作空间显示同步更新，但 Workspace 仍属于 BuildMate。
            if !repo.isEmpty && migrated.sourceLocator != owner + "/" + repo {
                migrated.displayName = repo
                migrated.sourceProviderID = BMSourceProviderID.github.rawValue
                migrated.sourceLocator = owner + "/" + repo
                migrated.branch = branch
                migrated.updatedAt = Date()
                save(migrated)
            }
            return migrated
        }
        let value = BMWorkspaceIdentity(
            workspaceID: UUID().uuidString,
            displayName: repo.isEmpty ? "未选择项目" : repo,
            sourceProviderID: BMSourceProviderID.github.rawValue,
            sourceLocator: owner.isEmpty || repo.isEmpty ? "" : owner + "/" + repo,
            branch: branch,
            updatedAt: Date()
        )
        save(value)
        return value
    }

    static func save(_ value: BMWorkspaceIdentity) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}

enum BMArchitectureBoundary {
    static let principles: [String] = [
        "BuildMate 是独立总控，不属于任何 Git/CI/AI 厂商。",
        "工作空间是 BuildMate 一等对象；源码仓库只是工作空间的一个 Source Adapter。",
        "源码平台、编译平台、AI Provider、产物回传与发布平台分别独立选择。",
        "任务黑匣子与 Task ID 跨 Provider 保持连续，切换平台不改变任务身份。",
        "一个远程 Run 已存在时只恢复同一 Run；Artifact 异常不得触发重复编译。",
        "任何 Provider 专属 Token 只存在于对应 Adapter/Keychain，不进入 Core、日志或诊断包。"
    ]
}
