import Foundation

struct BuildConfig: Codable {
    var displayName: String?
    var bundleID: String?
    var version: String?
    var build: Int?
    var productName: String?

    var hasOverrides: Bool {
        !(displayName ?? "").isEmpty || !(bundleID ?? "").isEmpty || !(version ?? "").isEmpty || build != nil || !(productName ?? "").isEmpty
    }
}

struct GitHubRepoInfo {
    var fullName: String
    var defaultBranch: String
    var isPrivate: Bool
    var canPush: Bool
}

struct GitHubWorkflowRun {
    var id: Int64
    var status: String
    var conclusion: String?
    var htmlURL: String?
    var createdAt: Date?

    var readableState: String {
        if status == "completed" {
            switch conclusion {
            case "success": return "✅ 编译成功"
            case "failure": return "❌ 编译失败"
            case "cancelled": return "⏹ 已取消"
            default: return "⚠️ 已结束：\(conclusion ?? "未知")"
            }
        }
        if status == "in_progress" { return "🔨 Xcode 正在编译…" }
        if status == "queued" { return "⏳ 已进入 GitHub 队列…" }
        return "⏳ \(status)"
    }
}

struct BuildReport: Codable {
    var runID: Int64?
    var ok: Bool
    var phase: String
    var projectType: String?
    var projectFile: String?
    var scheme: String?
    var displayName: String?
    var bundleID: String?
    var version: String?
    var build: String?
    var executable: String?
    var deploymentTarget: String?
    var ipaName: String?
    var debName: String?
    var errorSignature: String?
    var diagnosis: String?
    var createdAt: String?
    var warnings: [String]?
    var artifactKind: String?
    var artifactName: String?
    var artifactUploaded: Bool?
    var sourceSHA256: String?
    var expectedSourceSHA256: String?
    var sourceBytes: String?
    var expectedSourceBytes: String?
    var checkoutSHA: String?
    var expectedHeadSHA: String?
    var sourceName: String?
    var sourceTraceOK: Bool?

    var isPreflight: Bool { phase == "preflight" }
    var hasVerifiedArtifact: Bool { !isPreflight && ok && artifactUploaded == true }

    var headline: String {
        if isPreflight { return ok ? "✅ 工程预检通过（未执行编译）" : "❌ 工程预检失败" }
        if ok {
            if artifactKind == "DEB" || projectType == "theos" { return "✅ DEB 编译完成" }
            return "✅ IPA 编译完成"
        }
        return "❌ 编译失败"
    }

    var summary: String {
        var lines: [String] = []
        lines.append(headline)
        if let projectType { lines.append("工程：\(projectType)") }
        if let scheme { lines.append("Scheme：\(scheme)") }
        if let displayName { lines.append("标题：\(displayName)") }
        if let bundleID { lines.append("Bundle ID：\(bundleID)") }
        if let version { lines.append("版本：\(version) (Build \(build ?? "?") )") }
        if let deploymentTarget { lines.append("最低 iOS：\(deploymentTarget)") }
        if let ipaName { lines.append("IPA：\(ipaName)") }
        if let debName { lines.append("DEB：\(debName)") }
        if let errorSignature, !errorSignature.isEmpty { lines.append("错误：\(errorSignature)") }
        if let diagnosis, !diagnosis.isEmpty { lines.append("判断：\(diagnosis)") }
        if let sourceSHA256 { lines.append("源码 SHA-256：\(sourceSHA256)") }
        if let expectedSourceSHA256 { lines.append("期望 SHA-256：\(expectedSourceSHA256)") }
        if let checkoutSHA { lines.append("Actions Checkout：\(checkoutSHA)") }
        if let expectedHeadSHA { lines.append("派发前 HEAD：\(expectedHeadSHA)") }
        if let sourceTraceOK { lines.append(sourceTraceOK ? "源码链路：✅ 指纹一致" : "源码链路：❌ 指纹不一致") }
        if let warnings, !warnings.isEmpty {
            lines.append("预检提醒：")
            for warning in warnings.prefix(5) { lines.append("• \(warning)") }
        }
        return lines.joined(separator: "\n")
    }
}

struct GitHubArtifact {
    var id: Int64
    var name: String
    var downloadURL: String
    var expired: Bool
}

struct BuildHistoryRecord: Codable, Identifiable {
    var id: Int64 { runID }
    var runID: Int64
    var result: String
    var date: Date
    var repository: String? = nil
    var sourceName: String? = nil
    var aiRounds: Int? = nil
    var aiSummary: String? = nil
    var artifactName: String? = nil

    var dateText: String {
        let f = DateFormatter()
        f.dateFormat = "MM-dd HH:mm"
        return f.string(from: date)
    }
}

struct PendingArtifactRecord: Codable, Identifiable {
    var id: Int64 { runID }
    var runID: Int64
    var owner: String
    var repo: String
    var artifactKind: String
    var artifactName: String? = nil
    var preferredFileName: String? = nil
    var runURL: String? = nil
    var localPath: String? = nil
    var createdAt: Date = Date()

    var displayKind: String { artifactKind.uppercased() == "DEB" ? "DEB" : "IPA" }
}

enum PendingArtifactStore {
    private static let key = "pending-artifacts-v1"

    static func load() -> [PendingArtifactRecord] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([PendingArtifactRecord].self, from: data)) ?? []
    }

    static func save(_ items: [PendingArtifactRecord]) {
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}

enum BuildHistoryStore {
    private static let key = "build-history-v1"

    static func load() -> [BuildHistoryRecord] {
        guard let data = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([BuildHistoryRecord].self, from: data)) ?? []
    }

    static func save(_ items: [BuildHistoryRecord]) {
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    @discardableResult
    static func upsert(_ item: BuildHistoryRecord, into current: [BuildHistoryRecord], limit: Int = 30) -> [BuildHistoryRecord] {
        var items = current.filter { $0.runID != item.runID }
        items.insert(item, at: 0)
        if items.count > limit { items = Array(items.prefix(limit)) }
        save(items)
        return items
    }
}


struct GitHubAccount: Identifiable, Hashable {
    let login: String
    var id: String { login }
}

struct GitHubRepository: Identifiable, Hashable {
    let fullName: String
    let owner: String
    let name: String
    let isPrivate: Bool
    let defaultBranch: String
    let updatedAt: Date?
    var id: String { fullName }
}
