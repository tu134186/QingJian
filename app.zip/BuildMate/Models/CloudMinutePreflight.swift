import Foundation

struct BMCloudMinuteGitHubResult {
    let login: String
    let repository: GitHubRepoInfo
}

/// Build222: capability checks that run before any cloud Build is created.
/// They consume normal provider API calls only; they never start a runner.
enum BMCloudMinutePreflight {
    static func validateGitHub(_ github: GitHubService) async throws -> BMCloudMinuteGitHubResult {
        let account = try await github.currentAccount()
        let repository = try await github.repoInfo()
        guard repository.canPush else {
            throw NSError(
                domain: "BuildMate.CloudPreflight",
                code: 403,
                userInfo: [NSLocalizedDescriptionKey: "GitHub 当前仓库没有 Contents 写入能力。请先修复 Token / Repository access，再启动云编译。"]
            )
        }
        return .init(login: account.login, repository: repository)
    }

    static func validateCodemagic(_ codemagic: CodemagicService) async throws -> String {
        try await codemagic.testConnection()
    }
}
