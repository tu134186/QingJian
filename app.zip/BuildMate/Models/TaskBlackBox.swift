import Foundation
import SwiftUI

struct BMBlackBoxEvent: Codable, Identifiable, Hashable {
    let id: UUID
    let sequence: Int
    let taskID: String
    let taskType: String
    let date: Date
    let level: String
    let stage: String
    let message: String
    let sourceSHA256: String?
    let runID: String?
    let diagnosticID: String?
    let provider: String?
    let round: Int?
    let sourceLabel: String?
    let platform: String?
    let nodeID: String?
    let parentTaskID: String?
    let correlationID: String?
    let errorFingerprint: String?

    init(sequence: Int, taskID: String, taskType: String, level: String = "INFO", stage: String, message: String, sourceSHA256: String? = nil, runID: String? = nil, diagnosticID: String? = nil, provider: String? = nil, round: Int? = nil, sourceLabel: String? = nil, platform: String? = nil, nodeID: String? = nil, parentTaskID: String? = nil, correlationID: String? = nil, errorFingerprint: String? = nil) {
        self.id = UUID(); self.sequence = sequence; self.taskID = taskID; self.taskType = taskType; self.date = Date()
        self.level = level; self.stage = stage; self.message = message; self.sourceSHA256 = sourceSHA256; self.runID = runID
        self.diagnosticID = diagnosticID; self.provider = provider; self.round = round; self.sourceLabel = sourceLabel
        self.platform = platform; self.nodeID = nodeID; self.parentTaskID = parentTaskID; self.correlationID = correlationID; self.errorFingerprint = errorFingerprint
    }
}

struct BMTaskSummary: Identifiable, Hashable {
    let taskID: String
    let taskType: String
    let provider: String?
    let sourceSHA256: String?
    let sourceLabel: String?
    let runID: String?
    let startedAt: Date
    let updatedAt: Date
    let lastStage: String
    let lastMessage: String
    let hasError: Bool
    let completed: Bool
    let cancelled: Bool
    var id: String { taskID }

    var stateTitle: String {
        if cancelled || lastStage.contains("cancel") { return "已停止" }
        if lastStage == "completed" || completed { return "已完成" }
        if hasError {
            // Build146：真实云端失败/源码失败优先，Artifact 错误只能发生在 build.succeeded 之后。
            if lastStage.contains("build.failed") || lastStage.contains("sourceFailure") { return "真实编译失败" }
            if lastStage.contains("artifact") || lastStage.contains("relay") { return "产物回传异常" }
            return "任务异常"
        }
        return "进行中"
    }
}

@MainActor
final class BMTaskBlackBox: ObservableObject {
    static let shared = BMTaskBlackBox()
    private let key = "buildmate-task-black-box-v1"
    private let maxEvents = 1600
    @Published private(set) var events: [BMBlackBoxEvent] = []

    private init() {
        if let data = UserDefaults.standard.data(forKey: key), let saved = try? JSONDecoder().decode([BMBlackBoxEvent].self, from: data) {
            events = Array(saved.suffix(maxEvents))
        }
    }

    func newTask(type: String, provider: String? = nil, sourceSHA256: String? = nil, runID: String? = nil, sourceLabel: String? = nil) -> String {
        let id = "BM-" + UUID().uuidString.prefix(8).uppercased()
        record(taskID: String(id), taskType: type, stage: "created", message: "任务已创建", sourceSHA256: sourceSHA256, runID: runID, provider: provider, sourceLabel: sourceLabel)
        return String(id)
    }

    func record(taskID: String, taskType: String, level: String = "INFO", stage: String, message: String, sourceSHA256: String? = nil, runID: String? = nil, diagnosticID: String? = nil, provider: String? = nil, round: Int? = nil, sourceLabel: String? = nil, platform: String? = nil, nodeID: String? = nil, parentTaskID: String? = nil, correlationID: String? = nil, errorFingerprint: String? = nil) {
        let safeMessage = Self.redact(message)
        let next = (events.last?.sequence ?? 0) + 1
        events.append(.init(sequence: next, taskID: taskID, taskType: taskType, level: level, stage: stage, message: safeMessage, sourceSHA256: sourceSHA256, runID: runID, diagnosticID: diagnosticID, provider: provider, round: round, sourceLabel: sourceLabel, platform: platform, nodeID: nodeID, parentTaskID: parentTaskID, correlationID: correlationID, errorFingerprint: errorFingerprint))
        if events.count > maxEvents { events.removeFirst(events.count - maxEvents) }
        persist()
    }

    func lifecycle(_ stage: String, detail: String) { record(taskID: "APP", taskType: "AppLifecycle", stage: stage, message: detail) }

    func events(for taskID: String) -> [BMBlackBoxEvent] { events.filter { $0.taskID == taskID } }

    var taskSummaries: [BMTaskSummary] {
        let taskEvents = events.filter { $0.taskID != "APP" }
        let groups = Dictionary(grouping: taskEvents, by: \.taskID)
        return groups.compactMap { taskID, values in
            let sorted = values.sorted { $0.sequence < $1.sequence }
            guard let first = sorted.first, let last = sorted.last else { return nil }
            // Build1047：产物已经通过 Relay 回传并完成 SHA/格式校验时，本质上已经是终态成功。
            // 旧版本曾只记录 artifact.relay.completed、没有再写一条 completed，导致任务中心出现
            // “回传成功 + 进行中”的矛盾状态。这里仅做黑匣子展示层终态归一，不改变编译/回传主链。
            let verifiedArtifactEvent = sorted.last(where: { event in
                event.stage == "artifact.relay.completed" ||
                (event.stage == "artifact.download.verified") ||
                (event.message.contains("回传成功") && event.message.contains("SHA-256 已校验"))
            })
            let explicitTerminal = sorted.last(where: { ["completed","cancelled","failed"].contains($0.stage) || $0.level == "ERROR" })
            let terminal = verifiedArtifactEvent ?? explicitTerminal ?? last
            let completed = terminal.stage == "completed" || verifiedArtifactEvent != nil
            let cancelled = !completed && (terminal.stage == "cancelled" || terminal.stage.contains("cancel"))
            let hasError = !completed && !cancelled && (terminal.stage == "failed" || terminal.level == "ERROR")
            return BMTaskSummary(taskID: taskID, taskType: first.taskType, provider: sorted.compactMap(\.provider).last, sourceSHA256: sorted.compactMap(\.sourceSHA256).last, sourceLabel: sorted.compactMap(\.sourceLabel).last, runID: sorted.compactMap(\.runID).last, startedAt: first.date, updatedAt: last.date, lastStage: terminal.stage, lastMessage: terminal.message, hasError: hasError, completed: completed, cancelled: cancelled)
        }.sorted { $0.updatedAt > $1.updatedAt }
    }

    var latestTaskID: String? { taskSummaries.first?.taskID }

    func taskID(runID: String?, sourceSHA256: String? = nil) -> String? {
        taskSummaries.first { task in
            if let runID, !runID.isEmpty, task.runID == runID { return true }
            if let sourceSHA256, !sourceSHA256.isEmpty, task.sourceSHA256 == sourceSHA256 { return true }
            return false
        }?.taskID
    }

    func clear() { events.removeAll(); UserDefaults.standard.removeObject(forKey: key) }

    func exportText(taskID: String? = nil) throws -> URL {
        let selected = taskID.map { events(for: $0) } ?? events
        let formatter = DateFormatter(); formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSS"
        var lines = ["BuildMate 任务黑匣子", "范围：\(taskID ?? "全部历史")", "导出时间：\(formatter.string(from: Date()))", "事件数：\(selected.count)", "注意：Token / API Key / Authorization / Cookie 等敏感信息会自动脱敏。", ""]
        for e in selected {
            var meta = "#\(e.sequence) [\(formatter.string(from: e.date))] [\(e.level)] [\(e.taskType)] [\(e.taskID)] [\(e.stage)]"
            if let p=e.provider,!p.isEmpty { meta += " provider=\(p)" }; if let r=e.runID,!r.isEmpty { meta += " run=\(r)" }; if let d=e.diagnosticID,!d.isEmpty { meta += " diagnostic=\(d)" }; if let round=e.round { meta += " round=\(round)" }; if let sha=e.sourceSHA256,!sha.isEmpty { meta += " sha=\(sha)" }; if let platform=e.platform,!platform.isEmpty { meta += " platform=\(platform)" }; if let node=e.nodeID,!node.isEmpty { meta += " node=\(node)" }; if let parent=e.parentTaskID,!parent.isEmpty { meta += " parent=\(parent)" }; if let c=e.correlationID,!c.isEmpty { meta += " correlation=\(c)" }; if let f=e.errorFingerprint,!f.isEmpty { meta += " fingerprint=\(f)" }
            lines += [meta, e.message, ""]
        }
        let suffix = taskID ?? "All"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("BuildMate-Task-BlackBox-\(suffix).txt")
        try lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8); return url
    }

    func exportJSON(taskID: String? = nil) throws -> URL {
        let selected = taskID.map { events(for: $0) } ?? events
        let encoder=JSONEncoder(); encoder.outputFormatting=[.prettyPrinted,.sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        let data=try encoder.encode(selected); let suffix=taskID ?? "All"
        let url=FileManager.default.temporaryDirectory.appendingPathComponent("BuildMate-Task-BlackBox-\(suffix).json"); try data.write(to:url,options:.atomic); return url
    }

    private func persist() { guard let data=try? JSONEncoder().encode(events) else{return}; UserDefaults.standard.set(data,forKey:key) }
    private static func redact(_ input:String)->String { var text=input; let patterns=["(?i)(authorization\\s*[:=]\\s*)([^\\s,;]+)","(?i)(x-auth-token\\s*[:=]\\s*)([^\\s,;]+)","(?i)(api[_ -]?key\\s*[:=]\\s*)([^\\s,;]+)","(?i)(token\\s*[:=]\\s*)([^\\s,;]+)","(?i)(cookie\\s*[:=]\\s*)([^\\n]+)"]; for p in patterns { if let re=try? NSRegularExpression(pattern:p){ let r=NSRange(text.startIndex...,in:text); text=re.stringByReplacingMatches(in:text,range:r,withTemplate:"$1<REDACTED>") } }; return text }
}
