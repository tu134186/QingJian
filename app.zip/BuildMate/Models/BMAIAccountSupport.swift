import Foundation

enum BMAIProviderPortal {
    static func registerURL(for provider: AIProvider) -> URL? {
        let text: String
        switch provider {
        case .openAI: text = "https://platform.openai.com/api-keys"
        case .deepSeek: text = "https://platform.deepseek.com/api_keys"
        case .doubao: text = "https://console.volcengine.com/ark"
        case .qwen: text = "https://bailian.console.aliyun.com/"
        case .kimi: text = "https://platform.moonshot.cn/console/api-keys"
        case .gemini: text = "https://aistudio.google.com/apikey"
        case .compatible: return nil
        }
        return URL(string: text)
    }

    static func billingURL(for provider: AIProvider) -> URL? {
        let text: String
        switch provider {
        case .openAI: text = "https://platform.openai.com/settings/organization/billing/overview"
        case .deepSeek: text = "https://platform.deepseek.com/top_up"
        case .doubao: text = "https://console.volcengine.com/ark"
        case .qwen: text = "https://bailian.console.aliyun.com/"
        case .kimi: text = "https://platform.moonshot.cn/console"
        case .gemini: text = "https://aistudio.google.com/"
        case .compatible: return nil
        }
        return URL(string: text)
    }
}

enum BMAIAccountService {
    static func deepSeekBalance(apiKey: String) async throws -> String {
        guard let url = URL(string: "https://api.deepseek.com/user/balance") else {
            throw BMContentSupport.error("DeepSeek 余额接口地址无效")
        }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else {
            throw BMContentSupport.error("DeepSeek 余额接口没有返回 HTTP 响应")
        }
        guard (200...299).contains(http.statusCode) else {
            var message = "DeepSeek 余额查询失败（HTTP \(http.statusCode)）"
            if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let error = obj["error"] as? [String: Any],
               let detail = error["message"] as? String,
               !detail.isEmpty {
                message += "：\(detail)"
            }
            throw BMContentSupport.error(message)
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let infos = obj["balance_infos"] as? [[String: Any]],
              let first = infos.first else {
            throw BMContentSupport.error("DeepSeek 余额返回格式无法识别")
        }
        let currency = first["currency"] as? String ?? "CNY"
        let total = first["total_balance"] as? String ?? "--"
        let grant = first["granted_balance"] as? String ?? "--"
        let top = first["topped_up_balance"] as? String ?? "--"
        let available = obj["is_available"] as? Bool ?? false
        return "\(available ? "可用" : "余额不足") · \(currency) \(total)（充值 \(top) / 赠送 \(grant)）"
    }
}
