import Foundation

struct BMCodemagicRunUISnapshot: Hashable {
    let status: String
    let stage: BuildWorkStage
    let detail: String
    let shouldStopBusyImmediately: Bool
}

enum BMCodemagicRunPresentation {
    /// Single mapping from Codemagic's authoritative remote state into the user-facing workbench state.
    /// Build184: all surfaces must converge on this mapping instead of each page inventing its own terminal text.
    static func snapshot(for state: CodemagicBuildState, recoveryMode: Bool = false) -> BMCodemagicRunUISnapshot {
        let shortID = String(state.id.prefix(8))
        switch state.normalizedStatus {
        case "network_unknown":
            return .init(
                status: state.readableStatus,
                stage: .recovering,
                detail: recoveryMode ? "网络恢复中 · 同一 Run 不变" : "网络恢复中 · 保留同一 Run \(shortID) · 不重新编译",
                shouldStopBusyImmediately: false
            )
        case "failed":
            return .init(
                status: "❌ Codemagic 编译失败",
                stage: .failed,
                detail: "Codemagic \(shortID) · failed · 正在补充错误报告",
                shouldStopBusyImmediately: true
            )
        case "canceled":
            return .init(
                status: "⏹ Codemagic 已取消",
                stage: .cancelled,
                detail: "Codemagic \(shortID) · cancelled",
                shouldStopBusyImmediately: true
            )
        case "timeout":
            return .init(
                status: "❌ Codemagic 构建超时",
                stage: .failed,
                detail: "Codemagic \(shortID) · timeout",
                shouldStopBusyImmediately: true
            )
        case "skipped":
            return .init(
                status: "❌ Codemagic 构建已跳过",
                stage: .failed,
                detail: "Codemagic \(shortID) · skipped",
                shouldStopBusyImmediately: true
            )
        case "finished":
            return .init(
                status: state.readableStatus,
                stage: .packaging,
                detail: state.hasIPA ? "Codemagic 已成功结束 · IPA 产物已出现" : (state.hasDEB ? "Codemagic 已成功结束 · DEB 产物已出现" : "Codemagic 已成功结束 · 正在同步编译产物（不重新编译）"),
                shouldStopBusyImmediately: false
            )
        case "queued", "pending":
            return .init(status: state.readableStatus, stage: .queued, detail: "Codemagic \(shortID) · \(state.status)", shouldStopBusyImmediately: false)
        default:
            return .init(status: state.readableStatus, stage: .compiling, detail: "Codemagic \(shortID) · \(state.status)", shouldStopBusyImmediately: false)
        }
    }
}
