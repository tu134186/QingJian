import Foundation

enum BitriseWorkflowTemplate {
    static let yaml = #"""
format_version: '13'
default_step_lib_source: https://github.com/bitrise-io/bitrise-steplib.git
project_type: other
workflows:
  primary:
    steps:
    - script@1:
        title: BuildMate · verify source
        inputs:
        - content: |-
            set -euo pipefail
            test -f app.zip
            unzip -tq app.zip
            rm -rf src && mkdir src
            unzip -q app.zip -d src
            test -f src/project.yml
            test -d src/BuildMate
    - script@1:
        title: BuildMate · XcodeGen
        inputs:
        - content: |-
            set -euo pipefail
            if ! command -v xcodegen >/dev/null 2>&1; then brew install xcodegen; fi
            cd src
            xcodegen generate
    - script@1:
        title: BuildMate · unsigned IPA
        inputs:
        - content: |-
            set -euo pipefail
            cd src
            xcodebuild -project BuildMate.xcodeproj -scheme BuildMate -configuration Release -sdk iphoneos -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
            APP="build/Build/Products/Release-iphoneos/BuildMate.app"
            test -d "$APP"
            rm -rf Payload BuildMate-Bitrise.ipa
            mkdir Payload
            cp -R "$APP" Payload/
            zip -qry BuildMate-Bitrise.ipa Payload
            test $(stat -f%z BuildMate-Bitrise.ipa) -gt 100000
    - deploy-to-bitrise-io@2:
        inputs:
        - deploy_path: "$BITRISE_SOURCE_DIR/src/BuildMate-Bitrise.ipa"
"""#
}
