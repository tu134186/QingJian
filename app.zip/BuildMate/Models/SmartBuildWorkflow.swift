import Foundation

// Build1066: repository bootstrap must deploy the same proven full GitHub Actions
// workflow that ships with BuildMate. The previous embedded template only ran a
// Linux preflight, so a newly initialized/repaired repository could silently lose
// real macOS/Xcode IPA/DEB compilation even though the checked-in workflow was full.
enum SmartBuildWorkflow {
    // Historical name retained to avoid touching stable callers. Content is now the
    // complete Multi Builder workflow (full + preflight), not preflight-only.
    static let linuxPreflight = #"""
name: BuildMate Multi Builder
on:
  workflow_dispatch:
    inputs:
      mode:
        description: '选择运行模式：full 正式编译 / preflight 仅预检'
        required: true
        default: 'full'
        type: choice
        options:
          - full
          - preflight
      expected_source_sha256:
        description: 'BuildMate 本地源码 ZIP SHA-256'
        required: false
        default: ''
      expected_source_bytes:
        description: 'BuildMate 本地源码 ZIP 字节数'
        required: false
        default: ''
      source_name:
        description: 'BuildMate 选择的源码文件名'
        required: false
        default: ''
      expected_head_sha:
        description: 'BuildMate 派发前分支 HEAD SHA'
        required: false
        default: ''
permissions:
  contents: write
  actions: read
jobs:
  build:
    runs-on: macos-15
    timeout-minutes: 35
    steps:
      - name: 1. 读取仓库
        uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - name: 1.5 规范运行模式
        id: mode
        shell: bash
        run: |
          MODE='${{ inputs.mode }}'
          case "$MODE" in
            full|preflight) ;;
            *) MODE='full' ;;
          esac
          [ -n "$MODE" ] || MODE='full'
          echo "value=$MODE" >> "$GITHUB_OUTPUT"
          echo "BuildMate mode: $MODE"
      - name: 1.7 源码指纹门
        id: source_trace
        shell: bash
        run: |
          set -e
          test -f app.zip || { echo '❌ 根目录缺少 app.zip'; exit 1; }
          mkdir -p .buildmate
          ACTUAL_SHA=$(shasum -a 256 app.zip | awk '{print $1}')
          ACTUAL_BYTES=$(wc -c < app.zip | tr -d ' ')
          CHECKOUT_SHA=$(git rev-parse HEAD)
          EXPECTED_SHA='${{ inputs.expected_source_sha256 }}'
          EXPECTED_BYTES='${{ inputs.expected_source_bytes }}'
          EXPECTED_HEAD='${{ inputs.expected_head_sha }}'
          SOURCE_NAME='${{ inputs.source_name }}'
          echo "源码文件: $SOURCE_NAME"
          echo "Actions checkout: $CHECKOUT_SHA"
          echo "派发前 HEAD: $EXPECTED_HEAD"
          echo "app.zip SHA-256: $ACTUAL_SHA"
          echo "期望 SHA-256: $EXPECTED_SHA"
          echo "app.zip bytes: $ACTUAL_BYTES / expected: $EXPECTED_BYTES"
          TRACE_OK=true
          if [ -n "$EXPECTED_SHA" ] && [ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]; then TRACE_OK=false; fi
          if [ -n "$EXPECTED_BYTES" ] && [ "$ACTUAL_BYTES" != "$EXPECTED_BYTES" ]; then TRACE_OK=false; fi
          export SOURCE_NAME ACTUAL_SHA EXPECTED_SHA ACTUAL_BYTES EXPECTED_BYTES CHECKOUT_SHA EXPECTED_HEAD TRACE_OK
          python3 - <<'PY'
          import json,os,pathlib
          d={
            'sourceName':os.environ.get('SOURCE_NAME',''),
            'sourceSHA256':os.environ.get('ACTUAL_SHA',''),
            'expectedSourceSHA256':os.environ.get('EXPECTED_SHA',''),
            'sourceBytes':os.environ.get('ACTUAL_BYTES',''),
            'expectedSourceBytes':os.environ.get('EXPECTED_BYTES',''),
            'checkoutSHA':os.environ.get('CHECKOUT_SHA',''),
            'expectedHeadSHA':os.environ.get('EXPECTED_HEAD',''),
            'sourceTraceOK':os.environ.get('TRACE_OK','true')=='true'
          }
          pathlib.Path('.buildmate/source-trace.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
          PY
          if [ "$TRACE_OK" != true ]; then
            echo '❌ 源码指纹不一致：已阻止编译，避免 Actions 使用旧 app.zip。'
            exit 86
          fi
          echo '✅ 源码指纹一致，允许进入解压/编译。'
      - name: 2. 解压并识别工程
        id: inspect
        shell: bash
        run: |
          set -e
          test -f app.zip || { echo '❌ 根目录缺少 app.zip'; exit 1; }
          rm -rf src .buildmate-work; mkdir -p src .buildmate-work .buildmate
          unzip -q app.zip -d src
          ROOT=src
          if [ ! -f src/Makefile ] && [ ! -f src/project.yml ] && ! find src -maxdepth 1 -type d \( -name '*.xcodeproj' -o -name '*.xcworkspace' \) | grep -q .; then
            P=$(find src -type f \( -name Makefile -o -name project.yml \) | head -1 || true)
            [ -z "$P" ] && P=$(find src -type d \( -name '*.xcworkspace' -o -name '*.xcodeproj' \) | head -1 || true)
            [ -n "$P" ] && ROOT=$(dirname "$P")
            if [ "$ROOT" != src ]; then mkdir .buildmate-work/root; cp -R "$ROOT"/. .buildmate-work/root/; rm -rf src; mv .buildmate-work/root src; fi
          fi
          if [ -f src/Makefile ] && { [ -f src/control ] || [ -f src/layout/DEBIAN/control ] || grep -q 'THEOS' src/Makefile; }; then TYPE=theos; FILE=Makefile
          elif [ -f src/project.yml ]; then TYPE=xcodegen; FILE=project.yml
          elif P=$(find src -maxdepth 1 -type d -name '*.xcworkspace' | head -1) && [ -n "$P" ]; then TYPE=workspace; FILE=$(basename "$P")
          elif P=$(find src -maxdepth 1 -type d -name '*.xcodeproj' | head -1) && [ -n "$P" ]; then TYPE=xcodeproj; FILE=$(basename "$P")
          else echo '❌ 无法识别 Theos / project.yml / xcodeproj / xcworkspace'; exit 1; fi
          echo "type=$TYPE" >> "$GITHUB_OUTPUT"; echo "file=$FILE" >> "$GITHUB_OUTPUT"
      - name: 4A. 准备 Xcode 工程
        if: ${{ steps.inspect.outputs.type != 'theos' }}
        id: xcode
        working-directory: src
        shell: bash
        run: |
          set -e
          TYPE='${{ steps.inspect.outputs.type }}'; FILE='${{ steps.inspect.outputs.file }}'
          if [ "$TYPE" = xcodegen ]; then brew install xcodegen >/dev/null; xcodegen generate; FILE=$(find . -maxdepth 1 -name '*.xcodeproj' | head -1); TYPE=xcodeproj; fi
          if [ "$TYPE" = workspace ]; then LIST=$(xcodebuild -workspace "$FILE" -list -json); SCHEME=$(printf '%s' "$LIST"|python3 -c "import json,sys;d=json.load(sys.stdin);s=d.get('workspace',{}).get('schemes',[]);print(s[0] if s else '')")
          else LIST=$(xcodebuild -project "$FILE" -list -json); SCHEME=$(printf '%s' "$LIST"|python3 -c "import json,sys;d=json.load(sys.stdin);s=d.get('project',{}).get('schemes',[]);print(s[0] if s else '')"); fi
          test -n "$SCHEME" || { echo '❌ 找不到 Scheme'; exit 1; }
          echo "kind=$TYPE" >> "$GITHUB_OUTPUT"; echo "file=$FILE" >> "$GITHUB_OUTPUT"; echo "scheme=$SCHEME" >> "$GITHUB_OUTPUT"
      - name: 4B. 安装 Theos / DEB 签名依赖
        if: ${{ steps.inspect.outputs.type == 'theos' && steps.mode.outputs.value != 'preflight' }}
        shell: bash
        run: |
          set -e
          export THEOS="$HOME/theos"
          if [ ! -d "$THEOS" ]; then git clone --recursive https://github.com/theos/theos.git "$THEOS"; fi

          # Theos 在最终 dylib 签名阶段需要 ldid。GitHub macOS runner 并不保证预装，
          # 缺失时源码可编译/链接成功，却会在 “Signing …” 阶段以 Error 127 失败。
          if ! command -v ldid >/dev/null 2>&1; then
            echo "ℹ️ 未检测到 ldid，正在通过 Homebrew 安装…"
            brew install ldid
          fi
          command -v ldid >/dev/null 2>&1 || { echo "❌ ldid 安装后仍不可用"; exit 127; }
          echo "✅ ldid: $(command -v ldid)"
          ldid -h >/dev/null 2>&1 || true

          echo "THEOS=$THEOS" >> "$GITHUB_ENV"
      - name: 5A. Xcode 编译
        if: ${{ steps.inspect.outputs.type != 'theos' && steps.mode.outputs.value != 'preflight' }}
        id: ipa
        working-directory: src
        shell: bash
        run: |
          set -o pipefail
          TYPE='${{ steps.xcode.outputs.kind }}'; FILE='${{ steps.xcode.outputs.file }}'; SCHEME='${{ steps.xcode.outputs.scheme }}'
          rm -rf build compile.log compile-errors.txt
          if [ "$TYPE" = workspace ]; then BASE=(xcodebuild -workspace "$FILE" -scheme "$SCHEME"); else BASE=(xcodebuild -project "$FILE" -scheme "$SCHEME"); fi
          # GitHub Actions 的 bash 默认带 -e；真实编译失败时如果不临时关闭 errexit，
          # shell 会在 xcodebuild | tee 这一行直接退出，后面的 STATUS 与错误提取根本不会执行。
          set +e
          "${BASE[@]}" -configuration Release -sdk iphoneos -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build 2>&1 | tee compile.log
          STATUS=${PIPESTATUS[0]}
          set -e
          if [ "$STATUS" -ne 0 ]; then
            grep -n -B 2 -A 5 -E 'error:|fatal error:|SwiftCompile|CompileSwift|EmitSwiftModule|Command SwiftCompile failed' compile.log | tail -320 > compile-errors.txt || true
            if [ ! -s compile-errors.txt ]; then tail -240 compile.log > compile-errors.txt || true; fi
            exit "$STATUS"
          fi
          APP=$(find build/Build/Products -type d -path '*Release-iphoneos/*.app' | head -1 || true); test -n "$APP" || exit 1
          PLIST="$APP/Info.plist"; EXEC=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$PLIST" 2>/dev/null || true); test -n "$EXEC" && test -f "$APP/$EXEC" || { echo '❌ 主程序校验失败'; exit 1; }
          VER=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$PLIST" 2>/dev/null || echo unknown); IPA="${EXEC}-V${VER}.ipa"
          rm -rf Payload "$IPA"; mkdir Payload; cp -R "$APP" Payload/; zip -qry "$IPA" Payload; unzip -tq "$IPA"; echo "file=$IPA" >> "$GITHUB_OUTPUT"
      - name: 5B. Theos 编译 DEB
        if: ${{ steps.inspect.outputs.type == 'theos' && steps.mode.outputs.value != 'preflight' }}
        id: deb
        working-directory: src
        shell: bash
        run: |
          set -o pipefail
          rm -rf packages compile.log compile-errors.txt
          export THEOS="$HOME/theos"
          set +e
          make clean package FINALPACKAGE=1 messages=yes 2>&1 | tee compile.log
          STATUS=${PIPESTATUS[0]}
          set -e
          if [ "$STATUS" -ne 0 ]; then
            grep -n -B 2 -A 5 -E 'error:|fatal error:|Undefined symbols|ld:|logos|make\[[0-9]+\]: \*\*\*' compile.log | tail -320 > compile-errors.txt || true
            if [ ! -s compile-errors.txt ]; then tail -240 compile.log > compile-errors.txt || true; fi
            exit "$STATUS"
          fi
          DEB=$(find packages -type f -name '*.deb' | head -1 || true); test -n "$DEB" || { echo '❌ Theos 未生成 DEB'; exit 1; }
          echo "file=$DEB" >> "$GITHUB_OUTPUT"
      - name: 6A. 上传 IPA
        if: ${{ steps.inspect.outputs.type != 'theos' && steps.mode.outputs.value != 'preflight' && success() }}
        uses: actions/upload-artifact@v4
        with: { name: 'IPA-${{ github.run_number }}', path: 'src/${{ steps.ipa.outputs.file }}', if-no-files-found: error }
      - name: 6B. 上传 DEB
        if: ${{ steps.inspect.outputs.type == 'theos' && steps.mode.outputs.value != 'preflight' && success() }}
        uses: actions/upload-artifact@v4
        with: { name: 'DEB-${{ github.run_number }}', path: 'src/${{ steps.deb.outputs.file }}', if-no-files-found: error }
      - name: 7. 生成真实报告和诊断上下文
        if: always()
        shell: bash
        run: |
          python3 - <<'PY'
          import json,os,re,pathlib,datetime
          typ=os.environ.get('PTYPE',''); source=pathlib.Path('src')
          errp=source/'compile-errors.txt'; logp=source/'compile.log'
          extracted=errp.read_text(errors='ignore') if errp.exists() else ''
          full=logp.read_text(errors='ignore') if logp.exists() else ''
          text=extracted if extracted.strip() else full[-24000:]
          ok=os.environ.get('JOB_STATUS')=='success'; lines=[x.strip() for x in text.splitlines() if 'error:' in x.lower() or 'fatal error:' in x.lower()]; sig=(lines[0] if lines else (text.splitlines()[-1] if text else ''))[:1200]
          mode=os.environ.get('MODE') or 'full'; ipa=os.environ.get('IPA') or ''; deb=os.environ.get('DEB') or ''
          artifact_kind=('DEB' if deb else ('IPA' if ipa else None)); artifact_name=(deb or ipa or None); artifact_uploaded=bool(ok and mode!='preflight' and artifact_name)
          report={'runID':int(os.environ.get('RUN_ID','0')),'ok':ok,'phase':mode,'projectType':typ,'projectFile':os.environ.get('PFILE') or None,'scheme':os.environ.get('SCHEME') or None,'displayName':None,'bundleID':None,'version':None,'build':None,'executable':None,'deploymentTarget':None,'ipaName':ipa or None,'debName':deb or None,'errorSignature':sig or None,'diagnosis':(('真实编译失败，已提取 Xcode/Theos 原始 error、命令上下文与相关源码。' if text else '真实编译失败，但本次运行未产生 compile.log；请查看 GitHub Run 原始日志。') if not ok else None),'createdAt':datetime.datetime.utcnow().isoformat()+'Z','warnings':None,'artifactKind':artifact_kind,'artifactName':artifact_name,'artifactUploaded':artifact_uploaded}
          tracep=pathlib.Path('.buildmate/source-trace.json')
          if tracep.exists():
            try: report.update(json.loads(tracep.read_text()))
            except Exception: pass
          pathlib.Path('.buildmate').mkdir(exist_ok=True); pathlib.Path('.buildmate/latest-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
          files=[]; exts=('swift','m','mm','xm','x','h')
          # 先匹配标准 Xcode/Theos 的 file:line:column: error 诊断。
          pat=re.compile(r'(?P<path>[^\n:]+?\.(?:'+ '|'.join(exts) +r')):(?P<line>\d+)(?::\d+)?:[^\n]*(?:error:|fatal error:)',re.I)
          candidates=[]
          for m in pat.finditer(text): candidates.append((m.group('path').strip(),int(m.group('line'))))
          # 再从完整 compile.log 补抓，兼容同一轮多条真实编译器错误。
          full_tail=full[-60000:]
          for m in pat.finditer(full_tail):
            pair=(m.group('path').strip(),int(m.group('line')))
            if pair not in candidates: candidates.append(pair)
          # 最后兜底：从错误文本出现过的源码文件名定位唯一文件，至少给诊断源码片段。
          if not candidates:
            names=re.findall(r'([A-Za-z0-9_+.-]+\.(?:'+ '|'.join(exts) +r'))', text+'\n'+full_tail, re.I)
            for name in names:
              ms=list(source.rglob(pathlib.Path(name).name))
              if len(ms)==1: candidates.append((str(ms[0]),1))
          seen=set()
          for rel,line in candidates:
            if '/src/' in rel: rel=rel.split('/src/',1)[1]
            rel=rel.lstrip('./'); f=source/rel
            if not f.exists():
              ms=list(source.rglob(pathlib.Path(rel).name)); f=ms[0] if len(ms)==1 else f
            if f.exists():
              key=str(f.relative_to(source))
              if key in seen: continue
              seen.add(key); arr=f.read_text(errors='ignore').splitlines(); line=max(1,min(line,max(1,len(arr))))
              # 小文件直接提供完整上下文，避免把 enum/struct/func 的定义裁掉而误判成“类型不存在”。
              # 大文件仍以报错行窗口为主，并额外补相关声明的上下文。
              if len(arr) <= 220:
                snippet='\n'.join(f'{i+1}: {arr[i]}' for i in range(len(arr)))
                files.append({'path':key,'line':line,'snippet':snippet,'contextMode':'full-file'})
              else:
                a=max(0,line-34); b=min(len(arr),line+33)
                ranges=[(a,b)]
                # 从报错行/错误文本里提取常见 Swift/ObjC 符号，向上寻找其声明并补一小段。
                focus=' '.join([arr[line-1] if arr else '', text[-8000:], full_tail[-8000:]])
                symbols=[]
                for sym in re.findall(r'\b[A-Z][A-Za-z0-9_]{2,}\b', focus):
                  if sym not in symbols: symbols.append(sym)
                  if len(symbols)>=12: break
                decl_re_cache={}
                for sym in symbols:
                  dr=decl_re_cache.setdefault(sym,re.compile(r'\b(?:enum|struct|class|protocol|typealias)\s+'+re.escape(sym)+r'\b|\b(?:func|let|var)\s+'+re.escape(sym)+r'\b'))
                  for idx,sline in enumerate(arr):
                    if dr.search(sline):
                      ranges.append((max(0,idx-4),min(len(arr),idx+22))); break
                # 合并重叠区间，限制总量，避免超大 prompt。
                ranges.sort(); merged=[]
                for ra,rb in ranges:
                  if merged and ra <= merged[-1][1]+3: merged[-1]=(merged[-1][0],max(merged[-1][1],rb))
                  else: merged.append((ra,rb))
                chunks=[]; used=0
                for ra,rb in merged:
                  if used>=180: break
                  rb=min(rb,ra+(180-used)); chunks.append('\n'.join(f'{i+1}: {arr[i]}' for i in range(ra,rb))); used += rb-ra
                files.append({'path':key,'line':line,'snippet':'\n... [related declaration context] ...\n'.join(chunks),'contextMode':'focused+declarations'})
            if len(files)>=5: break
          # 如果编译失败但仍未定位文件，提供少量 Swift/ObjC/Logos 文件头作为最后修复上下文。
          if not ok and not files:
            for f in list(source.rglob('*.swift'))+list(source.rglob('*.xm'))+list(source.rglob('*.m')):
              if any(part in {'build','DerivedData','.git'} for part in f.parts): continue
              arr=f.read_text(errors='ignore').splitlines()
              if not arr: continue
              files.append({'path':str(f.relative_to(source)),'line':1,'snippet':'\n'.join(f'{i+1}: {arr[i]}' for i in range(min(len(arr),80)))})
              if len(files)>=3: break
          pathlib.Path('.buildmate/repair-context.json').write_text(json.dumps({'runID':int(os.environ.get('RUN_ID','0')),'errorSignature':sig or None,'diagnosis':report['diagnosis'],'compileErrors':text[-20000:] if text else None,'files':files,'attempt':None},ensure_ascii=False,indent=2))
          PY
        env:
          JOB_STATUS: ${{ job.status }}
          RUN_ID: ${{ github.run_id }}
          MODE: ${{ steps.mode.outputs.value }}
          PTYPE: ${{ steps.inspect.outputs.type }}
          PFILE: ${{ steps.inspect.outputs.file }}
          SCHEME: ${{ steps.xcode.outputs.scheme }}
          IPA: ${{ steps.ipa.outputs.file }}
          DEB: ${{ steps.deb.outputs.file }}
      - name: 8. 保存报告
        if: always()
        shell: bash
        run: |
          git config user.name 'BuildMate Bot'; git config user.email 'buildmate@users.noreply.github.com'
          git add .buildmate/latest-report.json .buildmate/repair-context.json .buildmate/source-trace.json
          git commit -m 'BuildMate: build context [skip ci]' || exit 0
          git pull --rebase || true; git push
      - name: 9. 失败日志
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: BuildMate-Compile-Logs-${{ github.run_number }}
          path: |
            src/compile.log
            src/compile-errors.txt
            .buildmate/repair-context.json
            .buildmate/source-trace.json
          if-no-files-found: ignore

"""#
}
