import Foundation

// Build160: node selection, health refresh and reconnect policy for private Mac Agents.
struct BMMacAgentSchedulingDecision: Equatable {
    let nodeID: String?
    let allowed: Bool
    let reason: String
}

enum BMMacAgentSelectionStore {
    private static let key = "buildmate-mac-agent-selected-node-v1"
    static var selectedNodeID: String? {
        get { UserDefaults.standard.string(forKey: key) }
        set { UserDefaults.standard.set(newValue, forKey: key) }
    }
}

enum BMMacAgentScheduler {
    static func score(_ node: BMMacAgentNodeSnapshot) -> Int {
        guard node.mayAcceptTask else { return Int.min }
        let capacity = max(1, node.maxConcurrentTasks)
        let freeSlots = max(0, capacity - node.activeTaskIDs.count)
        let xcodeBonus = node.xcodeVersions.isEmpty ? 0 : 20
        let capabilityBonus = min(node.capabilities.count, 20)
        return freeSlots * 100 + xcodeBonus + capabilityBonus
    }

    static func choose(from nodes: [BMMacAgentNodeSnapshot], preferredNodeID: String? = BMMacAgentSelectionStore.selectedNodeID) -> BMMacAgentSchedulingDecision {
        if let preferredNodeID, let preferred = nodes.first(where: { $0.nodeID == preferredNodeID }), preferred.mayAcceptTask {
            return .init(nodeID: preferred.nodeID, allowed: true, reason: "使用用户指定且健康的 Mac Agent 节点。")
        }
        guard let best = nodes.filter(\.mayAcceptTask).max(by: { score($0) < score($1) }) else {
            return .init(nodeID: nil, allowed: false, reason: "当前没有在线且有空闲容量的 Mac Agent。")
        }
        return .init(nodeID: best.nodeID, allowed: true, reason: "已按在线状态、空闲并发与 Xcode/能力信息选择节点。")
    }
}

@MainActor
final class BMMacAgentNodeManager: ObservableObject {
    @Published private(set) var nodes: [BMMacAgentNodeSnapshot] = []
    @Published var statusText = "待刷新"
    @Published var refreshing = false

    init() { reload() }

    func reload() {
        nodes = BMMacAgentNodeStore.load().sorted { $0.nodeName.localizedCaseInsensitiveCompare($1.nodeName) == .orderedAscending }
    }

    func refreshConfiguredNode() async {
        let config = SelfHostedMacStoredConfig.load()
        guard config.isReady else { statusText = "请先配置 Mac Agent 地址"; return }
        refreshing = true
        defer { refreshing = false; reload() }
        do {
            let service = SelfHostedMacService(endpoint: config.endpoint, token: config.token)
            _ = try await service.discoverCapabilities()
            _ = try await service.heartbeat()
            statusText = "节点能力与心跳已刷新"
        } catch {
            statusText = "刷新失败：\(error.localizedDescription)"
        }
    }

    func select(_ nodeID: String?) {
        BMMacAgentSelectionStore.selectedNodeID = nodeID
        objectWillChange.send()
    }

    func reconnectHint(for node: BMMacAgentNodeSnapshot, taskID: String?, runID: String?) -> String {
        guard node.isStale || node.state == .offline else { return "节点在线，无需恢复" }
        guard let taskID, !taskID.isEmpty, let runID, !runID.isEmpty else { return "节点断线；等待心跳恢复，不创建新 Run" }
        return "节点断线；恢复后继续 Task \(taskID) / Run \(runID)，禁止重新派发"
    }
}
