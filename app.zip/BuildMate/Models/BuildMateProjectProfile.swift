import Foundation

struct BuildMateProjectProfile: Codable, Identifiable, Equatable {
    var owner: String
    var repo: String
    var branch: String
    var kind: String
    var updatedAt: Date

    var id: String { owner + "/" + repo }
    var fullName: String { owner + "/" + repo }
}

enum BuildMateProjectStore {
    private static let key = "buildmate-project-profiles-v1"

    static func load() -> [BuildMateProjectProfile] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let value = try? JSONDecoder().decode([BuildMateProjectProfile].self, from: data) else { return [] }
        return value.sorted { $0.updatedAt > $1.updatedAt }
    }

    static func save(_ value: [BuildMateProjectProfile]) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    @discardableResult
    static func remember(owner: String, repo: String, branch: String, kind: String, current: [BuildMateProjectProfile], limit: Int = 30) -> [BuildMateProjectProfile] {
        guard !owner.isEmpty, !repo.isEmpty else { return current }
        let item = BuildMateProjectProfile(owner: owner, repo: repo, branch: branch, kind: kind, updatedAt: Date())
        var items = current.filter { !($0.owner == owner && $0.repo == repo) }
        items.insert(item, at: 0)
        if items.count > limit { items = Array(items.prefix(limit)) }
        save(items)
        return items
    }
}
