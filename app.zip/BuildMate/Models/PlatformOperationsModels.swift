import Foundation

// Build153：平台运营层。核心事实仍归 BuildMate；Provider 只提供能力。
struct BMArtifactLedgerItem: Codable, Identifiable, Equatable {
    var id: String
    var workspaceID: String
    var taskID: String
    var sourceSHA256: String
    var providerID: String
    var runID: String
    var kind: String
    var fileName: String
    var localPath: String?
    var byteCount: Int64?
    var checksumSHA256: String?
    var verified: Bool
    var createdAt: Date
}

enum BMArtifactLedgerStore {
    private static let key = "buildmate-artifact-ledger-v1"
    static func load() -> [BMArtifactLedgerItem] {
        guard let data = UserDefaults.standard.data(forKey: key), let items = try? JSONDecoder().decode([BMArtifactLedgerItem].self, from: data) else { return [] }
        return items.sorted { $0.createdAt > $1.createdAt }
    }
    static func save(_ items: [BMArtifactLedgerItem]) { if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: key) } }
    static func upsert(_ item: BMArtifactLedgerItem) { var all = load(); all.removeAll { $0.id == item.id }; all.append(item); save(all) }
}

enum BMHealthLevel: String, Codable { case healthy = "正常", warning = "注意", unavailable = "未配置" }
struct BMHealthProbe: Identifiable { let id: String; let title: String; let level: BMHealthLevel; let detail: String }

enum BMPlatformHealthCenter {
    static func snapshot() -> [BMHealthProbe] {
        let github = !KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        let cm = !KeychainStore.read("codemagic-api-token").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !(UserDefaults.standard.string(forKey: "codemagic-app-id") ?? "").isEmpty
        let ai = !KeychainStore.read("ai-api-key").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !KeychainStore.read("ai-api-key-openai").isEmpty || !KeychainStore.read("ai-api-key-deepseek").isEmpty
        let recovery = CodemagicRunRecoveryStore.load()
        return [
            .init(id:"core", title:"BuildMate Core", level:.healthy, detail:"Workspace / Task / Artifact 状态由 Core 持有"),
            .init(id:"github", title:"源码平台 · GitHub", level:github ? .healthy : .unavailable, detail:github ? "本机凭据已存在" : "尚未配置本机源码凭据"),
            .init(id:"codemagic", title:"编译平台 · Codemagic", level:cm ? .healthy : .unavailable, detail:cm ? "API 配置已存在" : "尚未完成 API 配置"),
            .init(id:"relay", title:"产物回传 · Git Relay", level:cm && github ? .healthy : .warning, detail:cm && github ? "具备自动回传所需本机链路" : "需要源码与编译平台均可用"),
            .init(id:"ai", title:"AI Provider", level:ai ? .healthy : .unavailable, detail:ai ? "本机 AI 凭据已存在" : "未配置，不影响普通编译"),
            .init(id:"recovery", title:"待恢复 Run", level:recovery == nil ? .healthy : .warning, detail:recovery == nil ? "没有遗留 Codemagic Run" : "发现可恢复 Run：\(recovery?.buildID ?? "")")
        ]
    }
}

struct BMSecurityFinding: Identifiable { let id = UUID(); let title: String; let safe: Bool; let detail: String }
enum BMSecurityCenter {
    static func snapshot() -> [BMSecurityFinding] {
        let github = !KeychainStore.read("github-token").isEmpty
        let cm = !KeychainStore.read("codemagic-api-token").isEmpty
        return [
            .init(title:"GitHub 凭据", safe:true, detail:github ? "保存在 Keychain；界面/诊断不得输出明文" : "未配置"),
            .init(title:"Codemagic 凭据", safe:true, detail:cm ? "保存在 Keychain；仅请求时读取" : "未配置"),
            .init(title:"AI API Key", safe:true, detail:"按 Provider 存入 Keychain；黑匣子继续执行脱敏"),
            .init(title:"诊断导出", safe:true, detail:"Authorization / Token / API Key / Cookie 继续禁止进入诊断包"),
            .init(title:"云端 Secret", safe:true, detail:"CODEMAGIC_API_TOKEN 与 BUILDMATE_RELAY_GITHUB_TOKEN 只由 Codemagic Secret 注入，不写入源码")
        ]
    }
}

enum BMAIRepairApprovalPolicy: String, Codable, CaseIterable, Identifiable {
    case alwaysReview = "每轮修改都审核"
    case reviewBeforeCloudBuild = "本地修复后，云编译前审核"
    case safePatchAutoApply = "低风险 Patch 自动应用"
    var id: String { rawValue }
}

enum BMAIRepairGovernanceStore {
    private static let policyKey = "ai-repair-approval-policy-v1"
    private static let maxRoundsKey = "ai-repair-max-rounds-v1"
    static var policy: BMAIRepairApprovalPolicy {
        get { UserDefaults.standard.string(forKey: policyKey).flatMap(BMAIRepairApprovalPolicy.init(rawValue:)) ?? .reviewBeforeCloudBuild }
        set { UserDefaults.standard.set(newValue.rawValue, forKey: policyKey) }
    }
    static var maxRounds: Int {
        get { let n = UserDefaults.standard.integer(forKey: maxRoundsKey); return n == 0 ? 3 : min(5, max(1, n)) }
        set { UserDefaults.standard.set(min(5, max(1, newValue)), forKey: maxRoundsKey) }
    }
}
