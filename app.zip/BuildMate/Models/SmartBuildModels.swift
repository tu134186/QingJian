import Foundation
import CryptoKit

struct SmartPreflightResult: Codable, Hashable {
    var ok: Bool
    var sha256: String
    var byteCount: Int
    var sourceName: String
    var messages: [String]
}

enum SmartBuildOutcome: String, Codable {
    case success, failed, artifactPending, blocked, preflightPassed, preflightFailed
}

struct SmartBuildFingerprint: Codable, Identifiable {
    var id: String { sha256 + "|" + provider }
    var sha256: String
    var sourceName: String
    var versionHint: String?
    var buildHint: String?
    var outcome: SmartBuildOutcome
    var provider: String
    var date: Date
    var runID: Int64?
    var artifactName: String?
}

struct SmartBuildUsage: Codable {
    var localChecks = 0
    var localBlocks = 0
    var linuxChecks = 0
    var linuxBlocks = 0
    var duplicateBlocks = 0
    var githubMacRuns = 0
    var codemagicRuns = 0
    var bitriseRuns = 0
    var successes = 0
    var failures = 0
    var estimatedMacMinutesSaved = 0
    var monthKey = SmartBuildUsage.currentMonthKey

    static var currentMonthKey: String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM"; return f.string(from: Date())
    }
}

enum SmartBuildStore {
    private static let fingerprintKey = "smart-build-fingerprints-v1"
    private static let usageKey = "smart-build-usage-v1"

    static func fingerprints() -> [SmartBuildFingerprint] {
        guard let data = UserDefaults.standard.data(forKey: fingerprintKey) else { return [] }
        return (try? JSONDecoder().decode([SmartBuildFingerprint].self, from: data)) ?? []
    }

    static func latest(for sha256: String) -> SmartBuildFingerprint? {
        fingerprints().filter { $0.sha256 == sha256 }.sorted { $0.date > $1.date }.first
    }

    static func latest(for sha256: String, provider: String) -> SmartBuildFingerprint? {
        fingerprints().filter { $0.sha256 == sha256 && $0.provider == provider }.sorted { $0.date > $1.date }.first
    }

    static func record(_ item: SmartBuildFingerprint) {
        var items = fingerprints()
        items.removeAll { $0.sha256 == item.sha256 && $0.provider == item.provider }
        items.insert(item, at: 0)
        if items.count > 80 { items = Array(items.prefix(80)) }
        if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: fingerprintKey) }
    }

    static func usage() -> SmartBuildUsage {
        var value: SmartBuildUsage
        if let data = UserDefaults.standard.data(forKey: usageKey), let decoded = try? JSONDecoder().decode(SmartBuildUsage.self, from: data) { value = decoded }
        else { value = SmartBuildUsage() }
        if value.monthKey != SmartBuildUsage.currentMonthKey { value = SmartBuildUsage() }
        return value
    }

    static func mutateUsage(_ body: (inout SmartBuildUsage) -> Void) {
        var value = usage(); body(&value)
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: usageKey) }
    }

    /// Build1039：现行“源码体检”已退役。
    /// 历史 Agent/旧页面若误调用本入口，也绝不能再根据 ZIP 结构宣称“源码正确”。
    /// 这里只保留 SHA/文件大小供旧数据结构兼容，并明确返回不可作为编译结论。
    static func localPreflight(data: Data, sourceName: String) -> SmartPreflightResult {
        let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        return SmartPreflightResult(
            ok: false,
            sha256: digest,
            byteCount: data.count,
            sourceName: sourceName,
            messages: [
                "本地源码体检已停用：ZIP 结构不能证明源码可编译。",
                "源码正确性只接受真实 Xcode/Theos 云编译结果。",
                "SHA-256：\(digest.prefix(16))…"
            ]
        )
    }

    /// 只解析 ZIP Central Directory 文件名，不解压源码；iOS 16.5 可安全执行，
    /// 用来在上传前发现“多包一层目录/缺 project.yml/缺源码”等高频打包错误。
    private static func zipEntryNames(data: Data) -> [String] {
        let b = [UInt8](data)
        guard b.count >= 22 else { return [] }
        var eocd: Int? = nil
        let lower = max(0, b.count - 65_557)
        if b.count >= 4 {
            for i in stride(from: b.count - 4, through: lower, by: -1) {
                if b[i] == 0x50 && b[i+1] == 0x4b && b[i+2] == 0x05 && b[i+3] == 0x06 { eocd = i; break }
            }
        }
        guard let e = eocd, e + 21 < b.count else { return [] }
        func u16(_ i: Int) -> Int { Int(b[i]) | (Int(b[i+1]) << 8) }
        func u32(_ i: Int) -> Int { Int(b[i]) | (Int(b[i+1]) << 8) | (Int(b[i+2]) << 16) | (Int(b[i+3]) << 24) }
        let count = u16(e + 10)
        var pos = u32(e + 16)
        guard pos >= 0 && pos < b.count else { return [] }
        var names: [String] = []
        for _ in 0..<min(count, 20_000) {
            guard pos + 46 <= b.count,
                  b[pos] == 0x50, b[pos+1] == 0x4b, b[pos+2] == 0x01, b[pos+3] == 0x02 else { break }
            let nameLen = u16(pos + 28), extraLen = u16(pos + 30), commentLen = u16(pos + 32)
            let start = pos + 46, end = start + nameLen
            guard end <= b.count else { break }
            let nameData = Data(b[start..<end])
            if let name = String(data: nameData, encoding: .utf8) { names.append(name) }
            pos = end + extraLen + commentLen
            if pos > b.count { break }
        }
        return names
    }
}

enum BuildFailureKind: String {
    case source = "源码编译错误"
    case quota = "云端额度/计费限制"
    case payment = "付款/预算限制"
    case network = "网络/服务异常"
    case runner = "Runner 未启动"
    case auth = "认证/配置错误"
    case artifact = "产物回传异常"
    case platform = "平台/API 链路异常"
    case unknown = "未分类异常"

    static func classify(_ text: String) -> BuildFailureKind {
        let s = text.lowercased()
        if s.contains("spending limit") || s.contains("billing") || s.contains("payment") || s.contains("付款") || s.contains("预算") { return .payment }
        if s.contains("quota") || s.contains("included minutes") || s.contains("minutes") && s.contains("limit") || s.contains("额度") { return .quota }
        if s.contains("job was not started") || s.contains("runner") && s.contains("not started") { return .runner }
        if s.contains("artifact") || s.contains("产物回传") || s.contains("重新抓取 ipa") || s.contains("public-url") { return .artifact }
        if s.contains("401") || s.contains("403") || s.contains("token") && s.contains("fail") || s.contains("权限") || s.contains("认证") || s.contains("配置") { return .auth }
        if s.contains("unsupported url") || s.contains("url 不受支持") || s.contains("-1002") { return .platform }
        if s.contains("timed out") || s.contains("cannot parse response") || s.contains("无法解析") || s.contains("启动结果未确认") || s.contains("network") || s.contains("http 5") || s.contains("网络") || s.contains("请求失败") { return .network }
        if s.contains("error:") || s.contains("compile") || s.contains("编译失败") { return .source }
        return .unknown
    }
}
