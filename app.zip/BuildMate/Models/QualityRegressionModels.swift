import Foundation

enum BMQualityStatus: String, Codable {
    case passed = "自动通过"
    case verified = "实机已验证"
    case warning = "警告"
    case pending = "待实机验证"
    case failed = "失败"
}

struct BMQualityCheck: Identifiable, Codable, Hashable {
    var id: String { key }
    let key: String
    let title: String
    let detail: String
    let status: BMQualityStatus
    let evidence: String
}

struct BMRegressionSnapshot: Codable {
    let version: String
    let build: Int
    let createdAt: Date
    let checks: [BMQualityCheck]
}

enum BMQualityRegressionStore {
    private static let snapshotKey = "quality-regression-snapshot-v1"

    static func runLocalAudit() -> BMRegressionSnapshot {
        var checks: [BMQualityCheck] = []
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
        let buildText = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0"
        let build = Int(buildText) ?? 0

        checks.append(.init(key: "runtime-version", title: "运行版本可识别", detail: "Bundle 版本与 Build 可正常读取。", status: (!version.isEmpty && build > 0) ? .passed : .failed, evidence: "运行中：V\(version) · Build \(build)；不再用旧 Build105 硬编码判定当前版本"))

        let rules = BuildGuardStore.knownRegressionRules()
        checks.append(.init(key: "regression-rules", title: "回归规则库", detail: "关键历史 Bug 与高风险边界已进入规则库。", status: rules.count >= 6 ? .passed : .warning, evidence: "当前规则 \(rules.count) 条"))

        let providers = BMProviderRegistry.builtIns
        let uniqueProviderIDs = Set(providers.map { $0.id })
        checks.append(.init(key: "provider-registry", title: "Provider 标准层", detail: "云编译/私有节点通过统一 Registry 扩展。", status: uniqueProviderIDs.count == providers.count && providers.count >= 5 ? .passed : .failed, evidence: "已注册 \(providers.count) 个 Provider，ID 唯一 \(uniqueProviderIDs.count) 个"))

        if let d = BuildGuardStore.latestDiagnostic() {
            checks.append(.init(key: "diagnostic-chain", title: "真实错误诊断链", detail: "最近一次真实编译诊断可读取。", status: .passed, evidence: "\(d.provider) · \(d.trueErrorCount) 个 error · \(d.warningCount) 个 warning"))
        } else {
            checks.append(.init(key: "diagnostic-chain", title: "真实错误诊断链", detail: "本机尚无可复用的真实编译诊断记录。", status: .pending, evidence: "需要一次真实失败样本验证"))
        }

        if let ipa = BuildGuardStore.latestIPA() {
            checks.append(.init(key: "ipa-chain", title: "IPA 产物验证链", detail: "最近一次 IPA 基础完整性记录可读取。", status: ipa.passed ? .passed : .failed, evidence: "\(ipa.name) · \(ipa.byteCount) bytes"))
        } else {
            checks.append(.init(key: "ipa-chain", title: "IPA 产物验证链", detail: "本机尚无 IPA 验证记录。", status: .pending, evidence: "等待真实 IPA 下载后验证"))
        }

        if let baseline = BuildGuardStore.baseline() {
            checks.append(.init(key: "baseline", title: "稳定基线", detail: "已存在真实成功源码基线。", status: .passed, evidence: "\(baseline.sourceName) · \(baseline.sha256.prefix(12))…"))
        } else {
            checks.append(.init(key: "baseline", title: "稳定基线", detail: "尚未从真实云端成功记录提升稳定基线。", status: .warning, evidence: "不会自动伪造稳定基线"))
        }

        // Build101 是用户实机确认的稳定基线。这里记录“历史证据”，不是把 Build102 未测试功能伪装成通过。
        let verified101: [(String,String)] = [
            ("App 安装与启动", "Build101 已真实 Xcode 编译、IPA 安装并在 iOS 16.5 启动"),
            ("正常编译启动", "Build101 实机确认可启动正常编译"),
            ("运行中停止编译", "Build101 实机确认主按钮切换停止编译并成功停止"),
            ("停止后返回待机", "Build101 实机确认停止态可回到待机"),
            ("编译中锁定源码操作", "Build101 实机确认切换/清除源码被锁定"),
            ("停止后保留源码", "Build101 实机确认停止任务不会误删源码"),
            ("源码体检", "Build101 实机确认源码体检后可继续编译")
        ]
        for (index, item) in verified101.enumerated() {
            checks.append(.init(key: "build101-device-\(index)", title: item.0, detail: "继承稳定基线的历史回归证据。", status: .verified, evidence: item.1))
        }

        checks.append(.init(key: "build221-anchor", title: "Build221 模块化收官稳定锚点", detail: "Build220 的真实 Xcode 类型错误已经闭环修复，Build221 已完成真实 Codemagic/Xcode 编译与 IPA 安装启动。", status: .verified, evidence: "2026-09-08 真机确认 V2.18.1 · Build221"))
        checks.append(.init(key: "build222-preflight", title: "Build222 零分钟体检", detail: "Build222 已真实编译安装，正式 Run 前先验证 GitHub 写入与 Codemagic API。", status: .verified, evidence: "2026-09-08 真机确认 V2.18.2 · Build222"))
        checks.append(.init(key: "build223-release-center", title: "Build223 发布准备中心", detail: "Build223 已真实 Codemagic/Xcode 编译并安装启动，质量回归修正与发布准备中心通过真机验收。", status: .verified, evidence: "2026-09-08 真机确认 V2.19.0 · Build223"))
        checks.append(.init(key: "build224-release-workspace", title: "Build224 发布工作台稳定锚点", detail: "Build224 已真实 Codemagic/Xcode 编译并安装启动，发布工作台与安全交接链通过真机验收。", status: .verified, evidence: "2026-09-08 真机确认 V2.20.0 · Build224"))
        checks.append(.init(key: "build225-asc-probe", title: "Build225 App Store Connect 只读探针", detail: "Build225 已真实 Codemagic/Xcode 编译并安装启动，App Store Connect 第一阶段页面与主链稳定。", status: .verified, evidence: "2026-09-08 真机确认 V2.21.0 · Build225"))
        checks.append(.init(key: "build226-apple-upload", title: "Build226 Apple Build Upload 执行链", detail: "Build226 已真实 Codemagic/Xcode 编译并安装启动，IPA 上传执行链页面与安全边界通过真机验收。", status: .verified, evidence: "2026-09-08 真机确认 V2.22.0 · Build226"))
        checks.append(.init(key: "blackbox-current", title: "任务黑匣子当前链路", detail: "统一任务流水、终态同步、恢复与诊断导出已经进入正式执行链。", status: .verified, evidence: "Build103 起持续演进；Build184 修正 Run 终态跨页面同步"))

        let snapshot = BMRegressionSnapshot(version: version, build: build, createdAt: Date(), checks: checks)
        if let data = try? JSONEncoder().encode(snapshot) { UserDefaults.standard.set(data, forKey: snapshotKey) }
        return snapshot
    }

    static func latest() -> BMRegressionSnapshot? {
        guard let data = UserDefaults.standard.data(forKey: snapshotKey) else { return nil }
        return try? JSONDecoder().decode(BMRegressionSnapshot.self, from: data)
    }
}
