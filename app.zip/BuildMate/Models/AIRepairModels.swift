import Foundation

struct RepairFileContext: Codable {
    var path: String
    var line: Int?
    var snippet: String
}

struct RepairContext: Codable {
    var runID: Int64?
    var errorSignature: String?
    var diagnosis: String?
    var compileErrors: String?
    var files: [RepairFileContext]
    var attempt: Int?
}

struct RepairPatch: Codable, Identifiable {
    var id: String { path + search }
    var path: String
    var search: String
    var replace: String
    var reason: String?
}

struct AIRepairPlan: Codable {
    var summary: String
    var confidence: Int
    var risk: String
    var patches: [RepairPatch]
    var stopReason: String?
    var sourceSHA256: String? = nil
    var taskID: String? = nil

    var isAutoSafe: Bool {
        risk.lowercased() == "low" && confidence >= 80 && !patches.isEmpty
    }
}

struct AIUsage: Codable {
    var promptTokens: Int?
    var completionTokens: Int?
    var totalTokens: Int?
}

struct AIRepairResult {
    var plan: AIRepairPlan
    var usage: AIUsage?
    var rawResponse: String? = nil
    var formattedResponse: String? = nil
}
