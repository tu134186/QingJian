import Foundation

struct CodemagicArtifactRecoveryRecord: Codable, Hashable {
    let buildID: String
    let artifactName: String
    let buildURL: String?
    let sourceSHA256: String?
    let createdAt: Date
    let taskID: String?
    let relayBranch: String?
    let relayPath: String?

    init(buildID: String, artifactName: String, buildURL: String?, sourceSHA256: String?, createdAt: Date, taskID: String? = nil, relayBranch: String? = nil, relayPath: String? = nil) {
        self.buildID = buildID
        self.artifactName = artifactName
        self.buildURL = buildURL
        self.sourceSHA256 = sourceSHA256
        self.createdAt = createdAt
        self.taskID = taskID
        self.relayBranch = relayBranch
        self.relayPath = relayPath
    }
}

enum CodemagicArtifactRecoveryStore {
    private static let key = "codemagic-artifact-recovery-v1"
    static func load() -> CodemagicArtifactRecoveryRecord? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(CodemagicArtifactRecoveryRecord.self, from: data)
    }
    static func save(_ record: CodemagicArtifactRecoveryRecord) {
        guard let data = try? JSONEncoder().encode(record) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
    static func clear() { UserDefaults.standard.removeObject(forKey: key) }
}

/// Build1042：Codemagic publishing 阶段生成的任务专属产物回传回执。
/// 只保存 Build/Task/产物指纹与 Git Relay 路径，不保存任何 Token 或 Cookie。
struct BMCodemagicRelayReceipt: Codable, Hashable {
    let schema: Int
    let taskID: String
    let buildID: String
    let sourceSHA256: String
    let artifactKind: String
    let artifactName: String
    let artifactPath: String
    let relayBranch: String
    let byteCount: Int
    let sha256: String
    let codemagicArtifactLinksAvailable: Bool
    let createdAt: String
}
