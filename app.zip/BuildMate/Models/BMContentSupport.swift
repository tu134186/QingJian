import Foundation

/// Build178：从 ContentView 抽离的纯辅助逻辑。
/// 不保存 UI 状态，不启动任务，不触碰云编译主链。
enum BMContentSupport {
    static func cleaned(_ string: String) -> String? {
        let value = string.trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }

    static func friendlyFileError(_ error: Error, fileName: String) -> String {
        let ns = error as NSError
        if ns.domain == NSCocoaErrorDomain && (ns.code == 4 || ns.code == 260) {
            return "\(fileName) 已不存在，请重新选择。"
        }
        return error.localizedDescription
    }

    static func fileSizeText(_ url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        guard let size = values?.fileSize else { return "" }
        return ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    static func error(_ text: String) -> NSError {
        NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: text])
    }


    static func compactCompilerErrors(_ text: String, limit: Int = 5) -> String {
        let lines = text.components(separatedBy: .newlines)
        let prioritized = lines.filter {
            let lower = $0.lowercased()
            return lower.contains(" error:") || lower.hasPrefix("error:") || lower.contains("fatal error:")
        }
        let source = prioritized.isEmpty ? lines.filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty } : prioritized
        var seen = Set<String>()
        let unique = source.compactMap { raw -> String? in
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !line.isEmpty, !seen.contains(line) else { return nil }
            seen.insert(line)
            return line
        }
        return unique.prefix(max(1, limit)).joined(separator: "\n")
    }
}
