import Foundation

struct BMServiceProbe: Codable, Identifiable {
    var id: String { service }
    let service: String
    let ok: Bool
    let date: Date
    let latencyMS: Int
    let message: String
}

struct BMDeviceVerification: Codable {
    let date: Date
    let sourceName: String
    let sha256: String
    let note: String
}

enum DevelopmentControlStore {
    private static let probeKey = "buildmate-service-probes-v1"
    private static let deviceKey = "buildmate-device-verification-v1"

    static func probes() -> [BMServiceProbe] {
        guard let data = UserDefaults.standard.data(forKey: probeKey),
              let values = try? JSONDecoder().decode([BMServiceProbe].self, from: data) else { return [] }
        return values.sorted { $0.date > $1.date }
    }

    static func latestProbe(_ service: String) -> BMServiceProbe? {
        probes().first { $0.service == service }
    }

    static func saveProbe(service: String, ok: Bool, startedAt: Date, message: String) {
        let ms = max(1, Int(Date().timeIntervalSince(startedAt) * 1000))
        var values = probes().filter { $0.service != service }
        values.insert(.init(service: service, ok: ok, date: Date(), latencyMS: ms, message: String(message.prefix(180))), at: 0)
        if values.count > 20 { values = Array(values.prefix(20)) }
        if let data = try? JSONEncoder().encode(values) { UserDefaults.standard.set(data, forKey: probeKey) }
    }

    static func deviceVerification() -> BMDeviceVerification? {
        guard let data = UserDefaults.standard.data(forKey: deviceKey) else { return nil }
        return try? JSONDecoder().decode(BMDeviceVerification.self, from: data)
    }

    static func markDeviceVerified(sourceName: String, sha256: String, note: String = "已由用户在真机启动并完成基础功能检查。") {
        let value = BMDeviceVerification(date: Date(), sourceName: sourceName, sha256: sha256, note: note)
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: deviceKey) }
    }

    static func clearDeviceVerification() {
        UserDefaults.standard.removeObject(forKey: deviceKey)
    }
}
