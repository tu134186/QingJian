import Foundation

enum BMCodemagicBuildAuthority: String, Codable, CaseIterable {
    case unknown, initializing, queued, preparing, fetching, testing, building, publishing, finishing, finished, failed, canceled, timeout, skipped, networkUnknown

    init(remoteStatus: String) {
        switch remoteStatus.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "initializing": self = .initializing
        case "queued", "pending": self = .queued
        case "preparing": self = .preparing
        case "fetching": self = .fetching
        case "testing": self = .testing
        case "building", "in_progress", "in-progress": self = .building
        case "publishing": self = .publishing
        case "finishing": self = .finishing
        case "finished", "success": self = .finished
        case "failed": self = .failed
        case "canceled", "cancelled": self = .canceled
        case "timeout", "timed_out": self = .timeout
        case "skipped": self = .skipped
        case "network_unknown": self = .networkUnknown
        default: self = .unknown
        }
    }

    var isTerminal: Bool {
        switch self { case .finished, .failed, .canceled, .timeout, .skipped: return true; default: return false }
    }
}

enum BMArtifactAuthority: String, Codable, CaseIterable {
    case notStarted, locating, downloading, validating, ready, failed, notApplicable
}

struct CodemagicRunRecoveryRecord: Codable, Hashable {
    var taskID: String
    var buildID: String
    var buildURL: String?
    var sourceSHA256: String
    var sourceName: String
    var buildState: BMCodemagicBuildAuthority
    var artifactState: BMArtifactAuthority
    var lastRemoteStatus: String
    var firstError: String?
    var networkFailures: Int
    var createdAt: Date
    var updatedAt: Date
    // Build170：用户主动停止后保留 Run 证据，但禁止 App 自动恢复同一 Run。
    var userStopRequested: Bool? = nil

    var isBuildTerminal: Bool { buildState.isTerminal }
    var allowsAutomaticResume: Bool { userStopRequested != true }
}

enum CodemagicRunRecoveryStore {
    private static let key = "codemagic-run-recovery-v1"

    static func load() -> CodemagicRunRecoveryRecord? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(CodemagicRunRecoveryRecord.self, from: data)
    }

    static func save(_ record: CodemagicRunRecoveryRecord) {
        guard let data = try? JSONEncoder().encode(record) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    static func mutate(_ body: (inout CodemagicRunRecoveryRecord) -> Void) {
        guard var value = load() else { return }
        body(&value)
        value.updatedAt = Date()
        save(value)
    }

    static func clear() { UserDefaults.standard.removeObject(forKey: key) }
}
