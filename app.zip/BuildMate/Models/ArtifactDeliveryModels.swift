import Foundation

struct BMArtifactDeliveryRecord: Codable, Identifiable, Hashable {
    let id: String
    var provider: String
    var runID: String
    var sourceSHA256: String?
    var artifactName: String
    var localPath: String?
    var buildURL: String?
    var verified: Bool
    var byteCount: Int
    var createdAt: Date
    var updatedAt: Date
    var deliveredAt: Date?

    var localURL: URL? {
        guard let localPath, FileManager.default.fileExists(atPath: localPath) else { return nil }
        return URL(fileURLWithPath: localPath)
    }

    var isLocalReady: Bool { verified && localURL != nil }
    var stateTitle: String {
        if isLocalReady { return deliveredAt == nil ? "本机可用" : "已分享" }
        if buildURL != nil { return "可重新获取" }
        return "记录保留"
    }

    var shortRunID: String {
        if runID.count <= 12 { return runID }
        return String(runID.prefix(12))
    }
}

enum BMArtifactDeliveryStore {
    private static let key = "buildmate-artifact-delivery-v1"
    private static let limit = 30

    static func load() -> [BMArtifactDeliveryRecord] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([BMArtifactDeliveryRecord].self, from: data) else { return [] }
        return reconcile(decoded)
    }

    static func save(_ items: [BMArtifactDeliveryRecord]) {
        let normalized = Array(items.sorted { $0.updatedAt > $1.updatedAt }.prefix(limit))
        guard let data = try? JSONEncoder().encode(normalized) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }

    @discardableResult
    static func upsert(provider: String, runID: String, sourceSHA256: String?, artifactName: String, localURL: URL?, buildURL: String?, verified: Bool, byteCount: Int) -> BMArtifactDeliveryRecord {
        var items = load()
        let stableID = provider.lowercased() + "|" + runID + "|" + artifactName
        let now = Date()
        let previous = items.first(where: { $0.id == stableID })
        let record = BMArtifactDeliveryRecord(
            id: stableID,
            provider: provider,
            runID: runID,
            sourceSHA256: sourceSHA256,
            artifactName: artifactName,
            localPath: localURL?.path ?? previous?.localPath,
            buildURL: buildURL ?? previous?.buildURL,
            verified: verified || (previous?.verified ?? false),
            byteCount: max(byteCount, previous?.byteCount ?? 0),
            createdAt: previous?.createdAt ?? now,
            updatedAt: now,
            deliveredAt: previous?.deliveredAt
        )
        items.removeAll { $0.id == stableID }
        items.insert(record, at: 0)
        save(items)
        return record
    }

    static func markDelivered(localURL: URL) {
        var items = load()
        guard let index = items.firstIndex(where: { $0.localPath == localURL.path }) else { return }
        items[index].deliveredAt = Date()
        items[index].updatedAt = Date()
        save(items)
    }

    static func latestLocal() -> BMArtifactDeliveryRecord? {
        load().first(where: { $0.isLocalReady })
    }

    static func needsDelivery(localURL: URL) -> Bool {
        guard let item = load().first(where: { $0.localPath == localURL.path }) else { return true }
        return item.deliveredAt == nil
    }

    static func localCount() -> Int { load().filter { $0.isLocalReady }.count }

    static func remove(id: String, deleteLocalFile: Bool) {
        var items = load()
        if deleteLocalFile, let item = items.first(where: { $0.id == id }), let url = item.localURL {
            try? FileManager.default.removeItem(at: url)
        }
        items.removeAll { $0.id == id }
        save(items)
    }

    private static func reconcile(_ input: [BMArtifactDeliveryRecord]) -> [BMArtifactDeliveryRecord] {
        var changed = false
        let output = input.map { item -> BMArtifactDeliveryRecord in
            guard let path = item.localPath, !FileManager.default.fileExists(atPath: path) else { return item }
            var copy = item
            copy.localPath = nil
            copy.updatedAt = Date()
            changed = true
            return copy
        }
        if changed, let data = try? JSONEncoder().encode(output) {
            UserDefaults.standard.set(data, forKey: key)
        }
        return output.sorted { $0.updatedAt > $1.updatedAt }
    }
}
