import Foundation

// Build99 核心框架：业务模块彼此隔离，只通过轻量模型/协议通信。
enum BMModuleID: String, CaseIterable, Codable, Identifiable {
    case source = "源码管理"
    case build = "编译调度"
    case providers = "编译平台"
    case diagnostics = "错误诊断"
    case artifacts = "产物中心"
    case release = "质量发布"
    var id: String { rawValue }
}

enum BMBuildPhase: String, Codable, CaseIterable {
    case idle = "待机"
    case preflight = "本地预检"
    case syncing = "同步源码"
    case queued = "云端排队"
    case building = "Xcode 编译"
    case packaging = "产物打包"
    case downloading = "获取产物"
    case verifying = "验证产物"
    case success = "完成"
    case failed = "失败"
    case cancelled = "已取消"
}

struct BMBuildTaskSnapshot: Codable, Identifiable {
    let id: String
    var sourceName: String
    var sourceSHA256: String
    var providerID: String
    var remoteBuildID: String
    var phase: BMBuildPhase
    var createdAt: Date
    var updatedAt: Date
    var message: String
}

protocol BMCompilerProviderAdapter {
    var providerID: String { get }
    var displayName: String { get }
    var isConfigured: Bool { get }
}

struct BMProviderDescriptor: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let icon: String
    let kind: String
    let supportsCancel: Bool
    let supportsArtifacts: Bool
    let supportsDiagnostics: Bool
}

enum BMProviderRegistry {
    // 这里只注册“编译执行器”。源码平台由 BMSourceProviderRegistry 独立管理。
    // 同一个厂商可同时提供源码与 CI，但在 BuildMate 内必须作为两个不同角色存在。
    static let builtIns: [BMProviderDescriptor] = [
        .init(id: "codemagic", name: "Codemagic", icon: "cloud.fill", kind: "云编译", supportsCancel: true, supportsArtifacts: true, supportsDiagnostics: true),
        .init(id: "bitrise", name: "Bitrise", icon: "bolt.horizontal.circle.fill", kind: "云编译", supportsCancel: true, supportsArtifacts: true, supportsDiagnostics: true),
        .init(id: "github", name: "GitHub Actions", icon: "chevron.left.forwardslash.chevron.right", kind: "CI", supportsCancel: false, supportsArtifacts: true, supportsDiagnostics: true),
        .init(id: "selfhost", name: "自托管 Mac", icon: "desktopcomputer", kind: "本地/私有云", supportsCancel: true, supportsArtifacts: true, supportsDiagnostics: true),
        .init(id: "generic-rest", name: "通用 REST Provider", icon: "network", kind: "扩展接口", supportsCancel: true, supportsArtifacts: true, supportsDiagnostics: true)
    ]
}

enum BMSourceLifecycleStore {
    static let autoCleanupKey = "source-auto-cleanup-after-delivery-v1"
    static var autoCleanupAfterDelivery: Bool {
        get {
            if UserDefaults.standard.object(forKey: autoCleanupKey) == nil { return true }
            return UserDefaults.standard.bool(forKey: autoCleanupKey)
        }
        set { UserDefaults.standard.set(newValue, forKey: autoCleanupKey) }
    }
}
