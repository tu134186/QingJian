import Foundation
import CryptoKit

struct BMCompileIssue: Codable, Identifiable, Hashable {
    var id: String { "\(file ?? "-")|\(line ?? 0)|\(message)" }
    var severity: String
    var file: String?
    var line: Int?
    var column: Int?
    var message: String
    var raw: String
}

struct BMCompileDiagnostic: Codable, Hashable {
    var createdAt: Date
    var provider: String
    var buildID: String?
    var issues: [BMCompileIssue]
    var rawText: String
    var trueErrorCount: Int { issues.filter { $0.severity == "error" }.count }
    var warningCount: Int { issues.filter { $0.severity == "warning" }.count }
    var rootCause: BMCompileIssue? { issues.first(where: { $0.severity == "error" }) }
    var cascadeErrorCount: Int { max(0, trueErrorCount - (rootCause == nil ? 0 : 1)) }
    var headline: String {
        if let first = issues.first(where: { $0.severity == "error" }) {
            if let file = first.file, let line = first.line { return "\(file) · \(line) 行 · \(first.message)" }
            return first.message
        }
        return rawText.isEmpty ? "暂无真实编译错误" : String(rawText.prefix(180))
    }
}

struct BMIPAVerification: Codable, Hashable {
    var date: Date
    var name: String
    var byteCount: Int
    var sha256: String
    var passed: Bool
    var notes: [String]
}

struct BMStableBaseline: Codable, Hashable {
    var date: Date
    var sourceName: String
    var sha256: String
    var note: String
}

struct BMGuardRule: Identifiable, Hashable {
    var id: String { title }
    var title: String
    var detail: String
    var level: String
}

enum BuildGuardStore {
    private static let diagnosticKey = "build-guard-diagnostic-v1"
    private static let ipaKey = "build-guard-ipa-v1"
    private static let baselineKey = "build-guard-baseline-v1"

    static func saveDiagnostic(_ value: BMCompileDiagnostic) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: diagnosticKey) }
    }
    static func latestDiagnostic() -> BMCompileDiagnostic? {
        guard let data = UserDefaults.standard.data(forKey: diagnosticKey) else { return nil }
        return try? JSONDecoder().decode(BMCompileDiagnostic.self, from: data)
    }

    /// Return diagnostic evidence only when it belongs to the requested remote build.
    /// A diagnostic from an older Build ID must never be reused as the root cause of a new task.
    static func diagnostic(forBuildID buildID: String?) -> BMCompileDiagnostic? {
        guard let expected = buildID?.trimmingCharacters(in: .whitespacesAndNewlines), !expected.isEmpty,
              let diagnostic = latestDiagnostic(),
              let actual = diagnostic.buildID?.trimmingCharacters(in: .whitespacesAndNewlines),
              !actual.isEmpty,
              actual == expected else { return nil }
        return diagnostic
    }
    static func saveIPA(_ value: BMIPAVerification) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: ipaKey) }
    }
    static func latestIPA() -> BMIPAVerification? {
        guard let data = UserDefaults.standard.data(forKey: ipaKey) else { return nil }
        return try? JSONDecoder().decode(BMIPAVerification.self, from: data)
    }
    static func saveBaseline(_ value: BMStableBaseline) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: baselineKey) }
    }
    static func baseline() -> BMStableBaseline? {
        guard let data = UserDefaults.standard.data(forKey: baselineKey) else { return nil }
        return try? JSONDecoder().decode(BMStableBaseline.self, from: data)
    }

    static func parseCompileErrors(_ text: String, provider: String, buildID: String? = nil) -> BMCompileDiagnostic {
        let ns = text as NSString
        let pattern = #"(?m)^(.+?\.swift):(\d+):(\d+):\s*(error|warning|note):\s*(.+)$"#
        let regex = try? NSRegularExpression(pattern: pattern)
        var issues: [BMCompileIssue] = []
        let full = NSRange(location: 0, length: ns.length)
        regex?.enumerateMatches(in: text, range: full) { match, _, _ in
            guard let match, match.numberOfRanges >= 6 else { return }
            let path = ns.substring(with: match.range(at: 1))
            let file = URL(fileURLWithPath: path).lastPathComponent
            let line = Int(ns.substring(with: match.range(at: 2)))
            let column = Int(ns.substring(with: match.range(at: 3)))
            let severity = ns.substring(with: match.range(at: 4))
            let message = ns.substring(with: match.range(at: 5)).trimmingCharacters(in: .whitespacesAndNewlines)
            let raw = ns.substring(with: match.range(at: 0))
            let issue = BMCompileIssue(severity: severity, file: file, line: line, column: column, message: message, raw: raw)
            if !issues.contains(where: { $0.severity == issue.severity && $0.file == issue.file && $0.line == issue.line && $0.column == issue.column && $0.message == issue.message }) {
                issues.append(issue)
            }
        }
        if issues.isEmpty {
            for line in text.components(separatedBy: .newlines) where line.lowercased().contains("error:") {
                issues.append(BMCompileIssue(severity: "error", file: nil, line: nil, column: nil, message: line.trimmingCharacters(in: .whitespaces), raw: line))
            }
        }
        let result = BMCompileDiagnostic(createdAt: Date(), provider: provider, buildID: buildID, issues: Array(issues.prefix(60)), rawText: String(text.prefix(30_000)))
        saveDiagnostic(result)
        return result
    }

    static func verifyIPA(data: Data, name: String) -> BMIPAVerification {
        let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        let b = [UInt8](data.prefix(4))
        let zipHeader = b.count >= 2 && b[0] == 0x50 && b[1] == 0x4B
        var notes: [String] = []
        var passed = true
        if data.count < 100_000 { passed = false; notes.append("产物小于 100 KB，疑似日志或空包") }
        if !zipHeader { passed = false; notes.append("IPA 不是 PK/ZIP 文件头") }
        if !name.lowercased().hasSuffix(".ipa") { notes.append("文件名不是 .ipa 后缀") }
        if passed { notes.append("基础 IPA 完整性通过：大小与 ZIP 文件头正常") }
        notes.append("SHA-256：\(digest.prefix(16))…")
        let value = BMIPAVerification(date: Date(), name: name, byteCount: data.count, sha256: digest, passed: passed, notes: notes)
        saveIPA(value)
        return value
    }


    static func verifyDEB(data: Data, name: String) -> BMIPAVerification {
        let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        let arMagic = Data("!<arch>\n".utf8)
        let hasArHeader = data.count >= arMagic.count && data.prefix(arMagic.count).elementsEqual(arMagic)
        var notes: [String] = []
        var passed = true
        if data.count < 2_000 { passed = false; notes.append("产物小于 2 KB，疑似日志或空包") }
        if !hasArHeader { passed = false; notes.append("DEB 不是标准 ar 文件头") }
        if !name.lowercased().hasSuffix(".deb") { notes.append("文件名不是 .deb 后缀") }
        if passed { notes.append("基础 DEB 完整性通过：大小与 ar 文件头正常") }
        notes.append("SHA-256：\(digest.prefix(16))…")
        return BMIPAVerification(date: Date(), name: name, byteCount: data.count, sha256: digest, passed: passed, notes: notes)
    }

    static func knownRegressionRules() -> [BMGuardRule] {
        [
            .init(title: "iOS 16.5 首屏安全边界", detail: "多云 Token/App ID/Workflow 不得重新塞回 ContentView 冷启动初始化。", level: "高风险"),
            .init(title: "SwiftUI @State 独立声明", detail: "禁止多个变量共用一条 @State 逗号声明，避免属性包装器与 immutable self 编译错误。", level: "阻断"),
            .init(title: "真实错误优先", detail: "云端额度、付款、Runner、认证失败不得触发 AI 修改源码。", level: "阻断"),
            .init(title: "ActivityShareSheet 回归", detail: "禁止重新出现不可见作用域 ActivityShareSheet(items: shareItems) 旧错误。", level: "阻断"),
            .init(title: "版本历史只追加", detail: "MARKETING_VERSION/Build/关于页/CHANGELOG/README/开发历史必须一致，旧条目不可全局替换。", level: "发布门"),
            .init(title: "云编译 API 禁止重复声明", detail: "新增停止/取消接口前必须全局扫描同名函数；重复声明会造成 invalid redeclaration 并触发级联编译错误。", level: "阻断")
        ]
    }
}
