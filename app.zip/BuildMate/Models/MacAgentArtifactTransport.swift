import Foundation
import CryptoKit

// Build162: Mac Agent Artifact return contract. Build completion and Artifact delivery remain separate facts.
struct BMMacAgentRunState: Codable {
    let protocolVersion: String
    let taskID: String
    let runID: String
    let state: String
    let exitCode: Int32?
    let logPath: String
    let updatedAt: Date
}

struct BMMacAgentArtifactList: Codable {
    let protocolVersion: String
    let taskID: String
    let runID: String
    let artifacts: [BMMacAgentArtifactReceipt]
}

struct BMMacAgentDiscoveryRecord: Identifiable, Equatable {
    let id: String
    let name: String
    let host: String
    let port: Int
    var endpoint: String { "http://\(host):\(port)" }
}

enum BMMacArtifactVerifier {
    static func sha256(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }
    static func verify(_ data: Data, receipt: BMMacAgentArtifactReceipt) -> Bool {
        Int64(data.count) == receipt.bytes && sha256(data).lowercased() == receipt.sha256.lowercased()
    }
    static func destinationURL(fileName: String) throws -> URL {
        let safe = fileName.replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "\\", with: "_")
        let base = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            .appendingPathComponent("BuildMateArtifacts", isDirectory: true)
        try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent(safe)
    }
}
