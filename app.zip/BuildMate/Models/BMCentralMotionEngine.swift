import Foundation

/// Central-effect motion math extracted from ContentView.
/// Pure calculations only: no UI state, no network, no persistence.
enum BMCentralMotionEngine {
    static let transitionDuration: TimeInterval = 0.90

    /// 高速任务结束时不要像急刹车一样直接掉到待机。
    /// 降到待机/终态使用更长的惯性减速，其余阶段仍保持快速响应。
    static func transitionDuration(from startSpeed: Double, to targetSpeed: Double) -> TimeInterval {
        if startSpeed >= 240, targetSpeed <= BMCentralTaskSpeedProfile.idleSpeed + 1 { return 2.35 }
        if startSpeed >= 120, targetSpeed < startSpeed { return 1.45 }
        return transitionDuration
    }

    static func targetSpeed(for stage: BuildWorkStage) -> Double {
        BMCentralTaskSpeedProfile.speed(for: stage)
    }

    static func angle(
        at date: Date,
        anchorAngle: Double,
        transitionStart: Date,
        startSpeed: Double,
        targetSpeed: Double,
        duration: TimeInterval? = nil
    ) -> Double {
        let duration = duration ?? transitionDuration(from: startSpeed, to: targetSpeed)
        let dt = max(0, date.timeIntervalSince(transitionStart))
        guard duration > 0 else { return anchorAngle }
        if dt < duration {
            let u = dt / duration
            let delta = targetSpeed - startSpeed
            let integratedSmoothstep = u * u * u - 0.5 * u * u * u * u
            return anchorAngle + startSpeed * dt + delta * duration * integratedSmoothstep
        }
        let transitionAngle = anchorAngle + (startSpeed + targetSpeed) * 0.5 * duration
        return transitionAngle + targetSpeed * (dt - duration)
    }

    static func velocity(
        at date: Date,
        transitionStart: Date,
        startSpeed: Double,
        targetSpeed: Double,
        duration: TimeInterval? = nil
    ) -> Double {
        let duration = duration ?? transitionDuration(from: startSpeed, to: targetSpeed)
        let dt = max(0, date.timeIntervalSince(transitionStart))
        guard duration > 0, dt < duration else { return targetSpeed }
        let u = max(0, min(1, dt / duration))
        let smooth = u * u * (3 - 2 * u)
        return startSpeed + (targetSpeed - startSpeed) * smooth
    }
}
