import Foundation

enum BMReleaseDestination: String, Codable, CaseIterable, Identifiable {
    case testFlight = "TestFlight"
    case appStore = "App Store"

    var id: String { rawValue }
}

struct BMReleaseMetadataProfile: Codable, Hashable {
    var appName: String
    var bundleID: String
    var sku: String
    var primaryLocale: String
    var supportURL: String
    var privacyURL: String
    var marketingURL: String
    var copyright: String
    var reviewContactNote: String

    static func runtimeDefault() -> BMReleaseMetadataProfile {
        let info = Bundle.main.infoDictionary ?? [:]
        let name = (info["CFBundleDisplayName"] as? String) ?? (info["CFBundleName"] as? String) ?? "BuildMate"
        let bundle = Bundle.main.bundleIdentifier ?? ""
        return .init(
            appName: name,
            bundleID: bundle,
            sku: bundle.isEmpty ? "" : bundle.replacingOccurrences(of: ".", with: "-").uppercased(),
            primaryLocale: "zh-Hans",
            supportURL: "",
            privacyURL: "",
            marketingURL: "",
            copyright: "",
            reviewContactNote: "",
        )
    }
}

struct BMReleaseCredentialReference: Codable, Hashable {
    var referenceName: String
    var provider: String
    var keyIDHint: String
    var issuerIDHint: String
    var configuredExternally: Bool

    static let empty = BMReleaseCredentialReference(
        referenceName: "",
        provider: "App Store Connect API Key",
        keyIDHint: "",
        issuerIDHint: "",
        configuredExternally: false
    )
}

enum BMReleasePlanStatus: String, Codable {
    case draft = "草稿"
    case ready = "待主人确认"
    case approved = "已批准"
}

struct BMReleasePlan: Codable, Hashable, Identifiable {
    let id: UUID
    let createdAt: Date
    var destination: BMReleaseDestination
    var version: String
    var build: String
    var bundleID: String
    var artifactName: String
    var artifactBytes: Int
    var sourceSHA256: String
    var credentialReferenceName: String
    var status: BMReleasePlanStatus
    var ownerApprovalAt: Date?

    var hasArtifactEvidence: Bool { !artifactName.isEmpty && artifactBytes > 0 }
    var hasIdentity: Bool { !version.isEmpty && !build.isEmpty && !bundleID.isEmpty }
}

struct BMReleaseWorkspaceValidation: Identifiable, Hashable {
    let id: String
    let title: String
    let detail: String
    let passed: Bool
}

enum BMReleaseWorkspaceStore {
    private static let metadataKey = "buildmate-release-metadata-v1"
    private static let credentialKey = "buildmate-release-credential-reference-v1"
    private static let plansKey = "buildmate-release-plans-v1"

    static func metadata() -> BMReleaseMetadataProfile {
        guard let data = UserDefaults.standard.data(forKey: metadataKey),
              let value = try? JSONDecoder().decode(BMReleaseMetadataProfile.self, from: data) else {
            return .runtimeDefault()
        }
        return value
    }

    static func saveMetadata(_ value: BMReleaseMetadataProfile) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: metadataKey)
    }

    static func credentialReference() -> BMReleaseCredentialReference {
        guard let data = UserDefaults.standard.data(forKey: credentialKey),
              let value = try? JSONDecoder().decode(BMReleaseCredentialReference.self, from: data) else {
            return .empty
        }
        return value
    }

    static func saveCredentialReference(_ value: BMReleaseCredentialReference) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: credentialKey)
    }

    static func plans() -> [BMReleasePlan] {
        guard let data = UserDefaults.standard.data(forKey: plansKey),
              let value = try? JSONDecoder().decode([BMReleasePlan].self, from: data) else { return [] }
        return value.sorted { $0.createdAt > $1.createdAt }
    }

    static func savePlan(_ plan: BMReleasePlan) {
        var values = plans().filter { $0.id != plan.id }
        values.insert(plan, at: 0)
        if values.count > 20 { values = Array(values.prefix(20)) }
        guard let data = try? JSONEncoder().encode(values) else { return }
        UserDefaults.standard.set(data, forKey: plansKey)
    }

    static func approvePlan(_ plan: BMReleasePlan) -> BMReleasePlan {
        var updated = plan
        updated.status = .approved
        updated.ownerApprovalAt = Date()
        savePlan(updated)
        return updated
    }

    static func makePlan(destination: BMReleaseDestination) -> BMReleasePlan {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? ""
        let metadata = metadata()
        let ipa = BuildGuardStore.latestIPA()
        let baseline = BuildGuardStore.baseline()
        let credential = credentialReference()
        let plan = BMReleasePlan(
            id: UUID(),
            createdAt: Date(),
            destination: destination,
            version: version,
            build: build,
            bundleID: metadata.bundleID,
            artifactName: ipa?.name ?? "",
            artifactBytes: ipa?.byteCount ?? 0,
            sourceSHA256: baseline?.sha256 ?? "",
            credentialReferenceName: credential.referenceName,
            status: .ready,
            ownerApprovalAt: nil
        )
        savePlan(plan)
        return plan
    }

    static func validations(metadata: BMReleaseMetadataProfile? = nil, credential: BMReleaseCredentialReference? = nil) -> [BMReleaseWorkspaceValidation] {
        let profile = metadata ?? self.metadata()
        let credential = credential ?? self.credentialReference()
        let runtimeBundle = Bundle.main.bundleIdentifier ?? ""
        let ipa = BuildGuardStore.latestIPA()
        let baseline = BuildGuardStore.baseline()
        let urlCheck: (String) -> Bool = { text in
            guard let url = URL(string: text), let scheme = url.scheme?.lowercased() else { return false }
            return scheme == "https" && url.host != nil
        }
        return [
            .init(id: "bundle", title: "Bundle ID 一致", detail: profile.bundleID.isEmpty ? "尚未填写 Bundle ID" : "资料：\(profile.bundleID) · 运行：\(runtimeBundle)", passed: !profile.bundleID.isEmpty && profile.bundleID == runtimeBundle),
            .init(id: "app-name", title: "App 名称", detail: profile.appName.isEmpty ? "尚未填写 App 名称" : profile.appName, passed: !profile.appName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty),
            .init(id: "sku", title: "SKU", detail: profile.sku.isEmpty ? "尚未填写 SKU" : profile.sku, passed: !profile.sku.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty),
            .init(id: "support-url", title: "Support URL", detail: profile.supportURL.isEmpty ? "尚未填写 HTTPS Support URL" : profile.supportURL, passed: urlCheck(profile.supportURL)),
            .init(id: "privacy-url", title: "隐私政策 URL", detail: profile.privacyURL.isEmpty ? "尚未填写 HTTPS 隐私政策 URL" : profile.privacyURL, passed: urlCheck(profile.privacyURL)),
            .init(id: "ipa", title: "真实 IPA 证据", detail: ipa == nil ? "暂无最近 IPA 验证记录" : "\(ipa!.name) · \(ipa!.byteCount) bytes", passed: ipa?.passed == true),
            .init(id: "baseline", title: "稳定源码锚点", detail: baseline == nil ? "暂无稳定基线" : "\(baseline!.sourceName) · \(baseline!.sha256.prefix(12))…", passed: baseline != nil),
            .init(id: "credential-ref", title: "发布凭据引用", detail: credential.configuredExternally ? "已声明外部安全凭据：\(credential.referenceName)" : "未配置；BuildMate 不保存私钥明文", passed: credential.configuredExternally && !credential.referenceName.isEmpty)
        ]
    }

    static func handoffReport(plan: BMReleasePlan, metadata: BMReleaseMetadataProfile? = nil) -> String {
        let profile = metadata ?? self.metadata()
        let checks = validations(metadata: profile)
        let passed = checks.filter(\.passed).count
        return [
            "BuildMate 发布交接单",
            "目标：\(plan.destination.rawValue)",
            "版本：V\(plan.version) · Build \(plan.build)",
            "App：\(profile.appName)",
            "Bundle ID：\(plan.bundleID)",
            "SKU：\(profile.sku)",
            "IPA：\(plan.artifactName.isEmpty ? "无" : plan.artifactName)",
            "Source SHA：\(plan.sourceSHA256.isEmpty ? "无" : plan.sourceSHA256)",
            "凭据引用：\(plan.credentialReferenceName.isEmpty ? "未配置" : plan.credentialReferenceName)",
            "主人审批：\(plan.status.rawValue)",
            "本机质量门：\(passed)/\(checks.count)",
            "",
            "安全边界：此交接单不包含 Token、API 私钥、密码或 Cookie。真实上传/提交审核必须经过外部凭据授权与主人确认。"
        ].joined(separator: "\n")
    }
}
