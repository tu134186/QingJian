import Foundation

enum BMKnowledgeConfidence: String, Codable, CaseIterable {
    case verified = "已验证"
    case official = "官方支持"
    case reference = "参考案例"
    case failed = "失败方案"
}

struct BMKnowledgeEvidence: Codable, Hashable, Identifiable {
    let id: String
    let sourceType: String
    let title: String
    let reference: String
    let capturedAt: Date
}

struct BMEngineeringCase: Codable, Hashable, Identifiable {
    let id: String
    var platform: BMPlatform
    var toolchain: String
    var errorFingerprint: String
    var symptoms: [String]
    var rootCause: String
    var solution: String
    var failedApproaches: [String]
    var prevention: [String]
    var sourceSHA256: String?
    var fixedVersion: String?
    var verification: String
    var confidence: BMKnowledgeConfidence
    var occurrences: Int
    var lastSeenAt: Date
    var evidence: [BMKnowledgeEvidence]
}

enum BMKnowledgeBase {
    private static let key = "buildmate-engineering-kb-v1"

    static func all() -> [BMEngineeringCase] {
        guard let data = UserDefaults.standard.data(forKey: key), let value = try? JSONDecoder().decode([BMEngineeringCase].self, from: data) else { return [] }
        return value
    }

    static func upsert(_ item: BMEngineeringCase) {
        var items = all()
        if let index = items.firstIndex(where: { $0.id == item.id || $0.errorFingerprint == item.errorFingerprint }) { items[index] = item }
        else { items.append(item) }
        if let data = try? JSONEncoder().encode(items) { UserDefaults.standard.set(data, forKey: key) }
    }

    static func search(fingerprint: String, platform: BMPlatform? = nil) -> [BMEngineeringCase] {
        let needle = fingerprint.lowercased()
        return all().filter { item in
            (platform == nil || item.platform == platform) && (item.errorFingerprint.lowercased().contains(needle) || needle.contains(item.errorFingerprint.lowercased()) || item.symptoms.contains(where: { $0.lowercased().contains(needle) }))
        }.sorted { lhs, rhs in
            rank(lhs.confidence) == rank(rhs.confidence) ? lhs.lastSeenAt > rhs.lastSeenAt : rank(lhs.confidence) > rank(rhs.confidence)
        }
    }

    private static func rank(_ confidence: BMKnowledgeConfidence) -> Int {
        switch confidence { case .verified: return 4; case .official: return 3; case .reference: return 2; case .failed: return 1 }
    }
}
