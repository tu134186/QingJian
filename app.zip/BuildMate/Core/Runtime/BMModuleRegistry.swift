import Foundation

enum BMModuleCategory: String, Codable, CaseIterable {
    case core
    case intelligence
    case platform
    case integration
    case observability
    case ui
}

struct BMModuleDescriptor: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let category: BMModuleCategory
    let required: Bool
    let enabled: Bool
    let removable: Bool
    let dependsOn: [String]
    let note: String
}

enum BMModuleRegistry {
    static var modules: [BMModuleDescriptor] {
        [
            .init(id: "core.task", name: "任务系统", category: .core, required: true, enabled: true, removable: false, dependsOn: [], note: "统一 Task ID 与状态机"),
            .init(id: "core.blackbox", name: "任务黑匣子", category: .observability, required: true, enabled: true, removable: false, dependsOn: ["core.task"], note: "证据、诊断与恢复流水"),
            .init(id: "core.design", name: "Design System", category: .ui, required: true, enabled: true, removable: false, dependsOn: [], note: "全局 UI 校服与主题引擎"),
            .init(id: "core.knowledge", name: "工程知识库", category: .intelligence, required: false, enabled: BMFeatureFlags.isEnabled(.knowledgeBase), removable: true, dependsOn: ["core.blackbox"], note: "错题、成功经验、失败方案与验证证据"),
            .init(id: "core.agent", name: "智能体系统", category: .intelligence, required: false, enabled: BMFeatureFlags.isEnabled(.agentSystem), removable: true, dependsOn: ["core.task"], note: "岗位、权限、审批与预算"),
            .init(id: "core.collaboration", name: "协同总线", category: .integration, required: false, enabled: BMFeatureFlags.isEnabled(.collaborationBus), removable: true, dependsOn: ["core.task"], note: "跨 Agent、设备与平台任务协作"),
            .init(id: "core.artifactReturn", name: "产物回传层", category: .integration, required: true, enabled: true, removable: false, dependsOn: ["core.task", "core.blackbox"], note: "统一 IPA/APK/AAB/HarmonyOS 产物回传与 Relay 接口"),
            .init(id: "core.workspace", name: "BuildMate 工作空间", category: .core, required: true, enabled: true, removable: false, dependsOn: ["core.task"], note: "独立于 GitHub/Codemagic 的项目身份与上下文"),
            .init(id: "source.github", name: "GitHub 源码适配器", category: .integration, required: false, enabled: true, removable: true, dependsOn: ["core.workspace"], note: "当前正式 Source Adapter；不代表 BuildMate 平台身份"),
            .init(id: "source.gitlab", name: "GitLab 源码适配器", category: .integration, required: false, enabled: false, removable: true, dependsOn: ["core.workspace"], note: "未来可替换 Source Adapter"),
            .init(id: "compiler.codemagic", name: "Codemagic 编译适配器", category: .integration, required: false, enabled: true, removable: true, dependsOn: ["core.task", "core.artifactReturn"], note: "可替换 Build Provider"),
            .init(id: "compiler.bitrise", name: "Bitrise 编译适配器", category: .integration, required: false, enabled: true, removable: true, dependsOn: ["core.task", "core.artifactReturn"], note: "可替换 Build Provider"),
            .init(id: "compiler.githubActions", name: "GitHub Actions 编译适配器", category: .integration, required: false, enabled: true, removable: true, dependsOn: ["core.task", "core.artifactReturn"], note: "GitHub 的 CI 能力，与源码平台角色分离"),
            .init(id: "platform.ios", name: "iOS 平台", category: .platform, required: true, enabled: true, removable: false, dependsOn: ["core.task"], note: "当前稳定主平台"),
            .init(id: "platform.android", name: "Android 接口", category: .platform, required: false, enabled: BMFeatureFlags.isEnabled(.androidPlatform), removable: true, dependsOn: [], note: "仅预留 Adapter，不引入 Gradle/SDK"),
            .init(id: "platform.harmonyos", name: "HarmonyOS 接口", category: .platform, required: false, enabled: BMFeatureFlags.isEnabled(.harmonyOSPlatform), removable: true, dependsOn: [], note: "仅预留 Adapter，不引入 DevEco/Hvigor"),
            .init(id: "distribution.apple", name: "Apple 发布接口", category: .integration, required: false, enabled: BMFeatureFlags.isEnabled(.appStoreDistribution), removable: true, dependsOn: ["platform.ios", "core.agent"], note: "App Store Connect / TestFlight 发布 Adapter 骨架；默认关闭，不保存账号秘密"),
            .init(id: "distribution.googlePlay", name: "Google Play 发布接口", category: .integration, required: false, enabled: BMFeatureFlags.isEnabled(.googlePlayDistribution), removable: true, dependsOn: ["platform.android", "core.agent"], note: "Google Play Console 发布 Adapter 骨架；默认关闭"),
            .init(id: "distribution.huawei", name: "华为 AppGallery 发布接口", category: .integration, required: false, enabled: BMFeatureFlags.isEnabled(.huaweiAppGalleryDistribution), removable: true, dependsOn: ["core.agent"], note: "AppGallery Connect / HarmonyOS 发布 Adapter 骨架；默认关闭"),
            .init(id: "integration.privateMac", name: "私人 Mac 节点", category: .integration, required: false, enabled: BMFeatureFlags.isEnabled(.privateMacNode), removable: true, dependsOn: ["core.collaboration"], note: "未来本地 Xcode 执行节点"),
            .init(id: "integration.research", name: "外部研究", category: .integration, required: false, enabled: BMFeatureFlags.isEnabled(.externalResearch), removable: true, dependsOn: ["core.agent"], note: "官方文档、GitHub Issue 与公开案例检索")
        ]
    }
}
