import Foundation

enum BMFeature: String, CaseIterable, Codable {
    case agentSystem
    case knowledgeBase
    case collaborationBus
    case androidPlatform
    case harmonyOSPlatform
    case privateMacNode
    case externalResearch
    case appStoreDistribution
    case googlePlayDistribution
    case huaweiAppGalleryDistribution
}

enum BMFeatureFlags {
    private static let prefix = "buildmate-feature-"

    static func isEnabled(_ feature: BMFeature) -> Bool {
        switch feature {
        case .agentSystem, .knowledgeBase, .collaborationBus:
            return false
        case .androidPlatform, .harmonyOSPlatform, .privateMacNode, .externalResearch, .appStoreDistribution, .googlePlayDistribution, .huaweiAppGalleryDistribution:
            return UserDefaults.standard.bool(forKey: prefix + feature.rawValue)
        }
    }

    static func set(_ feature: BMFeature, enabled: Bool) {
        UserDefaults.standard.set(enabled, forKey: prefix + feature.rawValue)
    }
}
