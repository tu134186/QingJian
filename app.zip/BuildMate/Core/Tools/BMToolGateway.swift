import Foundation

enum BMToolKind: String, Codable, CaseIterable {
    case sourceControl
    case cloudBuild
    case localBuild
    case aiProvider
    case research
    case artifactStore
    case distribution
    case secretVault
}

struct BMToolDescriptor: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let kind: BMToolKind
    let capabilities: [String]
    let available: Bool
}

struct BMToolRequest: Codable, Hashable {
    let taskID: String
    let agentID: String
    let capability: String
    let resourceID: String?
    let payloadSummary: String
}

struct BMToolResult: Codable, Hashable {
    let succeeded: Bool
    let message: String
    let externalRunID: String?
    let artifactID: String?
    let diagnosticID: String?
}

protocol BMToolAdapter {
    var descriptor: BMToolDescriptor { get }
    func canPerform(capability: String) -> Bool
}

enum BMSecretBoundary {
    static let rule = "Agent 只能请求授权动作；不得读取 GitHub Token、AI API Key、App Store Connect 私钥、Google Service Account、华为服务账号密钥、密码、Cookie 等秘密明文。"
}

struct BMSecretReference: Codable, Hashable, Identifiable {
    let id: String
    let providerID: String
    let accountLabel: String
    let capabilityScope: [String]
    let createdAt: Date

    // 这里只保存秘密的引用与权限范围，不保存秘密明文本身。
}

