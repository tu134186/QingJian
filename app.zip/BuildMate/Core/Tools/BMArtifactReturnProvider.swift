import Foundation

enum BMArtifactReturnChannel: String, Codable, CaseIterable {
    case providerAPI
    case providerPostPublish
    case externalRelay
    case store
    case manual
}

enum BMArtifactReturnState: String, Codable {
    case pending
    case available
    case downloaded
    case unavailable
    case expired
}

struct BMArtifactReturnReceipt: Codable, Hashable, Identifiable {
    let id: String
    let taskID: String
    let runID: String?
    let provider: String
    let platform: BMPlatform
    let channel: BMArtifactReturnChannel
    let artifactName: String
    let artifactType: String
    let sourceSHA256: String?
    let artifactURL: String?
    let checksum: String?
    let state: BMArtifactReturnState
    let createdAt: Date
    let expiresAt: Date?

    init(id: String = UUID().uuidString,
         taskID: String,
         runID: String? = nil,
         provider: String,
         platform: BMPlatform,
         channel: BMArtifactReturnChannel,
         artifactName: String,
         artifactType: String,
         sourceSHA256: String? = nil,
         artifactURL: String? = nil,
         checksum: String? = nil,
         state: BMArtifactReturnState,
         createdAt: Date = Date(),
         expiresAt: Date? = nil) {
        self.id = id
        self.taskID = taskID
        self.runID = runID
        self.provider = provider
        self.platform = platform
        self.channel = channel
        self.artifactName = artifactName
        self.artifactType = artifactType
        self.sourceSHA256 = sourceSHA256
        self.artifactURL = artifactURL
        self.checksum = checksum
        self.state = state
        self.createdAt = createdAt
        self.expiresAt = expiresAt
    }
}

protocol BMArtifactReturnProvider {
    var id: String { get }
    var name: String { get }
    var channel: BMArtifactReturnChannel { get }
    var requiresSecret: Bool { get }
    func supports(platform: BMPlatform, artifactType: String) -> Bool
}

struct BMCodemagicArtifactReturnProvider: BMArtifactReturnProvider {
    let id = "artifact.codemagic"
    let name = "Codemagic Artifact API"
    let channel: BMArtifactReturnChannel = .providerAPI
    let requiresSecret = true

    func supports(platform: BMPlatform, artifactType: String) -> Bool {
        platform == .iOS && artifactType.lowercased() == "ipa"
    }
}

struct BMExternalRelayArtifactReturnProvider: BMArtifactReturnProvider {
    let id = "artifact.externalRelay"
    let name = "外部产物 Relay"
    let channel: BMArtifactReturnChannel = .externalRelay
    let requiresSecret = true

    func supports(platform: BMPlatform, artifactType: String) -> Bool {
        switch platform {
        case .iOS: return artifactType.lowercased() == "ipa"
        case .android: return ["apk", "aab"].contains(artifactType.lowercased())
        case .harmonyOS: return true
        case .unknown: return false
        }
    }
}

enum BMArtifactReturnRegistry {
    static let providers: [any BMArtifactReturnProvider] = [
        BMCodemagicArtifactReturnProvider(),
        BMExternalRelayArtifactReturnProvider()
    ]
}
