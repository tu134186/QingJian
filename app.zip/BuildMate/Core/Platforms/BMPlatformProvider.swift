import Foundation

enum BMPlatform: String, Codable, CaseIterable, Identifiable {
    case iOS
    case android
    case harmonyOS
    case unknown
    var id: String { rawValue }
}

struct BMPlatformCapability: Codable, Hashable {
    var projectDetection = false
    var preflight = false
    var dependencyCheck = false
    var build = false
    var test = false
    var sign = false
    var artifactInspection = false
    var release = false
}

struct BMPlatformDescriptor: Codable, Hashable, Identifiable {
    let platform: BMPlatform
    let displayName: String
    let providerID: String
    let enabled: Bool
    let available: Bool
    let capabilities: BMPlatformCapability
    var id: String { providerID }
}

protocol BMPlatformProvider {
    var descriptor: BMPlatformDescriptor { get }
    func canHandle(sourceName: String, fileNames: [String]) -> Bool
}

struct BMIOSPlatformProvider: BMPlatformProvider {
    let descriptor = BMPlatformDescriptor(
        platform: .iOS,
        displayName: "iOS",
        providerID: "platform.ios",
        enabled: true,
        available: true,
        capabilities: .init(projectDetection: true, preflight: true, dependencyCheck: true, build: true, test: true, sign: true, artifactInspection: true, release: true)
    )
    func canHandle(sourceName: String, fileNames: [String]) -> Bool {
        fileNames.contains { $0.hasSuffix(".xcodeproj") || $0.hasSuffix(".xcworkspace") || $0 == "project.yml" || $0.hasSuffix(".swift") }
    }
}

struct BMAndroidPlatformProvider: BMPlatformProvider {
    var descriptor: BMPlatformDescriptor {
        .init(platform: .android, displayName: "Android", providerID: "platform.android", enabled: BMFeatureFlags.isEnabled(.androidPlatform), available: false, capabilities: .init(projectDetection: true))
    }
    func canHandle(sourceName: String, fileNames: [String]) -> Bool {
        fileNames.contains { ["build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "AndroidManifest.xml"].contains($0) }
    }
}

struct BMHarmonyOSPlatformProvider: BMPlatformProvider {
    var descriptor: BMPlatformDescriptor {
        .init(platform: .harmonyOS, displayName: "HarmonyOS", providerID: "platform.harmonyos", enabled: BMFeatureFlags.isEnabled(.harmonyOSPlatform), available: false, capabilities: .init(projectDetection: true))
    }
    func canHandle(sourceName: String, fileNames: [String]) -> Bool {
        fileNames.contains { $0 == "build-profile.json5" || $0 == "hvigorfile.ts" || $0.hasSuffix(".ets") }
    }
}

enum BMPlatformRegistry {
    static var providers: [any BMPlatformProvider] {
        [BMIOSPlatformProvider(), BMAndroidPlatformProvider(), BMHarmonyOSPlatformProvider()]
    }

    static func descriptor(for platform: BMPlatform) -> BMPlatformDescriptor? {
        providers.map(\.descriptor).first { $0.platform == platform }
    }
}
