import Foundation

enum BMStoreChannel: String, Codable, CaseIterable, Identifiable {
    case appStore
    case googlePlay
    case huaweiAppGallery

    var id: String { rawValue }
}

enum BMStoreReleaseTrack: String, Codable, CaseIterable {
    case internalTesting
    case beta
    case production
}

struct BMDistributionCapability: Codable, Hashable {
    var accountValidation = false
    var uploadBuild = false
    var uploadMetadata = false
    var uploadScreenshots = false
    var manageTestRelease = false
    var submitReview = false
    var publishProduction = false
    var readReviewStatus = false
}

struct BMDistributionDescriptor: Codable, Hashable, Identifiable {
    let channel: BMStoreChannel
    let displayName: String
    let providerID: String
    let supportedPlatforms: [BMPlatform]
    let enabled: Bool
    let available: Bool
    let capabilities: BMDistributionCapability
    let secretPolicy: String

    var id: String { providerID }
}

struct BMStoreReleaseContext: Codable, Hashable {
    let taskID: String
    let parentTaskID: String?
    let correlationID: String?
    let platform: BMPlatform
    let sourceSHA256: String?
    let artifactID: String?
    let version: String
    let build: String
    let track: BMStoreReleaseTrack
}

enum BMStoreReleaseAction: String, Codable, CaseIterable {
    case validateAccount
    case uploadBuild
    case uploadMetadata
    case uploadScreenshots
    case prepareSubmission
    case submitReview
    case publishProduction
    case readReviewStatus
}

struct BMStoreReleaseRequest: Codable, Hashable {
    let context: BMStoreReleaseContext
    let action: BMStoreReleaseAction
    let credentialReferenceID: String?
    let metadataSummary: String?
}

struct BMStoreReleaseResult: Codable, Hashable {
    let succeeded: Bool
    let providerID: String
    let externalReleaseID: String?
    let externalBuildID: String?
    let reviewStatus: String?
    let message: String
}

protocol BMDistributionProvider {
    var descriptor: BMDistributionDescriptor { get }
    func canHandle(platform: BMPlatform, artifactName: String?) -> Bool
}

struct BMAppleDistributionProvider: BMDistributionProvider {
    var descriptor: BMDistributionDescriptor {
        .init(
            channel: .appStore,
            displayName: "App Store Connect / TestFlight",
            providerID: "distribution.apple",
            supportedPlatforms: [.iOS],
            enabled: BMFeatureFlags.isEnabled(.appStoreDistribution),
            available: false,
            capabilities: .init(
                accountValidation: true,
                uploadBuild: true,
                uploadMetadata: true,
                uploadScreenshots: true,
                manageTestRelease: true,
                submitReview: true,
                publishProduction: true,
                readReviewStatus: true
            ),
            secretPolicy: "仅接收凭证引用；禁止 Agent 读取 App Store Connect 私钥明文。"
        )
    }

    func canHandle(platform: BMPlatform, artifactName: String?) -> Bool {
        platform == .iOS && (artifactName == nil || artifactName?.lowercased().hasSuffix(".ipa") == true)
    }
}

struct BMGooglePlayDistributionProvider: BMDistributionProvider {
    var descriptor: BMDistributionDescriptor {
        .init(
            channel: .googlePlay,
            displayName: "Google Play Console",
            providerID: "distribution.googlePlay",
            supportedPlatforms: [.android],
            enabled: BMFeatureFlags.isEnabled(.googlePlayDistribution),
            available: false,
            capabilities: .init(
                accountValidation: true,
                uploadBuild: true,
                uploadMetadata: true,
                uploadScreenshots: true,
                manageTestRelease: true,
                submitReview: true,
                publishProduction: true,
                readReviewStatus: true
            ),
            secretPolicy: "仅接收服务账号凭证引用；禁止 Agent 读取 Service Account 密钥明文。"
        )
    }

    func canHandle(platform: BMPlatform, artifactName: String?) -> Bool {
        guard platform == .android else { return false }
        guard let name = artifactName?.lowercased() else { return true }
        return name.hasSuffix(".aab") || name.hasSuffix(".apk")
    }
}

struct BMHuaweiDistributionProvider: BMDistributionProvider {
    var descriptor: BMDistributionDescriptor {
        .init(
            channel: .huaweiAppGallery,
            displayName: "Huawei AppGallery Connect",
            providerID: "distribution.huawei",
            supportedPlatforms: [.harmonyOS, .android],
            enabled: BMFeatureFlags.isEnabled(.huaweiAppGalleryDistribution),
            available: false,
            capabilities: .init(
                accountValidation: true,
                uploadBuild: true,
                uploadMetadata: true,
                uploadScreenshots: true,
                manageTestRelease: true,
                submitReview: true,
                publishProduction: true,
                readReviewStatus: true
            ),
            secretPolicy: "仅接收华为服务账号凭证引用；禁止 Agent 读取密钥明文。"
        )
    }

    func canHandle(platform: BMPlatform, artifactName: String?) -> Bool {
        platform == .harmonyOS || platform == .android
    }
}

enum BMDistributionRegistry {
    static var providers: [any BMDistributionProvider] {
        [BMAppleDistributionProvider(), BMGooglePlayDistributionProvider(), BMHuaweiDistributionProvider()]
    }

    static func providers(for platform: BMPlatform) -> [BMDistributionDescriptor] {
        providers.map(\.descriptor).filter { $0.supportedPlatforms.contains(platform) }
    }
}

enum BMReleaseSafetyPolicy {
    static func decision(for action: BMStoreReleaseAction) -> BMPermissionDecision {
        switch action {
        case .validateAccount, .uploadBuild, .uploadMetadata, .uploadScreenshots, .prepareSubmission, .readReviewStatus:
            return .allow
        case .submitReview, .publishProduction:
            return .askOwner
        }
    }

    static let destructiveAccountChanges: BMPermissionDecision = .deny
}
