import Foundation

enum BMAgentRole: String, Codable, CaseIterable, Identifiable {
    case orchestrator
    case research
    case product
    case ui
    case coding
    case diagnostic
    case repair
    case build
    case testing
    case release
    var id: String { rawValue }
}

enum BMPermissionDecision: String, Codable, CaseIterable {
    case allow
    case askOwner
    case deny
}

enum BMAgentPermission: String, Codable, CaseIterable, Hashable {
    case readSource
    case modifySource
    case createBranch
    case readKnowledge
    case writeKnowledge
    case researchWeb
    case callAIProvider
    case startBuild
    case runTests
    case createArtifact
    case prepareStoreRelease
    case uploadStoreBuild
    case updateStoreMetadata
    case submitStoreReview
    case publishRelease
    case deleteSource
    case deleteRepository
    case changeSecrets
}

struct BMAgentBudget: Codable, Hashable {
    var maxRounds: Int = 5
    var maxBuilds: Int = 2
    var maxDurationMinutes: Int = 30
    var maxTokenUnits: Int = 200_000
    var hardStopOnLimit: Bool = true
}

struct BMAgentPolicy: Codable, Hashable, Identifiable {
    let role: BMAgentRole
    var permissions: [BMAgentPermission: BMPermissionDecision]
    var budget: BMAgentBudget
    var id: String { role.rawValue }

    static func safeDefault(for role: BMAgentRole) -> BMAgentPolicy {
        var map = Dictionary(uniqueKeysWithValues: BMAgentPermission.allCases.map { ($0, BMPermissionDecision.deny) })
        [.readSource, .readKnowledge].forEach { map[$0] = .allow }
        if [.orchestrator, .research, .coding, .diagnostic, .repair, .build, .testing].contains(role) { map[.callAIProvider] = .allow }
        if role == .research { map[.researchWeb] = .allow }
        if [.coding, .repair].contains(role) { map[.modifySource] = .allow; map[.createBranch] = .allow }
        if [.build, .testing, .orchestrator].contains(role) { map[.startBuild] = .allow; map[.runTests] = .allow }
        if role == .release {
            map[.createArtifact] = .allow
            map[.prepareStoreRelease] = .allow
            map[.uploadStoreBuild] = .allow
            map[.updateStoreMetadata] = .allow
            map[.submitStoreReview] = .askOwner
            map[.publishRelease] = .askOwner
        }
        map[.deleteSource] = .askOwner
        map[.deleteRepository] = .deny
        map[.changeSecrets] = .deny
        return .init(role: role, permissions: map, budget: .init())
    }
}

struct BMAgentDescriptor: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let role: BMAgentRole
    let capabilities: [String]
    let enabled: Bool
}

struct BMAgentWorkItem: Codable, Hashable, Identifiable {
    let id: String
    let parentTaskID: String
    let role: BMAgentRole
    let objective: String
    let sourceSHA256: String?
    let platform: BMPlatform
    let createdAt: Date
}

enum BMAgentRegistry {
    static let builtIns: [BMAgentDescriptor] = BMAgentRole.allCases.map {
        .init(id: "agent.\($0.rawValue)", name: $0.rawValue, role: $0, capabilities: [], enabled: BMFeatureFlags.isEnabled(.agentSystem))
    }
}
