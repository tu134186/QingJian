import Foundation

enum BMNodeKind: String, Codable, CaseIterable {
    case app
    case agent
    case mac
    case cloud
    case sourceControl
    case externalPlatform
}

struct BMNodeCapability: Codable, Hashable, Identifiable {
    let name: String
    let version: String?
    var id: String { name + (version ?? "") }
}

struct BMExecutionNode: Codable, Hashable, Identifiable {
    let id: String
    let name: String
    let kind: BMNodeKind
    let online: Bool
    let capabilities: [BMNodeCapability]
    let platform: BMPlatform?
    let lastSeenAt: Date?
}

struct BMCollaborationEnvelope: Codable, Hashable, Identifiable {
    let id: String
    let taskID: String
    let parentTaskID: String?
    let correlationID: String
    let senderNodeID: String
    let receiverNodeID: String?
    let capability: String
    let sourceSHA256: String?
    let diagnosticID: String?
    let createdAt: Date
}

@MainActor
final class BMCapabilityRegistry: ObservableObject {
    static let shared = BMCapabilityRegistry()
    @Published private(set) var nodes: [BMExecutionNode] = []
    private init() {}

    func register(_ node: BMExecutionNode) {
        nodes.removeAll { $0.id == node.id }
        nodes.append(node)
    }

    func unregister(nodeID: String) { nodes.removeAll { $0.id == nodeID } }
    func nodes(capableOf capability: String) -> [BMExecutionNode] {
        nodes.filter { $0.online && $0.capabilities.contains(where: { $0.name == capability }) }
    }
}
