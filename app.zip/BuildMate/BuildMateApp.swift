import SwiftUI

@main struct BuildMateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.locale, Locale(identifier: "zh-Hans"))
        }
    }
}
