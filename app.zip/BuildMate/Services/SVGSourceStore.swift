import Foundation

struct BMSVGSourceSaveResult {
    let url: URL
    let fileName: String
    let libraryNames: [String]
}

enum BMSVGSourceStore {
    static func normalize(_ raw: String) -> String {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.hasPrefix("```") {
            var lines = value.components(separatedBy: .newlines)
            if let first = lines.first, first.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("```") {
                lines.removeFirst()
            }
            if let last = lines.last, last.trimmingCharacters(in: .whitespacesAndNewlines) == "```" {
                lines.removeLast()
            }
            value = lines.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return value
    }

    static func validationMessage(for raw: String) -> (normalized: String, message: String) {
        let normalized = normalize(raw)
        let info = BMSVGInspector.inspect(text: normalized)
        if info.valid {
            return (normalized, info.animated ? "✅ 有效的动态 SVG，可直接保存。" : "✅ 有效的静态 SVG，可直接保存。")
        }
        return (normalized, "❌ \(info.reason ?? "SVG 代码无效")")
    }

    static func save(_ raw: String, directory: URL, currentLibraryNames: [String], maxItems: Int = 30) throws -> BMSVGSourceSaveResult {
        let text = normalize(raw)
        let info = BMSVGInspector.inspect(text: text)
        guard info.valid else {
            throw NSError(domain: "BuildMate.SVGSourceStore", code: 1, userInfo: [NSLocalizedDescriptionKey: info.reason ?? "SVG 代码无效。"]) 
        }
        guard let data = text.data(using: .utf8), data.count > 100 else {
            throw NSError(domain: "BuildMate.SVGSourceStore", code: 2, userInfo: [NSLocalizedDescriptionKey: "SVG 代码为空或不完整。"]) 
        }

        let fm = FileManager.default
        try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        let stamp = Int(Date().timeIntervalSince1970)
        var safeName = "Pasted-SVG-\(stamp).svg"
        var destination = directory.appendingPathComponent(safeName)
        var suffix = 2
        while fm.fileExists(atPath: destination.path) {
            safeName = "Pasted-SVG-\(stamp)-\(suffix).svg"
            destination = directory.appendingPathComponent(safeName)
            suffix += 1
        }

        try data.write(to: destination, options: [.atomic])
        var names = currentLibraryNames
        names.append(safeName)
        if names.count > maxItems {
            let overflowCount = names.count - maxItems
            let overflow = Array(names.prefix(overflowCount))
            names.removeFirst(overflowCount)
            for old in overflow {
                try? fm.removeItem(at: directory.appendingPathComponent(old))
            }
        }
        return BMSVGSourceSaveResult(url: destination, fileName: safeName, libraryNames: names)
    }
}
