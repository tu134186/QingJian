import Foundation

struct BMCodemagicFailureDiagnosticResult {
    var context: RepairContext?
    var compileErrorText: String?
    var evidenceProvider: String
    var attempts: Int
    var lastRemoteStatus: String

    var hasRealSourceEvidence: Bool {
        if let context, !context.files.isEmpty { return true }
        guard let compileErrorText else { return false }
        return BuildGuardStore.parseCompileErrors(compileErrorText, provider: evidenceProvider).trueErrorCount > 0
    }
}

/// Build247: Codemagic 的 build status 已进入 failed，并不代表 failed-build 的 publishing / Artifact
/// 已经全部完成或对 Builds API 可见。这里只读追踪原 buildId，不会 POST /builds，也不会新增云编译分钟。
enum BMCodemagicFailureDiagnosticRecovery {
    private static func bindingMatches(_ data: Data, buildID: String, taskID: String, sourceSHA256: String) -> Bool {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return false }
        let actualBuild = (object["buildID"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let actualTask = (object["taskID"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let actualSHA = (object["sourceSHA256"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() ?? ""
        guard !actualBuild.isEmpty, !actualTask.isEmpty, !actualSHA.isEmpty else { return false }
        return actualBuild == buildID && actualTask == taskID && actualSHA == sourceSHA256.lowercased()
    }

    static func recover(
        buildID: String,
        taskID: String,
        sourceSHA256: String,
        codemagic: CodemagicService,
        timeoutSeconds: TimeInterval = 180
    ) async -> BMCodemagicFailureDiagnosticResult {
        let deadline = Date().addingTimeInterval(max(30, timeoutSeconds))
        let directDiagnosticPath = ".buildmate/relay/\(taskID)/repair-context.json"
        var attempts = 0
        var bestErrorText: String?
        var lastStatus = "failed"

        while Date() < deadline {
            attempts += 1

            // 通道 A：持续刷新同一 buildId 的 Artifact 元数据。failed 后 JSON Artifact 可能延迟出现。
            if let state = try? await codemagic.buildState(id: buildID) {
                lastStatus = state.normalizedStatus
                if let artifact = state.artifacts.first(where: { $0.name.lowercased().contains("repair-context") }),
                   let data = try? await codemagic.downloadRawArtifact(artifact),
                   bindingMatches(data, buildID: buildID, taskID: taskID, sourceSHA256: sourceSHA256),
                   let context = try? JSONDecoder().decode(RepairContext.self, from: data),
                   context.files.isEmpty == false {
                    return .init(context: context, compileErrorText: context.compileErrors ?? bestErrorText, evidenceProvider: "CodemagicArtifact", attempts: attempts, lastRemoteStatus: lastStatus)
                }
                if bestErrorText == nil,
                   let artifact = state.artifacts.first(where: {
                       let n = $0.name.lowercased()
                       return n.contains("compile-errors") || n.contains("compile.log")
                   }),
                   let data = try? await codemagic.downloadRawArtifact(artifact),
                   let text = String(data: data, encoding: .utf8), !text.isEmpty {
                    bestErrorText = text
                }
            }

            // Build1032：失败诊断也只读取当前 Codemagic buildId 的 Artifact。
            // 旧 Git Relay/receipt/direct relay 不再参与当前运行链，避免删除 relay 参数后仍残留编译依赖。

            // 前 30 秒更密集；之后降低读取频率，避免手机弱网下制造无意义请求。
            let elapsed = max(0, timeoutSeconds - deadline.timeIntervalSinceNow)
            let sleepSeconds: UInt64 = elapsed < 30 ? 3 : 6
            try? await Task.sleep(nanoseconds: sleepSeconds * 1_000_000_000)
        }

        return .init(context: nil, compileErrorText: bestErrorText, evidenceProvider: bestErrorText == nil ? "none" : "CodemagicCompileErrors", attempts: attempts, lastRemoteStatus: lastStatus)
    }
}
