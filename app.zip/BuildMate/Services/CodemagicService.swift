import Foundation

final class CodemagicCancellationController: @unchecked Sendable {
    private let lock = NSLock()
    private var cancelled = false
    private var sessions: [URLSession] = []

    var isCancelled: Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    func check() throws {
        if isCancelled { throw CancellationError() }
    }

    func register(_ session: URLSession) {
        lock.lock()
        if cancelled {
            lock.unlock()
            session.invalidateAndCancel()
            return
        }
        sessions.append(session)
        lock.unlock()
    }

    func unregister(_ session: URLSession) {
        lock.lock()
        sessions.removeAll { $0 === session }
        lock.unlock()
    }

    func cancel() {
        lock.lock()
        guard !cancelled else { lock.unlock(); return }
        cancelled = true
        let active = sessions
        sessions.removeAll()
        lock.unlock()
        active.forEach { $0.invalidateAndCancel() }
    }
}

struct CodemagicArtifact: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let type: String
    let url: String
    let size: Int?

    var isIPA: Bool {
        type.lowercased() == "ipa" || name.lowercased().hasSuffix(".ipa")
    }
    var isDEB: Bool {
        type.lowercased() == "deb" || name.lowercased().hasSuffix(".deb")
    }
    var isDeliverable: Bool { isIPA || isDEB }
    var deliverableKind: String { isDEB ? "DEB" : "IPA" }
}

struct CodemagicArtifactDownloadResult {
    let data: Data
    let artifact: CodemagicArtifact
    let attempts: Int
}

struct CodemagicBuildState: Hashable {
    let id: String
    let status: String
    let artifacts: [CodemagicArtifact]
    let buildURL: String?

    var normalizedStatus: String {
        let value = status.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return value == "cancelled" ? "canceled" : value
    }
    var isFinished: Bool { ["finished", "failed", "canceled", "timeout", "skipped"].contains(normalizedStatus) }
    var hasIPA: Bool { artifacts.contains(where: \.isIPA) }
    var hasDEB: Bool { artifacts.contains(where: \.isDEB) }
    var hasDeliverable: Bool { artifacts.contains(where: \.isDeliverable) }
    var succeeded: Bool { normalizedStatus == "finished" }

    var readableStatus: String {
        switch normalizedStatus {
        case "finished": return hasDeliverable ? "✅ Codemagic 编译成功 · 产物已出现" : "✅ Codemagic 编译成功 · 等待产物回传"
        case "failed": return "❌ Codemagic 编译失败"
        case "canceled": return "⏹ Codemagic 已取消"
        case "timeout": return "❌ Codemagic 构建超时"
        case "skipped": return "⏭ Codemagic 构建已跳过"
        case "network_unknown": return "📡 网络恢复中 · 保留同一 Codemagic Run"
        case "queued": return "⏳ Codemagic 已进入队列…"
        case "initializing", "preparing", "fetching", "testing", "building", "publishing", "finishing": return "🔨 Codemagic · \(normalizedStatus)"
        default: return "⏳ Codemagic：\(status)"
        }
    }
}

final class CodemagicService {
    private let token: String
    private let appID: String
    private let workflowID: String
    private let branch: String
    private let baseURL = URL(string: "https://api.codemagic.io")!

    init(token: String, appID: String, workflowID: String, branch: String) {
        self.token = token.trimmingCharacters(in: .whitespacesAndNewlines)
        self.appID = appID.trimmingCharacters(in: .whitespacesAndNewlines)
        self.workflowID = workflowID.trimmingCharacters(in: .whitespacesAndNewlines)
        self.branch = branch.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func testConnection() async throws -> String {
        let url = endpoint(["apps", appID])
        let object = try await requestJSON(url: url, method: "GET", body: nil, stage: "连接测试")
        if let application = object["application"] as? [String: Any] {
            let name = (application["appName"] as? String) ?? "BuildMate"
            return "✅ 已连接 Codemagic · \(name)"
        }
        return "✅ Codemagic API 已连接"
    }

    func startBuild(taskID: String? = nil, unifiedTaskID: String? = nil, sourceSHA256: String? = nil, relayRepo: String? = nil, relayBranch: String? = nil, relayPath: String? = nil) async throws -> String {
        guard !token.isEmpty else { throw CMError.message("Codemagic API Token 为空。") }
        guard !appID.isEmpty else { throw CMError.message("Codemagic App ID 为空。") }
        guard !workflowID.isEmpty else { throw CMError.message("Codemagic Workflow ID 为空。") }
        guard !branch.isEmpty else { throw CMError.message("Codemagic Branch 为空。") }

        var body: [String: Any] = ["appId": appID, "workflowId": workflowID, "branch": branch]
        var variables: [String: String] = [:]
        if let taskID = taskID?.trimmingCharacters(in: .whitespacesAndNewlines), !taskID.isEmpty { variables["BM_TASK_ID"] = taskID }
        if let unifiedTaskID = unifiedTaskID?.trimmingCharacters(in: .whitespacesAndNewlines), !unifiedTaskID.isEmpty { variables["BM_UNIFIED_TASK_ID"] = unifiedTaskID }
        if let sourceSHA256 = sourceSHA256?.trimmingCharacters(in: .whitespacesAndNewlines), !sourceSHA256.isEmpty { variables["BM_SOURCE_SHA256"] = sourceSHA256 }
        if let relayRepo = relayRepo?.trimmingCharacters(in: .whitespacesAndNewlines), !relayRepo.isEmpty { variables["BM_RELAY_REPO"] = relayRepo }
        if let relayBranch = relayBranch?.trimmingCharacters(in: .whitespacesAndNewlines), !relayBranch.isEmpty { variables["BM_RELAY_BRANCH"] = relayBranch }
        if let relayPath = relayPath?.trimmingCharacters(in: .whitespacesAndNewlines), !relayPath.isEmpty { variables["BM_RELAY_PATH"] = relayPath }
        if !variables.isEmpty { body["environment"] = ["variables": variables] }
        do {
            let object = try await requestJSON(url: endpoint(["builds"]), method: "POST", body: body, stage: "启动 Build")
            guard let buildID = object["buildId"] as? String, !buildID.isEmpty else {
                throw CMError.message("Codemagic 没有返回 buildId。")
            }
            return buildID
        } catch {
            // Build1046：POST /builds 的“不确定结果”不只表现为 timedOut。
            // iOS 16.5 实机还出现过 cannot parse response：客户端没有拿到可解析响应，
            // 但无法据此证明 Codemagic 没有接受 POST。此时严禁自动再次 POST，避免重复扣分钟。
            // 先只读反查最近 Builds；找到同一 Task/SHA 就接管原 Run，找不到才安全停止。
            if isAmbiguousDispatchError(error), let taskID, !taskID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                if let recovered = await recoverDispatchedBuildID(taskID: taskID, sourceSHA256: sourceSHA256) {
                    return recovered
                }
                throw CMError.message("Codemagic 启动结果未确认；BuildMate 已只读反查云端，但暂未找到对应任务。为避免重复创建付费 Build，本次不会自动再次 POST /builds。请先查看云端运行记录，确认未创建后再手动重新编译。")
            }
            throw error
        }
    }

    func cancelBuild(id: String) async throws {
        let cleanID = id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanID.isEmpty else { throw CMError.message("Codemagic buildId 为空。") }
        var request = URLRequest(url: endpoint(["builds", cleanID, "cancel"]))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(token, forHTTPHeaderField: "x-auth-token")
        let (data, response) = try await perform(request, stage: "取消 Build")
        if let http = response as? HTTPURLResponse, http.statusCode == 208 { return }
        try validate(response: response, data: data)
    }

    func buildState(id: String, cancellation: CodemagicCancellationController? = nil) async throws -> CodemagicBuildState {
        let cleanID = id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanID.isEmpty else { throw CMError.message("Codemagic buildId 为空。") }

        // Build147：官方 v3 的 data.status 是 Build 的唯一权威状态源。
        let v3URL = URL(string: "https://codemagic.io/api/v3/builds/\(cleanID)")!
        let v3 = try await requestJSON(url: v3URL, method: "GET", body: nil, stage: "读取 Build v3 状态", cancellation: cancellation)
        let dataObject = (v3["data"] as? [String: Any]) ?? v3
        let authoritativeStatus = (dataObject["status"] as? String) ?? "unknown"
        var artifacts = extractArtifacts(from: dataObject)

        // Build1038：v3 的 short_lived_download_url 在实机上曾返回 /artifacts/.签名串，
        // 但该短链可能 404；旧 Builds API 同时可能仍提供稳定的 authenticated artifact URL。
        // 因此无论 v3 是否已经发现 Artifact，都补读旧 API 并合并；只让 v3 status 作为状态权威源。
        if let legacy = try? await requestJSON(url: endpoint(["builds", cleanID]), method: "GET", body: nil, stage: "补充稳定 Artifact 元数据", cancellation: cancellation) {
            let legacyBuild = (legacy["build"] as? [String: Any]) ?? legacy
            artifacts.append(contentsOf: extractArtifacts(from: legacyBuild))
        }
        artifacts = deduplicateAndSortArtifacts(artifacts)
        let buildURL = "https://codemagic.io/app/\(appID)/build/\(cleanID)"
        return CodemagicBuildState(id: cleanID, status: authoritativeStatus, artifacts: artifacts, buildURL: buildURL)
    }

    private func extractArtifacts(from value: Any) -> [CodemagicArtifact] {
        var result: [CodemagicArtifact] = []
        var seen = Set<String>()
        func walk(_ node: Any) {
            if let dict = node as? [String: Any] {
                let name = (dict["name"] as? String) ?? (dict["fileName"] as? String) ?? (dict["filename"] as? String)
                let type = (dict["type"] as? String) ?? ""
                // Build1038：不要再用 short-lived 覆盖稳定 url。把同一 Artifact 的所有官方 URL 都保留下来，
                // 后面按“稳定 authenticated URL -> 其他下载 URL -> 临时签名 URL”排序。
                let urlKeys = ["url", "downloadUrl", "downloadURL", "short_lived_download_url", "shortLivedDownloadUrl"]
                if let name {
                    for key in urlKeys {
                        guard let raw = dict[key] as? String else { continue }
                        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty, !seen.contains(trimmed) else { continue }
                        let isIPA = name.lowercased().hasSuffix(".ipa") || type.lowercased() == "ipa" || trimmed.lowercased().contains(".ipa")
                        guard isIPA || !name.isEmpty else { continue }
                        seen.insert(trimmed)
                        let size = (dict["size"] as? NSNumber)?.intValue ?? dict["size"] as? Int
                        result.append(CodemagicArtifact(name: name, type: type, url: trimmed, size: size))
                    }
                }
                for child in dict.values { walk(child) }
            } else if let array = node as? [Any] {
                for child in array { walk(child) }
            }
        }
        walk(value)
        return deduplicateAndSortArtifacts(result)
    }

    private func deduplicateAndSortArtifacts(_ input: [CodemagicArtifact]) -> [CodemagicArtifact] {
        var seen = Set<String>()
        return input
            .filter { artifact in
                let key = artifact.url.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !key.isEmpty, !seen.contains(key) else { return false }
                seen.insert(key)
                return true
            }
            .sorted { lhs, rhs in
                let left = artifactURLRank(lhs.url)
                let right = artifactURLRank(rhs.url)
                if left != right { return left < right }
                return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending
            }
    }

    /// 0 = Codemagic 官方 authenticated artifact URL（最稳定，可 POST /public-url）
    /// 1 = 其他下载 URL；2 = /artifacts/.签名短链（只作为兜底，绝不优先）。
    private func artifactURLRank(_ raw: String) -> Int {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = text.lowercased()
        if lower.contains("/artifacts/.") { return 2 }
        if lower.contains("/artifacts/") { return 0 }
        return 1
    }

    /// Build147：网络故障不是业务终态。轮询永远绑定同一个 buildId，不会再次 POST /builds。
    func waitForCompletion(id: String, timeoutSeconds: Int = 1800, artifactGraceSeconds: Int = 120, maxConsecutiveNetworkFailures: Int = 6, onUpdate: @escaping (CodemagicBuildState) -> Void) async throws -> CodemagicBuildState {
        let deadline = Date().addingTimeInterval(TimeInterval(timeoutSeconds))
        var terminalWithoutIPAAt: Date?
        var lastState: CodemagicBuildState?
        var networkFailures = 0
        while Date() < deadline {
            try Task.checkCancellation()
            do {
                let state = try await buildState(id: id)
                networkFailures = 0
                lastState = state
                onUpdate(state)
                if ["failed", "canceled", "timeout", "skipped"].contains(state.normalizedStatus) { return state }
                if state.normalizedStatus == "finished" {
                    if state.hasDeliverable { return state }
                    if terminalWithoutIPAAt == nil { terminalWithoutIPAAt = Date() }
                    if Date().timeIntervalSince(terminalWithoutIPAAt!) >= TimeInterval(artifactGraceSeconds) { return state }
                } else { terminalWithoutIPAAt = nil }
                try await Task.sleep(nanoseconds: 5_000_000_000)
            } catch is CancellationError { throw CancellationError() }
            catch {
                networkFailures += 1
                let synthetic = CodemagicBuildState(id: id, status: "network_unknown", artifacts: lastState?.artifacts ?? [], buildURL: lastState?.buildURL ?? "https://codemagic.io/app/\(appID)/build/\(id)")
                onUpdate(synthetic)
                if networkFailures >= max(1, maxConsecutiveNetworkFailures) {
                    throw CMError.message("网络连续失败 \(networkFailures) 次；已暂停主动轮询。Run ID 已保留，恢复网络后只会继续查询同一 Run，不会新建编译。最后错误：\(error.localizedDescription)")
                }
                let seconds = min(30, 1 + networkFailures * 4) // 5, 9, 13, 17 ... 30
                try await Task.sleep(nanoseconds: UInt64(seconds) * 1_000_000_000)
            }
        }
        if let lastState { return lastState }
        throw CMError.message("等待 Codemagic 超时；Run ID 已保留，可继续恢复。")
    }

    func downloadArtifact(_ artifact: CodemagicArtifact) async throws -> Data {
        let data = try await downloadRawArtifact(artifact)
        let minimumBytes = artifact.isDEB ? 2_000 : 100_000
        guard data.count > minimumBytes else {
            throw CMError.message("下载到的产物只有 \(data.count) B，不像有效 \(artifact.deliverableKind)，已阻止保存。")
        }
        return data
    }

    /// Build1033：一次用户动作只执行一轮 Artifact 获取。
    /// 同一轮内允许读取“当前 Build 状态 + v3 短时下载地址”两种官方表示，但绝不 sleep、绝不自动第 2 次。
    /// 失败后立即把控制权交回工作台“重抓产物”，不会重新触发云编译。
    func downloadArtifact(buildID: String, preferredName: String?, cancellation: CodemagicCancellationController? = nil, onAttempt: ((Int, String) -> Void)? = nil) async throws -> CodemagicArtifactDownloadResult {
        try Task.checkCancellation()
        try cancellation?.check()

        // Build1038：一次用户动作仍然只做 1 轮，不 sleep、不轮询第二轮。
        // 但这一轮会把同一 Build 当前已经返回的官方 Artifact URL 全部合并，
        // 优先走稳定 authenticated URL -> POST /public-url -> GET；临时签名短链只做同轮兜底。
        var candidates = (try await buildState(id: buildID, cancellation: cancellation)).artifacts.filter { $0.isDeliverable }
        if let preferredName, !preferredName.isEmpty {
            let exact = candidates.filter { $0.name == preferredName }
            if !exact.isEmpty { candidates = exact }
        }

        // 再读一次 v3 JSON 仅用于补齐当前这一轮的 URL 表示；不等待、不重试。
        if let v3 = try? await v3DeliverableArtifacts(buildID: buildID, cancellation: cancellation) {
            candidates.append(contentsOf: v3)
        }
        candidates = deduplicateAndSortArtifacts(candidates)

        guard !candidates.isEmpty else {
            throw CMError.message("Codemagic Build 已完成，但当前官方 API 没有返回可下载产物地址。已停止自动抓取，可稍后手动点‘重抓产物’。")
        }

        var errors: [String] = []
        for artifact in candidates {
            try cancellation?.check()
            let route = artifactURLRank(artifact.url) == 0 ? "官方稳定地址" : (artifactURLRank(artifact.url) == 2 ? "官方临时地址" : "官方下载地址")
            onAttempt?(1, "单次抓取 · \(route) · \(artifact.name)")
            do {
                let data = try await downloadRawArtifact(artifact, cancellation: cancellation)
                let minimumBytes = artifact.isDEB ? 2_000 : 100_000
                guard data.count > minimumBytes else {
                    throw CMError.message("下载到的产物只有 \(data.count) B，不像有效 \(artifact.deliverableKind)，已阻止保存。")
                }
                return CodemagicArtifactDownloadResult(data: data, artifact: artifact, attempts: 1)
            } catch {
                if cancellation?.isCancelled == true { throw CancellationError() }
                errors.append("\(route)：\(error.localizedDescription)")
            }
        }

        let name = candidates.first?.name ?? preferredName ?? "产物"
        throw CMError.message("Codemagic 已生成 \(name)，本次官方 Artifact 获取链仍未回传。已停止自动抓取，可稍后手动点‘重抓产物’。" + errors.joined(separator: "；"))
    }


    // Build138：读取 Codemagic 新 v3 Build 表示，并从未知/演进中的 JSON 结构中安全提取 IPA URL。
    private func v3DeliverableArtifacts(buildID: String, cancellation: CodemagicCancellationController? = nil) async throws -> [CodemagicArtifact] {
        let cleanID = buildID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanID.isEmpty else { return [] }
        guard let url = URL(string: "https://codemagic.io/api/v3/builds/\(cleanID)") else { return [] }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(token, forHTTPHeaderField: "x-auth-token")
        let (data, response) = try await perform(request, stage: "读取 Codemagic v3 Build", cancellation: cancellation)
        try validate(response: response, data: data)
        let root = try JSONSerialization.jsonObject(with: data)
        var found: [CodemagicArtifact] = []
        var seen = Set<String>()

        func walk(_ value: Any) {
            if let dict = value as? [String: Any] {
                let name = (dict["name"] as? String) ?? (dict["fileName"] as? String) ?? (dict["filename"] as? String) ?? ""
                let type = (dict["type"] as? String) ?? ""
                let urlKeys = ["url", "downloadUrl", "downloadURL", "short_lived_download_url", "shortLivedDownloadUrl"]
                for key in urlKeys {
                    guard let raw = dict[key] as? String, !raw.isEmpty else { continue }
                    let lowerName = name.lowercased()
                    let lowerURL = raw.lowercased()
                    let isDeliverable = lowerName.hasSuffix(".ipa") || lowerName.hasSuffix(".deb") || type.lowercased() == "ipa" || type.lowercased() == "deb" || lowerURL.contains(".ipa") || lowerURL.contains(".deb")
                    guard isDeliverable, !seen.contains(raw) else { continue }
                    seen.insert(raw)
                    let inferred = name.isEmpty ? (URL(string: raw)?.lastPathComponent.isEmpty == false ? URL(string: raw)!.lastPathComponent : "Codemagic.ipa") : name
                    found.append(CodemagicArtifact(name: inferred, type: "ipa", url: raw, size: dict["size"] as? Int))
                }
                dict.values.forEach(walk)
            } else if let array = value as? [Any] {
                array.forEach(walk)
            }
        }
        walk(root)
        return found
    }


    /// Build143：下载由 Codemagic post-publish 通过 Relay 回传的短时公共 URL。
    /// Relay JSON 只保存短时 URL/构建指纹/HTTP 状态，不保存任何 Token。
    func downloadRelayPublicURL(_ rawURL: String, expectedName: String? = nil, cancellation: CodemagicCancellationController? = nil) async throws -> Data {
        try cancellation?.check()
        guard let url = URL(string: rawURL.trimmingCharacters(in: .whitespacesAndNewlines)),
              let scheme = url.scheme?.lowercased(), ["https", "http"].contains(scheme) else {
            throw CMError.message("Relay 返回的 Artifact URL 无效。")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        let (data, response) = try await performArtifactDownload(request, stage: "下载 Relay Artifact \(expectedName ?? "IPA")", cancellation: cancellation)
        try validate(response: response, data: data)
        guard data.count > 100_000 else {
            throw CMError.message("Relay 下载到的产物只有 \(data.count) B，不像有效 IPA。")
        }
        return data
    }

    /// Build139：尽力从 Codemagic 旧 Build JSON 与 v3 JSON 中提取服务器 post-publish 的 BuildMate 证据标记。
    /// API 是否暴露发布日志由 Codemagic 决定；拿不到时返回空数组，不影响编译主链。
    func artifactReturnEvidence(buildID: String, cancellation: CodemagicCancellationController? = nil) async -> [String] {
        let cleanID = buildID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanID.isEmpty else { return [] }
        var evidence: [String] = []
        var seen = Set<String>()

        func collect(_ value: Any) {
            if let string = value as? String {
                if string.contains("BUILDMATE_ARTIFACT_") || string.contains("buildmate-artifact-return-observable-v1") || string.contains("buildmate-artifact-preflight-v1") {
                    let clipped = String(string.prefix(1200))
                    if !seen.contains(clipped) { seen.insert(clipped); evidence.append(clipped) }
                }
            } else if let dict = value as? [String: Any] {
                dict.values.forEach(collect)
            } else if let array = value as? [Any] {
                array.forEach(collect)
            }
        }

        let requests: [URLRequest] = {
            var result: [URLRequest] = []
            let oldURL = endpoint(["builds", cleanID])
            var old = URLRequest(url: oldURL)
            old.httpMethod = "GET"
            old.setValue("application/json", forHTTPHeaderField: "Accept")
            old.setValue(token, forHTTPHeaderField: "x-auth-token")
            result.append(old)
            if let v3URL = URL(string: "https://codemagic.io/api/v3/builds/\(cleanID)") {
                var v3 = URLRequest(url: v3URL)
                v3.httpMethod = "GET"
                v3.setValue("application/json", forHTTPHeaderField: "Accept")
                v3.setValue(token, forHTTPHeaderField: "x-auth-token")
                result.append(v3)
            }
            return result
        }()

        for request in requests {
            do {
                let (data, response) = try await perform(request, stage: "读取 Artifact Return 服务器证据", cancellation: cancellation)
                try validate(response: response, data: data)
                let root = try JSONSerialization.jsonObject(with: data)
                collect(root)
            } catch {
                if cancellation?.isCancelled == true { break }
            }
        }
        return evidence
    }

    /// Build1038：Codemagic 官方 Artifact 两类 URL 必须分开处理：
    /// 1) authenticated URL：/artifacts/<uuid>/<uuid>/file.ipa -> POST /public-url -> GET public URL
    /// 2) public/signed URL：/artifacts/.<token> -> 直接 GET，而且必须把整条 URL 当作不透明签名串，不能改 path。
    func downloadRawArtifact(_ artifact: CodemagicArtifact, cancellation: CodemagicCancellationController? = nil) async throws -> Data {
        try cancellation?.check()
        let raw = artifact.url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { throw CMError.message("Codemagic Artifact 没有可用下载地址。") }

        if isSignedPublicArtifactURL(raw) {
            guard let signedURL = URL(string: raw), let scheme = signedURL.scheme?.lowercased(), ["http", "https"].contains(scheme) else {
                throw CMError.message("Codemagic 临时 Artifact URL 无法解析。")
            }
            var request = URLRequest(url: signedURL)
            request.httpMethod = "GET"
            let (data, response) = try await performArtifactDownload(request, stage: "下载 Codemagic 临时 Artifact \(artifact.name)", cancellation: cancellation)
            try validate(response: response, data: data)
            return data
        }

        let protectedURL = try resolveProtectedArtifactURL(raw)
        do {
            let publicURL = try await createPublicArtifactURL(from: protectedURL, cancellation: cancellation)
            try cancellation?.check()
            var request = URLRequest(url: publicURL)
            request.httpMethod = "GET"
            let (data, response) = try await performArtifactDownload(request, stage: "下载 Codemagic 官方 Artifact \(artifact.name)", cancellation: cancellation)
            try validate(response: response, data: data)
            return data
        } catch let publicError {
            if cancellation?.isCancelled == true { throw CancellationError() }
            // 官方文档的第 1 步 URL 本身是 authenticated URL；若 public-url 临时失败，
            // 最后只做一次带 x-auth-token 的 GET 兜底，不新增轮询或云 Build。
            do {
                var request = URLRequest(url: protectedURL)
                request.httpMethod = "GET"
                request.setValue(token, forHTTPHeaderField: "x-auth-token")
                let (data, response) = try await performArtifactDownload(request, stage: "认证下载 Codemagic Artifact \(artifact.name)", cancellation: cancellation)
                try validate(response: response, data: data)
                return data
            } catch {
                if cancellation?.isCancelled == true { throw CancellationError() }
                throw CMError.message("Codemagic Artifact 下载失败。public-url：\(publicError.localizedDescription)；认证直下：\(error.localizedDescription)")
            }
        }
    }

    private func isSignedPublicArtifactURL(_ raw: String) -> Bool {
        let lower = raw.lowercased()
        return lower.contains("/artifacts/.") || lower.contains("short_lived") || lower.contains("short-lived")
            || lower.contains("signature=") || lower.contains("token=")
    }


    func artifactURLDescription(_ artifact: CodemagicArtifact) -> String {
        switch artifactURLRank(artifact.url) {
        case 0: return "authenticated-stable"
        case 2: return "signed-temporary"
        default: return "download-url"
        }
    }

    func redactedArtifactURLString(_ raw: String) -> String {
        guard let url = URL(string: raw), let host = url.host else { return "地址已脱敏" }
        let kind = isSignedPublicArtifactURL(raw) ? "signed-temporary" : "authenticated-stable"
        let file = url.lastPathComponent.isEmpty ? "artifact" : url.lastPathComponent
        return "host=\(host) · type=\(kind) · file=\(file)"
    }

    /// 供任务黑匣子记录解析后的安全地址（不含 API Token）。
    /// 签名短链保持原样，绝不正规化其 path；稳定 authenticated URL 才允许清理重复斜杠。
    func resolvedArtifactURLString(_ artifact: CodemagicArtifact) throws -> String {
        let raw = artifact.url.trimmingCharacters(in: .whitespacesAndNewlines)
        if isSignedPublicArtifactURL(raw) { return raw }
        return try resolveProtectedArtifactURL(raw).absoluteString
    }

    private func createPublicArtifactURL(from protectedURL: URL, cancellation: CodemagicCancellationController? = nil) async throws -> URL {
        let publicEndpoint = protectedURL.appendingPathComponent("public-url")
        var request = URLRequest(url: publicEndpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(token, forHTTPHeaderField: "x-auth-token")
        let expiresAt = Int(Date().addingTimeInterval(10 * 60).timeIntervalSince1970)
        request.httpBody = try JSONSerialization.data(withJSONObject: ["expiresAt": expiresAt])
        let (data, response) = try await perform(request, stage: "生成 Artifact 公共下载地址", cancellation: cancellation)

        // Build1041：实机证据显示 Codemagic 的 /public-url 在部分 IPA 上不再返回 JSON，
        // 而是直接 HTTP 302 到 itms-services://?action=download-manifest&url=<HTTPS signed artifact>。
        // 这仍然是有效的官方回传结果，不能把 302 当失败。
        if let http = response as? HTTPURLResponse, (300...399).contains(http.statusCode),
           let location = http.value(forHTTPHeaderField: "Location"),
           let nested = httpsArtifactURL(fromRedirectLocation: location) {
            return nested
        }

        try validate(response: response, data: data)
        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rawURL = object["url"] as? String else {
            throw CMError.message("Codemagic public-url 没有返回下载地址。")
        }
        let text = rawURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: text), let scheme = url.scheme?.lowercased(), ["http", "https"].contains(scheme) else {
            throw CMError.message("Codemagic public-url 返回了无效地址。")
        }
        // public-url 的返回值是签名 URL。它必须原样使用，不能再经过 path 规范化。
        return url
    }

    private func httpsArtifactURL(fromRedirectLocation raw: String) -> URL? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if let url = URL(string: text), let scheme = url.scheme?.lowercased(), ["http", "https"].contains(scheme) {
            return url
        }
        guard let wrapper = URLComponents(string: text), wrapper.scheme?.lowercased() == "itms-services",
              let nestedText = wrapper.queryItems?.first(where: { $0.name.lowercased() == "url" })?.value,
              let nested = URL(string: nestedText), let scheme = nested.scheme?.lowercased(), ["http", "https"].contains(scheme) else {
            return nil
        }
        return nested
    }

    private func endpoint(_ components: [String]) -> URL {
        components.reduce(baseURL) { partial, component in
            partial.appendingPathComponent(component.trimmingCharacters(in: CharacterSet(charactersIn: "/")))
        }
    }

    /// 只解析“稳定 authenticated artifact URL”。签名 URL 不允许进入这里，避免破坏签名 path。
    private func resolveProtectedArtifactURL(_ raw: String) throws -> URL {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw CMError.message("Codemagic Artifact 没有可用下载地址。") }
        if isSignedPublicArtifactURL(text) {
            guard let exact = URL(string: text) else { throw CMError.message("Codemagic 签名 Artifact URL 无法解析。") }
            return exact
        }
        if let absolute = URL(string: text), let scheme = absolute.scheme?.lowercased(), scheme == "https" || scheme == "http" {
            if var components = URLComponents(url: absolute, resolvingAgainstBaseURL: false) {
                components.percentEncodedPath = components.percentEncodedPath.replacingOccurrences(of: "/{2,}", with: "/", options: .regularExpression)
                if let normalized = components.url { return normalized }
            }
            return absolute
        }
        if text.hasPrefix("/") {
            guard let url = URL(string: "https://api.codemagic.io\(text)") else { throw CMError.message("Codemagic Artifact 相对地址无法解析。") }
            return url
        }
        return endpoint(text.split(separator: "/").map(String.init))
    }

    /// Build144：启动请求超时后的幂等恢复。只读查询，不会再次触发 Build。
    /// Codemagic 不同 API 版本的列表 JSON 结构可能不同，因此递归扫描 buildId/id 与环境变量。
    private func recoverDispatchedBuildID(taskID: String, sourceSHA256: String?) async -> String? {
        let cleanTask = taskID.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanSHA = sourceSHA256?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !cleanTask.isEmpty else { return nil }

        for attempt in 0..<3 {
            if attempt > 0 { try? await Task.sleep(nanoseconds: 4_000_000_000) }
            guard var parts = URLComponents(url: endpoint(["builds"]), resolvingAgainstBaseURL: false) else { continue }
            parts.queryItems = [URLQueryItem(name: "appId", value: appID)]
            guard let url = parts.url else { continue }
            do {
                var request = URLRequest(url: url)
                request.httpMethod = "GET"
                request.setValue("application/json", forHTTPHeaderField: "Accept")
                request.setValue(token, forHTTPHeaderField: "x-auth-token")
                let (data, response) = try await performWithTimeout(request, stage: "启动超时后反查 Run", timeout: 15)
                try validate(response: response, data: data)
                let root = try JSONSerialization.jsonObject(with: data)
                if let id = findRecoveredBuildID(in: root, taskID: cleanTask, sourceSHA256: cleanSHA) { return id }
            } catch {
                // 恢复查询是 best-effort；失败后继续下一次，只读不重发 Build。
            }
        }
        return nil
    }

    private func findRecoveredBuildID(in value: Any, taskID: String, sourceSHA256: String) -> String? {
        if let dict = value as? [String: Any] {
            let flattened = String(describing: dict)
            let taskMatched = flattened.contains(taskID)
            let shaMatched = sourceSHA256.isEmpty || flattened.contains(sourceSHA256)
            if taskMatched && shaMatched {
                for key in ["buildId", "_id", "id"] {
                    if let id = dict[key] as? String, !id.isEmpty { return id }
                }
            }
            for child in dict.values {
                if let id = findRecoveredBuildID(in: child, taskID: taskID, sourceSHA256: sourceSHA256) { return id }
            }
        } else if let array = value as? [Any] {
            for child in array {
                if let id = findRecoveredBuildID(in: child, taskID: taskID, sourceSHA256: sourceSHA256) { return id }
            }
        }
        return nil
    }

    private func isAmbiguousDispatchError(_ error: Error) -> Bool {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain {
            let ambiguousCodes: Set<Int> = [
                NSURLErrorTimedOut,
                NSURLErrorNetworkConnectionLost,
                NSURLErrorCannotParseResponse,
                NSURLErrorBadServerResponse,
                NSURLErrorCannotConnectToHost,
                NSURLErrorDNSLookupFailed
            ]
            if ambiguousCodes.contains(ns.code) { return true }
        }
        let text = error.localizedDescription.lowercased()
        return text.contains("timed out")
            || text.contains("超时")
            || text.contains("cannot parse response")
            || text.contains("无法解析")
            || text.contains("connection lost")
            || text.contains("network connection was lost")
    }

    private func performWithTimeout(_ request: URLRequest, stage: String, timeout: TimeInterval) async throws -> (Data, URLResponse) {
        var req = request
        req.timeoutInterval = timeout
        let config = URLSessionConfiguration.ephemeral
        config.waitsForConnectivity = true
        config.timeoutIntervalForRequest = timeout
        config.timeoutIntervalForResource = timeout + 5
        let session = URLSession(configuration: config)
        defer { session.finishTasksAndInvalidate() }
        do { return try await session.data(for: req) }
        catch { throw CMError.message("Codemagic 网络请求失败（阶段：\(stage)）：\(error.localizedDescription)") }
    }

    private func requestJSON(url: URL, method: String, body: [String: Any]?, stage: String, cancellation: CodemagicCancellationController? = nil) async throws -> [String: Any] {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(token, forHTTPHeaderField: "x-auth-token")
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await perform(request, stage: stage, cancellation: cancellation)
        try validate(response: response, data: data)
        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw CMError.message("Codemagic 返回了无法识别的数据。")
        }
        return object
    }

    // Build1040：彻底替换旧的“禁止重定向 -> 手工逐跳重建 URL”下载器。
    // 1039 实机日志已经证明：Codemagic 返回的稳定 Artifact URL 正确，
    // 真正失败发生在 iOS 16.5 的 Artifact 重定向链，旧下载器最终统一落到 -1002。
    // 新实现让一个 URLSession 在同一任务里完成重定向；delegate 只负责把 Location
    // 规范为 http/https，并在离开 api.codemagic.io 时自动去掉 x-auth-token。
    // 这条链不增加 Artifact 抓取轮次，也不会重新触发云 Build。
    private func performArtifactDownload(_ initialRequest: URLRequest, stage: String, cancellation: CodemagicCancellationController? = nil) async throws -> (Data, URLResponse) {
        try cancellation?.check()
        guard let initialURL = initialRequest.url,
              let scheme = initialURL.scheme?.lowercased(),
              ["http", "https"].contains(scheme) else {
            throw CMError.message("Codemagic Artifact 初始 URL 无效（阶段：\(stage)）。")
        }

        let delegate = CMArtifactRedirectDelegate(apiHost: baseURL.host ?? "api.codemagic.io")
        let config = URLSessionConfiguration.ephemeral
        config.waitsForConnectivity = true
        config.timeoutIntervalForRequest = 90
        config.timeoutIntervalForResource = 180
        let session = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
        cancellation?.register(session)
        defer {
            cancellation?.unregister(session)
            session.finishTasksAndInvalidate()
        }

        do {
            let (data, response) = try await session.data(for: initialRequest)
            try cancellation?.check()
            return (data, response)
        } catch {
            if cancellation?.isCancelled == true { throw CancellationError() }
            let ns = error as NSError
            if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { throw CancellationError() }
            if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorUnsupportedURL {
                let failing = (ns.userInfo[NSURLErrorFailingURLStringErrorKey] as? String)
                    ?? (ns.userInfo[NSURLErrorFailingURLErrorKey] as? URL)?.absoluteString
                    ?? initialURL.absoluteString
                let safe = redactFailingArtifactURL(failing)
                throw CMError.message("Codemagic Artifact 重定向 URL 无法由 iOS 处理（阶段：\(stage)；失败地址：\(safe)）。")
            }
            throw CMError.message("Codemagic Artifact 网络请求失败（阶段：\(stage)）：\(error.localizedDescription)")
        }
    }

    private func redactFailingArtifactURL(_ raw: String) -> String {
        guard let url = URL(string: raw) else { return "无法解析" }
        let scheme = url.scheme ?? "?"
        let host = url.host ?? "?"
        let path = url.path
        if path.contains("/artifacts/.") { return "\(scheme)://\(host)/artifacts/<signed>" }
        let tail = url.lastPathComponent.isEmpty ? "artifact" : url.lastPathComponent
        return "\(scheme)://\(host)/…/\(tail)"
    }

    private func resolveRedirectURL(_ raw: String, relativeTo base: URL?) throws -> URL {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if let absolute = URL(string: text), let scheme = absolute.scheme?.lowercased(), scheme == "https" || scheme == "http" {
            // Build1038：重定向若已经进入签名 Artifact URL，必须原样保留，不能规范化 path。
            if isSignedPublicArtifactURL(text) { return absolute }
            if var components = URLComponents(url: absolute, resolvingAgainstBaseURL: false) {
                components.percentEncodedPath = components.percentEncodedPath.replacingOccurrences(of: "/{2,}", with: "/", options: .regularExpression)
                if let normalized = components.url { return normalized }
            }
            return absolute
        }
        if let base, let relative = URL(string: text, relativeTo: base)?.absoluteURL,
           let scheme = relative.scheme?.lowercased(), scheme == "https" || scheme == "http" {
            return relative
        }
        return try resolveProtectedArtifactURL(text)
    }

    private func perform(_ request: URLRequest, stage: String, cancellation: CodemagicCancellationController? = nil) async throws -> (Data, URLResponse) {
        do {
            try cancellation?.check()
            if let cancellation {
                let config = URLSessionConfiguration.ephemeral
                config.waitsForConnectivity = true
                config.timeoutIntervalForRequest = 90
                config.timeoutIntervalForResource = 180
                let session = URLSession(configuration: config)
                cancellation.register(session)
                defer { cancellation.unregister(session); session.finishTasksAndInvalidate() }
                let result = try await session.data(for: request)
                try cancellation.check()
                return result
            }
            return try await URLSession.shared.data(for: request)
        } catch {
            if cancellation?.isCancelled == true { throw CancellationError() }
            let ns = error as NSError
            if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { throw CancellationError() }
            if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorUnsupportedURL {
                throw CMError.message("Codemagic URL 不受支持（阶段：\(stage)；路径：\(request.url?.path ?? "未知")）。")
            }
            throw CMError.message("Codemagic 网络请求失败（阶段：\(stage)）：\(error.localizedDescription)")
        }
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw CMError.message("Codemagic 网络响应无效。") }
        guard (200...299).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? ""
            let clipped = String(text.prefix(600))
            if http.statusCode == 401 || http.statusCode == 403 {
                throw CMError.message("Codemagic Token/App 权限验证失败（HTTP \(http.statusCode)）。")
            }
            throw CMError.message("Codemagic HTTP \(http.statusCode)：\(clipped.isEmpty ? "请求失败" : clipped)")
        }
    }

    private enum CMError: LocalizedError {
        case message(String)
        var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
    }
}


private final class CMArtifactRedirectDelegate: NSObject, URLSessionTaskDelegate {
    private let apiHost: String

    init(apiHost: String) {
        self.apiHost = apiHost.lowercased()
        super.init()
    }

    func urlSession(_ session: URLSession,
                    task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        var next = request

        // Foundation 通常已经给出绝对 URL；如果没有，则从 Location 相对当前响应地址重建。
        if let location = response.value(forHTTPHeaderField: "Location")?
            .trimmingCharacters(in: .whitespacesAndNewlines),
           !location.isEmpty {
            // Build1041：Codemagic 对 IPA 的公共下载地址有时会先 302 到
            // itms-services://?action=download-manifest&url=<https signed artifact>。
            // iOS URLSession 不能跟随 itms-services，因此不能把它当成真正下载地址。
            // 这里直接取出其 url 参数里的 HTTPS signed artifact，并继续同一轮 GET。
            if let wrapper = URLComponents(string: location),
               wrapper.scheme?.lowercased() == "itms-services",
               let nestedText = wrapper.queryItems?.first(where: { $0.name.lowercased() == "url" })?.value,
               let nested = URL(string: nestedText),
               let nestedScheme = nested.scheme?.lowercased(),
               ["http", "https"].contains(nestedScheme) {
                next.url = nested
            } else if let absolute = URL(string: location),
                      let scheme = absolute.scheme?.lowercased(),
                      ["http", "https"].contains(scheme) {
                next.url = absolute
            } else if let base = response.url,
                      let relative = URL(string: location, relativeTo: base)?.absoluteURL,
                      let scheme = relative.scheme?.lowercased(),
                      ["http", "https"].contains(scheme) {
                next.url = relative
            }
        }

        guard let url = next.url,
              let scheme = url.scheme?.lowercased(),
              ["http", "https"].contains(scheme) else {
            completionHandler(nil)
            return
        }

        // Token 只允许留在 Codemagic API 主机；跳到公共签名/CDN 对象存储时必须移除。
        if url.host?.lowercased() != apiHost || url.path.contains("/artifacts/.") {
            next.setValue(nil, forHTTPHeaderField: "x-auth-token")
        }
        completionHandler(next)
    }
}
