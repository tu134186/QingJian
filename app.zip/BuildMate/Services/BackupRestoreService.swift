import Foundation
import CryptoKit
import Security

struct BMBackupFileItem: Codable {
    let name: String
    let dataBase64: String
}

struct BMBackupPayload: Codable {
    let schema: Int
    let createdAt: Date
    let appVersion: String
    let build: Int
    let settings: [String: String]
    let secrets: [String: String]
    let centralEffects: [BMBackupFileItem]
}

struct BMEncryptedBackupEnvelope: Codable {
    let format: String
    let schema: Int
    let saltBase64: String
    let sealedBase64: String
}

struct BMBackupPreview {
    let sourceVersion: String
    let sourceBuild: Int
    let settingCount: Int
    let secretCount: Int
    let centralEffectCount: Int
    let ignoredLegacyCount: Int
    let workflowWillMigrate: Bool

    var summary: String {
        var parts = ["配置 \(settingCount) 项", "凭据 \(secretCount) 项", "中央素材 \(centralEffectCount) 个"]
        if ignoredLegacyCount > 0 { parts.append("忽略旧字段 \(ignoredLegacyCount) 项") }
        if workflowWillMigrate { parts.append("旧 Codemagic Workflow 将迁移") }
        return parts.joined(separator: " · ")
    }
}

enum BMBackupRestoreError: LocalizedError {
    case passwordTooShort, invalidFile, decryptFailed, rollbackUnavailable
    var errorDescription: String? {
        switch self {
        case .passwordTooShort: return "备份密码至少需要 6 位。"
        case .invalidFile: return "这不是有效的 BuildMate 备份文件。"
        case .decryptFailed: return "备份密码错误，或备份文件已损坏。"
        case .rollbackUnavailable: return "没有可回滚的恢复前快照。"
        }
    }
}

enum BMBackupRestoreService {
    // 只恢复当前产品仍存在的数据。旧 AI/中枢/自动调度/Bitrise/页面状态永远不会写回。
    private static let safeDefaultKeys = [
        "owner", "repo", "cloud-compiler-v1",
        "github-actions-owner", "github-actions-repo", "github-actions-branch",
        "codemagic-app-id", "codemagic-workflow-id", "codemagic-branch",
        "selfhost-endpoint",
        "central-effect-library-v1", "central-effect-custom-enabled", "central-effect-theme-v1",
        "central-effect-rotate-v1", "central-effect-motion-mode-v2", "central-effect-fixed-speed-v2",
        "central-effect-scale-v1", "central-effect-circle-correction-v1"
    ]

    private static let secretKeys = [
        "github-token", "github-actions-token", "codemagic-api-token", "selfhost-token"
    ]

    private static var rollbackURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        let dir = base.appendingPathComponent("BuildMate", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("pre-restore-snapshot.bmbak")
    }

    static func makeBackup(password: String) throws -> Data {
        guard password.count >= 6 else { throw BMBackupRestoreError.passwordTooShort }
        var settings: [String: String] = [:]
        for key in safeDefaultKeys {
            if let value = UserDefaults.standard.object(forKey: key) {
                if let s = value as? String { settings[key] = s }
                else if let b = value as? Bool { settings[key] = b ? "__bool:true" : "__bool:false" }
                else if let n = value as? NSNumber { settings[key] = "__number:\(n)" }
                else if let a = value as? [String], let data = try? JSONEncoder().encode(a) { settings[key] = "__strings:" + data.base64EncodedString() }
            }
        }
        var secrets: [String: String] = [:]
        for key in secretKeys {
            let value = KeychainStore.read(key)
            if !value.isEmpty { secrets[key] = value }
        }
        var files: [BMBackupFileItem] = []
        if let dir = try? BMCentralEffectLibraryStore.directory() {
            for name in BMCentralEffectLibraryStore.loadNames() {
                let url = dir.appendingPathComponent(name)
                if let data = try? Data(contentsOf: url), data.count <= 8_000_000 {
                    files.append(.init(name: name, dataBase64: data.base64EncodedString()))
                }
            }
        }
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
        let build = Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0") ?? 0
        let payload = BMBackupPayload(schema: 1, createdAt: Date(), appVersion: version, build: build, settings: settings, secrets: secrets, centralEffects: files)
        return try encrypt(payload: payload, password: password)
    }

    static func preview(data: Data, password: String) throws -> BMBackupPreview {
        let payload = try decodePayload(from: normalizedBackupData(data), password: password)
        let acceptedSettings = payload.settings.keys.filter { safeDefaultKeys.contains($0) }
        let acceptedSecrets = payload.secrets.keys.filter { secretKeys.contains($0) }
        let ignored = max(0, payload.settings.count - acceptedSettings.count) + max(0, payload.secrets.count - acceptedSecrets.count)
        let oldWorkflow = payload.settings["codemagic-workflow-id"]
        return .init(
            sourceVersion: payload.appVersion,
            sourceBuild: payload.build,
            settingCount: acceptedSettings.count,
            secretCount: acceptedSecrets.count,
            centralEffectCount: payload.centralEffects.count,
            ignoredLegacyCount: ignored,
            workflowWillMigrate: oldWorkflow == CodemagicStoredConfig.legacyWorkflowID || oldWorkflow?.isEmpty == true
        )
    }

    @discardableResult
    static func restore(data: Data, password: String, createRollbackSnapshot: Bool = true) throws -> BMBackupPayload {
        guard password.count >= 6 else { throw BMBackupRestoreError.passwordTooShort }
        let payload = try decodePayload(from: normalizedBackupData(data), password: password)

        if createRollbackSnapshot {
            let snapshot = try makeBackup(password: password)
            try? snapshot.write(to: rollbackURL, options: .atomic)
        }

        for (key, rawValue) in payload.settings {
            guard safeDefaultKeys.contains(key) else { continue }
            let value = migratedValue(rawValue, forKey: key)
            if value == "__bool:true" { UserDefaults.standard.set(true, forKey: key) }
            else if value == "__bool:false" { UserDefaults.standard.set(false, forKey: key) }
            else if value.hasPrefix("__number:"), let d = Double(value.dropFirst(9)) { UserDefaults.standard.set(d, forKey: key) }
            else if value.hasPrefix("__strings:"), let d = Data(base64Encoded: String(value.dropFirst(10))), let a = try? JSONDecoder().decode([String].self, from: d) { UserDefaults.standard.set(a, forKey: key) }
            else { UserDefaults.standard.set(value, forKey: key) }
        }
        for (key, value) in payload.secrets where secretKeys.contains(key) { _ = KeychainStore.save(value, key: key) }

        if let dir = try? BMCentralEffectLibraryStore.directory() {
            var restoredNames: [String] = []
            for item in payload.centralEffects.prefix(30) {
                let safeName = URL(fileURLWithPath: item.name).lastPathComponent
                guard !safeName.isEmpty, let bytes = Data(base64Encoded: item.dataBase64) else { continue }
                let url = dir.appendingPathComponent(safeName)
                try? bytes.write(to: url, options: .atomic)
                restoredNames.append(safeName)
            }
            if !restoredNames.isEmpty { BMCentralEffectLibraryStore.saveNames(restoredNames) }
        }
        return payload
    }

    static func canRollback() -> Bool { FileManager.default.fileExists(atPath: rollbackURL.path) }

    @discardableResult
    static func rollback(password: String) throws -> BMBackupPayload {
        guard let data = try? Data(contentsOf: rollbackURL) else { throw BMBackupRestoreError.rollbackUnavailable }
        let payload = try restore(data: data, password: password, createRollbackSnapshot: false)
        try? FileManager.default.removeItem(at: rollbackURL)
        return payload
    }

    private static func normalizedBackupData(_ data: Data) throws -> Data {
        if (try? JSONDecoder().decode(BMEncryptedBackupEnvelope.self, from: data)) != nil { return data }
        return try BMZipBackupReader.extractBackupData(from: data)
    }

    private static func decodePayload(from data: Data, password: String) throws -> BMBackupPayload {
        guard password.count >= 6 else { throw BMBackupRestoreError.passwordTooShort }
        guard let envelope = try? JSONDecoder().decode(BMEncryptedBackupEnvelope.self, from: data), envelope.format == "BuildMateBackup",
              let salt = Data(base64Encoded: envelope.saltBase64), let sealedData = Data(base64Encoded: envelope.sealedBase64),
              let box = try? AES.GCM.SealedBox(combined: sealedData) else { throw BMBackupRestoreError.invalidFile }
        let key = deriveKey(password: password, salt: salt)
        let plain: Data
        do { plain = try AES.GCM.open(box, using: key) } catch { throw BMBackupRestoreError.decryptFailed }
        guard let payload = try? JSONDecoder().decode(BMBackupPayload.self, from: plain), payload.schema == 1 else { throw BMBackupRestoreError.invalidFile }
        return payload
    }

    private static func migratedValue(_ value: String, forKey key: String) -> String {
        if key == "codemagic-workflow-id", value.isEmpty || value == CodemagicStoredConfig.legacyWorkflowID {
            return CodemagicStoredConfig.currentWorkflowID
        }
        if key == "cloud-compiler-v1" {
            if value == BMCloudCompiler.github.rawValue { return value }
            return BMCloudCompiler.codemagic.rawValue
        }
        return value
    }

    private static func encrypt(payload: BMBackupPayload, password: String) throws -> Data {
        let plain = try JSONEncoder().encode(payload)
        let salt = randomData(count: 16)
        let key = deriveKey(password: password, salt: salt)
        let sealed = try AES.GCM.seal(plain, using: key)
        guard let combined = sealed.combined else { throw BMBackupRestoreError.invalidFile }
        return try JSONEncoder().encode(BMEncryptedBackupEnvelope(format: "BuildMateBackup", schema: 1, saltBase64: salt.base64EncodedString(), sealedBase64: combined.base64EncodedString()))
    }

    private static func deriveKey(password: String, salt: Data) -> SymmetricKey {
        var material = Data(password.utf8) + salt
        for _ in 0..<120_000 { material = Data(SHA256.hash(data: material + salt)) }
        return SymmetricKey(data: material)
    }

    private static func randomData(count: Int) -> Data {
        var bytes = [UInt8](repeating: 0, count: count)
        _ = SecRandomCopyBytes(kSecRandomDefault, count, &bytes)
        return Data(bytes)
    }
}
