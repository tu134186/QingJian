import Foundation

enum AIProvider: String, CaseIterable, Identifiable {
    case openAI = "OpenAI"
    case deepSeek = "DeepSeek"
    case doubao = "豆包"
    case qwen = "千问"
    case kimi = "Kimi"
    case gemini = "Gemini"
    case compatible = "自定义"
    var id: String { rawValue }
    var usesResponsesAPI: Bool { self == .openAI }
}

struct AIRepairProtocolError: LocalizedError {
    let message: String
    let rawResponse: String
    let formattedResponse: String?
    var errorDescription: String? { message }
}

final class AIRepairService {
    let provider: AIProvider
    let endpoint: String
    let model: String
    let apiKey: String

    init(provider: AIProvider = .compatible, endpoint: String, model: String, apiKey: String) {
        self.provider = provider
        self.endpoint = endpoint.trimmingCharacters(in: .whitespacesAndNewlines)
        self.model = model.trimmingCharacters(in: .whitespacesAndNewlines)
        self.apiKey = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func testConnection() async throws -> String {
        let text = try await call(system: "Reply with exactly OK.", user: "Connection test", jsonMode: false, maxTokens: 32)
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// 深度接管中心使用的自由文本分析入口。与自动 Patch 协议完全分离：
    /// 这里只返回诊断/修改建议，不自动改源码，避免破坏已验证的安全门。
    func makeDeepTakeoverAnalysis(contextText: String) async throws -> String {
        let trimmed = contextText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw simpleError("深度接管上下文为空。") }
        let system = """
        You are BuildMate Deep Takeover Agent. Perform a senior-level diagnosis for an iOS Swift/Objective-C/Logos project from REAL BuildMate diagnostics and source context.
        Goals:
        1. Identify root cause, not only the first compiler symptom.
        2. Distinguish compile errors, runtime/state bugs, UI bugs, GitHub Run binding issues, stale-state issues, and packaging issues.
        3. Prefer the smallest safe change and preserve verified Provider, AI repair, IPA/DEB artifact pipelines and historical release records.
        4. Never request or expose tokens, API keys, passwords, cookies or session secrets.
        5. Return concise Chinese sections: 根因 / 建议修改 / 风险 / 验证步骤.
        6. Do not claim a source change has been applied. This endpoint is analysis-only; BuildMate will decide how to apply changes in a later stage.
        """
        return try await call(system: system, user: trimmed, jsonMode: false, maxTokens: 5000)
    }

    func makeRepairPlan(context: RepairContext) async throws -> AIRepairResult {
        let contextData = try JSONEncoder().encode(context)
        let contextText = String(data: contextData, encoding: .utf8) ?? "{}"
        let system = """
        You are BuildMate AI Repair Agent for iOS Swift/Objective-C/Logos projects. You receive REAL Xcode or Theos compiler errors and source snippets. Produce the smallest safe repair plan that resolves as many independently proven compile errors as safely possible within the patch limit.
        Hard rules:
        1. Never invent a file not present in the supplied context.
        2. Automatic patches are allowed only for .swift, .m, .mm, .xm, .x, .h files.
        3. Do not modify project.yml, Info.plist, entitlements, signing, certificates, bundle identifiers, workflows, Makefile/control, dependencies, package manifests, or secrets.
        4. Do not refactor. Fix only the direct compile error.
        5. Each patch is exact search/replace copied from supplied snippets and must uniquely identify the target.
        6. Prefer at most 3 patches. If you identify more than 3 independently proven low-risk fixes, ORDER patches from most certain/smallest/lowest-risk to least certain. BuildMate will safely execute only the first 3 and leave the rest for the next real compile round. Do not artificially stop after the first error.
        7. Before inventing or adding a type/enum/struct/function, inspect ALL supplied snippets for an existing declaration. If contextMode is full-file, treat that snippet as the complete source file and prefer editing the existing declaration (for example, add a missing enum case) instead of creating a duplicate declaration.
        8. If evidence is insufficient or risk is not low, return patches=[] and explain stopReason.
        9. confidence is 0-100. risk must be low, medium, or high.
        10. Return JSON only: {\"summary\":\"...\",\"confidence\":90,\"risk\":\"low\",\"patches\":[{\"path\":\"Tweak.xm\",\"search\":\"exact old text\",\"replace\":\"exact new text\",\"reason\":\"...\"}],\"stopReason\":null}
        """
        let userInput = "REAL BUILD CONTEXT:\n\(contextText)"
        guard !contextText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, contextText != "{}" else {
            throw AIRepairProtocolError(message: "AI 修复输入为空：repair-context 没有可发送内容。", rawResponse: "", formattedResponse: nil)
        }
        var content = try await call(system: system, user: userInput, jsonMode: true, maxTokens: 3200)
        if content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            // DeepSeek 官方说明 JSON Output 偶发返回空 content。不能把它算成代码修复失败；
            // 同一轮自动降级为普通文本模式，并继续要求“只返回 JSON”。
            let fallbackSystem = system + "\nIMPORTANT: JSON transport mode returned empty content. Return ONLY the JSON object described above, with no markdown and no commentary."
            let retry = try await call(system: fallbackSystem, user: userInput, jsonMode: false, maxTokens: 3200)
            if retry.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                throw AIRepairProtocolError(message: "AI 接口连续两次返回空文本（JSON 模式 + 普通模式）。", rawResponse: content, formattedResponse: retry)
            }
            content = retry
        }
        var plan: AIRepairPlan? = decodeRepairPlan(content)
        var formatted: String? = nil

        // 某些兼容接口会错误返回 No input provided。上下文明明存在时，同一轮内部
        // 用更短、更明确的真实编译输入重试一次；这不是新的代码修复轮次。
        if let p = plan, p.patches.isEmpty, (p.stopReason ?? "").lowercased().contains("no input") {
            let compact = compactRepairInput(context)
            let retrySystem = system + "\nThe previous response incorrectly said there was no input. The following compact payload contains REAL compiler errors and source snippets. Do not say no input; inspect it and return the JSON repair plan only."
            let retry = try await call(system: retrySystem, user: compact, jsonMode: true, maxTokens: 3200)
            formatted = retry
            if let retryPlan = decodeRepairPlan(retry) {
                plan = retryPlan
                content = content + "\n\n[BuildMate same-round no-input retry]\n" + retry
            }
        }

        if plan == nil {
            let cleanupSystem = """
            You are a strict JSON formatter. Return ONLY one valid JSON object with exactly these top-level keys: summary, confidence, risk, patches, stopReason. confidence must be an integer 0-100. risk must be low, medium, or high. patches must be an array. Every patch must contain path, search, replace, reason. All search/replace values must be valid JSON strings with newlines escaped as \n. Preserve the intended patch content. Do not add markdown fences or commentary.
            """
            let cleaned = try await call(system: cleanupSystem, user: content, jsonMode: true, maxTokens: 3200)
            formatted = cleaned
            plan = decodeRepairPlan(cleaned)
        }
        guard let finalPlan = plan else {
            throw AIRepairProtocolError(message: "AI 返回的修复计划经过自动清洗和二次格式化后仍无法解析。", rawResponse: content, formattedResponse: formatted)
        }
        let acceptedPlan = limitToSafePatchBatch(finalPlan)
        try validate(acceptedPlan)
        return AIRepairResult(plan: acceptedPlan, usage: nil, rawResponse: content, formattedResponse: formatted)
    }

    private func call(system: String, user: String, jsonMode: Bool, maxTokens: Int) async throws -> String {
        guard let url = URL(string: endpoint), !endpoint.isEmpty else { throw simpleError("AI Endpoint 无效。") }
        guard !model.isEmpty else { throw simpleError("AI 模型不能为空。") }
        guard !apiKey.isEmpty else { throw simpleError("AI API Key 不能为空。") }
        var payload: [String: Any]
        if provider.usesResponsesAPI {
            payload = ["model": model, "instructions": system, "input": user, "max_output_tokens": maxTokens]
            if jsonMode { payload["text"] = ["format": ["type": "json_object"]] }
        } else {
            payload = ["model": model, "messages": [["role":"system","content":system],["role":"user","content":user]], "stream": false, "max_tokens": maxTokens]
            if jsonMode { payload["response_format"] = ["type": "json_object"] }
            // DeepSeek v4 默认开启 thinking。修复计划是严格结构化 JSON，关闭 thinking 更适合协议输出，
            // 同时避开 reasoning_content 很长而最终 content 为空/不足的问题。
            if provider == .deepSeek && jsonMode { payload["thinking"] = ["type": "disabled"] }
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"; req.timeoutInterval = 150
        req.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw simpleError("AI 接口没有返回 HTTP 响应。") }
        guard (200...299).contains(http.statusCode) else {
            var msg = "AI 请求失败（HTTP \(http.statusCode)）"
            if let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let e = o["error"] as? [String: Any], let m = e["message"] as? String { msg += "：\(m)" }
            throw simpleError(msg)
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw simpleError("AI 返回内容不是 JSON。") }
        if provider.usesResponsesAPI {
            if let output = obj["output"] as? [[String: Any]] {
                for item in output {
                    if let content = item["content"] as? [[String: Any]] {
                        for c in content { if let text = c["text"] as? String { return text } }
                    }
                }
            }
            if let text = obj["output_text"] as? String { return text }
            throw simpleError("OpenAI Responses API 没有返回文本。")
        }
        guard let choices = obj["choices"] as? [[String: Any]], let first = choices.first, let message = first["message"] as? [String: Any] else { throw simpleError("兼容接口返回格式不支持。") }
        let finishReason = first["finish_reason"] as? String ?? "unknown"
        let content = (message["content"] as? String) ?? ""
        if content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let reasoning = (message["reasoning_content"] as? String) ?? ""
            if !reasoning.isEmpty {
                // 不把思维链当成 Patch；只把原因带回上层，让同轮 fallback 重新请求最终 JSON。
                return ""
            }
            if finishReason == "length" { throw simpleError("AI 输出达到长度上限，但没有形成最终修复方案。") }
        }
        return content
    }


    private func compactRepairInput(_ context: RepairContext) -> String {
        var parts: [String] = []
        if let runID = context.runID { parts.append("Run: #\(runID)") }
        if let diagnosis = context.diagnosis, !diagnosis.isEmpty { parts.append("Diagnosis: \(diagnosis)") }
        if let errors = context.compileErrors, !errors.isEmpty {
            parts.append("Compiler errors:\n" + String(errors.suffix(9000)))
        }
        for file in context.files.prefix(6) {
            let line = file.line.map { ":\($0)" } ?? ""
            parts.append("Source \(file.path)\(line):\n" + String(file.snippet.prefix(5000)))
        }
        return parts.joined(separator: "\n\n")
    }

    private func decodeRepairPlan(_ raw: String) -> AIRepairPlan? {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        text = text.replacingOccurrences(of: "```json", with: "", options: .caseInsensitive)
                   .replacingOccurrences(of: "```", with: "")
                   .replacingOccurrences(of: "“", with: "\"")
                   .replacingOccurrences(of: "”", with: "\"")
                   .replacingOccurrences(of: "，", with: ",")
                   .replacingOccurrences(of: "：", with: ":")
        text = extractJSONObject(text)
        text = stripTrailingCommas(text)
        text = escapeLiteralNewlinesInsideJSONString(text)
        guard let rawData = text.data(using: .utf8) else { return nil }
        if let plan = try? JSONDecoder().decode(AIRepairPlan.self, from: rawData) { return plan }
        guard let object = try? JSONSerialization.jsonObject(with: rawData) as? [String: Any] else { return nil }
        return normalizePlan(object)
    }

    private func normalizePlan(_ object: [String: Any]) -> AIRepairPlan? {
        let summary = stringValue(object["summary"]) ?? stringValue(object["reason"]) ?? "AI 修复计划"
        let confidence = intValue(object["confidence"]) ?? 0
        let risk = (stringValue(object["risk"]) ?? "high").lowercased()
        let stopReason = stringValue(object["stopReason"] ?? object["stop_reason"])
        let rawPatches = (object["patches"] as? [[String: Any]]) ?? []
        let patches: [RepairPatch] = rawPatches.compactMap { item in
            guard let path = stringValue(item["path"] ?? item["file"]),
                  let search = stringValue(item["search"] ?? item["old"] ?? item["before"]),
                  let replace = stringValue(item["replace"] ?? item["new"] ?? item["after"]) else { return nil }
            return RepairPatch(path: path, search: search, replace: replace, reason: stringValue(item["reason"]))
        }
        return AIRepairPlan(summary: summary, confidence: min(100, max(0, confidence)), risk: risk, patches: patches, stopReason: stopReason)
    }

    private func stringValue(_ value: Any?) -> String? {
        if let s = value as? String { return s }
        if let n = value as? NSNumber { return n.stringValue }
        return nil
    }

    private func intValue(_ value: Any?) -> Int? {
        if let i = value as? Int { return i }
        if let n = value as? NSNumber { return n.intValue }
        if let s = value as? String {
            let digits = s.filter { $0.isNumber || $0 == "-" }
            return Int(digits)
        }
        return nil
    }

    private func extractJSONObject(_ text: String) -> String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.hasPrefix("{") && t.hasSuffix("}") { return t }
        guard let a = t.firstIndex(of: "{"), let b = t.lastIndex(of: "}"), a <= b else { return t }
        return String(t[a...b])
    }

    private func stripTrailingCommas(_ text: String) -> String {
        var out = text
        for _ in 0..<4 {
            let previous = out
            out = out.replacingOccurrences(of: ",}", with: "}")
                     .replacingOccurrences(of: ",]", with: "]")
                     .replacingOccurrences(of: ",\n}", with: "\n}")
                     .replacingOccurrences(of: ",\n]", with: "\n]")
            if out == previous { break }
        }
        return out
    }

    private func escapeLiteralNewlinesInsideJSONString(_ text: String) -> String {
        var result = ""
        var inString = false
        var escaped = false
        for scalar in text.unicodeScalars {
            let ch = Character(String(scalar))
            if inString {
                if escaped {
                    result.append(ch)
                    escaped = false
                } else if ch == "\\" {
                    result.append(ch)
                    escaped = true
                } else if ch == "\"" {
                    result.append(ch)
                    inString = false
                } else if ch == "\n" {
                    result += "\\n"
                } else if ch == "\r" {
                    result += "\\r"
                } else if ch == "\t" {
                    result += "\\t"
                } else {
                    result.append(ch)
                }
            } else {
                result.append(ch)
                if ch == "\"" { inString = true }
            }
        }
        return result
    }

    private func limitToSafePatchBatch(_ plan: AIRepairPlan) -> AIRepairPlan {
        guard plan.patches.count > 3 else { return plan }
        // AI 已按“最确定、最小、低风险优先”返回 Patch；安全阀不再整轮拒绝，
        // 只接受前 3 个，其余留给下一次真实编译后的新上下文继续处理。
        var limited = plan
        limited.patches = Array(plan.patches.prefix(3))
        limited.summary = plan.summary + "（本轮识别到 \(plan.patches.count) 处候选，安全执行前 3 处，其余留待下一轮。）"
        return limited
    }

    private func validate(_ plan: AIRepairPlan) throws {
        let allowed = [".swift", ".m", ".mm", ".xm", ".x", ".h"]
        for patch in plan.patches {
            let path=patch.path.replacingOccurrences(of:"\\",with:"/")
            guard allowed.contains(where: { path.hasSuffix($0) }) else { throw simpleError("AI 尝试修改不允许的文件 \(path)，已阻止。") }
            guard !path.hasPrefix("/") && !path.contains("..") else { throw simpleError("AI 返回了不安全路径，已阻止。") }
            guard !patch.search.isEmpty, patch.search.count <= 5000, patch.replace.count <= 5000 else { throw simpleError("AI Patch 范围过大，已阻止。") }
            let low=(patch.search+patch.replace).lowercased()
            let blocked=["api_key","github_pat_","certificate","provisioning_profile","code_sign_identity",".github/workflows"]
            if blocked.contains(where:{low.contains($0)}) { throw simpleError("AI Patch 涉及敏感区域，已阻止。") }
        }
    }
    private func simpleError(_ text:String)->NSError { NSError(domain:"BuildMateAI",code:-1,userInfo:[NSLocalizedDescriptionKey:text]) }
}
