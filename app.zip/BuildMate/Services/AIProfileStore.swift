import Foundation

enum BMAIProfileStore {
    static func storedProvider() -> AIProvider {
        AIProvider(rawValue: UserDefaults.standard.string(forKey: "ai-provider") ?? "OpenAI") ?? .openAI
    }

    static func defaultEndpoint(_ provider: AIProvider) -> String {
        switch provider {
        case .openAI: return "https://api.openai.com/v1/responses"
        case .deepSeek: return "https://api.deepseek.com/chat/completions"
        case .doubao: return "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
        case .qwen: return "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
        case .kimi: return "https://api.moonshot.cn/v1/chat/completions"
        case .gemini: return "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
        case .compatible: return ""
        }
    }

    static func defaultModel(_ provider: AIProvider) -> String {
        switch provider {
        case .openAI: return "gpt-5.6"
        case .deepSeek: return "deepseek-v4-pro"
        case .qwen: return "qwen-plus"
        case .gemini: return "gemini-3.7-flash"
        case .doubao, .kimi, .compatible: return ""
        }
    }

    static func suffix(_ provider: AIProvider) -> String {
        switch provider {
        case .openAI: return "openai"
        case .deepSeek: return "deepseek"
        case .doubao: return "doubao"
        case .qwen: return "qwen"
        case .kimi: return "kimi"
        case .gemini: return "gemini"
        case .compatible: return "custom"
        }
    }

    static func storedEndpoint(_ provider: AIProvider) -> String {
        let key = "ai-endpoint-" + suffix(provider)
        if let value = UserDefaults.standard.string(forKey: key), !value.isEmpty { return value }
        let legacy = UserDefaults.standard.string(forKey: "ai-endpoint") ?? ""
        if provider == .openAI, legacy.contains("openai.com") { return legacy }
        if provider == .deepSeek, legacy.contains("deepseek.com") { return legacy }
        return defaultEndpoint(provider)
    }

    static func storedModel(_ provider: AIProvider) -> String {
        let key = "ai-model-" + suffix(provider)
        if let value = UserDefaults.standard.string(forKey: key), !value.isEmpty { return value }
        let legacy = UserDefaults.standard.string(forKey: "ai-model") ?? ""
        if provider == .openAI, legacy.lowercased().hasPrefix("gpt-") { return legacy }
        if provider == .deepSeek, legacy.lowercased().hasPrefix("deepseek-") { return legacy }
        return defaultModel(provider)
    }

    static func storedKey(_ provider: AIProvider) -> String {
        let key = "ai-api-key-" + suffix(provider)
        let value = KeychainStore.read(key)
        if !value.isEmpty { return value }
        if provider == .openAI || provider == .deepSeek { return KeychainStore.read("ai-api-key") }
        return ""
    }

    static func save(provider: AIProvider, endpoint: String, model: String, apiKey: String) {
        let profileSuffix = suffix(provider)
        UserDefaults.standard.set(endpoint, forKey: "ai-endpoint-" + profileSuffix)
        UserDefaults.standard.set(model, forKey: "ai-model-" + profileSuffix)
        KeychainStore.save(apiKey, key: "ai-api-key-" + profileSuffix)
    }
}
