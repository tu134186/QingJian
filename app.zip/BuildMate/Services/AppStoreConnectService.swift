import Foundation
import CryptoKit

struct BMASCAppSummary: Identifiable, Hashable {
    let id: String
    let name: String
    let bundleID: String
    let sku: String
}

struct BMASCBuildSummary: Identifiable, Hashable {
    let id: String
    let version: String
    let uploadedDate: String
    let processingState: String
}

struct BMASCProbeResult: Hashable {
    let app: BMASCAppSummary
    let builds: [BMASCBuildSummary]
    let checkedAt: Date
}

struct BMASCUploadOperation: Hashable {
    let method: String
    let url: URL
    let offset: Int64
    let length: Int64
    let headers: [String: String]
    let partNumber: Int64?
}

struct BMASCBuildUploadSession: Identifiable, Hashable {
    let id: String
    let appID: String
    let version: String
    let build: String
    let state: String
    let createdDate: String
}

struct BMASCUploadReservation: Identifiable, Hashable {
    let id: String
    let fileName: String
    let fileSize: Int64
    let state: String
    let operations: [BMASCUploadOperation]
}

struct BMASCUploadResult: Hashable {
    let uploadID: String
    let fileID: String
    let fileName: String
    let fileSize: Int64
    let md5: String
    let state: String
    let completedAt: Date
}

enum BMASCError: LocalizedError {
    case invalidToken
    case invalidIPA(String)
    case missingUploadOperations
    case http(Int, String)
    case uploadPart(Int, Int, String)
    case appNotFound(String)
    case malformedResponse

    var errorDescription: String? {
        switch self {
        case .invalidToken: return "JWT 为空。请粘贴 App Store Connect 临时 JWT；BuildMate 不会保存它。"
        case let .invalidIPA(reason): return "IPA 不可上传：\(reason)"
        case .missingUploadOperations: return "Apple 已创建文件预留，但没有返回上传分片指令。"
        case let .http(code, detail): return "App Store Connect HTTP \(code)：\(detail)"
        case let .uploadPart(index, code, detail): return "IPA 第 \(index) 个分片上传失败（HTTP \(code)）：\(detail)"
        case let .appNotFound(bundleID): return "账号验证成功，但没有找到 Bundle ID：\(bundleID)"
        case .malformedResponse: return "App Store Connect 返回数据无法识别。"
        }
    }
}

/// Build226: App Store Connect 真实 Build Upload 执行器。
/// - JWT 仅作为函数参数存在于内存，不写 UserDefaults、文件、日志或黑匣子。
/// - Apple 返回的预签名上传 URL 同样只在内存使用，不持久化。
/// - 真正创建 Build Upload / 上传 IPA 前由 UI 执行主人批准与二次确认。
enum AppStoreConnectService {
    private static let base = URL(string: "https://api.appstoreconnect.apple.com/v1")!

    static func probe(jwt: String, bundleID: String) async throws -> BMASCProbeResult {
        let token = try normalizedToken(jwt)
        let apps = try await listApps(jwt: token, bundleID: bundleID)
        guard let app = apps.first else { throw BMASCError.appNotFound(bundleID) }
        let builds = try await listBuilds(jwt: token, appID: app.id)
        return .init(app: app, builds: builds, checkedAt: Date())
    }

    static func listApps(jwt: String, bundleID: String) async throws -> [BMASCAppSummary] {
        var components = URLComponents(url: base.appendingPathComponent("apps"), resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "filter[bundleId]", value: bundleID),
            URLQueryItem(name: "fields[apps]", value: "name,bundleId,sku"),
            URLQueryItem(name: "limit", value: "10")
        ]
        let data = try await apiRequest(components.url!, method: "GET", jwt: jwt)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rows = root["data"] as? [[String: Any]] else { throw BMASCError.malformedResponse }
        return rows.compactMap { row in
            guard let id = row["id"] as? String,
                  let attrs = row["attributes"] as? [String: Any] else { return nil }
            return .init(id: id,
                         name: attrs["name"] as? String ?? "",
                         bundleID: attrs["bundleId"] as? String ?? "",
                         sku: attrs["sku"] as? String ?? "")
        }
    }

    static func listBuilds(jwt: String, appID: String) async throws -> [BMASCBuildSummary] {
        var components = URLComponents(url: base.appendingPathComponent("builds"), resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "filter[app]", value: appID),
            URLQueryItem(name: "fields[builds]", value: "version,uploadedDate,processingState"),
            URLQueryItem(name: "sort", value: "-uploadedDate"),
            URLQueryItem(name: "limit", value: "10")
        ]
        let data = try await apiRequest(components.url!, method: "GET", jwt: jwt)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rows = root["data"] as? [[String: Any]] else { throw BMASCError.malformedResponse }
        return rows.compactMap { row in
            guard let id = row["id"] as? String,
                  let attrs = row["attributes"] as? [String: Any] else { return nil }
            return .init(id: id,
                         version: attrs["version"] as? String ?? "",
                         uploadedDate: attrs["uploadedDate"] as? String ?? "",
                         processingState: attrs["processingState"] as? String ?? "UNKNOWN")
        }
    }

    static func createBuildUpload(jwt: String, appID: String, version: String, build: String) async throws -> BMASCBuildUploadSession {
        let token = try normalizedToken(jwt)
        let body: [String: Any] = [
            "data": [
                "type": "buildUploads",
                "attributes": [
                    "cfBundleShortVersionString": version,
                    "cfBundleVersion": build,
                    "platform": "IOS"
                ],
                "relationships": [
                    "app": ["data": ["type": "apps", "id": appID]]
                ]
            ]
        ]
        let data = try await apiRequest(base.appendingPathComponent("buildUploads"), method: "POST", jwt: token, json: body)
        return try parseBuildUpload(data, appID: appID)
    }

    static func reserveIPA(jwt: String, uploadID: String, fileURL: URL) async throws -> BMASCUploadReservation {
        let info = try ipaInfo(fileURL)
        let body: [String: Any] = [
            "data": [
                "type": "buildUploadFiles",
                "attributes": [
                    "fileName": info.name,
                    "fileSize": info.size,
                    "assetType": "ASSET",
                    "uti": "com.apple.ipa"
                ],
                "relationships": [
                    "buildUpload": ["data": ["type": "buildUploads", "id": uploadID]]
                ]
            ]
        ]
        let data = try await apiRequest(base.appendingPathComponent("buildUploadFiles"), method: "POST", jwt: try normalizedToken(jwt), json: body)
        return try parseReservation(data)
    }

    static func uploadIPA(jwt: String,
                          appID: String,
                          version: String,
                          build: String,
                          fileURL: URL,
                          progress: @escaping @Sendable (Double, String) -> Void) async throws -> BMASCUploadResult {
        let token = try normalizedToken(jwt)
        let info = try ipaInfo(fileURL)
        progress(0.02, "创建 Apple Build Upload")
        let session = try await createBuildUpload(jwt: token, appID: appID, version: version, build: build)
        progress(0.06, "预留 IPA 文件")
        let reservation = try await reserveIPA(jwt: token, uploadID: session.id, fileURL: fileURL)
        guard !reservation.operations.isEmpty else { throw BMASCError.missingUploadOperations }

        let scoped = fileURL.startAccessingSecurityScopedResource()
        defer { if scoped { fileURL.stopAccessingSecurityScopedResource() } }
        let md5 = try checksumMD5(fileURL)
        let total = max(Int64(1), reservation.operations.reduce(Int64(0)) { $0 + $1.length })
        var sent: Int64 = 0
        for (index, operation) in reservation.operations.enumerated() {
            let chunk = try readChunk(fileURL: fileURL, offset: operation.offset, length: operation.length)
            var request = URLRequest(url: operation.url)
            request.httpMethod = operation.method.isEmpty ? "PUT" : operation.method
            request.timeoutInterval = 180
            operation.headers.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
            request.httpBody = chunk
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 180
            config.timeoutIntervalForResource = 300
            config.urlCache = nil
            config.requestCachePolicy = .reloadIgnoringLocalCacheData
            let (data, response) = try await URLSession(configuration: config).data(for: request)
            guard let http = response as? HTTPURLResponse else { throw BMASCError.malformedResponse }
            guard (200...299).contains(http.statusCode) else {
                let detail = String(data: data, encoding: .utf8).map { String($0.prefix(300)) } ?? "预签名上传失败"
                throw BMASCError.uploadPart(index + 1, http.statusCode, detail)
            }
            sent += operation.length
            let fraction = min(0.88, 0.08 + (Double(sent) / Double(total)) * 0.80)
            progress(fraction, "上传 IPA 分片 \(index + 1)/\(reservation.operations.count)")
        }

        progress(0.91, "提交 IPA 校验")
        let commitBody: [String: Any] = [
            "data": [
                "type": "buildUploadFiles",
                "id": reservation.id,
                "attributes": [
                    "uploaded": true,
                    "sourceFileChecksums": [
                        "file": ["hash": md5, "algorithm": "MD5"]
                    ]
                ]
            ]
        ]
        _ = try await apiRequest(base.appendingPathComponent("buildUploadFiles").appendingPathComponent(reservation.id), method: "PATCH", jwt: token, json: commitBody)
        progress(0.95, "等待 Apple 接收状态")
        let final = try await readBuildUpload(jwt: token, uploadID: session.id, appID: appID)
        progress(1.0, "Apple 已接收 Build Upload")
        return .init(uploadID: session.id, fileID: reservation.id, fileName: info.name, fileSize: info.size, md5: md5, state: final.state, completedAt: Date())
    }

    static func readBuildUpload(jwt: String, uploadID: String, appID: String) async throws -> BMASCBuildUploadSession {
        var components = URLComponents(url: base.appendingPathComponent("buildUploads").appendingPathComponent(uploadID), resolvingAgainstBaseURL: false)!
        components.queryItems = [URLQueryItem(name: "fields[buildUploads]", value: "cfBundleShortVersionString,cfBundleVersion,createdDate,state,platform,uploadedDate")]
        let data = try await apiRequest(components.url!, method: "GET", jwt: try normalizedToken(jwt))
        return try parseBuildUpload(data, appID: appID)
    }

    private static func parseBuildUpload(_ data: Data, appID: String) throws -> BMASCBuildUploadSession {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let row = root["data"] as? [String: Any],
              let id = row["id"] as? String,
              let attrs = row["attributes"] as? [String: Any] else { throw BMASCError.malformedResponse }
        let state: String
        if let stateDict = attrs["state"] as? [String: Any] { state = stateDict["state"] as? String ?? "UNKNOWN" }
        else { state = attrs["state"] as? String ?? "UNKNOWN" }
        return .init(id: id,
                     appID: appID,
                     version: attrs["cfBundleShortVersionString"] as? String ?? "",
                     build: attrs["cfBundleVersion"] as? String ?? "",
                     state: state,
                     createdDate: attrs["createdDate"] as? String ?? "")
    }

    private static func parseReservation(_ data: Data) throws -> BMASCUploadReservation {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let row = root["data"] as? [String: Any],
              let id = row["id"] as? String,
              let attrs = row["attributes"] as? [String: Any] else { throw BMASCError.malformedResponse }
        let rows = attrs["uploadOperations"] as? [[String: Any]] ?? []
        let operations: [BMASCUploadOperation] = rows.compactMap { op in
            guard let urlText = op["url"] as? String, let url = URL(string: urlText) else { return nil }
            let headerRows = op["requestHeaders"] as? [[String: Any]] ?? []
            var headers: [String: String] = [:]
            headerRows.forEach { row in
                if let name = row["name"] as? String, let value = row["value"] as? String { headers[name] = value }
            }
            return .init(method: op["method"] as? String ?? "PUT",
                         url: url,
                         offset: int64(op["offset"]),
                         length: int64(op["length"]),
                         headers: headers,
                         partNumber: optionalInt64(op["partNumber"]))
        }
        let deliveryState: String
        if let state = attrs["assetDeliveryState"] as? [String: Any] { deliveryState = state["state"] as? String ?? "AWAITING_UPLOAD" }
        else { deliveryState = "AWAITING_UPLOAD" }
        return .init(id: id,
                     fileName: attrs["fileName"] as? String ?? "",
                     fileSize: int64(attrs["fileSize"]),
                     state: deliveryState,
                     operations: operations)
    }

    private static func apiRequest(_ url: URL, method: String, jwt: String, json: [String: Any]? = nil) async throws -> Data {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.timeoutInterval = 30
        request.setValue("Bearer \(jwt)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let json {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: json)
        }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 60
        config.urlCache = nil
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        let session = URLSession(configuration: config)
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw BMASCError.malformedResponse }
        guard (200...299).contains(http.statusCode) else {
            throw BMASCError.http(http.statusCode, appleErrorSummary(data) ?? "请求失败")
        }
        return data
    }

    private static func normalizedToken(_ jwt: String) throws -> String {
        let token = jwt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !token.isEmpty else { throw BMASCError.invalidToken }
        return token
    }

    private static func ipaInfo(_ url: URL) throws -> (name: String, size: Int64) {
        guard url.pathExtension.lowercased() == "ipa" else { throw BMASCError.invalidIPA("请选择 .ipa 文件") }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        guard size > 100_000 else { throw BMASCError.invalidIPA("文件小于 100 KB，疑似无效产物") }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        let header = try handle.read(upToCount: 2) ?? Data()
        guard header.count == 2, header[0] == 0x50, header[1] == 0x4B else { throw BMASCError.invalidIPA("不是 PK/ZIP 文件头") }
        return (url.lastPathComponent, size)
    }

    private static func checksumMD5(_ url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hasher = Insecure.MD5()
        while true {
            let data = try handle.read(upToCount: 1024 * 1024) ?? Data()
            if data.isEmpty { break }
            hasher.update(data: data)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private static func readChunk(fileURL: URL, offset: Int64, length: Int64) throws -> Data {
        guard offset >= 0, length > 0, length <= Int64(Int.max) else { throw BMASCError.invalidIPA("Apple 返回了无效分片范围") }
        let handle = try FileHandle(forReadingFrom: fileURL)
        defer { try? handle.close() }
        try handle.seek(toOffset: UInt64(offset))
        let data = try handle.read(upToCount: Int(length)) ?? Data()
        guard data.count == Int(length) else { throw BMASCError.invalidIPA("读取上传分片长度不完整") }
        return data
    }

    private static func int64(_ value: Any?) -> Int64 {
        if let n = value as? NSNumber { return n.int64Value }
        if let n = value as? Int64 { return n }
        if let n = value as? Int { return Int64(n) }
        if let s = value as? String { return Int64(s) ?? 0 }
        return 0
    }

    private static func optionalInt64(_ value: Any?) -> Int64? {
        let v = int64(value)
        return v == 0 ? nil : v
    }

    private static func appleErrorSummary(_ data: Data) -> String? {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let errors = root["errors"] as? [[String: Any]], let first = errors.first else { return nil }
        let title = first["title"] as? String ?? ""
        let detail = first["detail"] as? String ?? ""
        return [title, detail].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}
