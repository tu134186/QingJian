import Foundation

struct SelfHostedMacStoredConfig {
    var endpoint:String; var token:String
    var isReady:Bool { !endpoint.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty }
    static func load()->Self { .init(endpoint:UserDefaults.standard.string(forKey:"selfhost-endpoint") ?? "", token:KeychainStore.read("selfhost-token")) }
}

final class SelfHostedMacService {
    let endpoint:String, token:String
    init(endpoint:String,token:String){self.endpoint=endpoint;self.token=token}

    private func request(path: String, method: String = "GET", body: Data? = nil) throws -> URLRequest {
        guard let base = URL(string: endpoint.trimmingCharacters(in: .whitespacesAndNewlines)),
              let url = URL(string: path, relativeTo: base) else { throw E.msg("自托管 Mac 地址无效") }
        var r = URLRequest(url: url)
        r.httpMethod = method
        r.timeoutInterval = 20
        r.setValue(BMMacAgentProtocol.version, forHTTPHeaderField: "X-BuildMate-Agent-Protocol")
        if !token.isEmpty { r.setValue("Bearer \(token)", forHTTPHeaderField:"Authorization") }
        if body != nil { r.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        r.httpBody = body
        return r
    }

    func testConnection() async throws -> String {
        do {
            let node = try await discoverCapabilities()
            return "✅ Mac Agent \(node.nodeName) · \(node.macOSVersion) · Xcode \(node.xcodeVersions.first ?? "未知")"
        } catch {
            // Compatibility fallback for pre-v1 endpoint; never treats this as Agent-v1 verified.
            guard let u=URL(string:endpoint) else {throw E.msg("自托管地址无效")}
            var r=URLRequest(url:u);r.httpMethod="HEAD";r.timeoutInterval=15
            if !token.isEmpty{r.setValue("Bearer \(token)",forHTTPHeaderField:"Authorization")}
            let (_,res)=try await URLSession.shared.data(for:r)
            guard let h=res as? HTTPURLResponse,(200...499).contains(h.statusCode) else{throw E.msg("无法连接自托管 Mac")}
            return "⚠️ 地址可达，但尚未确认 BuildMate Mac Agent v1 协议"
        }
    }

    func discoverCapabilities() async throws -> BMMacAgentNodeSnapshot {
        let (data, response) = try await URLSession.shared.data(for: request(path: "/buildmate/v1/handshake"))
        try validate(response)
        let hello = try JSONDecoder().decode(BMMacAgentHandshake.self, from: data)
        guard hello.protocolVersion == BMMacAgentProtocol.version else { throw E.msg("Mac Agent 协议版本不兼容") }
        let node = BMMacAgentNodeSnapshot(nodeID: hello.nodeID, nodeName: hello.nodeName, endpoint: endpoint, agentVersion: hello.agentVersion, macOSVersion: hello.macOSVersion, xcodeVersions: hello.xcodeVersions, capabilities: hello.capabilities, maxConcurrentTasks: hello.maxConcurrentTasks, state: .online, activeTaskIDs: [], lastHeartbeatAt: Date())
        BMMacAgentNodeStore.upsert(node)
        return node
    }

    func heartbeat() async throws -> BMMacAgentNodeSnapshot {
        let (data, response) = try await URLSession.shared.data(for: request(path: "/buildmate/v1/heartbeat"))
        try validate(response)
        let beat = try JSONDecoder().decode(BMMacAgentHeartbeat.self, from: data)
        guard beat.protocolVersion == BMMacAgentProtocol.version else { throw E.msg("Mac Agent 心跳协议不兼容") }
        let old = BMMacAgentNodeStore.load().first { $0.nodeID == beat.nodeID }
        let node = BMMacAgentNodeSnapshot(nodeID: beat.nodeID, nodeName: old?.nodeName ?? beat.nodeID, endpoint: endpoint, agentVersion: old?.agentVersion ?? "未知", macOSVersion: old?.macOSVersion ?? "未知", xcodeVersions: old?.xcodeVersions ?? [], capabilities: old?.capabilities ?? [], maxConcurrentTasks: old?.maxConcurrentTasks ?? 1, state: beat.state, activeTaskIDs: beat.activeTaskIDs, lastHeartbeatAt: beat.sentAt)
        BMMacAgentNodeStore.upsert(node)
        return node
    }

    func dispatch(_ task: BMMacAgentTaskEnvelope) async throws -> BMMacAgentRunReceipt {
        let body = try JSONEncoder().encode(task)
        let (data, response) = try await URLSession.shared.data(for: request(path: "/buildmate/v1/tasks", method: "POST", body: body))
        try validate(response)
        let receipt = try JSONDecoder().decode(BMMacAgentRunReceipt.self, from: data)
        guard receipt.protocolVersion == BMMacAgentProtocol.version, receipt.taskID == task.id, receipt.acceptedSourceSHA256 == task.sourceSHA256 else { throw E.msg("Mac Agent 回执与 Task/Source SHA 不一致") }
        return receipt
    }

    func recover(taskID: String, runID: String) async throws -> BMMacAgentRunState {
        let safeTask = taskID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? taskID
        let safeRun = runID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? runID
        let (data, response) = try await URLSession.shared.data(for: request(path: "/buildmate/v1/tasks/\(safeTask)/runs/\(safeRun)"))
        try validate(response)
        let state = try JSONDecoder().decode(BMMacAgentRunState.self, from: data)
        guard state.protocolVersion == BMMacAgentProtocol.version, state.taskID == taskID, state.runID == runID else { throw E.msg("Mac Agent 恢复回执不一致") }
        return state
    }

    func artifacts(taskID: String, runID: String) async throws -> [BMMacAgentArtifactReceipt] {
        let t = taskID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? taskID
        let r = runID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? runID
        let (data, response) = try await URLSession.shared.data(for: request(path: "/buildmate/v1/tasks/\(t)/runs/\(r)/artifacts"))
        try validate(response)
        let list = try JSONDecoder().decode(BMMacAgentArtifactList.self, from: data)
        guard list.protocolVersion == BMMacAgentProtocol.version, list.taskID == taskID, list.runID == runID else { throw E.msg("Artifact 列表与 Task/Run 不一致") }
        return list.artifacts
    }

    func downloadArtifact(taskID: String, runID: String, receipt: BMMacAgentArtifactReceipt, workspaceID: String, sourceSHA256: String) async throws -> URL {
        let t = taskID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? taskID
        let r = runID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? runID
        let a = receipt.artifactID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? receipt.artifactID
        let (data, response) = try await URLSession.shared.data(for: request(path: "/buildmate/v1/tasks/\(t)/runs/\(r)/artifacts/\(a)/download"))
        try validate(response)
        guard BMMacArtifactVerifier.verify(data, receipt: receipt) else { throw E.msg("Artifact SHA256/字节数校验失败") }
        let destination = try BMMacArtifactVerifier.destinationURL(fileName: receipt.fileName)
        try data.write(to: destination, options: .atomic)
        BMArtifactLedgerStore.upsert(.init(id: receipt.artifactID, workspaceID: workspaceID, taskID: taskID, sourceSHA256: sourceSHA256, providerID: "private-mac-agent", runID: runID, kind: (receipt.fileName as NSString).pathExtension.lowercased(), fileName: receipt.fileName, localPath: destination.path, byteCount: receipt.bytes, checksumSHA256: receipt.sha256, verified: true, createdAt: Date()))
        return destination
    }

    private func validate(_ response: URLResponse) throws {
        guard let h=response as? HTTPURLResponse,(200...299).contains(h.statusCode) else{throw E.msg("Mac Agent 请求失败")}
    }
    private enum E:LocalizedError{case msg(String);var errorDescription:String?{if case .msg(let s)=self{return s};return nil}}
}
