import Foundation
import Compression

enum BMZipBackupReaderError: LocalizedError {
    case noBackupFile
    case unsupportedCompression
    case malformedArchive

    var errorDescription: String? {
        switch self {
        case .noBackupFile: return "ZIP 里没有找到 BuildMate .bmbak 备份。"
        case .unsupportedCompression: return "ZIP 使用了当前版本不支持的压缩方式。"
        case .malformedArchive: return "ZIP 文件结构损坏。"
        }
    }
}

enum BMZipBackupReader {
    // 读取 ZIP Central Directory，而不是依赖 Local Header 的 size。
    // 这样也支持 iOS/macOS 常见的 data-descriptor ZIP（general purpose bit 3）。
    static func extractBackupData(from data: Data) throws -> Data {
        let bytes = [UInt8](data)
        var offset = 0
        while offset + 46 <= bytes.count {
            if u32(bytes, offset) != 0x02014b50 { offset += 1; continue }

            let method = Int(u16(bytes, offset + 10))
            let compressedSize = Int(u32(bytes, offset + 20))
            let uncompressedSize = Int(u32(bytes, offset + 24))
            let nameLength = Int(u16(bytes, offset + 28))
            let extraLength = Int(u16(bytes, offset + 30))
            let commentLength = Int(u16(bytes, offset + 32))
            let localOffset = Int(u32(bytes, offset + 42))
            let nameStart = offset + 46
            guard nameStart + nameLength <= bytes.count else { throw BMZipBackupReaderError.malformedArchive }
            let name = String(bytes: bytes[nameStart..<(nameStart + nameLength)], encoding: .utf8) ?? ""

            if name.lowercased().hasSuffix(".bmbak") && !name.contains("__MACOSX/") && !name.contains("/._") {
                guard localOffset + 30 <= bytes.count, u32(bytes, localOffset) == 0x04034b50 else { throw BMZipBackupReaderError.malformedArchive }
                let localNameLength = Int(u16(bytes, localOffset + 26))
                let localExtraLength = Int(u16(bytes, localOffset + 28))
                let dataStart = localOffset + 30 + localNameLength + localExtraLength
                guard compressedSize >= 0, dataStart + compressedSize <= bytes.count else { throw BMZipBackupReaderError.malformedArchive }
                let compressed = Data(bytes[dataStart..<(dataStart + compressedSize)])
                switch method {
                case 0:
                    return compressed
                case 8:
                    return try inflate(compressed, expectedSize: uncompressedSize)
                default:
                    throw BMZipBackupReaderError.unsupportedCompression
                }
            }

            offset = nameStart + nameLength + extraLength + commentLength
        }
        throw BMZipBackupReaderError.noBackupFile
    }

    private static func inflate(_ data: Data, expectedSize: Int) throws -> Data {
        guard expectedSize > 0 else { return Data() }
        var output = Data(count: expectedSize)
        let decoded: Int = output.withUnsafeMutableBytes { outBuffer in
            data.withUnsafeBytes { inBuffer in
                guard let outBase = outBuffer.bindMemory(to: UInt8.self).baseAddress,
                      let inBase = inBuffer.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(outBase, expectedSize, inBase, data.count, nil, COMPRESSION_ZLIB)
            }
        }
        guard decoded > 0 else { throw BMZipBackupReaderError.malformedArchive }
        output.count = decoded
        return output
    }

    private static func u16(_ b: [UInt8], _ i: Int) -> UInt16 {
        UInt16(b[i]) | (UInt16(b[i + 1]) << 8)
    }

    private static func u32(_ b: [UInt8], _ i: Int) -> UInt32 {
        UInt32(b[i]) | (UInt32(b[i + 1]) << 8) | (UInt32(b[i + 2]) << 16) | (UInt32(b[i + 3]) << 24)
    }
}
