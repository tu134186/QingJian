import Foundation
import Network

@MainActor
final class BMMacAgentBonjourDiscovery: ObservableObject {
    @Published private(set) var records: [BMMacAgentDiscoveryRecord] = []
    @Published private(set) var searching = false
    private var browser: NWBrowser?

    func start() {
        stop(); searching = true
        let browser = NWBrowser(for: .bonjour(type: "_buildmate._tcp", domain: nil), using: .tcp)
        self.browser = browser
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            let mapped = results.compactMap { result -> BMMacAgentDiscoveryRecord? in
                guard case let .service(name, _, _, _) = result.endpoint else { return nil }
                // Endpoint host/port is resolved by Network.framework when connected; use service URL marker here.
                return .init(id: name, name: name, host: name + ".local", port: 8765)
            }
            Task { @MainActor in self?.records = mapped.sorted { $0.name < $1.name } }
        }
        browser.stateUpdateHandler = { [weak self] state in
            if case .failed = state { Task { @MainActor in self?.searching = false } }
        }
        browser.start(queue: .global(qos: .utility))
    }

    func stop() { browser?.cancel(); browser = nil; searching = false }
}
