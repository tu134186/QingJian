import Foundation
import Security

enum KeychainStore {
    @discardableResult
    static func save(_ value: String, key: String) -> Bool {
        let data = Data(value.utf8)
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key
        ]
        // 先原位更新，避免旧实现“先删后加”在 SecItemAdd 失败时把有效 Token 一并丢掉。
        let update = SecItemUpdate(query as CFDictionary, [kSecValueData: data] as CFDictionary)
        if update == errSecSuccess { return true }
        if update != errSecItemNotFound { return false }
        var add = query
        add[kSecValueData] = data
        return SecItemAdd(add as CFDictionary, nil) == errSecSuccess
    }

    static func read(_ key: String) -> String {
        let q: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &item) == errSecSuccess,
              let d = item as? Data else { return "" }
        return String(data: d, encoding: .utf8) ?? ""
    }
}
