import Foundation
import CryptoKit

/// Build228：App Store Connect 最终发布自动化。
/// JWT 与 Apple 预签名 URL 都只在调用栈/内存存在，不做持久化。
/// 所有写操作均由发布工作台显式按钮触发；“提交审核”另有独立二次确认。
enum AppStoreReleaseAutomationService {
    private static let base = URL(string: "https://api.appstoreconnect.apple.com/v1")!

    static func ensureVersion(jwt: String, appID: String, version: String, copyright: String) async throws -> BMASCVersionSummary {
        if let existing = try await listVersions(jwt: jwt, appID: appID).first(where: { $0.versionString == version }) { return existing }
        let body: [String: Any] = ["data": [
            "type": "appStoreVersions",
            "attributes": [
                "platform": "IOS",
                "versionString": version,
                "copyright": copyright,
                "releaseType": "MANUAL",
                "usesIdfa": false
            ],
            "relationships": ["app": ["data": ["type": "apps", "id": appID]]]
        ]]
        let data = try await request(base.appendingPathComponent("appStoreVersions"), method: "POST", jwt: jwt, json: body)
        return try parseVersion(data)
    }

    static func listVersions(jwt: String, appID: String) async throws -> [BMASCVersionSummary] {
        var c = URLComponents(url: base.appendingPathComponent("apps").appendingPathComponent(appID).appendingPathComponent("appStoreVersions"), resolvingAgainstBaseURL: false)!
        c.queryItems = [URLQueryItem(name: "filter[platform]", value: "IOS"), URLQueryItem(name: "fields[appStoreVersions]", value: "versionString,appStoreState"), URLQueryItem(name: "limit", value: "50")]
        let data = try await request(c.url!, method: "GET", jwt: jwt)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let rows = root["data"] as? [[String: Any]] else { throw BMASCError.malformedResponse }
        return rows.compactMap { row in
            guard let id = row["id"] as? String, let a = row["attributes"] as? [String: Any] else { return nil }
            return .init(id: id, versionString: a["versionString"] as? String ?? "", state: a["appStoreState"] as? String ?? "UNKNOWN")
        }
    }

    static func upsertLocalization(jwt: String, versionID: String, draft: BMAppStoreReleaseDraft, supportURL: String, marketingURL: String) async throws -> BMASCLocalizationSummary {
        let existing = try await listLocalizations(jwt: jwt, versionID: versionID).first(where: { $0.locale == draft.locale })
        var attrs: [String: Any] = [
            "description": draft.descriptionText,
            "keywords": draft.keywords,
            "promotionalText": draft.promotionalText,
            "supportUrl": supportURL,
            "whatsNew": draft.whatsNew
        ]
        if !marketingURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { attrs["marketingUrl"] = marketingURL }
        if let existing {
            let body: [String: Any] = ["data": ["type": "appStoreVersionLocalizations", "id": existing.id, "attributes": attrs]]
            _ = try await request(base.appendingPathComponent("appStoreVersionLocalizations").appendingPathComponent(existing.id), method: "PATCH", jwt: jwt, json: body)
            return existing
        }
        attrs["locale"] = draft.locale
        let body: [String: Any] = ["data": [
            "type": "appStoreVersionLocalizations",
            "attributes": attrs,
            "relationships": ["appStoreVersion": ["data": ["type": "appStoreVersions", "id": versionID]]]
        ]]
        let data = try await request(base.appendingPathComponent("appStoreVersionLocalizations"), method: "POST", jwt: jwt, json: body)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let row = root["data"] as? [String: Any], let id = row["id"] as? String else { throw BMASCError.malformedResponse }
        return .init(id: id, locale: draft.locale)
    }

    static func listLocalizations(jwt: String, versionID: String) async throws -> [BMASCLocalizationSummary] {
        var c = URLComponents(url: base.appendingPathComponent("appStoreVersions").appendingPathComponent(versionID).appendingPathComponent("appStoreVersionLocalizations"), resolvingAgainstBaseURL: false)!
        c.queryItems = [URLQueryItem(name: "fields[appStoreVersionLocalizations]", value: "locale"), URLQueryItem(name: "limit", value: "50")]
        let data = try await request(c.url!, method: "GET", jwt: jwt)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let rows = root["data"] as? [[String: Any]] else { throw BMASCError.malformedResponse }
        return rows.compactMap { row in
            guard let id = row["id"] as? String, let a = row["attributes"] as? [String: Any] else { return nil }
            return .init(id: id, locale: a["locale"] as? String ?? "")
        }
    }

    static func attachBuild(jwt: String, versionID: String, buildID: String) async throws {
        let body: [String: Any] = ["data": ["type": "builds", "id": buildID]]
        _ = try await request(base.appendingPathComponent("appStoreVersions").appendingPathComponent(versionID).appendingPathComponent("relationships").appendingPathComponent("build"), method: "PATCH", jwt: jwt, json: body)
    }

    static func uploadScreenshot(jwt: String, localizationID: String, displayType: String, fileURL: URL, progress: @escaping @Sendable (Double, String) -> Void) async throws -> String {
        let setID = try await ensureScreenshotSet(jwt: jwt, localizationID: localizationID, displayType: displayType)
        let scoped = fileURL.startAccessingSecurityScopedResource(); defer { if scoped { fileURL.stopAccessingSecurityScopedResource() } }
        let attrs = try FileManager.default.attributesOfItem(atPath: fileURL.path)
        let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
        guard size > 0 else { throw BMASCError.invalidIPA("截图文件为空") }
        let body: [String: Any] = ["data": [
            "type": "appScreenshots",
            "attributes": ["fileSize": size, "fileName": fileURL.lastPathComponent],
            "relationships": ["appScreenshotSet": ["data": ["type": "appScreenshotSets", "id": setID]]]
        ]]
        progress(0.05, "预留截图")
        let data = try await request(base.appendingPathComponent("appScreenshots"), method: "POST", jwt: jwt, json: body)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let row = root["data"] as? [String: Any], let screenshotID = row["id"] as? String, let a = row["attributes"] as? [String: Any] else { throw BMASCError.malformedResponse }
        let operations = parseOperations(a["uploadOperations"] as? [[String: Any]] ?? [])
        guard !operations.isEmpty else { throw BMASCError.missingUploadOperations }
        let total = max(Int64(1), operations.reduce(Int64(0)) { $0 + $1.length })
        var sent: Int64 = 0
        for (i, op) in operations.enumerated() {
            let chunk = try readChunk(fileURL, offset: op.offset, length: op.length)
            var req = URLRequest(url: op.url); req.httpMethod = op.method.isEmpty ? "PUT" : op.method; req.timeoutInterval = 180; req.httpBody = chunk
            op.headers.forEach { req.setValue($0.value, forHTTPHeaderField: $0.key) }
            let cfg = URLSessionConfiguration.ephemeral; cfg.urlCache = nil; cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
            let (responseData, response) = try await URLSession(configuration: cfg).data(for: req)
            guard let http = response as? HTTPURLResponse else { throw BMASCError.malformedResponse }
            guard (200...299).contains(http.statusCode) else { throw BMASCError.uploadPart(i + 1, http.statusCode, String(data: responseData, encoding: .utf8) ?? "截图上传失败") }
            sent += op.length; progress(min(0.9, 0.1 + Double(sent) / Double(total) * 0.8), "上传截图分片 \(i + 1)/\(operations.count)")
        }
        let md5 = try checksumMD5(fileURL)
        let commit: [String: Any] = ["data": ["type": "appScreenshots", "id": screenshotID, "attributes": ["uploaded": true, "sourceFileChecksum": md5]]]
        _ = try await request(base.appendingPathComponent("appScreenshots").appendingPathComponent(screenshotID), method: "PATCH", jwt: jwt, json: commit)
        progress(1.0, "截图已提交 Apple 处理")
        return screenshotID
    }

    static func createReviewDraft(jwt: String, appID: String, versionID: String) async throws -> BMASCReviewSubmissionSummary {
        let body: [String: Any] = ["data": ["type": "reviewSubmissions", "relationships": ["app": ["data": ["type": "apps", "id": appID]]]]]
        let data = try await request(base.appendingPathComponent("reviewSubmissions"), method: "POST", jwt: jwt, json: body)
        let submission = try parseReview(data)
        let itemBody: [String: Any] = ["data": [
            "type": "reviewSubmissionItems",
            "relationships": [
                "reviewSubmission": ["data": ["type": "reviewSubmissions", "id": submission.id]],
                "appStoreVersion": ["data": ["type": "appStoreVersions", "id": versionID]]
            ]
        ]]
        _ = try await request(base.appendingPathComponent("reviewSubmissionItems"), method: "POST", jwt: jwt, json: itemBody)
        return submission
    }

    static func submitReview(jwt: String, submissionID: String) async throws -> BMASCReviewSubmissionSummary {
        let body: [String: Any] = ["data": ["type": "reviewSubmissions", "id": submissionID, "attributes": ["submitted": true]]]
        let data = try await request(base.appendingPathComponent("reviewSubmissions").appendingPathComponent(submissionID), method: "PATCH", jwt: jwt, json: body)
        return try parseReview(data)
    }

    private static func ensureScreenshotSet(jwt: String, localizationID: String, displayType: String) async throws -> String {
        var c = URLComponents(url: base.appendingPathComponent("appStoreVersionLocalizations").appendingPathComponent(localizationID).appendingPathComponent("appScreenshotSets"), resolvingAgainstBaseURL: false)!
        c.queryItems = [URLQueryItem(name: "filter[screenshotDisplayType]", value: displayType), URLQueryItem(name: "fields[appScreenshotSets]", value: "screenshotDisplayType"), URLQueryItem(name: "limit", value: "10")]
        let data = try await request(c.url!, method: "GET", jwt: jwt)
        if let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let rows = root["data"] as? [[String: Any]], let id = rows.first?["id"] as? String { return id }
        let body: [String: Any] = ["data": [
            "type": "appScreenshotSets",
            "attributes": ["screenshotDisplayType": displayType],
            "relationships": ["appStoreVersionLocalization": ["data": ["type": "appStoreVersionLocalizations", "id": localizationID]]]
        ]]
        let created = try await request(base.appendingPathComponent("appScreenshotSets"), method: "POST", jwt: jwt, json: body)
        guard let root = try JSONSerialization.jsonObject(with: created) as? [String: Any], let row = root["data"] as? [String: Any], let id = row["id"] as? String else { throw BMASCError.malformedResponse }
        return id
    }

    private static func parseVersion(_ data: Data) throws -> BMASCVersionSummary {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let row = root["data"] as? [String: Any], let id = row["id"] as? String, let a = row["attributes"] as? [String: Any] else { throw BMASCError.malformedResponse }
        return .init(id: id, versionString: a["versionString"] as? String ?? "", state: a["appStoreState"] as? String ?? "UNKNOWN")
    }

    private static func parseReview(_ data: Data) throws -> BMASCReviewSubmissionSummary {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any], let row = root["data"] as? [String: Any], let id = row["id"] as? String else { throw BMASCError.malformedResponse }
        let a = row["attributes"] as? [String: Any]
        return .init(id: id, state: a?["state"] as? String ?? "READY_FOR_REVIEW")
    }

    private static func request(_ url: URL, method: String, jwt: String, json: [String: Any]? = nil) async throws -> Data {
        let token = jwt.trimmingCharacters(in: .whitespacesAndNewlines); guard !token.isEmpty else { throw BMASCError.invalidToken }
        var req = URLRequest(url: url); req.httpMethod = method; req.timeoutInterval = 45
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization"); req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let json { req.setValue("application/json", forHTTPHeaderField: "Content-Type"); req.httpBody = try JSONSerialization.data(withJSONObject: json) }
        let cfg = URLSessionConfiguration.ephemeral; cfg.urlCache = nil; cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        let (data, response) = try await URLSession(configuration: cfg).data(for: req)
        guard let http = response as? HTTPURLResponse else { throw BMASCError.malformedResponse }
        guard (200...299).contains(http.statusCode) else { throw BMASCError.http(http.statusCode, errorSummary(data) ?? "请求失败") }
        return data
    }

    private static func parseOperations(_ rows: [[String: Any]]) -> [BMASCUploadOperation] {
        rows.compactMap { op in
            guard let text = op["url"] as? String, let url = URL(string: text) else { return nil }
            var headers: [String: String] = [:]
            (op["requestHeaders"] as? [[String: Any]] ?? []).forEach { if let n = $0["name"] as? String, let v = $0["value"] as? String { headers[n] = v } }
            let offset = (op["offset"] as? NSNumber)?.int64Value ?? Int64(op["offset"] as? Int ?? 0)
            let length = (op["length"] as? NSNumber)?.int64Value ?? Int64(op["length"] as? Int ?? 0)
            return .init(method: op["method"] as? String ?? "PUT", url: url, offset: offset, length: length, headers: headers, partNumber: nil)
        }
    }

    private static func readChunk(_ url: URL, offset: Int64, length: Int64) throws -> Data {
        guard length > 0 && length <= Int64(Int.max) else { throw BMASCError.invalidIPA("Apple 返回无效上传范围") }
        let h = try FileHandle(forReadingFrom: url); defer { try? h.close() }; try h.seek(toOffset: UInt64(offset))
        let data = try h.read(upToCount: Int(length)) ?? Data(); guard data.count == Int(length) else { throw BMASCError.invalidIPA("截图分片读取不完整") }; return data
    }

    private static func checksumMD5(_ url: URL) throws -> String {
        let h = try FileHandle(forReadingFrom: url); defer { try? h.close() }; var hasher = Insecure.MD5()
        while true { let d = try h.read(upToCount: 1024 * 1024) ?? Data(); if d.isEmpty { break }; hasher.update(data: d) }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private static func errorSummary(_ data: Data) -> String? {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let errors = root["errors"] as? [[String: Any]], let first = errors.first else { return nil }
        return [first["title"] as? String ?? "", first["detail"] as? String ?? ""].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}
