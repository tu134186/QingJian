import Foundation
import CryptoKit


struct SourceUploadReceipt {
    let localSHA256: String
    let remoteSHA256: String
    let remoteBlobSHA: String?
    let commitSHA: String?
    let byteCount: Int
}

final class GitHubService {
    private static let networkSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.waitsForConnectivity = true
        config.timeoutIntervalForRequest = 90
        config.timeoutIntervalForResource = 180
        return URLSession(configuration: config)
    }()
    let owner: String
    let repo: String
    let token: String

    init(owner: String, repo: String, token: String) {
        self.owner = owner.trimmingCharacters(in: .whitespacesAndNewlines)
        self.repo = repo.trimmingCharacters(in: .whitespacesAndNewlines)
        self.token = token.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func request(_ url: URL, method: String = "GET", body: Data? = nil) -> URLRequest {
        var r = URLRequest(url: url)
        r.httpMethod = method
        r.httpBody = body
        r.timeoutInterval = 90
        r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        r.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        r.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        if body != nil { r.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        return r
    }

    private func isTransientNetworkError(_ code: URLError.Code) -> Bool {
        switch code {
        case .timedOut,
             .notConnectedToInternet,
             .cannotFindHost,
             .dnsLookupFailed,
             .cannotConnectToHost,
             .networkConnectionLost,
             .secureConnectionFailed,
             .internationalRoamingOff,
             .callIsActive,
             .dataNotAllowed:
            return true
        default:
            return false
        }
    }

    private func checkedData(_ request: URLRequest) async throws -> (Data, HTTPURLResponse) {
        let isSafeGET = (request.httpMethod ?? "GET").uppercased() == "GET"
        let maxAttempts = isSafeGET ? 4 : 1
        var attempt = 0
        var data = Data()
        var response: URLResponse?

        while attempt < maxAttempts {
            attempt += 1
            do {
                (data, response) = try await Self.networkSession.data(for: request)
                break
            } catch let e as URLError {
                // V2.9.16：GitHub 查询接口属于幂等 GET。iPhone/VPN/Wi‑Fi 切换时偶发
                // -1001 / -1200 不应直接判定“编译失败”，先指数退避重试。
                if isSafeGET, isTransientNetworkError(e.code), attempt < maxAttempts {
                    let delay = UInt64(1 << (attempt - 1)) * 1_000_000_000
                    try? await Task.sleep(nanoseconds: delay)
                    continue
                }
                let stage = request.url?.path ?? "GitHub API"
                let reason: String
                switch e.code {
                case .notConnectedToInternet: reason = "设备当前没有可用网络"
                case .timedOut: reason = "请求超时"
                case .cannotFindHost, .dnsLookupFailed: reason = "DNS/域名解析失败"
                case .cannotConnectToHost: reason = "无法连接 GitHub 服务器"
                case .networkConnectionLost: reason = "网络连接中途断开"
                case .secureConnectionFailed: reason = "HTTPS 安全连接失败"
                case .serverCertificateUntrusted: reason = "HTTPS 证书不受信任"
                default: reason = e.localizedDescription
                }
                let retryText = isSafeGET ? "（已自动重试 \(attempt) 次）" : ""
                throw NSError(domain: "GitHub.Network", code: e.errorCode, userInfo: [NSLocalizedDescriptionKey: "GitHub 网络错误：\(reason)\(retryText)\n阶段：\(stage)\n错误码：\(e.errorCode)"])
            }
        }

        guard let response else {
            throw NSError(domain: "GitHub.Network", code: -1, userInfo: [NSLocalizedDescriptionKey: "GitHub 网络请求没有返回响应"])
        }
        guard let http = response as? HTTPURLResponse else {
            throw NSError(domain: "GitHub", code: -1, userInfo: [NSLocalizedDescriptionKey: "GitHub 没有返回有效响应"])
        }
        guard (200...299).contains(http.statusCode) else {
            var message = "GitHub 请求失败（HTTP \(http.statusCode)）"
            if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                if let m = obj["message"] as? String, !m.isEmpty { message += "：\(m)" }
                if let errors = obj["errors"] as? [[String: Any]], !errors.isEmpty {
                    let details = errors.compactMap { item -> String? in
                        if let m = item["message"] as? String, !m.isEmpty { return m }
                        let field = item["field"] as? String ?? ""
                        let code = item["code"] as? String ?? ""
                        if !field.isEmpty || !code.isEmpty { return [field, code].filter { !$0.isEmpty }.joined(separator: ": ") }
                        return nil
                    }
                    if !details.isEmpty { message += "（" + details.joined(separator: "；") + "）" }
                }
            }
            if http.statusCode == 401 { message += "。请检查 Token 是否正确或已过期。" }
            if http.statusCode == 403 {
                message += "。当前 Token 权限不足或触发 GitHub 限制。"
                if let accepted = http.value(forHTTPHeaderField: "X-Accepted-GitHub-Permissions"), !accepted.isEmpty {
                    message += " GitHub 要求权限：\(accepted)。"
                }
                if let remaining = http.value(forHTTPHeaderField: "X-RateLimit-Remaining"), remaining == "0" {
                    message += " API 请求额度已用完，请等待重置。"
                }
            }
            if http.statusCode == 400 { message += "。请求格式被 GitHub/中间网络判定异常；BuildMate 会在写入链中先回读远端内容，再决定是否安全重试，避免重复提交。" }
            if http.statusCode == 404 { message += "。请检查 Owner、仓库名，以及 Token 是否被授权访问这个仓库。" }
            if http.statusCode == 422 { message += "。仓库名称可能已存在、不可用，或请求参数未通过 GitHub 校验。" }
            throw NSError(domain: "GitHub", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: message])
        }
        return (data, http)
    }

    func diagnostics() async -> GitHubDiagnostics {
        var repoOK = false
        var actionsReadOK = false
        var messages: [String] = []
        var rate = "未读取"

        do {
            let account = try await currentAccount()
            messages.append("Token / 登录：正常（@\(account.login)）")
        } catch {
            messages.append("Token / 登录：\(error.localizedDescription)")
        }

        do {
            let info = try await repoInfo()
            repoOK = true
            messages.append("Repository access：正常（\(info.fullName)）")
            messages.append(info.canPush ? "Contents 写入能力：GitHub 返回可写" : "Contents 写入能力：⚠️ GitHub 返回不可写，请检查 Contents → Read and write")
            do {
                _ = try await readFile(path: ".github/workflows/buildmate.yml", branch: info.defaultBranch)
                messages.append("Workflow 文件读取：正常")
            } catch {
                let ns = error as NSError
                if ns.code == 404 {
                    messages.append("Workflow 文件读取：尚未部署或当前 Token 看不到该路径")
                } else {
                    messages.append("Workflow 文件读取：\(error.localizedDescription)")
                }
            }
        } catch {
            messages.append("Repository access：\(error.localizedDescription)")
        }

        do {
            let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/actions/runs?per_page=1")!
            let (_, http) = try await checkedData(request(url))
            actionsReadOK = true
            let remain = http.value(forHTTPHeaderField: "X-RateLimit-Remaining") ?? "?"
            let limit = http.value(forHTTPHeaderField: "X-RateLimit-Limit") ?? "?"
            if let raw = http.value(forHTTPHeaderField: "X-RateLimit-Reset"), let t = TimeInterval(raw) {
                let f = DateFormatter(); f.dateFormat = "HH:mm"
                rate = "\(remain)/\(limit) · \(f.string(from: Date(timeIntervalSince1970: t))) 重置"
            } else { rate = "\(remain)/\(limit)" }
            messages.append("Actions 读取：正常")
        } catch { messages.append("Actions 读取：\(error.localizedDescription)") }

        messages.append("Workflows 写入：不做破坏性探测；部署/编译时会精确验证")
        messages.append("删除仓库：需 Administration → Read and write（体检不会执行删除）")
        return GitHubDiagnostics(repoReadOK: repoOK, actionsReadOK: actionsReadOK, rateLimitText: rate, summary: messages.joined(separator: "\n"))
    }

    func cancelWorkflowRun(id: Int64) async throws {
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/actions/runs/\(id)/cancel")!
        _ = try await checkedData(request(url, method: "POST"))
    }

    func currentAccount() async throws -> GitHubAccount {
        let url = URL(string: "https://api.github.com/user")!
        let (d, _) = try await checkedData(request(url))
        guard let o = try JSONSerialization.jsonObject(with: d) as? [String: Any],
              let login = o["login"] as? String, !login.isEmpty else {
            throw NSError(domain: "GitHub", code: -3, userInfo: [NSLocalizedDescriptionKey: "无法读取 GitHub 用户信息"])
        }
        return GitHubAccount(login: login)
    }

    func accessibleRepositories(maxPages: Int = 10) async throws -> [GitHubRepository] {
        let formatter = ISO8601DateFormatter()
        var result: [GitHubRepository] = []
        for page in 1...maxPages {
            var comps = URLComponents(string: "https://api.github.com/user/repos")!
            comps.queryItems = [
                URLQueryItem(name: "per_page", value: "100"),
                URLQueryItem(name: "page", value: String(page)),
                URLQueryItem(name: "sort", value: "updated"),
                URLQueryItem(name: "direction", value: "desc"),
                URLQueryItem(name: "affiliation", value: "owner,collaborator,organization_member")
            ]
            let (d, _) = try await checkedData(request(comps.url!))
            guard let items = try JSONSerialization.jsonObject(with: d) as? [[String: Any]] else { break }
            for item in items {
                guard let name = item["name"] as? String,
                      let full = item["full_name"] as? String,
                      let ownerObj = item["owner"] as? [String: Any],
                      let login = ownerObj["login"] as? String else { continue }
                result.append(GitHubRepository(
                    fullName: full, owner: login, name: name,
                    isPrivate: item["private"] as? Bool ?? false,
                    defaultBranch: item["default_branch"] as? String ?? "main",
                    updatedAt: (item["updated_at"] as? String).flatMap { formatter.date(from: $0) }
                ))
            }
            if items.count < 100 { break }
        }
        return result
    }

    func createRepository(name: String, description: String?, isPrivate: Bool, autoInit: Bool = true) async throws -> GitHubRepository {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty else {
            throw NSError(domain: "GitHub", code: -20, userInfo: [NSLocalizedDescriptionKey: "仓库名称不能为空。"])
        }
        let url = URL(string: "https://api.github.com/user/repos")!
        var payload: [String: Any] = [
            "name": cleanName,
            "private": isPrivate,
            "auto_init": autoInit
        ]
        if let description, !description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            payload["description"] = description.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        let body = try JSONSerialization.data(withJSONObject: payload)
        let (data, _) = try await checkedData(request(url, method: "POST", body: body))
        guard let item = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let name = item["name"] as? String,
              let full = item["full_name"] as? String,
              let ownerObj = item["owner"] as? [String: Any],
              let login = ownerObj["login"] as? String else {
            throw NSError(domain: "GitHub", code: -21, userInfo: [NSLocalizedDescriptionKey: "GitHub 已创建仓库，但 BuildMate 无法读取仓库信息。"] )
        }
        let formatter = ISO8601DateFormatter()
        return GitHubRepository(
            fullName: full,
            owner: login,
            name: name,
            isPrivate: item["private"] as? Bool ?? isPrivate,
            defaultBranch: item["default_branch"] as? String ?? "main",
            updatedAt: (item["updated_at"] as? String).flatMap { formatter.date(from: $0) }
        )
    }

    /// V2.7.8：确保空仓库真正拥有第一个提交和默认分支。
    /// GitHub 官方说明：空仓库可以通过 Contents API 创建内容来完成初始化。
    /// 这里故意不传 branch；对完全空的仓库传一个尚不存在的 main 会得到 404。
    func ensureRepositoryInitialized(branch: String) async throws {
        let encodedBranch = branch.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? branch
        let refURL = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/git/ref/heads/\(encodedBranch)")!

        do {
            _ = try await checkedData(request(refURL))
            return
        } catch {
            let ns = error as NSError
            guard ns.code == 404 else { throw error }
        }

        // 仓库存在但还没有任何分支：用 README 产生第一个 commit。
        let path = "README.md"
        let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        let putURL = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        let readme = "# \(repo)\n\nInitialized by BuildMate.\n"
        let payload: [String: Any] = [
            "message": "BuildMate: initialize repository",
            "content": Data(readme.utf8).base64EncodedString()
        ]
        let body = try JSONSerialization.data(withJSONObject: payload)
        do {
            _ = try await checkedData(request(putURL, method: "PUT", body: body))
        } catch {
            let ns = error as NSError
            if ns.code == 404 {
                throw NSError(domain: "BuildMate.RepositoryAccess", code: 404, userInfo: [NSLocalizedDescriptionKey:
                    "仓库已经存在，但当前 Token 无法读取或写入这个仓库，因此 BuildMate 不能创建第一个提交。\n\n如果你使用 Fine-grained Token，请把 Repository access 改为 All repositories，或手动把这个仓库加入允许列表；并给 Contents: Read and write、Workflows: Read and write。"
                ])
            }
            throw error
        }
    }

    func waitForRepositoryReady(branch: String, attempts: Int = 10) async throws {
        var lastError: Error?
        for attempt in 1...max(1, attempts) {
            do {
                _ = try await repoInfo()
                let encodedBranch = branch.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? branch
                let refURL = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/git/ref/heads/\(encodedBranch)")!
                _ = try await checkedData(request(refURL))
                return
            } catch {
                lastError = error
                if attempt < attempts {
                    try await Task.sleep(nanoseconds: 1_000_000_000)
                }
            }
        }
        let detail = lastError?.localizedDescription ?? "未知错误"
        throw NSError(
            domain: "GitHub.RepositoryReady",
            code: (lastError as NSError?)?.code ?? -22,
            userInfo: [NSLocalizedDescriptionKey: "仓库已经存在，但默认分支 \(branch) 暂时无法访问。BuildMate 已自动重试。\n\n\(detail)"]
        )
    }

    func existingRepository(owner expectedOwner: String, name: String) async throws -> GitHubRepository? {
        let service = GitHubService(owner: expectedOwner, repo: name, token: token)
        do {
            let info = try await service.repoInfo()
            return GitHubRepository(
                fullName: info.fullName,
                owner: expectedOwner,
                name: name,
                isPrivate: info.isPrivate,
                defaultBranch: info.defaultBranch,
                updatedAt: nil
            )
        } catch {
            let ns = error as NSError
            if ns.code == 404 { return nil }
            throw error
        }
    }

    /// V2.9.17：修改当前仓库可见性。GitHub 要求仓库 Administration 写权限。
    /// 只修改 private 字段，不改源码、Actions、默认分支或编译 Workflow。
    func setRepositoryPrivate(_ makePrivate: Bool) async throws -> GitHubRepoInfo {
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)")!
        let body = try JSONSerialization.data(withJSONObject: ["private": makePrivate])
        let (d, _) = try await checkedData(request(url, method: "PATCH", body: body))
        let o = try JSONSerialization.jsonObject(with: d) as? [String: Any]
        let permissions = o?["permissions"] as? [String: Any]
        return GitHubRepoInfo(
            fullName: o?["full_name"] as? String ?? "\(owner)/\(repo)",
            defaultBranch: o?["default_branch"] as? String ?? "main",
            isPrivate: o?["private"] as? Bool ?? makePrivate,
            canPush: permissions?["push"] as? Bool ?? false
        )
    }

    func deleteRepository() async throws {
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)")!
        _ = try await checkedData(request(url, method: "DELETE"))
    }

    func repoInfo() async throws -> GitHubRepoInfo {
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)")!
        let (d, _) = try await checkedData(request(url))
        let o = try JSONSerialization.jsonObject(with: d) as? [String: Any]
        let permissions = o?["permissions"] as? [String: Any]
        let canPush = permissions?["push"] as? Bool ?? false
        return GitHubRepoInfo(fullName: o?["full_name"] as? String ?? "\(owner)/\(repo)", defaultBranch: o?["default_branch"] as? String ?? "main", isPrivate: o?["private"] as? Bool ?? false, canPush: canPush)
    }

    /// V2.8.0：内容相同则不重复提交，减少 API 请求，也避免每次编译都重写 Workflow。
    /// 返回 true 表示发生了远端写入，false 表示远端已是相同内容。
    func putIfChanged(path: String, data: Data, message: String, branch: String) async throws -> Bool {
        do {
            let current = try await readFile(path: path, branch: branch)
            if current == data { return false }
        } catch {
            let ns = error as NSError
            if ns.code != 404 { throw error }
        }
        try await put(path: path, data: data, message: message, branch: branch)
        return true
    }

    static func sha256Hex(_ data: Data) -> String {
        SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    func branchHeadSHA(branch: String) async throws -> String {
        let encodedBranch = branch.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? branch
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/git/ref/heads/\(encodedBranch)")!
        let (data, _) = try await checkedData(request(url))
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let target = obj["object"] as? [String: Any],
              let sha = target["sha"] as? String, !sha.isEmpty else {
            throw NSError(domain: "GitHub", code: -73, userInfo: [NSLocalizedDescriptionKey: "无法读取 GitHub 分支 HEAD SHA。"] )
        }
        return sha
    }

    /// 上传后从目标分支重新读取并逐字节校验，防止界面已换新 ZIP、远端仍保留旧 app.zip。
    /// 只有远端内容与本地完全一致才允许继续 dispatch。
    ///
    /// GitHub Contents API 对 1 MB 以上文件在 JSON 模式下可能返回 content="" / encoding=none，
    /// 因此源码 ZIP 校验必须使用 raw media type 读取真实字节，不能把空 content 误判成远端空文件。
    func putAndVerify(path: String, data: Data, message: String, branch: String, attempts: Int = 3) async throws -> SourceUploadReceipt {
        let verifyAttempts = max(1, attempts)
        let localHash = Self.sha256Hex(data)
        let receipt = try await putWithReceipt(path: path, data: data, message: message, branch: branch)
        var lastRemoteCount: Int?
        var lastRemoteHash: String?
        var sawEmptyRead = false

        for attempt in 1...verifyAttempts {
            if attempt > 1 {
                try await Task.sleep(nanoseconds: UInt64(attempt - 1) * 1_000_000_000)
            } else {
                try await Task.sleep(nanoseconds: 450_000_000)
            }

            do {
                guard let remote = try await readRawFile(path: path, branch: branch) else {
                    if attempt == verifyAttempts {
                        throw NSError(domain: "GitHub", code: -71, userInfo: [NSLocalizedDescriptionKey: "GitHub 回读校验失败：连续 \(verifyAttempts) 次无法读取 \(path)。已阻止启动编译。"] )
                    }
                    continue
                }

                lastRemoteCount = remote.count
                let remoteHash = Self.sha256Hex(remote)
                lastRemoteHash = remoteHash

                if remote.isEmpty && !data.isEmpty {
                    sawEmptyRead = true
                    if attempt < verifyAttempts { continue }
                    throw NSError(domain: "GitHub", code: -74, userInfo: [NSLocalizedDescriptionKey: "GitHub 源码回读异常：远端连续返回 0 B 空内容。\n本地：\(data.count) B · SHA-256：\(localHash)\n已阻止启动 Codemagic，请稍后重试。"] )
                }

                if remote == data && remoteHash == localHash {
                    return SourceUploadReceipt(localSHA256: localHash, remoteSHA256: remoteHash, remoteBlobSHA: receipt.blobSHA, commitSHA: receipt.commitSHA, byteCount: data.count)
                }

                if attempt == verifyAttempts {
                    throw NSError(domain: "GitHub", code: -71, userInfo: [NSLocalizedDescriptionKey: "GitHub 回读校验失败：\(path) 真实指纹不一致。\n本地 SHA-256：\(localHash)\n远端 SHA-256：\(remoteHash)\n本地：\(data.count) B / 远端：\(remote.count) B。已阻止启动编译。"] )
                }
            } catch {
                let ns = error as NSError
                if ns.code == -74 || (ns.code == -71 && attempt == verifyAttempts) { throw error }
                if attempt == verifyAttempts { throw error }
            }
        }

        if sawEmptyRead {
            throw NSError(domain: "GitHub", code: -74, userInfo: [NSLocalizedDescriptionKey: "GitHub 源码回读异常：远端返回空内容，已阻止启动 Codemagic。"] )
        }
        let suffix = lastRemoteCount.map { "远端：\($0) B" } ?? "远端字节数未知"
        let hashSuffix = lastRemoteHash.map { " · SHA-256：\($0)" } ?? ""
        throw NSError(domain: "GitHub", code: -72, userInfo: [NSLocalizedDescriptionKey: "GitHub 上传校验失败。\n\(suffix)\(hashSuffix)"] )
    }

    /// Build126：Contents API 更新文件时，读取旧 SHA 与 PUT 之间如果远端刚好发生变化，
    /// GitHub 会返回 409 `does not match`。这属于乐观锁冲突，不代表源码损坏。
    /// 安全做法是重新读取最新 SHA 后仅重试一次；仍冲突就停止，绝不盲目覆盖。
    /// Build145：GitHub 写入改为“回读优先 + 幂等恢复”。
    /// 对 Contents API 的 400 / 409 / 5xx / 弱网异常，不盲目重复 PUT：
    /// 先读取远端真实字节并比较 SHA-256；若第一请求其实已成功，则直接接管该结果；
    /// 只有远端仍不是目标内容时，才重新读取最新 blob SHA 并安全重试。
    private func putWithReceipt(path: String, data: Data, message: String, branch: String) async throws -> (blobSHA: String?, commitSHA: String?) {
        let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        let putURL = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        let localHash = Self.sha256Hex(data)
        var lastError: Error?

        func readCurrentSHA() async throws -> String? {
            var comps = URLComponents(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
            comps.queryItems = [URLQueryItem(name: "ref", value: branch)]
            do {
                let (old, _) = try await checkedData(request(comps.url!))
                if let obj = try? JSONSerialization.jsonObject(with: old) as? [String: Any] { return obj["sha"] as? String }
                return nil
            } catch {
                let ns = error as NSError
                if ns.code == 404 { return nil }
                throw error
            }
        }

        func remoteAlreadyMatches() async -> Bool {
            guard let remote = try? await readRawFile(path: path, branch: branch) else { return false }
            return remote.count == data.count && Self.sha256Hex(remote) == localHash
        }

        for uploadAttempt in 1...3 {
            let sha = try await readCurrentSHA()
            var payload: [String: Any] = ["message": message, "content": data.base64EncodedString(), "branch": branch]
            if let sha { payload["sha"] = sha }
            let body = try JSONSerialization.data(withJSONObject: payload)

            do {
                let (responseData, _) = try await checkedData(request(putURL, method: "PUT", body: body))
                let obj = try? JSONSerialization.jsonObject(with: responseData) as? [String: Any]
                let content = obj?["content"] as? [String: Any]
                let commit = obj?["commit"] as? [String: Any]
                return (content?["sha"] as? String, commit?["sha"] as? String)
            } catch {
                lastError = error
                let ns = error as NSError
                let text = ns.localizedDescription.lowercased()
                let recoverableHTTP = ns.code == 400 || ns.code == 409 || (500...599).contains(ns.code)
                let recoverableNetwork = ns.domain == "GitHub.Network"
                let shaConflict = ns.code == 409 || text.contains("does not match")

                // 最关键的一步：响应坏掉/超时不代表 PUT 没成功。先以远端真实内容为准。
                if recoverableHTTP || recoverableNetwork {
                    if await remoteAlreadyMatches() {
                        let head = try? await branchHeadSHA(branch: branch)
                        return (sha, head)
                    }
                }

                guard uploadAttempt < 3, recoverableHTTP || recoverableNetwork else {
                    if shaConflict {
                        throw NSError(domain: "GitHub.SourceConflict", code: 409, userInfo: [NSLocalizedDescriptionKey: "GitHub 文件更新发生并发冲突。BuildMate 已回读远端确认未完成目标写入，并刷新最新 SHA 重试；为避免覆盖错误内容，本轮已安全停止。\n\n\(error.localizedDescription)"])
                    }
                    throw error
                }

                let delay = UInt64(uploadAttempt) * 900_000_000
                try? await Task.sleep(nanoseconds: delay)
            }
        }

        throw lastError ?? NSError(domain: "GitHub.Write", code: -90, userInfo: [NSLocalizedDescriptionKey: "GitHub 写入失败：已执行远端回读确认与安全重试，仍未完成目标内容写入。"] )
    }

    func put(path: String, data: Data, message: String, branch: String) async throws {
        _ = try await putWithReceipt(path: path, data: data, message: message, branch: branch)
    }

    func delete(path: String, message: String, branch: String) async throws {
        let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        var comps = URLComponents(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        comps.queryItems = [URLQueryItem(name: "ref", value: branch)]
        let (old, response) = try await URLSession.shared.data(for: request(comps.url!))
        guard let http = response as? HTTPURLResponse else { return }
        if http.statusCode == 404 { return }
        guard (200...299).contains(http.statusCode),
              let obj = try? JSONSerialization.jsonObject(with: old) as? [String: Any],
              let sha = obj["sha"] as? String else {
            _ = try await checkedData(request(comps.url!))
            return
        }
        let target = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        let body = try JSONSerialization.data(withJSONObject: ["message": message, "sha": sha, "branch": branch])
        _ = try await checkedData(request(target, method: "DELETE", body: body))
    }

    private func isWorkflowDispatch422(_ error: Error) -> Bool {
        let ns = error as NSError
        let combined = [
            error.localizedDescription,
            ns.localizedDescription,
            String(describing: error),
            ns.userInfo[NSLocalizedDescriptionKey] as? String ?? ""
        ].joined(separator: " ").lowercased()

        // Build 1028：不要再只依赖 NSError.code。真实设备上某些 async/bridging 路径
        // 会保留“HTTP 422 / Unexpected inputs”文本，但 code 不一定稳定透传为 422。
        // workflow_dispatch 的 422 不会创建 Run，因此兼容降级重试是安全的。
        return ns.code == 422
            || combined.contains("http 422")
            || combined.contains("（http 422）")
            || combined.contains("unexpected inputs provided")
            || combined.contains("unexpected input")
    }

    /// GitHub 官方 workflow_dispatch：直接要求 GitHub 返回真实 Run ID。
    /// 不再 dispatch 后扫描“最新 Run”进行猜测匹配。
    func dispatch(branch: String, mode: String = "full", expectedSourceSHA256: String? = nil, expectedSourceBytes: Int? = nil, sourceName: String? = nil, expectedHeadSHA: String? = nil) async throws -> GitHubWorkflowRun {
        var fullInputs: [String: String] = ["mode": mode]
        if let expectedSourceSHA256, !expectedSourceSHA256.isEmpty { fullInputs["expected_source_sha256"] = expectedSourceSHA256 }
        if let expectedSourceBytes { fullInputs["expected_source_bytes"] = String(expectedSourceBytes) }
        if let sourceName, !sourceName.isEmpty { fullInputs["source_name"] = String(sourceName.prefix(120)) }
        if let expectedHeadSHA, !expectedHeadSHA.isEmpty { fullInputs["expected_head_sha"] = expectedHeadSHA }

        var lastError: Error?
        let attempts: [[String: String]] = [fullInputs, ["mode": mode], [:]]
        for (index, candidateInputs) in attempts.enumerated() {
            do {
                return try await dispatchWorkflow(fileName: "buildmate.yml", branch: branch, inputs: candidateInputs)
            } catch {
                lastError = error
                guard index < attempts.count - 1, isWorkflowDispatch422(error) else { throw error }
            }
        }
        throw lastError ?? NSError(domain: "GitHub.Dispatch", code: 422, userInfo: [NSLocalizedDescriptionKey: "GitHub Actions workflow_dispatch 兼容重试全部失败。"])
    }

    /// POST /actions/workflows/{workflow}/dispatches + return_run_details=true
    /// GitHub 成功时必须返回 HTTP 200 和 workflow_run_id/run_url/html_url。
    func dispatchWorkflow(fileName: String, branch: String, inputs: [String: String] = [:]) async throws -> GitHubWorkflowRun {
        let encoded = fileName.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? fileName
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/actions/workflows/\(encoded)/dispatches")!
        let payload: [String: Any] = ["ref": branch, "inputs": inputs, "return_run_details": true]
        let body = try JSONSerialization.data(withJSONObject: payload)
        var req = request(url, method: "POST", body: body)
        // return_run_details 是 GitHub 当前 REST API 的官方能力；显式使用当前版本。
        req.setValue("2026-03-10", forHTTPHeaderField: "X-GitHub-Api-Version")
        let (data, http) = try await checkedData(req)
        guard http.statusCode == 200 else {
            throw NSError(domain: "GitHub.Dispatch", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: "GitHub 未返回真实 Run 详情（HTTP \(http.statusCode)），已停止，绝不猜 Run ID。"])
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let runID = (obj["workflow_run_id"] as? NSNumber)?.int64Value,
              runID > 0,
              let runURL = obj["run_url"] as? String,
              let htmlURL = obj["html_url"] as? String else {
            throw NSError(domain: "GitHub.Dispatch", code: -757, userInfo: [NSLocalizedDescriptionKey: "GitHub dispatch 已响应，但缺少 workflow_run_id/run_url/html_url，已停止，绝不扫描最新 Run。"])
        }
        let expectedAPI = "/repos/\(owner)/\(repo)/actions/runs/\(runID)"
        let expectedWeb = "github.com/\(owner)/\(repo)/actions/runs/\(runID)"
        guard runURL.contains(expectedAPI), htmlURL.lowercased().contains(expectedWeb.lowercased()) else {
            throw NSError(domain: "GitHub.Dispatch", code: -758, userInfo: [NSLocalizedDescriptionKey: "GitHub 返回的 Run 不属于当前仓库 \(owner)/\(repo)，已拒绝继续。"])
        }
        return GitHubWorkflowRun(id: runID, status: "queued", conclusion: nil, htmlURL: htmlURL, createdAt: Date())
    }

    func latestWorkflowRun() async throws -> GitHubWorkflowRun? {
        try await latestWorkflowRun(fileName: "buildmate.yml")
    }

    func latestWorkflowRun(fileName: String) async throws -> GitHubWorkflowRun? {
        let encoded = fileName.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? fileName
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/actions/workflows/\(encoded)/runs?event=workflow_dispatch&per_page=5")!
        let (d, _) = try await checkedData(request(url))
        guard let obj = try JSONSerialization.jsonObject(with: d) as? [String: Any], let runs = obj["workflow_runs"] as? [[String: Any]], let first = runs.first else { return nil }
        let formatter = ISO8601DateFormatter()
        return GitHubWorkflowRun(id: (first["id"] as? NSNumber)?.int64Value ?? 0, status: first["status"] as? String ?? "unknown", conclusion: first["conclusion"] as? String, htmlURL: first["html_url"] as? String, createdAt: (first["created_at"] as? String).flatMap { formatter.date(from: $0) })
    }

    func workflowRun(id: Int64) async throws -> GitHubWorkflowRun? {
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/actions/runs/\(id)")!
        do {
            let (d, _) = try await checkedData(request(url))
            guard let item = try JSONSerialization.jsonObject(with: d) as? [String: Any] else { return nil }
            let formatter = ISO8601DateFormatter()
            return GitHubWorkflowRun(
                id: (item["id"] as? NSNumber)?.int64Value ?? id,
                status: item["status"] as? String ?? "unknown",
                conclusion: item["conclusion"] as? String,
                htmlURL: item["html_url"] as? String,
                createdAt: (item["created_at"] as? String).flatMap { formatter.date(from: $0) }
            )
        } catch {
            let ns = error as NSError
            if ns.code == 404 { return nil }
            throw error
        }
    }

    func buildReport(branch: String) async throws -> BuildReport? {
        let encoded = ".buildmate/latest-report.json".addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)!
        var comps = URLComponents(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        comps.queryItems = [URLQueryItem(name: "ref", value: branch), URLQueryItem(name: "t", value: String(Date().timeIntervalSince1970))]
        let (data, response) = try await URLSession.shared.data(for: request(comps.url!))
        guard let http = response as? HTTPURLResponse else { return nil }
        if http.statusCode == 404 { return nil }
        guard (200...299).contains(http.statusCode) else { _ = try await checkedData(request(comps.url!)); return nil }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any], let b64 = obj["content"] as? String, let decoded = Data(base64Encoded: b64.replacingOccurrences(of: "\n", with: "")) else { return nil }
        return try JSONDecoder().decode(BuildReport.self, from: decoded)
    }

    func artifacts(runID: Int64) async throws -> [GitHubArtifact] {
        let url = URL(string: "https://api.github.com/repos/\(owner)/\(repo)/actions/runs/\(runID)/artifacts")!
        let (d, _) = try await checkedData(request(url))
        guard let obj = try JSONSerialization.jsonObject(with: d) as? [String: Any], let items = obj["artifacts"] as? [[String: Any]] else { return [] }
        return items.compactMap { a in
            guard let id = (a["id"] as? NSNumber)?.int64Value, let name = a["name"] as? String, let u = a["archive_download_url"] as? String else { return nil }
            return GitHubArtifact(id: id, name: name, downloadURL: u, expired: a["expired"] as? Bool ?? false)
        }
    }

    func downloadArtifact(_ artifact: GitHubArtifact) async throws -> URL {
        guard let url = URL(string: artifact.downloadURL) else { throw NSError(domain: "GitHub", code: -2, userInfo: [NSLocalizedDescriptionKey: "Artifact 下载地址无效"]) }
        let (data, _) = try await checkedData(request(url))
        let safe = artifact.name.replacingOccurrences(of: "/", with: "-")
        let out = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe).zip")
        try data.write(to: out, options: .atomic)
        return out
    }


    private func readGETAllow404(_ req: URLRequest) async throws -> (Data, HTTPURLResponse)? {
        var attempt = 0
        while attempt < 4 {
            attempt += 1
            do {
                let (data, response) = try await Self.networkSession.data(for: req)
                guard let http = response as? HTTPURLResponse else {
                    throw NSError(domain: "GitHub.Network", code: -1, userInfo: [NSLocalizedDescriptionKey: "GitHub 没有返回有效 HTTP 响应。"] )
                }
                if http.statusCode == 404 { return nil }
                guard (200...299).contains(http.statusCode) else { _ = try await checkedData(req); return nil }
                return (data, http)
            } catch let e as URLError {
                if isTransientNetworkError(e.code), attempt < 4 {
                    try? await Task.sleep(nanoseconds: UInt64(1 << (attempt - 1)) * 1_000_000_000)
                    continue
                }
                throw e
            }
        }
        return nil
    }

    /// 读取仓库文件真实字节。用于 app.zip 等大文件的上传后校验。
    /// GitHub Contents API 的默认 JSON 表示在文件 >1 MB 时可能不给 base64 content，
    /// raw media type 则直接返回文件内容，可避免把 2 MB+ ZIP 错读成 0 B。
    func readRawFile(path: String, branch: String) async throws -> Data? {
        let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        var comps = URLComponents(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        comps.queryItems = [URLQueryItem(name: "ref", value: branch), URLQueryItem(name: "t", value: String(Date().timeIntervalSince1970))]
        var req = request(comps.url!)
        req.setValue("application/vnd.github.raw+json", forHTTPHeaderField: "Accept")
        return try await readGETAllow404(req)?.0
    }

    func readFile(path: String, branch: String) async throws -> Data? {
        let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? path
        var comps = URLComponents(string: "https://api.github.com/repos/\(owner)/\(repo)/contents/\(encoded)")!
        comps.queryItems = [URLQueryItem(name: "ref", value: branch), URLQueryItem(name: "t", value: String(Date().timeIntervalSince1970))]
        guard let (data, _) = try await readGETAllow404(request(comps.url!)) else { return nil }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any], let b64 = obj["content"] as? String else { return nil }
        return Data(base64Encoded: b64.replacingOccurrences(of: "\n", with: ""))
    }

    func repairContext(branch: String) async throws -> RepairContext? {
        guard let data = try await readFile(path: ".buildmate/repair-context.json", branch: branch) else { return nil }
        return try JSONDecoder().decode(RepairContext.self, from: data)
    }

    func waitForRepairContext(branch: String, expectedRunID: Int64?, timeoutSeconds: Int = 45) async throws -> RepairContext? {
        let deadline = Date().addingTimeInterval(TimeInterval(timeoutSeconds))
        var last: RepairContext?
        while Date() < deadline {
            if let context = try await repairContext(branch: branch) {
                last = context
                let runMatches = expectedRunID == nil || context.runID == expectedRunID
                if runMatches && !context.files.isEmpty { return context }
            }
            try await Task.sleep(nanoseconds: 3_000_000_000)
        }
        return last
    }

    /// 只轮询 dispatch 官方返回的同一个 Run ID。
    func waitForCompletedRun(id: Int64, timeoutSeconds: Int = 900, onState: @escaping (GitHubWorkflowRun) -> Void) async throws -> GitHubWorkflowRun {
        let deadline = Date().addingTimeInterval(TimeInterval(timeoutSeconds))
        var transientFailures = 0
        var lastTransientError: Error?
        while Date() < deadline {
            do {
                guard let run = try await workflowRun(id: id) else {
                    throw NSError(domain: "GitHub.Run", code: 404, userInfo: [NSLocalizedDescriptionKey: "GitHub 官方返回 Run #\(id)，但当前仓库无法读取该 Run，已停止。"])
                }
                transientFailures = 0
                lastTransientError = nil
                onState(run)
                if run.status == "completed" { return run }
            } catch {
                let ns = error as NSError
                if ns.domain == "GitHub.Network" {
                    transientFailures += 1; lastTransientError = error
                } else { throw error }
            }
            try await Task.sleep(nanoseconds: 5_000_000_000)
        }
        if let lastTransientError {
            throw NSError(domain: "GitHub.NetworkWait", code: -9, userInfo: [NSLocalizedDescriptionKey: "等待 GitHub Run #\(id) 超时，期间网络波动 \(transientFailures) 次：\(lastTransientError.localizedDescription)"])
        }
        throw NSError(domain: "GitHub.Run", code: -9, userInfo: [NSLocalizedDescriptionKey: "等待 GitHub Run #\(id) 完成超时。"])
    }

    func waitForNewCompletedRun(after previousID: Int64?, timeoutSeconds: Int = 900, onState: @escaping (GitHubWorkflowRun) -> Void) async throws -> GitHubWorkflowRun {
        try await waitForNewCompletedRun(workflowFile: "buildmate.yml", after: previousID, timeoutSeconds: timeoutSeconds, onState: onState)
    }

    func waitForNewCompletedRun(workflowFile: String, after previousID: Int64?, timeoutSeconds: Int = 900, onState: @escaping (GitHubWorkflowRun) -> Void) async throws -> GitHubWorkflowRun {
        let deadline = Date().addingTimeInterval(TimeInterval(timeoutSeconds))
        var seenNew = false
        var transientFailures = 0
        var lastTransientError: Error?

        while Date() < deadline {
            do {
                if let run = try await latestWorkflowRun(fileName: workflowFile) {
                    transientFailures = 0
                    lastTransientError = nil
                    if previousID == nil || run.id != previousID { seenNew = true }
                    if seenNew {
                        onState(run)
                        if run.status == "completed" { return run }
                    }
                }
            } catch {
                let ns = error as NSError
                // checkedData 已对单次 GET 做 4 次重试；若仍是临时网络错误，
                // 也只跳过本轮轮询，绝不能把云端正在运行的编译标成失败。
                if ns.domain == "GitHub.Network" {
                    transientFailures += 1
                    lastTransientError = error
                } else {
                    throw error
                }
            }
            try await Task.sleep(nanoseconds: 5_000_000_000)
        }

        if let lastTransientError {
            throw NSError(domain: "GitHub.NetworkWait", code: -9, userInfo: [NSLocalizedDescriptionKey: "等待 GitHub Run 超时，期间网络连续波动 \(transientFailures) 次。云端编译不一定失败，可稍后刷新继续读取。最后错误：\(lastTransientError.localizedDescription)"])
        }
        throw NSError(domain: "GitHub", code: -9, userInfo: [NSLocalizedDescriptionKey: "等待 GitHub 编译超时。云端编译不一定失败，可稍后点刷新继续查看。"])
    }

}


struct GitHubDiagnostics {
    let repoReadOK: Bool
    let actionsReadOK: Bool
    let rateLimitText: String
    let summary: String
}
