import Foundation

enum BMPersistedFileKind {
    case source
    case icon
    case effect

    var defaultsKey: String {
        switch self {
        case .source: return "persisted-source-name-v1"
        case .icon: return "persisted-icon-name-v1"
        case .effect: return "persisted-central-effect-name-v1"
        }
    }

    var fallbackName: String {
        switch self {
        case .source: return "BuildMate-Source.zip"
        case .icon: return "BuildMate-OverrideIcon.png"
        case .effect: return "BuildMate-CentralEffect.png"
        }
    }
}

enum BMLocalFileStore {
    static func importedDirectory() throws -> URL {
        let fm = FileManager.default
        guard let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw NSError(domain: "BuildMate.LocalFileStore", code: 1, userInfo: [NSLocalizedDescriptionKey: "无法访问 BuildMate 本地存储目录。"])
        }
        let dir = base.appendingPathComponent("BuildMate/Imported", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func persistPickedFile(_ pickedURL: URL, kind: BMPersistedFileKind) throws -> URL {
        let scoped = pickedURL.startAccessingSecurityScopedResource()
        defer { if scoped { pickedURL.stopAccessingSecurityScopedResource() } }

        let fm = FileManager.default
        guard fm.fileExists(atPath: pickedURL.path) else {
            throw NSError(domain: "BuildMate.LocalFileStore", code: 2, userInfo: [NSLocalizedDescriptionKey: "选择的文件已经不可访问，请重新选择。"])
        }
        let dir = try importedDirectory()
        let rawName = pickedURL.lastPathComponent.isEmpty ? kind.fallbackName : pickedURL.lastPathComponent
        let safeName = rawName.replacingOccurrences(of: "/", with: "-")
        let destination = dir.appendingPathComponent(safeName, isDirectory: false)

        if let oldName = UserDefaults.standard.string(forKey: kind.defaultsKey) {
            let oldURL = dir.appendingPathComponent(oldName)
            if oldURL.path != destination.path { try? fm.removeItem(at: oldURL) }
        }
        if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
        try fm.copyItem(at: pickedURL, to: destination)
        guard fm.fileExists(atPath: destination.path) else {
            throw NSError(domain: "BuildMate.LocalFileStore", code: 3, userInfo: [NSLocalizedDescriptionKey: "源码复制完成后校验失败。"])
        }
        let attrs = try fm.attributesOfItem(atPath: destination.path)
        let byteCount = (attrs[.size] as? NSNumber)?.intValue ?? 0
        guard byteCount > 100 else {
            try? fm.removeItem(at: destination)
            throw NSError(domain: "BuildMate.LocalFileStore", code: 4, userInfo: [NSLocalizedDescriptionKey: "文件为空或不完整。"])
        }
        UserDefaults.standard.set(safeName, forKey: kind.defaultsKey)
        return destination
    }

    static func suggestedArtifactBaseName(for source: URL, repository: String) -> String {
        let base = source.deletingPathExtension().lastPathComponent
        return base.isEmpty ? (repository.isEmpty ? "BuildMate-Artifact" : repository) : base
    }

    static func safeFileComponent(_ text: String, fallback: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let source = trimmed.isEmpty ? fallback : trimmed
        let invalid = CharacterSet(charactersIn: "/\\:*?\"<>|")
        return source.components(separatedBy: invalid).joined(separator: "-")
    }

    static func persistDownloadedArtifact(
        _ rawURL: URL,
        kind: String?,
        runID: Int64,
        repository: String,
        artifactCategory: String,
        artifactFileName: String,
        categoryOverride: String? = nil,
        fileNameOverride: String? = nil
    ) throws -> URL {
        let fm = FileManager.default
        guard let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw NSError(domain: "BuildMate.LocalFileStore", code: 5, userInfo: [NSLocalizedDescriptionKey: "无法访问 BuildMate 产物目录。"])
        }
        let categoryValue = artifactCategory.trimmingCharacters(in: .whitespacesAndNewlines)
        let effectiveCategory = categoryValue.isEmpty ? (repository.isEmpty ? "未分类" : repository) : categoryValue
        let rawCategory = categoryOverride ?? effectiveCategory
        let category = safeFileComponent(rawCategory, fallback: repository.isEmpty ? "未分类" : repository)
        let dir = base.appendingPathComponent("BuildMate/Artifacts", isDirectory: true).appendingPathComponent(category, isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let baseName = repository.isEmpty ? "BuildMate" : repository
        let fallback = baseName + "-" + ((kind ?? "IPA").uppercased()) + "-Run-" + String(runID)
        let name = safeFileComponent(fileNameOverride ?? artifactFileName, fallback: fallback)
        let destination = dir.appendingPathComponent(name + ".zip")
        if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
        try fm.copyItem(at: rawURL, to: destination)
        return destination
    }
}

extension BMLocalFileStore {
    static func persistVerifiedArtifactData(_ data: Data, fileName: String, provider: String, runID: String) throws -> URL {
        guard !data.isEmpty else {
            throw NSError(domain: "BuildMate.LocalFileStore", code: 20, userInfo: [NSLocalizedDescriptionKey: "产物数据为空，无法保存。"])
        }
        let fm = FileManager.default
        guard let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw NSError(domain: "BuildMate.LocalFileStore", code: 21, userInfo: [NSLocalizedDescriptionKey: "无法访问 BuildMate 产物目录。"])
        }
        let providerDir = safeFileComponent(provider, fallback: "Provider")
        let dir = base.appendingPathComponent("BuildMate/Artifacts", isDirectory: true).appendingPathComponent(providerDir, isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let fallback = "BuildMate-" + providerDir + "-" + safeFileComponent(runID, fallback: "Run") + ".ipa"
        var safeName = safeFileComponent(fileName, fallback: fallback)
        if !safeName.lowercased().hasSuffix(".ipa") && !safeName.lowercased().hasSuffix(".zip") && !safeName.lowercased().hasSuffix(".deb") {
            safeName += ".ipa"
        }
        let destination = dir.appendingPathComponent(safeName, isDirectory: false)
        if fm.fileExists(atPath: destination.path) { try fm.removeItem(at: destination) }
        try data.write(to: destination, options: .atomic)
        let attrs = try fm.attributesOfItem(atPath: destination.path)
        let size = (attrs[.size] as? NSNumber)?.intValue ?? 0
        guard size == data.count else {
            try? fm.removeItem(at: destination)
            throw NSError(domain: "BuildMate.LocalFileStore", code: 22, userInfo: [NSLocalizedDescriptionKey: "产物落盘后大小校验失败。"])
        }
        return destination
    }
}
