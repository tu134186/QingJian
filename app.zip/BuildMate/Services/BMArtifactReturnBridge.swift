import Foundation

struct BMArtifactRelayResult {
    let data: Data
    let name: String
    let kind: String
    let receipt: BMCodemagicRelayReceipt
}

enum BMArtifactReturnBridge {
    /// 读取 Codemagic publishing 写入的任务专属 Git Relay。
    /// 这里只读既有分支；不会触发编译、不会写仓库、不会自动调度。
    static func fetch(
        github: GitHubService,
        recovery: CodemagicArtifactRecoveryRecord,
        expectedTaskID: String? = nil
    ) async throws -> BMArtifactRelayResult {
        guard let branch = recovery.relayBranch, !branch.isEmpty,
              let receiptPath = recovery.relayPath, !receiptPath.isEmpty else {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 1, userInfo: [NSLocalizedDescriptionKey: "当前任务没有 Artifact Return Bridge 路径。"])
        }
        guard let receiptData = try await github.readFile(path: receiptPath, branch: branch) else {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 2, userInfo: [NSLocalizedDescriptionKey: "Artifact Return receipt 尚未出现。"])
        }
        let receipt = try JSONDecoder().decode(BMCodemagicRelayReceipt.self, from: receiptData)
        guard receipt.buildID == recovery.buildID else {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 3, userInfo: [NSLocalizedDescriptionKey: "Relay receipt 的 Build ID 与当前任务不一致。"])
        }
        if let expectedTaskID, !expectedTaskID.isEmpty, receipt.taskID != expectedTaskID {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 4, userInfo: [NSLocalizedDescriptionKey: "Relay receipt 的 Task ID 与当前任务不一致。"])
        }
        if let source = recovery.sourceSHA256, !source.isEmpty, !receipt.sourceSHA256.isEmpty, source != receipt.sourceSHA256 {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 5, userInfo: [NSLocalizedDescriptionKey: "Relay receipt 的 Source SHA 与当前源码不一致。"])
        }
        guard let artifact = try await github.readRawFile(path: receipt.artifactPath, branch: branch) else {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 6, userInfo: [NSLocalizedDescriptionKey: "Relay receipt 已出现，但成品文件尚未可读。"])
        }
        guard artifact.count == receipt.byteCount else {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 7, userInfo: [NSLocalizedDescriptionKey: "Relay 成品字节数不匹配，已阻止保存。"])
        }
        let sha = GitHubService.sha256Hex(artifact)
        guard sha.caseInsensitiveCompare(receipt.sha256) == .orderedSame else {
            throw NSError(domain: "BuildMate.ArtifactRelay", code: 8, userInfo: [NSLocalizedDescriptionKey: "Relay 成品 SHA-256 不匹配，已阻止保存。"])
        }
        let kind = receipt.artifactKind.uppercased() == "DEB" ? "DEB" : "IPA"
        return BMArtifactRelayResult(data: artifact, name: receipt.artifactName, kind: kind, receipt: receipt)
    }
}
