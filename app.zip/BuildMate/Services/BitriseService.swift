import Foundation

struct BitriseStoredConfig {
    var token: String
    var appSlug: String
    var workflow: String
    var branch: String
    var isReady: Bool { !token.trimmed.isEmpty && !appSlug.trimmed.isEmpty && !workflow.trimmed.isEmpty && !branch.trimmed.isEmpty }
    static func load() -> Self { .init(token: KeychainStore.read("bitrise-api-token"), appSlug: UserDefaults.standard.string(forKey: "bitrise-app-slug") ?? "", workflow: UserDefaults.standard.string(forKey: "bitrise-workflow") ?? "primary", branch: UserDefaults.standard.string(forKey: "bitrise-branch") ?? "main") }
}

struct BitriseBuildState {
    let slug: String; let status: Int; let statusText: String
    var isFinished: Bool { [0,1,2,3].contains(status) && status != 0 ? true : ["success","error","failed","aborted"].contains(statusText.lowercased()) }
    var succeeded: Bool { status == 1 || statusText.lowercased() == "success" }
}

final class BitriseService {
    private let token: String, appSlug: String, workflow: String, branch: String
    private let base = URL(string: "https://api.bitrise.io/v0.1/")!
    init(token: String, appSlug: String, workflow: String, branch: String) { self.token=token.trimmed; self.appSlug=appSlug.trimmed; self.workflow=workflow.trimmed; self.branch=branch.trimmed }
    func testConnection() async throws -> String { _ = try await json("apps/\(appSlug)", "GET", nil); return "✅ Bitrise 已连接" }
    func startBuild() async throws -> String {
        let body:[String:Any] = ["hook_info":["type":"bitrise"], "build_params":["branch":branch,"workflow_id":workflow]]
        let o = try await json("apps/\(appSlug)/builds", "POST", body)
        let data = (o["data"] as? [String:Any]) ?? o
        guard let slug = data["build_slug"] as? String ?? data["slug"] as? String else { throw E.msg("Bitrise 没有返回 build slug") }
        return slug
    }
    func abort(buildSlug slug:String) async throws {
        _ = try await json("apps/\(appSlug)/builds/\(slug)/abort", "POST", ["abort_reason":"Stopped from BuildMate", "skip_notifications":true])
    }
    func state(_ slug:String) async throws -> BitriseBuildState {
        let o = try await json("apps/\(appSlug)/builds/\(slug)", "GET", nil); let d=(o["data"] as? [String:Any]) ?? o
        return .init(slug: slug, status: d["status"] as? Int ?? -1, statusText: d["status_text"] as? String ?? "running")
    }
    func wait(_ slug:String, update:@escaping(BitRiseUpdate)->Void) async throws -> BitriseBuildState {
        let deadline=Date().addingTimeInterval(1800); var last:BitriseBuildState?
        while Date()<deadline { let s=try await state(slug); last=s; update(.init(text:s.statusText)); if s.isFinished { return s }; try await Task.sleep(nanoseconds:5_000_000_000) }
        if let last { return last }; throw E.msg("等待 Bitrise 超时")
    }
    func ipa(buildSlug slug:String) async throws -> (String,Data) {
        let a=try await json("apps/\(appSlug)/builds/\(slug)/artifacts", "GET", nil)
        guard let item=(a["data"] as? [[String:Any]])?.first(where:{ (($0["title"] as? String) ?? "").lowercased().hasSuffix(".ipa") }), let artifactSlug=item["slug"] as? String else { throw E.msg("Bitrise 构建成功但未找到 IPA") }
        let detail=try await json("apps/\(appSlug)/builds/\(slug)/artifacts/\(artifactSlug)", "GET", nil); let d=(detail["data"] as? [String:Any]) ?? detail
        guard let u=d["expiring_download_url"] as? String ?? d["public_install_page_url"] as? String, let url=URL(string:u) else { throw E.msg("Bitrise IPA 没有下载地址") }
        let (bytes,r)=try await URLSession.shared.data(from:url); guard (r as? HTTPURLResponse).map({200...299 ~= $0.statusCode}) ?? false, bytes.count>100_000 else { throw E.msg("Bitrise IPA 下载异常") }
        return ((item["title"] as? String) ?? "BuildMate-Bitrise.ipa",bytes)
    }
    private func json(_ path:String,_ method:String,_ body:[String:Any]?) async throws -> [String:Any] {
        guard let url=URL(string:path,relativeTo:base) else { throw E.msg("Bitrise URL 无效") }; var r=URLRequest(url:url); r.httpMethod=method; r.setValue(token,forHTTPHeaderField:"Authorization"); r.setValue("application/json",forHTTPHeaderField:"Content-Type"); if let body { r.httpBody=try JSONSerialization.data(withJSONObject:body) }
        let (d,res)=try await URLSession.shared.data(for:r); guard let h=res as? HTTPURLResponse,(200...299).contains(h.statusCode) else { throw E.msg("Bitrise HTTP \((res as? HTTPURLResponse)?.statusCode ?? -1)：\(String(String(data:d,encoding:.utf8)?.prefix(300) ?? ""))") }; guard let o=try JSONSerialization.jsonObject(with:d) as? [String:Any] else { throw E.msg("Bitrise 返回数据无法识别") }; return o
    }
    private enum E:LocalizedError { case msg(String); var errorDescription:String? { if case .msg(let s)=self{return s};return nil } }
}
struct BitRiseUpdate { let text:String }
private extension String { var trimmed:String { trimmingCharacters(in:.whitespacesAndNewlines) } }
