import Foundation

struct BMSourceWorkspaceSnapshot {
    var sourceURL: URL?
    var iconURL: URL?
    var sourceSizeText: String
    var sourceSHA256: String
    var sourceMissing: Bool
    var iconMissing: Bool
}

/// Build220：源码工作副本的持久化恢复/清理收口。
/// 只负责本地文件与 UserDefaults，不创建云端 Run、不改 AI/黑匣子状态。
enum BMSourceWorkspaceStore {
    static func restore() throws -> BMSourceWorkspaceSnapshot {
        let dir = try BMLocalFileStore.importedDirectory()
        let fm = FileManager.default

        var sourceURL: URL?
        var iconURL: URL?
        var sourceSizeText = ""
        var sourceSHA256 = ""
        var sourceMissing = false
        var iconMissing = false

        if let name = UserDefaults.standard.string(forKey: BMPersistedFileKind.source.defaultsKey) {
            let url = dir.appendingPathComponent(name)
            if fm.fileExists(atPath: url.path) {
                sourceURL = url
                sourceSizeText = BMContentSupport.fileSizeText(url)
                sourceSHA256 = UserDefaults.standard.string(forKey: "current-source-sha256-v1") ?? ""
            } else {
                UserDefaults.standard.removeObject(forKey: BMPersistedFileKind.source.defaultsKey)
                UserDefaults.standard.removeObject(forKey: "current-source-sha256-v1")
                sourceMissing = true
            }
        }

        if let name = UserDefaults.standard.string(forKey: BMPersistedFileKind.icon.defaultsKey) {
            let url = dir.appendingPathComponent(name)
            if fm.fileExists(atPath: url.path) {
                iconURL = url
            } else {
                UserDefaults.standard.removeObject(forKey: BMPersistedFileKind.icon.defaultsKey)
                iconMissing = true
            }
        }

        return BMSourceWorkspaceSnapshot(
            sourceURL: sourceURL,
            iconURL: iconURL,
            sourceSizeText: sourceSizeText,
            sourceSHA256: sourceSHA256,
            sourceMissing: sourceMissing,
            iconMissing: iconMissing
        )
    }

    static func clearWorkingSource(_ sourceURL: URL?) {
        if let sourceURL { try? FileManager.default.removeItem(at: sourceURL) }
        UserDefaults.standard.removeObject(forKey: BMPersistedFileKind.source.defaultsKey)
        UserDefaults.standard.removeObject(forKey: "current-source-sha256-v1")
    }
}
