import Foundation

struct BMGitHubActionsUsage: Equatable {
    let usedMinutes: Double
    let includedMinutes: Double?

    var remainingMinutes: Double? {
        guard let includedMinutes else { return nil }
        return max(0, includedMinutes - usedMinutes)
    }

    var compactText: String {
        if let remainingMinutes { return "剩余 \(Int(remainingMinutes.rounded())) 分钟" }
        return "本月已用 \(Int(usedMinutes.rounded())) 分钟"
    }
}

enum BMGitHubActionsUsageService {
    private struct Viewer: Decodable { let login: String }
    private struct LegacyUsage: Decodable {
        let total_minutes_used: Double
        let included_minutes: Double
    }
    private struct UsageReport: Decodable { let usageItems: [UsageItem] }
    private struct UsageItem: Decodable {
        let product: String?
        let unitType: String?
        let quantity: Double?
        let netQuantity: Double?
        let grossQuantity: Double?
    }

    static func load(token: String) async throws -> BMGitHubActionsUsage {
        let token = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !token.isEmpty else { throw NSError(domain: "BuildMate", code: 401, userInfo: [NSLocalizedDescriptionKey: "GitHub Actions Token 未配置"] ) }
        let viewer: Viewer = try await request("https://api.github.com/user", token: token)

        // GitHub 旧官方 Actions billing endpoint 在可用账户上能直接给 included_minutes，优先用于“剩余分钟”。
        if let legacy: LegacyUsage = try? await request("https://api.github.com/users/\(viewer.login)/settings/billing/actions", token: token) {
            return .init(usedMinutes: legacy.total_minutes_used, includedMinutes: legacy.included_minutes)
        }

        // Enhanced Billing 官方 endpoint。它能可靠返回本月 Actions 实际用量；若账户不返回套餐额度，则只显示“已用”，不猜剩余值。
        let calendar = Calendar(identifier: .gregorian)
        let now = Date()
        let year = calendar.component(.year, from: now)
        let month = calendar.component(.month, from: now)
        let url = "https://api.github.com/users/\(viewer.login)/settings/billing/usage?year=\(year)&month=\(month)"
        let report: UsageReport = try await request(url, token: token)
        let used = report.usageItems.reduce(0.0) { sum, item in
            guard item.product?.lowercased() == "actions", item.unitType?.lowercased() == "minutes" else { return sum }
            return sum + (item.quantity ?? item.netQuantity ?? item.grossQuantity ?? 0)
        }
        return .init(usedMinutes: used, includedMinutes: nil)
    }

    private static func request<T: Decodable>(_ urlString: String, token: String) async throws -> T {
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("2026-03-10", forHTTPHeaderField: "X-GitHub-Api-Version")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            throw NSError(domain: "BuildMate.GitHubBilling", code: code, userInfo: [NSLocalizedDescriptionKey: "GitHub 用量接口 HTTP \(code)"])
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
}
