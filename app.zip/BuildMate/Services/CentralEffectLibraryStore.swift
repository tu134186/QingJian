import Foundation

struct BMCentralEffectImportResult {
    let url: URL
    let libraryNames: [String]
}

enum BMCentralEffectLibraryStore {
    private static let defaultsKey = "central-effect-library-v1"
    private static let maxItems = 30

    static func loadNames() -> [String] {
        UserDefaults.standard.stringArray(forKey: defaultsKey) ?? []
    }

    static func saveNames(_ names: [String]) {
        UserDefaults.standard.set(names, forKey: defaultsKey)
    }

    static func directory() throws -> URL {
        let dir = try BMLocalFileStore.importedDirectory().appendingPathComponent("CentralEffects", isDirectory: true)
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    static func url(for name: String) -> URL? {
        guard let dir = try? directory() else { return nil }
        let url = dir.appendingPathComponent(name)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    static func importFile(_ pickedURL: URL, currentNames: [String]) throws -> BMCentralEffectImportResult {
        let scoped = pickedURL.startAccessingSecurityScopedResource()
        defer { if scoped { pickedURL.stopAccessingSecurityScopedResource() } }

        let fm = FileManager.default
        let dir = try directory()
        let ext = pickedURL.pathExtension.lowercased()
        let base = pickedURL.deletingPathExtension().lastPathComponent
            .replacingOccurrences(of: "/", with: "-")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanBase = base.isEmpty ? "CentralEffect" : base
        var safeName = cleanBase + (ext.isEmpty ? "" : ".\(ext)")
        var destination = dir.appendingPathComponent(safeName)
        var suffix = 2
        while fm.fileExists(atPath: destination.path) {
            safeName = cleanBase + "-\(suffix)" + (ext.isEmpty ? "" : ".\(ext)")
            destination = dir.appendingPathComponent(safeName)
            suffix += 1
        }

        try fm.copyItem(at: pickedURL, to: destination)
        let attrs = try fm.attributesOfItem(atPath: destination.path)
        guard ((attrs[.size] as? NSNumber)?.intValue ?? 0) > 100 else {
            try? fm.removeItem(at: destination)
            throw NSError(domain: "BuildMate.CentralEffectLibraryStore", code: 1, userInfo: [NSLocalizedDescriptionKey: "素材为空或不完整。"])
        }

        var names = currentNames
        names.append(safeName)
        if names.count > maxItems {
            let overflowCount = names.count - maxItems
            let overflow = Array(names.prefix(overflowCount))
            names.removeFirst(overflowCount)
            for old in overflow {
                try? fm.removeItem(at: dir.appendingPathComponent(old))
            }
        }
        saveNames(names)
        return BMCentralEffectImportResult(url: destination, libraryNames: names)
    }

    static func remove(name: String, currentNames: [String]) -> [String] {
        if let dir = try? directory() {
            try? FileManager.default.removeItem(at: dir.appendingPathComponent(name))
        }
        let names = currentNames.filter { $0 != name }
        saveNames(names)
        return names
    }
}
