import SwiftUI

struct MacAgentNodesView: View {
    @StateObject private var manager = BMMacAgentNodeManager()
    @State private var selection: String? = BMMacAgentSelectionStore.selectedNodeID
    @StateObject private var discovery = BMMacAgentBonjourDiscovery()

    var body: some View {
        List {
            Section("节点控制") {
                Button {
                    Task { await manager.refreshConfiguredNode() }
                } label: {
                    Label(manager.refreshing ? "正在刷新…" : "发现 / 刷新已配置节点", systemImage: "arrow.triangle.2.circlepath")
                }.accessibilityIdentifier("ui.1a0151164c71").disabled(manager.refreshing)
                HStack { Text("调度方式"); Spacer(); Text(selection == nil ? "自动选择" : "指定节点").foregroundColor(.secondary) }
                Button("恢复自动选择") { selection = nil; manager.select(nil) }.accessibilityIdentifier("ui.0139b966b718")
                Text(manager.statusText).font(.caption).foregroundColor(.secondary)
                Button {
                    discovery.searching ? discovery.stop() : discovery.start()
                } label: { Label(discovery.searching ? "停止局域网发现" : "自动发现局域网 Mac", systemImage: "dot.radiowaves.left.and.right") }.accessibilityIdentifier("ui.f3178d81f85f")
                if !discovery.records.isEmpty {
                    ForEach(discovery.records) { item in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.name).font(.subheadline)
                            Text("发现服务：\(item.host):\(item.port) · 配对后再写入 Token")
                                .font(.caption2).foregroundColor(.secondary)
                        }
                    }
                }
            }

            Section("Mac Agent 节点") {
                if manager.nodes.isEmpty {
                    Text("暂无已握手节点。先在编译平台配置 Mac Agent 地址，再执行发现/刷新。")
                        .font(.caption).foregroundColor(.secondary)
                } else {
                    ForEach(manager.nodes) { node in
                        Button {
                            selection = node.nodeID
                            manager.select(node.nodeID)
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Image(systemName: selection == node.nodeID ? "checkmark.circle.fill" : "circle")
                                    Text(node.nodeName).font(.headline)
                                    Spacer()
                                    Text(node.isStale ? "离线/过期" : node.state.rawValue).font(.caption)
                                }
                                Text("macOS \(node.macOSVersion) · Xcode \(node.xcodeVersions.joined(separator: ", ").isEmpty ? "未知" : node.xcodeVersions.joined(separator: ", "))")
                                    .font(.caption).foregroundColor(.secondary)
                                Text("并发 \(node.activeTaskIDs.count)/\(max(1, node.maxConcurrentTasks)) · 能力 \(node.capabilities.count) 项")
                                    .font(.caption2).foregroundColor(.secondary)
                                Text("最后心跳：\(node.lastHeartbeatAt.formatted(date: .abbreviated, time: .standard))")
                                    .font(.caption2).foregroundColor(.secondary)
                                HStack {
                                    Label(BMMacAgentPairingStore.isTrusted(nodeID: node.nodeID) ? "已可信配对" : "未可信配对", systemImage: BMMacAgentPairingStore.isTrusted(nodeID: node.nodeID) ? "checkmark.shield.fill" : "shield.lefthalf.filled")
                                    Spacer()
                                    Button(BMMacAgentPairingStore.isTrusted(nodeID: node.nodeID) ? "撤销" : "信任") {
                                        if BMMacAgentPairingStore.isTrusted(nodeID: node.nodeID) { BMMacAgentPairingStore.revoke(nodeID: node.nodeID) } else { BMMacAgentPairingStore.trust(nodeID: node.nodeID) }
                                        manager.reload()
                                    }.accessibilityIdentifier("ui.0950089c65b0").buttonStyle(.bordered)
                                }.font(.caption2)
                            }.padding(.vertical, 4)
                        }.accessibilityIdentifier("ui.25cf13d0d618").buttonStyle(.plain)
                    }
                }
            }

            Section("调度与断线恢复") {
                let decision = BMMacAgentScheduler.choose(from: manager.nodes, preferredNodeID: selection)
                Label(decision.allowed ? "存在可执行节点" : "当前不可派发", systemImage: decision.allowed ? "checkmark.shield" : "exclamationmark.triangle")
                Text(decision.reason).font(.caption).foregroundColor(.secondary)
                Text("节点掉线时 BuildMate 只等待心跳并恢复原 Task/Run；不会因为断线创建第二个云编译任务。")
                    .font(.caption).foregroundColor(.secondary)
            }

            Section("安全边界") {
                Label("Token 仅存 Keychain，不写入节点账本/黑匣子", systemImage: "key.fill")
                Label("Task ID + Source SHA + Run ID 回执必须一致", systemImage: "link")
                Label("节点未验证前不会进入自主编译默认调度", systemImage: "hand.raised.fill")
            }
        }
        .navigationTitle("Mac Agent 节点")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { manager.reload() }
        .onDisappear { discovery.stop() }
    }
}
