import SwiftUI

/// Build178：中央特效内置视觉从 ContentView 抽离。
/// 仅负责纯展示，不持有任务状态，不参与编译/AI/网络主链。
struct BMCentralBuiltInEffectView: View {
    let theme: BMCentralTheme
    let spin: Double
    let accent: Color
    let time: TimeInterval

    @ViewBuilder
    var body: some View {

        let reverse = -spin * 0.36
        let pulse = 0.94 + 0.06 * sin(time * 3.2)

        switch theme {
        case .sharinganPro:
            // Build129：默认写轮眼改为严格数学同心的 SwiftUI 矢量绘制。
            // 外环、瞳孔、三勾玉共享同一几何中心，120° 等分，彻底消除高速旋转时 PNG 视觉偏心造成的左右晃动。
            BMPerfectSharinganView(spin: spin, accent: accent)

        case .aiReactor:
            ZStack {
                ForEach(0..<3, id: \.self) { ring in
                    Circle()
                        .trim(from: Double(ring) * 0.09, to: 0.58 + Double(ring) * 0.10)
                        .stroke(accent.opacity(0.78 - Double(ring) * 0.16), style: StrokeStyle(lineWidth: CGFloat(2.3 - Double(ring) * 0.4), lineCap: .round))
                        .frame(width: CGFloat(68 - ring * 12), height: CGFloat(68 - ring * 12))
                        .rotationEffect(.degrees(ring % 2 == 0 ? spin * (0.82 + Double(ring) * 0.14) : reverse))
                }
                ForEach(0..<4, id: \.self) { i in
                    Circle().fill(i == 0 ? Color.white : accent)
                        .frame(width: i == 0 ? 5 : 4, height: i == 0 ? 5 : 4)
                        .offset(y: -31)
                        .rotationEffect(.degrees(spin * 0.64 + Double(i) * 90))
                        .shadow(color: accent, radius: 4)
                }
                Circle().fill(accent.opacity(0.18)).frame(width: 31, height: 31).scaleEffect(pulse)
                Circle().stroke(Color.white.opacity(0.72), lineWidth: 1.2).frame(width: 23, height: 23)
                Circle().fill(accent).frame(width: 13, height: 13).shadow(color: accent, radius: 8)
                Circle().fill(Color.white).frame(width: 4, height: 4)
            }

        case .mechanicalTurbine:
            ZStack {
                ForEach(0..<12, id: \.self) { i in
                    Capsule()
                        .fill(accent.opacity(i % 3 == 0 ? 0.90 : 0.42))
                        .frame(width: 2.2, height: i % 3 == 0 ? 8 : 5)
                        .offset(y: -34)
                        .rotationEffect(.degrees(Double(i) * 30 + reverse * 0.22))
                }
                Circle().stroke(accent.opacity(0.45), lineWidth: 1.5).frame(width: 61, height: 61)
                ForEach(0..<8, id: \.self) { i in
                    Capsule()
                        .fill(LinearGradient(colors: [accent, accent.opacity(0.20)], startPoint: .top, endPoint: .bottom))
                        .frame(width: 8, height: 25)
                        .clipShape(Capsule())
                        .offset(y: -14)
                        .rotationEffect(.degrees(Double(i) * 45 + spin))
                }
                Circle().fill(Color.black).frame(width: 30, height: 30)
                Circle().stroke(accent, lineWidth: 3).frame(width: 25, height: 25).rotationEffect(.degrees(reverse))
                Circle().fill(accent).frame(width: 10, height: 10).shadow(color: accent, radius: 6)
                Circle().fill(Color.white.opacity(0.9)).frame(width: 3, height: 3)
            }

        case .quantumHex:
            ZStack {
                ForEach(0..<2, id: \.self) { ring in
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .trim(from: ring == 0 ? 0.03 : 0.18, to: ring == 0 ? 0.82 : 0.94)
                        .stroke(accent.opacity(ring == 0 ? 0.86 : 0.52), style: StrokeStyle(lineWidth: ring == 0 ? 2.1 : 1.4, lineCap: .round))
                        .frame(width: ring == 0 ? 61 : 45, height: ring == 0 ? 61 : 45)
                        .rotationEffect(.degrees(ring == 0 ? spin * 0.74 : reverse * 1.18))
                }
                ForEach(0..<6, id: \.self) { i in
                    Rectangle()
                        .fill(i % 2 == 0 ? Color.white : accent)
                        .frame(width: 6, height: 6)
                        .rotationEffect(.degrees(45))
                        .offset(y: -31)
                        .rotationEffect(.degrees(Double(i) * 60 + spin * 0.42))
                        .shadow(color: accent, radius: 4)
                }
                Circle().stroke(accent.opacity(0.8), lineWidth: 1.2).frame(width: 30, height: 30).scaleEffect(pulse)
                RoundedRectangle(cornerRadius: 5).fill(accent.opacity(0.24)).frame(width: 24, height: 24).rotationEffect(.degrees(spin * 0.30))
                Circle().fill(accent).frame(width: 11, height: 11).shadow(color: accent, radius: 8)
                Circle().fill(Color.white).frame(width: 4, height: 4)
            }

        case .plasmaVortex:
            ZStack {
                ForEach(0..<3, id: \.self) { i in
                    Circle()
                        .trim(from: 0.07 + Double(i) * 0.12, to: 0.56 + Double(i) * 0.10)
                        .stroke(AngularGradient(colors: [accent.opacity(0.15), accent, Color.white.opacity(0.9), accent.opacity(0.18)], center: .center), style: StrokeStyle(lineWidth: CGFloat(3.2 - Double(i) * 0.65), lineCap: .round))
                        .frame(width: CGFloat(68 - i * 13), height: CGFloat(68 - i * 13))
                        .rotationEffect(.degrees(i % 2 == 0 ? spin * (0.78 + Double(i) * 0.12) : reverse * 1.1))
                }
                ForEach(0..<5, id: \.self) { i in
                    Circle().fill(i % 2 == 0 ? Color.white : accent)
                        .frame(width: 4.5, height: 4.5)
                        .offset(y: -29)
                        .rotationEffect(.degrees(Double(i) * 72 - spin * 0.52))
                        .shadow(color: accent, radius: 5)
                }
                Circle().fill(accent.opacity(0.16)).frame(width: 36, height: 36).scaleEffect(pulse)
                Circle().stroke(Color.white.opacity(0.72), lineWidth: 1).frame(width: 20, height: 20)
                Circle().fill(accent).frame(width: 12, height: 12).shadow(color: accent, radius: 9)
                Circle().fill(Color.white).frame(width: 3.5, height: 3.5)
            }

        case .darkGoldGyro:
            ZStack {
                ForEach(0..<16, id: \.self) { i in
                    Capsule()
                        .fill(accent.opacity(i % 4 == 0 ? 0.92 : 0.34))
                        .frame(width: 1.8, height: i % 4 == 0 ? 8 : 4)
                        .offset(y: -35)
                        .rotationEffect(.degrees(Double(i) * 22.5 + reverse * 0.18))
                }
                Ellipse().stroke(accent.opacity(0.84), lineWidth: 1.8).frame(width: 66, height: 27).rotationEffect(.degrees(spin * 0.52))
                Ellipse().stroke(Color.white.opacity(0.54), lineWidth: 1.1).frame(width: 64, height: 30).rotationEffect(.degrees(60 + reverse * 0.58))
                Ellipse().stroke(accent.opacity(0.55), lineWidth: 1.4).frame(width: 64, height: 30).rotationEffect(.degrees(120 + spin * 0.44))
                Circle().stroke(accent.opacity(0.72), lineWidth: 2).frame(width: 32, height: 32).rotationEffect(.degrees(reverse))
                Circle().fill(Color.black).frame(width: 21, height: 21)
                Circle().fill(accent).frame(width: 10, height: 10).shadow(color: accent, radius: 8)
                Circle().fill(Color.white.opacity(0.95)).frame(width: 3, height: 3).offset(x: -2.5, y: -2.5)
            }
        }
    
    }
}
