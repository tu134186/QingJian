import SwiftUI
import UIKit

// Build181: build report, history, and repository management presentation extracted from ContentView.
struct CurrentBuildReportSheet: View {
    let report: BuildReport
    let runURL: String?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            List {
                Section("编译结果") {
                    BMKeyValueRow("状态", value: report.headline)
                    if let runID = report.runID { BMKeyValueRow("Run ID", value: "#\(runID)") }
                    if let projectType = report.projectType { BMKeyValueRow("工程", value: projectType) }
                    if let scheme = report.scheme { BMKeyValueRow("Scheme", value: scheme) }
                    if let version = report.version { BMKeyValueRow("版本", value: "\(version) · Build \(report.build ?? "?")") }
                }
                if report.displayName != nil || report.bundleID != nil || report.deploymentTarget != nil {
                    Section("App 信息") {
                        if let name = report.displayName { BMKeyValueRow("名称", value: name) }
                        if let bundleID = report.bundleID { BMKeyValueRow("Bundle ID", value: bundleID) }
                        if let target = report.deploymentTarget { BMKeyValueRow("最低 iOS", value: target) }
                    }
                }
                if let artifact = report.ipaName ?? report.debName ?? report.artifactName {
                    Section("产物") {
                        BMKeyValueRow("文件", value: artifact)
                        if let kind = report.artifactKind { BMKeyValueRow("类型", value: kind) }
                        BMKeyValueRow("验证", value: report.hasVerifiedArtifact ? "已验证" : "未验证")
                    }
                }
                if !report.ok {
                    Section("错误信息") {
                        if let signature = report.errorSignature, !signature.isEmpty {
                            Text(signature).textSelection(.enabled)
                        }
                        if let diagnosis = report.diagnosis, !diagnosis.isEmpty {
                            Text(diagnosis).textSelection(.enabled)
                        }
                    }
                }
                if let warnings = report.warnings, !warnings.isEmpty {
                    Section("提醒") {
                        ForEach(Array(warnings.prefix(8).enumerated()), id: \.offset) { _, warning in
                            Text(warning)
                        }
                    }
                }
                if let runURL, let url = URL(string: runURL) {
                    Section { Link("在 GitHub 查看本次 Run", destination: url).accessibilityIdentifier("ui.aa4b1e32b417") }
                }
            }
            .navigationTitle("编译报告")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() }.accessibilityIdentifier("ui.ddb765feb9cb") } }
        }
    }
}

struct BuildFailureReportSheet: View {
    let reportURL: URL?
    let sourceURL: URL?
    let runID: Int64?
    let runURL: String?
    let failureText: String
    let taskID: String?
    @State private var diagnosticSharePayload: BMDiagnosticSharePayload?
    @State private var isExportingDiagnostic = false
    @State private var diagnosticExportError = ""
    @State private var showingDiagnosticExportError = false
    @State private var rawExpanded = false

    private var reportText: String {
        guard let reportURL else { return failureText }
        return (try? String(contentsOf: reportURL, encoding: .utf8)) ?? failureText
    }
    private var normalized: String { (failureText + "\n" + reportText).lowercased() }
    private var isCancelled: Bool { normalized.contains("用户已停止") || normalized.contains("cancelled") || normalized.contains("canceled") }
    private var hasSourceEvidence: Bool { normalized.contains("真实源码错误") || normalized.contains("compile error") || normalized.contains(" error:") || normalized.contains("repair-context") }
    private var isArtifactFailure: Bool { normalized.contains("artifact") || normalized.contains("产物回传") || normalized.contains("ipa 回传") || normalized.contains("重新抓取 ipa") }
    private var headline: String {
        if isCancelled { return "任务已停止 · 诊断已保留" }
        if hasSourceEvidence { return "真实编译失败" }
        if isArtifactFailure { return "产物回传异常" }
        return "云端链路异常"
    }
    private var subtitle: String { runID.map { "Run #\($0)" } ?? "当前任务" }
    private var diagnosis: String {
        if isCancelled { return "任务由用户停止。BuildMate 已保留本次 Run、黑匣子与诊断数据，不会自动续跑。" }
        if hasSourceEvidence { return "已取得真实编译错误证据。建议根据 BUG 报告修改源码后手动再次编译。" }
        if isArtifactFailure { return "当前更像产物获取/回传问题，不代表源码一定编译失败。优先查看云端详情或尝试重抓产物。" }
        return "当前没有足够证据证明是源码错误。先看任务时间线与云端运行详情，避免误改源码。"
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: BMDesign.Spacing.section) {
                    BMPlainCard {
                        HStack(spacing: 12) {
                            Image(systemName: isCancelled ? "stop.circle.fill" : "exclamationmark.triangle.fill")
                                .font(.title2).foregroundColor(isCancelled ? .orange : .red)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(headline).font(.headline)
                                Text(subtitle).font(.caption).foregroundColor(.secondary)
                            }
                            Spacer()
                        }
                    }

                    BMUnifiedCard("诊断工具", icon: "wrench.and.screwdriver.fill") {
                        HStack(spacing: 10) {
                            NavigationLink(destination: TaskBlackBoxView(taskID: taskID ?? BMTaskBlackBox.shared.latestTaskID)) {
                                diagnosticTile("任务时间线", icon: "waveform.path.ecg.rectangle")
                            }.buttonStyle(.plain)
                            Button { exportDiagnosticBundle() } label: { diagnosticTile(isExportingDiagnostic ? "生成中…" : "导出诊断包", icon: "shippingbox.fill") }
                                .buttonStyle(.plain).disabled(isExportingDiagnostic)
                            if let runURL, let url = URL(string: runURL) {
                                Link(destination: url) { diagnosticTile("云端详情", icon: "arrow.up.right.square") }.buttonStyle(.plain)
                            } else {
                                diagnosticTile("暂无云端", icon: "icloud.slash").opacity(0.55)
                            }
                        }
                    }

                    BMUnifiedCard("错误诊断", icon: "stethoscope") {
                        Text(diagnosis).font(.subheadline).foregroundColor(.primary)
                    }

                    BMUnifiedCard("原始 BUG 报告", icon: "doc.text.magnifyingglass") {
                        Button {
                            withAnimation(BMDesign.Motion.standard) { rawExpanded.toggle() }
                        } label: {
                            HStack {
                                Text(rawExpanded ? "收起原始报告" : "展开原始报告").font(.subheadline.weight(.semibold))
                                Spacer(); Image(systemName: rawExpanded ? "chevron.up" : "chevron.down")
                            }
                        }.buttonStyle(.plain)
                        if rawExpanded {
                            Divider()
                            Text(reportText)
                                .font(.system(.caption, design: .monospaced))
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                }
                .padding(BMDesign.Spacing.page)
            }
            .background(BMTheme.palette.page)
            .navigationTitle("BUG 报告")
            .navigationBarTitleDisplayMode(.inline)
        }
        .sheet(item: $diagnosticSharePayload) { payload in BMBlackBoxShareSheet(items: [payload.url]) }
        .alert("诊断包导出失败", isPresented: $showingDiagnosticExportError) { Button("好", role: .cancel) {} } message: { Text(diagnosticExportError) }
    }

    private func diagnosticTile(_ title: String, icon: String) -> some View {
        VStack(spacing: 7) {
            Image(systemName: icon).font(.system(size: 18, weight: .semibold)).foregroundColor(.blue)
            Text(title).font(.caption2.weight(.semibold)).foregroundColor(.primary).lineLimit(1).minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, minHeight: 66)
        .background(BMTheme.palette.elevated)
        .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.control, style: .continuous))
    }

    private func exportDiagnosticBundle() {
        guard !isExportingDiagnostic else { return }
        isExportingDiagnostic = true
        do {
            let resolved = taskID ?? BMTaskBlackBox.shared.latestTaskID
            let package = try BMDiagnosticPackageBuilder.build(taskID: resolved, reportURL: reportURL, fallbackText: failureText)
            let attrs = try FileManager.default.attributesOfItem(atPath: package.path)
            guard ((attrs[.size] as? NSNumber)?.int64Value ?? 0) > 0 else { throw NSError(domain: "BuildMate.DiagnosticExport", code: 2, userInfo: [NSLocalizedDescriptionKey: "诊断 ZIP 为 0 B。"] ) }
            isExportingDiagnostic = false
            diagnosticSharePayload = BMDiagnosticSharePayload(url: package)
        } catch {
            isExportingDiagnostic = false
            diagnosticExportError = error.localizedDescription
            showingDiagnosticExportError = true
        }
    }
}

struct BuildHistoryView: View {
    let items: [BuildHistoryRecord]
    @State private var filter = "全部"
    private var filtered: [BuildHistoryRecord] {
        if filter == "成功" { return items.filter { $0.result.contains("成功") || $0.result.contains("完成") } }
        if filter == "失败" { return items.filter { $0.result.contains("失败") || $0.result.contains("❌") } }
        return items
    }
    var body: some View {
        List {
            Picker("筛选", selection: $filter) { ForEach(["全部","成功","失败"], id: \.self) { Text($0) } }.accessibilityIdentifier("ui.6777d2b42191").pickerStyle(.segmented)
            ForEach(filtered) { item in
                NavigationLink { BuildHistoryDetailView(item: item) } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(item.result).font(.headline).lineLimit(2)
                        if let repo = item.repository { Text(repo).font(.caption).foregroundColor(.secondary) }
                        HStack { Text("Run #\(item.runID)"); Spacer(); Text(item.dateText) }.font(.caption).foregroundColor(.secondary)
                    }.padding(.vertical, 3)
                }.accessibilityIdentifier("ui.21b632c73a11")
            }
        }.navigationTitle("全部编译历史").navigationBarTitleDisplayMode(.inline)
    }
}

struct BuildHistoryDetailView: View {
    let item: BuildHistoryRecord
    var body: some View {
        List {
            Section("真实编译") {
                BMKeyValueRow("结果", value: item.result)
                BMKeyValueRow("Run ID", value: "#\(item.runID)")
                BMKeyValueRow("时间", value: item.dateText)
                if let repository = item.repository { BMKeyValueRow("仓库", value: repository) }
                if let sourceName = item.sourceName { BMKeyValueRow("源码", value: sourceName) }
            }
            if let artifact = item.artifactName, !artifact.isEmpty {
                Section("最终产物") { BMKeyValueRow("文件", value: artifact) }
            }
            Section {
                Text("历史详情只保存 BuildMate 当时真实拿到的数据；旧版本记录没有保存的字段不会补造。")
                    .font(.caption).foregroundColor(.secondary)
            }
        }
        .navigationTitle("编译详情")
        .navigationBarTitleDisplayMode(.inline)
    }
}
