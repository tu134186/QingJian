import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct ReleaseWorkspaceView: View {
    @State private var metadata = BMReleaseWorkspaceStore.metadata()
    @State private var credential = BMReleaseWorkspaceStore.credentialReference()
    @State private var destination: BMReleaseDestination = .testFlight
    @State private var plans = BMReleaseWorkspaceStore.plans()
    @State private var toast = ""
    @State private var ascJWT = ""
    @State private var ascProbe: BMASCProbeResult?
    @State private var ascChecking = false
    @State private var selectedIPAURL: URL?
    @State private var selectedIPAName = ""
    @State private var selectedIPABytes: Int64 = 0
    @State private var showingIPAImporter = false
    @State private var showingUploadConfirmation = false
    @State private var uploadBusy = false
    @State private var uploadProgress = 0.0
    @State private var uploadStage = ""
    @State private var uploadResult: BMASCUploadResult?
    @State private var releaseDraft = BMAppStoreReleaseDraftStore.load()
    @State private var releaseBusy = false
    @State private var releaseStage = ""
    @State private var selectedScreenshotURL: URL?
    @State private var selectedScreenshotName = ""
    @State private var showingScreenshotImporter = false
    @State private var showingReviewDraftConfirmation = false
    @State private var showingSubmitReviewConfirmation = false

    private var checks: [BMReleaseWorkspaceValidation] {
        BMReleaseWorkspaceStore.validations(metadata: metadata, credential: credential)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                statusCard
                metadataCard
                credentialCard
                liveASCProbeCard
                liveUploadCard
                releaseAutomationCard
                planCard
                historyCard
                safetyCard
                if !toast.isEmpty { Text(toast).font(.caption).foregroundColor(.secondary) }
            }
            .padding(16)
        }
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("发布工作台")
        .navigationBarTitleDisplayMode(.inline)
        .fileImporter(isPresented: $showingIPAImporter, allowedContentTypes: [UTType(filenameExtension: "ipa") ?? .data], allowsMultipleSelection: false) { result in
            do {
                guard let url = try result.get().first else { return }
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
                selectedIPAURL = url
                selectedIPAName = url.lastPathComponent
                selectedIPABytes = (attrs[.size] as? NSNumber)?.int64Value ?? 0
                uploadResult = nil
                toast = "✅ 已选择 IPA：\(url.lastPathComponent)"
            } catch {
                toast = "❌ 选择 IPA 失败：\(error.localizedDescription)"
            }
        }
        .fileImporter(isPresented: $showingScreenshotImporter, allowedContentTypes: [.png, .jpeg], allowsMultipleSelection: false) { result in
            do {
                guard let url = try result.get().first else { return }
                selectedScreenshotURL = url
                selectedScreenshotName = url.lastPathComponent
                toast = "✅ 已选择截图：\(url.lastPathComponent)"
            } catch { toast = "❌ 选择截图失败：\(error.localizedDescription)" }
        }
        .confirmationDialog("创建 App Review 草稿？", isPresented: $showingReviewDraftConfirmation, titleVisibility: .visible) {
            Button("确认创建审核草稿") { createReviewDraft() }.accessibilityIdentifier("ui.1cc9f3bcf32c")
            Button("取消", role: .cancel) { }.accessibilityIdentifier("ui.08741e8a63ff")
        } message: {
            Text("会在 App Store Connect 创建 Review Submission 并加入当前 App Store Version，但不会提交审核。")
        }
        .confirmationDialog("最终提交给 Apple 审核？", isPresented: $showingSubmitReviewConfirmation, titleVisibility: .visible) {
            Button("确认提交审核", role: .destructive) { submitReview() }.accessibilityIdentifier("ui.f9ffce4cbf79")
            Button("取消", role: .cancel) { }.accessibilityIdentifier("ui.1484f458d203")
        } message: {
            Text("这是不可当作普通测试点击的真实外部动作。只有元数据、Build、截图和审核草稿均确认无误后再提交。")
        }
        .confirmationDialog("确认上传 IPA 到 App Store Connect？", isPresented: $showingUploadConfirmation, titleVisibility: .visible) {
            Button("确认真实上传", role: .destructive) { startRealUpload() }.accessibilityIdentifier("ui.114a5f34cadf")
            Button("取消", role: .cancel) { }.accessibilityIdentifier("ui.644607623876")
        } message: {
            Text("此动作会在 Apple 端创建 Build Upload，并真实传输当前 IPA。不会提交审核，也不会正式上线。")
        }
    }

    private var statusCard: some View {
        card("发布资料总览", "shippingbox.fill") {
            let passed = checks.filter(\.passed).count
            HStack {
                metric("通过", passed)
                metric("待补", checks.count - passed)
                metric("计划", plans.count)
            }
            ForEach(checks) { check in
                HStack(alignment: .top, spacing: 9) {
                    Image(systemName: check.passed ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .foregroundColor(check.passed ? .green : .orange).frame(width: 20)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(check.title).font(.caption.weight(.semibold))
                        Text(check.detail).font(.caption2).foregroundColor(.secondary)
                    }
                }
            }
        }
    }

    private var metadataCard: some View {
        card("App Store 元数据", "doc.text.fill") {
            field("App 名称", text: $metadata.appName)
            field("Bundle ID", text: $metadata.bundleID)
            field("SKU", text: $metadata.sku)
            field("主语言", text: $metadata.primaryLocale)
            field("Support URL", text: $metadata.supportURL, keyboard: .URL)
            field("隐私政策 URL", text: $metadata.privacyURL, keyboard: .URL)
            field("Marketing URL（可选）", text: $metadata.marketingURL, keyboard: .URL)
            field("版权信息（可选）", text: $metadata.copyright)
            VStack(alignment: .leading, spacing: 5) {
                Text("审核备注（本机准备）").font(.caption).foregroundColor(.secondary)
                TextEditor(text: $metadata.reviewContactNote)
                    .frame(minHeight: 80)
                    .padding(7)
                    .background(Color(uiColor: .tertiarySystemGroupedBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            Button {
                BMReleaseWorkspaceStore.saveMetadata(metadata)
                toast = "✅ 发布元数据已保存"
            } label: {
                Label("保存元数据", systemImage: "square.and.arrow.down.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.f6fb97a64c97").buttonStyle(.borderedProminent)
        }
    }

    private var credentialCard: some View {
        card("App Store Connect 凭据引用", "key.fill") {
            Text("这里只保存凭据名称和非秘密提示，不保存 .p8 私钥正文。真实 API Adapter 接入时从安全边界按引用取用。")
                .font(.caption).foregroundColor(.secondary)
            field("凭据引用名称", text: $credential.referenceName)
            field("Key ID 提示（可选）", text: $credential.keyIDHint)
            field("Issuer ID 提示（可选）", text: $credential.issuerIDHint)
            Toggle("已在外部安全存储配置", isOn: $credential.configuredExternally).accessibilityIdentifier("ui.e50cce9a0894")
            Button {
                BMReleaseWorkspaceStore.saveCredentialReference(credential)
                toast = "✅ 凭据引用已保存（未保存私钥明文）"
            } label: {
                Label("保存凭据引用", systemImage: "lock.shield.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.b55bd2ff6003").buttonStyle(.bordered)
        }
    }


    private var liveASCProbeCard: some View {
        card("App Store Connect 真实连接", "network") {
            Text("粘贴一个临时 JWT 做真实只读验证。JWT 只存在当前页面内存，离开页面即丢失，不写入 UserDefaults、文件、日志或任务黑匣子。")
                .font(.caption).foregroundColor(.secondary)
            SecureField("临时 JWT（不保存）", text: $ascJWT)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .padding(10)
                .background(Color(uiColor: .tertiarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            Button {
                let token = ascJWT
                ascChecking = true
                ascProbe = nil
                Task {
                    do {
                        let result = try await AppStoreConnectService.probe(jwt: token, bundleID: metadata.bundleID)
                        await MainActor.run {
                            ascProbe = result
                            ascChecking = false
                            toast = "✅ App Store Connect 真实账号验证成功"
                        }
                    } catch {
                        await MainActor.run {
                            ascChecking = false
                            toast = "❌ \(error.localizedDescription)"
                        }
                    }
                }
            } label: {
                Label(ascChecking ? "正在验证…" : "真实验证账号与 App", systemImage: "checkmark.shield.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.2cabe9e1b42f")
            .buttonStyle(.borderedProminent)
            .disabled(ascChecking || ascJWT.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || metadata.bundleID.isEmpty)

            if let probe = ascProbe {
                Divider().opacity(0.45)
                Label("已连接：\(probe.app.name)", systemImage: "checkmark.circle.fill").foregroundColor(.green)
                Text("Bundle ID：\(probe.app.bundleID) · SKU：\(probe.app.sku)").font(.caption).foregroundColor(.secondary)
                Text("最近构建：\(probe.builds.isEmpty ? "暂无" : "\(probe.builds.count) 个")").font(.caption.weight(.semibold))
                ForEach(probe.builds.prefix(3)) { build in
                    Text("Build \(build.version) · \(build.processingState)").font(.caption2).foregroundColor(.secondary)
                }
            }
        }
    }

    private var liveUploadCard: some View {
        card("IPA 真实上传", "arrow.up.circle.fill") {
            Text("Build226 接入 Apple Build Upload REST 链：选择 IPA → 主人批准计划 → 二次确认 → 创建 Build Upload → 预留文件 → 按 Apple 分片指令上传 → MD5 校验提交。上传本身不会提交审核或正式上线。")
                .font(.caption).foregroundColor(.secondary)

            Button {
                showingIPAImporter = true
            } label: {
                Label(selectedIPAURL == nil ? "选择 IPA 文件" : "重新选择 IPA", systemImage: "doc.badge.plus").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.77892888542e").buttonStyle(.bordered)

            if selectedIPAURL != nil {
                VStack(alignment: .leading, spacing: 4) {
                    Text(selectedIPAName).font(.caption.weight(.semibold))
                    Text("\(ByteCountFormatter.string(fromByteCount: selectedIPABytes, countStyle: .file)) · 本机文件，仅在上传动作读取")
                        .font(.caption2).foregroundColor(.secondary)
                }
            }

            let approved = plans.first(where: { $0.status == .approved && $0.version == runtimeVersion && $0.build == runtimeBuild })
            HStack(spacing: 8) {
                Image(systemName: approved == nil ? "exclamationmark.triangle.fill" : "checkmark.shield.fill")
                    .foregroundColor(approved == nil ? .orange : .green)
                Text(approved == nil ? "当前版本还没有主人批准的发布计划" : "已找到主人批准计划：\(approved!.destination.rawValue)")
                    .font(.caption)
            }

            if uploadBusy {
                ProgressView(value: uploadProgress)
                Text("\(Int(uploadProgress * 100))% · \(uploadStage)").font(.caption2).foregroundColor(.secondary)
            }

            Button {
                showingUploadConfirmation = true
            } label: {
                Label(uploadBusy ? "正在上传…" : "真实上传 IPA 到 Apple", systemImage: "icloud.and.arrow.up.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.8979f1be6d37")
            .buttonStyle(.borderedProminent)
            .tint(.orange)
            .disabled(uploadBusy || selectedIPAURL == nil || ascProbe == nil || ascJWT.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || approved == nil)

            if let result = uploadResult {
                Divider().opacity(0.45)
                Label("Apple Build Upload 已接收", systemImage: "checkmark.circle.fill").foregroundColor(.green)
                Text("Upload：\(result.uploadID) · File：\(result.fileID)").font(.caption2).textSelection(.enabled)
                Text("状态：\(result.state) · MD5：\(result.md5.prefix(12))…").font(.caption2).foregroundColor(.secondary)
            }
        }
    }


    private var releaseAutomationCard: some View {
        card("App Store 最终发布自动化", "app.badge.checkmark") {
            Text("Build228 把版本、版本级元数据、Build 绑定、截图上传与 App Review 草稿/提交串成一条真实链。所有写操作都需要显式点击；最终提交审核还有独立二次确认。")
                .font(.caption).foregroundColor(.secondary)

            field("发布语言", text: $releaseDraft.locale)
            VStack(alignment: .leading, spacing: 5) {
                Text("App 描述").font(.caption).foregroundColor(.secondary)
                TextEditor(text: $releaseDraft.descriptionText).frame(minHeight: 90).padding(7)
                    .background(Color(uiColor: .tertiarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 10))
            }
            field("关键词（逗号分隔）", text: $releaseDraft.keywords)
            field("推广文本", text: $releaseDraft.promotionalText)
            field("本次更新说明", text: $releaseDraft.whatsNew)
            Picker("截图规格", selection: $releaseDraft.screenshotDisplayType) {
                Text("iPhone 6.7 英寸").tag("APP_IPHONE_67")
                Text("iPhone 6.5 英寸").tag("APP_IPHONE_65")
                Text("iPhone 6.1 英寸").tag("APP_IPHONE_61")
            }.accessibilityIdentifier("ui.80f7cff2787e").pickerStyle(.menu)

            if releaseBusy {
                ProgressView()
                Text(releaseStage).font(.caption2).foregroundColor(.secondary)
            }

            Button {
                syncReleaseMetadataAndBuild()
            } label: {
                Label("同步版本元数据并绑定当前 Build", systemImage: "arrow.triangle.2.circlepath.circle.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.0b92106b3722")
            .buttonStyle(.borderedProminent)
            .disabled(releaseBusy || ascProbe == nil || ascJWT.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Button { showingScreenshotImporter = true } label: {
                Label(selectedScreenshotURL == nil ? "选择 App Store 截图" : "重新选择截图", systemImage: "photo.badge.plus").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.7fcd9078a550").buttonStyle(.bordered)

            if !selectedScreenshotName.isEmpty {
                Text(selectedScreenshotName).font(.caption2).foregroundColor(.secondary)
            }

            Button { uploadScreenshot() } label: {
                Label("真实上传这张截图", systemImage: "photo.on.rectangle.angled").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.a3ec6d80be10")
            .buttonStyle(.bordered)
            .disabled(releaseBusy || selectedScreenshotURL == nil || releaseDraft.lastLocalizationID.isEmpty || ascJWT.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Divider().opacity(0.45)
            HStack {
                Text("发布阶段").font(.caption.weight(.semibold))
                Spacer()
                Text(releaseDraft.phase.rawValue).font(.caption2.bold()).foregroundColor(releaseDraft.phase == .submitted ? .green : .orange)
            }

            Button { showingReviewDraftConfirmation = true } label: {
                Label("创建 App Review 草稿", systemImage: "doc.badge.gearshape").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.8f9e5396a3d0")
            .buttonStyle(.bordered)
            .disabled(releaseBusy || releaseDraft.lastVersionID.isEmpty || ascProbe == nil || ascJWT.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Button { showingSubmitReviewConfirmation = true } label: {
                Label("最终提交 Apple 审核", systemImage: "paperplane.circle.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.c7f55d24db5d")
            .buttonStyle(.borderedProminent)
            .tint(.red)
            .disabled(releaseBusy || releaseDraft.lastReviewSubmissionID.isEmpty || ascJWT.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Text("隐私政策 URL 等共享 App 信息仍由上方本机资料门检查；若 Apple 账号侧还有年龄分级、出口合规、审核联系方式等必填项，Apple 会在提交时返回真实 409/422，BuildMate 会原样显示，不伪造成功。")
                .font(.caption2).foregroundColor(.secondary)
        }
    }

    private func syncReleaseMetadataAndBuild() {
        guard let probe = ascProbe else { toast = "❌ 请先真实验证 App Store Connect"; return }
        guard let build = probe.builds.first(where: { $0.version == runtimeBuild && $0.processingState == "VALID" }) ?? probe.builds.first(where: { $0.version == runtimeBuild }) else {
            toast = "❌ Apple 端还没找到 Build \(runtimeBuild)；请先等待 IPA 处理完成并重新验证"
            return
        }
        let token = ascJWT
        var draft = releaseDraft
        BMAppStoreReleaseDraftStore.save(draft)
        releaseBusy = true; releaseStage = "创建/读取 App Store Version"
        Task {
            do {
                let version = try await AppStoreReleaseAutomationService.ensureVersion(jwt: token, appID: probe.app.id, version: runtimeVersion, copyright: metadata.copyright)
                await MainActor.run { releaseStage = "同步版本级元数据" }
                let loc = try await AppStoreReleaseAutomationService.upsertLocalization(jwt: token, versionID: version.id, draft: draft, supportURL: metadata.supportURL, marketingURL: metadata.marketingURL)
                await MainActor.run { releaseStage = "绑定 Apple Build \(runtimeBuild)" }
                try await AppStoreReleaseAutomationService.attachBuild(jwt: token, versionID: version.id, buildID: build.id)
                await MainActor.run {
                    draft.lastVersionID = version.id; draft.lastLocalizationID = loc.id; draft.phase = .buildAttached
                    releaseDraft = draft; BMAppStoreReleaseDraftStore.save(draft)
                    releaseBusy = false; releaseStage = ""; toast = "✅ App Store Version、元数据和 Build 已真实同步"
                }
            } catch {
                await MainActor.run { releaseBusy = false; releaseStage = ""; toast = "❌ \(error.localizedDescription)" }
            }
        }
    }

    private func uploadScreenshot() {
        guard let url = selectedScreenshotURL, !releaseDraft.lastLocalizationID.isEmpty else { toast = "❌ 请先同步版本元数据并选择截图"; return }
        let token = ascJWT; var draft = releaseDraft
        releaseBusy = true; releaseStage = "准备截图上传"
        Task {
            do {
                _ = try await AppStoreReleaseAutomationService.uploadScreenshot(jwt: token, localizationID: draft.lastLocalizationID, displayType: draft.screenshotDisplayType, fileURL: url) { _, stage in
                    Task { @MainActor in releaseStage = stage }
                }
                await MainActor.run {
                    draft.phase = .screenshotsReady; releaseDraft = draft; BMAppStoreReleaseDraftStore.save(draft)
                    releaseBusy = false; releaseStage = ""; toast = "✅ 截图已真实上传并提交 Apple 处理"
                }
            } catch { await MainActor.run { releaseBusy = false; releaseStage = ""; toast = "❌ \(error.localizedDescription)" } }
        }
    }

    private func createReviewDraft() {
        guard let appID = ascProbe?.app.id, !releaseDraft.lastVersionID.isEmpty else { toast = "❌ 请先同步 App Store Version"; return }
        let token = ascJWT; var draft = releaseDraft
        releaseBusy = true; releaseStage = "创建 App Review 草稿"
        Task {
            do {
                let result = try await AppStoreReleaseAutomationService.createReviewDraft(jwt: token, appID: appID, versionID: draft.lastVersionID)
                await MainActor.run {
                    draft.lastReviewSubmissionID = result.id; draft.phase = .reviewDraft; releaseDraft = draft; BMAppStoreReleaseDraftStore.save(draft)
                    releaseBusy = false; releaseStage = ""; toast = "✅ 审核草稿已创建；尚未提交审核"
                }
            } catch { await MainActor.run { releaseBusy = false; releaseStage = ""; toast = "❌ \(error.localizedDescription)" } }
        }
    }

    private func submitReview() {
        guard !releaseDraft.lastReviewSubmissionID.isEmpty else { toast = "❌ 没有审核草稿"; return }
        let token = ascJWT; var draft = releaseDraft; let submissionID = draft.lastReviewSubmissionID
        releaseBusy = true; releaseStage = "真实提交 Apple 审核"
        Task {
            do {
                let result = try await AppStoreReleaseAutomationService.submitReview(jwt: token, submissionID: submissionID)
                await MainActor.run {
                    draft.phase = .submitted; releaseDraft = draft; BMAppStoreReleaseDraftStore.save(draft)
                    releaseBusy = false; releaseStage = ""; toast = "✅ 已向 Apple 提交审核 · \(result.state)"
                }
            } catch { await MainActor.run { releaseBusy = false; releaseStage = ""; toast = "❌ \(error.localizedDescription)" } }
        }
    }

    private var runtimeVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""
    }

    private var runtimeBuild: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? ""
    }

    private func startRealUpload() {
        guard let fileURL = selectedIPAURL, let appID = ascProbe?.app.id else {
            toast = "❌ 缺少已验证 App 或 IPA 文件"
            return
        }
        guard plans.contains(where: { $0.status == .approved && $0.version == runtimeVersion && $0.build == runtimeBuild }) else {
            toast = "❌ 请先创建当前版本发布计划并点击主人批准"
            return
        }
        let token = ascJWT
        uploadBusy = true
        uploadProgress = 0.01
        uploadStage = "准备真实上传"
        uploadResult = nil
        Task {
            do {
                let result = try await AppStoreConnectService.uploadIPA(jwt: token, appID: appID, version: runtimeVersion, build: runtimeBuild, fileURL: fileURL) { progress, stage in
                    Task { @MainActor in
                        uploadProgress = progress
                        uploadStage = stage
                    }
                }
                await MainActor.run {
                    uploadResult = result
                    uploadBusy = false
                    uploadProgress = 1.0
                    uploadStage = "Apple 已接收"
                    toast = "✅ IPA 已完成 Build Upload 传输；等待 Apple 后台处理"
                }
            } catch {
                await MainActor.run {
                    uploadBusy = false
                    uploadStage = "上传失败"
                    toast = "❌ \(error.localizedDescription)"
                }
            }
        }
    }

    private var planCard: some View {
        card("发布计划", "paperplane.fill") {
            Picker("目标", selection: $destination) {
                ForEach(BMReleaseDestination.allCases) { Text($0.rawValue).tag($0) }
            }.accessibilityIdentifier("ui.4660ee7cdfd7").pickerStyle(.segmented)
            Text(destination == .testFlight ? "TestFlight 用于内部/外部测试；正式 App Store 上线仍是单独审批动作。" : "App Store 正式发布计划只生成交接单，不会自动提交审核。")
                .font(.caption).foregroundColor(.secondary)
            Button {
                BMReleaseWorkspaceStore.saveMetadata(metadata)
                BMReleaseWorkspaceStore.saveCredentialReference(credential)
                let plan = BMReleaseWorkspaceStore.makePlan(destination: destination)
                plans = BMReleaseWorkspaceStore.plans()
                toast = plan.hasArtifactEvidence ? "✅ 发布计划已创建" : "⚠️ 已创建草案，但还缺真实 IPA 证据"
            } label: {
                Label("创建发布计划", systemImage: "plus.circle.fill").frame(maxWidth: .infinity)
            }.accessibilityIdentifier("ui.383573ea046f").buttonStyle(.borderedProminent)
        }
    }

    private var historyCard: some View {
        card("最近发布计划", "clock.arrow.circlepath") {
            if plans.isEmpty {
                Text("还没有发布计划。创建计划不会联网，也不会消耗 Codemagic 分钟。")
                    .font(.caption).foregroundColor(.secondary)
            } else {
                ForEach(plans.prefix(6)) { plan in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("\(plan.destination.rawValue) · V\(plan.version) (\(plan.build))").font(.subheadline.weight(.semibold))
                            Spacer()
                            Text(plan.status.rawValue).font(.caption2.bold()).foregroundColor(plan.status == .approved ? .green : .orange)
                        }
                        Text(plan.artifactName.isEmpty ? "IPA：暂无证据" : "IPA：\(plan.artifactName)").font(.caption2).foregroundColor(.secondary)
                        HStack {
                            Button("复制交接单") {
                                UIPasteboard.general.string = BMReleaseWorkspaceStore.handoffReport(plan: plan, metadata: metadata)
                                toast = "✅ 发布交接单已复制"
                            }.accessibilityIdentifier("ui.a3ba11392cb1").buttonStyle(.bordered)
                            if plan.status != .approved {
                                Button("主人批准") {
                                    _ = BMReleaseWorkspaceStore.approvePlan(plan)
                                    plans = BMReleaseWorkspaceStore.plans()
                                    toast = "✅ 已记录主人批准；仍未自动提交商店"
                                }.accessibilityIdentifier("ui.e055d4ade119").buttonStyle(.bordered)
                            }
                        }
                    }
                    if plan.id != plans.prefix(6).last?.id { Divider().opacity(0.45) }
                }
            }
        }
    }

    private var safetyCard: some View {
        card("真实发布能力边界", "shield.lefthalf.filled") {
            Label("本机元数据检查：已实现", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("发布计划 / 主人批准 / 交接单：已实现", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("App Store Connect 真实账号/App/Build 只读验证：已接入", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("IPA Build Upload REST 真实上传：已接入（主人批准 + 二次确认）", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("Apple Build Upload 状态回读：已接入", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("App Store Version / 版本级元数据 / Build 绑定：已接入", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("App Store 截图上传：已接入", systemImage: "checkmark.circle.fill").foregroundColor(.green)
            Label("App Review 草稿与提交：已接入；提交审核必须二次确认", systemImage: "person.badge.key.fill").foregroundColor(.green)
            Text("BuildMate 不会因为界面已经有按钮，就把未接入的 App Store API 描述成可用。")
                .font(.caption).foregroundColor(.secondary)
        }
    }

    private func field(_ title: String, text: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption).foregroundColor(.secondary)
            TextField(title, text: text)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .keyboardType(keyboard)
                .padding(10)
                .background(Color(uiColor: .tertiarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
    }

    @ViewBuilder
    private func card<Content: View>(_ title: String, _ icon: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            Label(title, systemImage: icon).font(.headline)
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func metric(_ title: String, _ value: Int) -> some View {
        VStack(spacing: 2) {
            Text("\(value)").font(.headline.monospacedDigit())
            Text(title).font(.caption2).foregroundColor(.secondary)
        }.frame(maxWidth: .infinity)
    }
}
