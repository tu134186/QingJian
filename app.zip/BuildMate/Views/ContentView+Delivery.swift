import SwiftUI
import UniformTypeIdentifiers
import UIKit

extension ContentView {
    @MainActor func refreshRunStatus(readReport: Bool, updateTerminalStage: Bool = true) async {
        checking = true
        defer { checking = false }
        do {
            let gh = GitHubService(owner: owner, repo: repo, token: token)
            let info = try await gh.repoInfo()
            let runToRefresh: GitHubWorkflowRun?
            if let lockedRunID = latestRunID {
                runToRefresh = try await gh.workflowRun(id: lockedRunID)
            } else {
                runToRefresh = try await gh.latestWorkflowRun()
            }
            if let run = runToRefresh {
                latestRunID = run.id
                runURL = run.htmlURL
                status = "\(run.readableState)\nRun #\(run.id)"
                if run.status == "queued" { workStage = .queued; workDetail = "Run #\(run.id) 等待云端执行" }
                else if run.status == "in_progress" { workStage = .compiling; workDetail = "Run #\(run.id) 正在云端编译" }
                else if run.conclusion == "success" {
                    if updateTerminalStage { workStage = .success; workDetail = "Run #\(run.id) 已成功" }
                }
                else if run.status == "completed" {
                    if updateTerminalStage { workStage = .failed; workDetail = "Run #\(run.id) 已失败" }
                }
            } else { status = "还没找到运行记录。" }
            if readReport, let r = try await gh.buildReport(branch: info.defaultBranch) {
                if r.runID == latestRunID {
                    report = r
                    status = r.summary + "\nRun #\(r.runID ?? 0)"
                } else {
                    report = nil
                    status += "\n\n⏳ 等待本次 Run 的报告同步，旧报告不会作为本次结果显示。"
                }
            }
        } catch { status = "❌ 刷新失败：\(error.localizedDescription)" }
    }

    @MainActor func downloadBuildArtifact() async {
        if let current = pendingArtifacts.first(where: { $0.runID == latestRunID }) ?? pendingArtifacts.first {
            await downloadPendingArtifact(current)
            return
        }
        guard let runID = latestRunID, let r = report, r.runID == runID, r.hasVerifiedArtifact else { return }
        rememberPendingArtifact(runID: runID, runURL: runURL, report: r)
        guard let pending = pendingArtifacts.first(where: { $0.runID == runID }) else { return }
        await downloadPendingArtifact(pending)
    }

    @MainActor func downloadPendingArtifact(_ pending: PendingArtifactRecord) async {
        busy = true
        defer { busy = false }
        do {
            let gh = GitHubService(owner: pending.owner, repo: pending.repo, token: token)
            let items = try await gh.artifacts(runID: pending.runID)
            let prefix = pending.displayKind == "DEB" ? "DEB-" : "IPA-"
            guard let artifact = items.first(where: { !$0.expired && $0.name.hasPrefix(prefix) }) else {
                throw BMContentSupport.error("Run #\(pending.runID) 的 \(pending.displayKind) Artifact 已找不到或已过期。待保存记录仍会保留，不会自动删除。")
            }
            let rawURL = try await gh.downloadArtifact(artifact)
            let localURL = try BMLocalFileStore.persistDownloadedArtifact(
                rawURL,
                kind: pending.displayKind,
                runID: pending.runID,
                repository: repo,
                artifactCategory: artifactCategory,
                artifactFileName: artifactFileName,
                categoryOverride: pending.repo,
                fileNameOverride: pending.preferredFileName
            )
            downloadedArtifact = localURL
            _ = BMArtifactDeliveryStore.upsert(provider: "GitHub Actions", runID: String(pending.runID), sourceSHA256: sourceLocalSHA256.isEmpty ? nil : sourceLocalSHA256, artifactName: pending.artifactName ?? localURL.lastPathComponent, localURL: localURL, buildURL: pending.runURL, verified: true, byteCount: (try? Data(contentsOf: localURL).count) ?? 0)
            if let idx = pendingArtifacts.firstIndex(where: { $0.runID == pending.runID }) {
                pendingArtifacts[idx].localPath = localURL.path
                PendingArtifactStore.save(pendingArtifacts)
            }
            status = "✅ \(pending.displayKind) 已缓存。点“保存 \(pending.displayKind)”保存到文件/分享；关闭 App 后入口仍会保留。"
        } catch {
            status = "❌ 下载失败：\(error.localizedDescription)"
        }
    }

    func rememberPendingArtifact(runID: Int64, runURL: String?, report: BuildReport) {
        guard report.hasVerifiedArtifact else { return }
        let kind = (report.artifactKind ?? (report.debName == nil ? "IPA" : "DEB")).uppercased()
        let item = PendingArtifactRecord(
            runID: runID,
            owner: owner,
            repo: repo,
            artifactKind: kind,
            artifactName: report.artifactName ?? report.ipaName ?? report.debName,
            preferredFileName: artifactFileName.isEmpty ? nil : artifactFileName,
            runURL: runURL,
            localPath: pendingArtifacts.first(where: { $0.runID == runID })?.localPath,
            createdAt: Date()
        )
        pendingArtifacts.removeAll { $0.runID == runID }
        pendingArtifacts.insert(item, at: 0)
        if pendingArtifacts.count > 10 { pendingArtifacts = Array(pendingArtifacts.prefix(10)) }
        PendingArtifactStore.save(pendingArtifacts)
    }

    func restorePendingArtifactState() {
        pendingArtifacts = PendingArtifactStore.load()
        downloadedArtifact = nil
        for item in pendingArtifacts {
            if let path = item.localPath, FileManager.default.fileExists(atPath: path) {
                downloadedArtifact = URL(fileURLWithPath: path)
                break
            }
        }
    }

    func restoreArtifactDeliveryState() {
        // 历史产物继续完整保存在“产物中心”，但首页工作台只恢复“当前源码 SHA”的产物。
        // 新源码、空源码、取消编译都不会再被旧 IPA 污染成“保存产物”。
        guard sourceURL != nil, !sourceLocalSHA256.isEmpty else {
            downloadedArtifact = nil
            return
        }
        if let latest = BMArtifactDeliveryStore.load().first(where: { $0.sourceSHA256 == sourceLocalSHA256 && $0.isLocalReady }),
           let url = latest.localURL {
            downloadedArtifact = url
            if artifactFileName.isEmpty { artifactFileName = latest.artifactName }
            if artifactCategory.isEmpty { artifactCategory = "IPA" }
        } else if let current = downloadedArtifact, !FileManager.default.fileExists(atPath: current.path) {
            downloadedArtifact = nil
        } else if BMArtifactDeliveryStore.load().first(where: { $0.localPath == downloadedArtifact?.path && $0.sourceSHA256 == sourceLocalSHA256 }) == nil {
            downloadedArtifact = nil
        }
    }

    @MainActor func markPendingArtifactDelivered(localURL: URL) {
        BMArtifactDeliveryStore.markDelivered(localURL: localURL)
        let before = pendingArtifacts.count
        pendingArtifacts.removeAll { item in
            if let path = item.localPath { return path == localURL.path }
            return false
        }
        if pendingArtifacts.count != before {
            PendingArtifactStore.save(pendingArtifacts)
            restorePendingArtifactState()
            restoreArtifactDeliveryState()
            if BMSourceLifecycleStore.autoCleanupAfterDelivery {
                clearWorkingSource(manual: false)
                status = "✅ 产物已保存/分享；首页下一步已恢复正常动态按钮。工作台源码已自动清理，产物中心与编译历史仍保留。"
            } else {
                status = "✅ 产物已保存/分享；首页下一步已恢复为编译设置/后续动作。产物中心仍可再次分享。"
            }
        }
    }

    @MainActor func clearWorkingSource(manual: Bool) {
        guard !busy else { status = "⚠️ 编译运行中不能清理源码，请先停止或等待完成。"; return }
        BMSourceWorkspaceStore.clearWorkingSource(sourceURL)
        let clearedGeneration = UUID().uuidString
        // Build1016：清理源码只更新本地源码身份，不触发 UnifiedTask 归档链。
        activeUnifiedTask = nil
        UserDefaults.standard.set(false, forKey: "autopilot-pending-v1")
        sourceGenerationID = clearedGeneration
        UserDefaults.standard.set(clearedGeneration, forKey: "current-source-generation-v1")
        BMPatchDiffStore.clear()
        sourceURL = nil
        sourceSizeText = ""
        sourceTraceText = "尚未校验"
        sourceLocalSHA256 = ""
        sourceRemoteSHA256 = ""
        sourceUploadCommitSHA = ""
        sourceDispatchHeadSHA = ""
        if manual { status = "✅ 工作台源码已清空；原始 ZIP 和 GitHub 仓库未删除。" }
    }

    func readSecurityScoped(_ url: URL) throws -> Data {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        return try Data(contentsOf: url)
    }

    @MainActor func refreshCurrentRepositoryVisibility() async {
        guard !owner.isEmpty, !repo.isEmpty else { currentRepoIsPrivate = nil; return }
        let selectedOwner = owner
        let selectedRepo = repo
        let stored = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
        let activeToken = stored.isEmpty ? token.trimmingCharacters(in: .whitespacesAndNewlines) : stored
        guard !activeToken.isEmpty else { currentRepoIsPrivate = nil; return }
        do {
            let info = try await GitHubService(owner: selectedOwner, repo: selectedRepo, token: activeToken).repoInfo()
            // 用户可能在请求返回前又切了仓库；旧请求绝不能覆盖新仓库状态。
            guard owner == selectedOwner, repo == selectedRepo else { return }
            currentRepoIsPrivate = info.isPrivate
            repoState = "✅ " + info.defaultBranch
            repositories = repositories.map { item in
                guard item.owner == selectedOwner && item.name == selectedRepo else { return item }
                return GitHubRepository(fullName: item.fullName, owner: item.owner, name: item.name, isPrivate: info.isPrivate, defaultBranch: info.defaultBranch, updatedAt: item.updatedAt)
            }
        } catch {
            guard owner == selectedOwner, repo == selectedRepo else { return }
            currentRepoIsPrivate = repositories.first(where: { $0.owner == selectedOwner && $0.name == selectedRepo })?.isPrivate
            status = "⚠️ 已切换到 \(selectedOwner)/\(selectedRepo)，但刷新可见性失败：\(error.localizedDescription)"
        }
    }

    @MainActor func changeCurrentRepositoryVisibility(makePrivate: Bool) async {
        guard !owner.isEmpty, !repo.isEmpty else { status = "❌ 当前仓库信息不完整。"; return }
        let fresh = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
        let activeToken = fresh.isEmpty ? token.trimmingCharacters(in: .whitespacesAndNewlines) : fresh
        guard !activeToken.isEmpty else { status = "❌ GitHub Token 为空，请先重新连接 GitHub。"; return }
        token = activeToken
        visibilityChanging = true
        defer { visibilityChanging = false }
        do {
            let info = try await GitHubService(owner: owner, repo: repo, token: activeToken).setRepositoryPrivate(makePrivate)
            currentRepoIsPrivate = info.isPrivate
            repositories = repositories.map { item in
                guard item.owner == owner && item.name == repo else { return item }
                return GitHubRepository(fullName: item.fullName, owner: item.owner, name: item.name, isPrivate: info.isPrivate, defaultBranch: item.defaultBranch, updatedAt: item.updatedAt)
            }
            status = info.isPrivate ? "🔒 已将 \(info.fullName) 设为私有仓库。IPA/DEB 编译配置未改动。" : "🌐 已将 \(info.fullName) 改为公开仓库。"
        } catch {
            let ns = error as NSError
            status = ns.code == 403 ? "❌ 修改失败：Token 缺少 Administration → Read and write 权限。" : "❌ 修改仓库可见性失败：\(error.localizedDescription)"
        }
    }

    @MainActor func deleteCurrentRepository() async {
        guard !owner.isEmpty, !repo.isEmpty, !token.isEmpty else { status = "❌ 当前仓库信息不完整。"; return }
        do {
            let oldFull = owner + "/" + repo
            try await GitHubService(owner: owner, repo: repo, token: token).deleteRepository()
            savedProjects.removeAll { $0.owner == owner && $0.repo == repo }
            BuildMateProjectStore.save(savedProjects)
            repositories.removeAll { $0.owner == owner && $0.name == repo }
            owner = ""; repo = ""; latestRunID = nil; report = nil; downloadedArtifact = nil
            UserDefaults.standard.set("", forKey: "owner"); UserDefaults.standard.set("", forKey: "repo")
            status = "✅ 已删除 GitHub 仓库 " + oldFull
        } catch { status = "❌ 删除仓库失败：\(error.localizedDescription)。删除仓库需要 Token 具备 GitHub Administration 删除权限。" }
    }

    @MainActor func refreshDeepSeekBalance() async {
        guard aiProvider == .deepSeek, !aiKey.isEmpty else {
            aiBalanceText = "请先填写 DeepSeek Key"
            return
        }
        do {
            aiBalanceText = try await BMAIAccountService.deepSeekBalance(apiKey: aiKey)
        } catch {
            aiBalanceText = "查询失败：\(error.localizedDescription)"
        }
    }

    func saveCredentials() {
        UserDefaults.standard.set(owner, forKey: "owner")
        UserDefaults.standard.set(repo, forKey: "repo")
        UserDefaults.standard.set(aiProvider.rawValue, forKey: "ai-provider")
        saveAIProfile(for: aiProvider)
        KeychainStore.save(token, key: "github-token")

    }

    func saveAIProfile(for provider: AIProvider) {
        BMAIProfileStore.save(provider: provider, endpoint: aiEndpoint, model: aiModel, apiKey: aiKey)
    }

    func loadAIProfile(for provider: AIProvider) {
        aiEndpoint = BMAIProfileStore.storedEndpoint(provider)
        aiModel = BMAIProfileStore.storedModel(provider)
        aiKey = BMAIProfileStore.storedKey(provider)
    }



    func effectLibraryURL(name: String) -> URL? {
        BMCentralEffectLibraryStore.url(for: name)
    }

    func persistEffectIntoLibrary(_ pickedURL: URL) throws -> URL {
        let result = try BMCentralEffectLibraryStore.importFile(pickedURL, currentNames: customEffectLibraryNames)
        customEffectLibraryNames = result.libraryNames
        return result.url
    }

    @MainActor func restorePersistedFiles() {
        do {
            let restored = try BMSourceWorkspaceStore.restore()
            sourceURL = restored.sourceURL
            iconURL = restored.iconURL
            sourceSizeText = restored.sourceSizeText
            sourceLocalSHA256 = restored.sourceSHA256
            if UserDefaults.standard.string(forKey: "current-source-generation-v1") == nil {
                UserDefaults.standard.set(sourceGenerationID, forKey: "current-source-generation-v1")
            }
            if restored.sourceMissing { status = "❌ 上次选择的源码文件已不存在，请重新选择源码 ZIP。" }

            let dir = try BMLocalFileStore.importedDirectory()
            if let name = UserDefaults.standard.string(forKey: BMPersistedFileKind.effect.defaultsKey) {
                if let libraryURL = effectLibraryURL(name: name) {
                    customEffectURL = libraryURL
                } else {
                    let legacyURL = dir.appendingPathComponent(name)
                    if FileManager.default.fileExists(atPath: legacyURL.path) {
                        let migrated = try persistEffectIntoLibrary(legacyURL)
                        customEffectURL = migrated
                        UserDefaults.standard.set(migrated.lastPathComponent, forKey: BMPersistedFileKind.effect.defaultsKey)
                    } else {
                        UserDefaults.standard.removeObject(forKey: BMPersistedFileKind.effect.defaultsKey)
                        customEffectURL = nil
                        customEffectEnabled = false
                        UserDefaults.standard.set(false, forKey: "central-effect-custom-enabled")
                    }
                }
            }
        } catch {
            status = "❌ 无法恢复本地源码：\(error.localizedDescription)"
        }
    }

    func record(_ run: GitHubWorkflowRun, report: BuildReport? = nil) {
        let result = (report?.runID == run.id) ? (report?.headline ?? run.readableState) : run.readableState
        let item = BuildHistoryRecord(
            runID: run.id, result: result, date: Date(),
            repository: owner.isEmpty || repo.isEmpty ? nil : "\(owner)/\(repo)",
            sourceName: sourceURL?.lastPathComponent,
            aiRounds: aiRound > 0 ? aiRound : nil,
            aiSummary: lastPlan?.summary,
            artifactName: artifactFileName.isEmpty ? downloadedArtifact?.lastPathComponent : artifactFileName
        )
        buildHistory = BuildHistoryStore.upsert(item, into: buildHistory)
    }

    func rememberProject(owner: String, repo: String, branch: String, kind: String = "auto") {
        guard !owner.isEmpty, !repo.isEmpty else { return }
        savedProjects = BuildMateProjectStore.remember(owner: owner, repo: repo, branch: branch, kind: kind, current: savedProjects)

        var workspace = BMWorkspaceIdentityStore.load(owner: owner, repo: repo, branch: branch)
        workspace.displayName = repo
        workspace.sourceProviderID = BMSourceProviderID.github.rawValue
        workspace.sourceLocator = owner + "/" + repo
        workspace.branch = branch
        workspace.updatedAt = Date()
        BMWorkspaceIdentityStore.save(workspace)
    }

}
