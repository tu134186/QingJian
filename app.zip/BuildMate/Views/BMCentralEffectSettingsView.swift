import SwiftUI
import UniformTypeIdentifiers
import UIKit

/// Build186: central-effect settings are isolated from ContentView.
/// The view owns only editor/library presentation state; persisted effect configuration remains bound to ContentView.
struct BMCentralEffectSettingsView: View {
    @Binding var customEffectLibraryNames: [String]
    @Binding var customEffectURL: URL?
    @Binding var customEffectEnabled: Bool
    @Binding var centralThemeRaw: String
    @Binding var customEffectRotates: Bool
    @Binding var customMotionMode: BMCentralMotionMode
    @Binding var customFixedSpeed: Double
    @Binding var customEffectScale: Double
    @Binding var customCircleCorrection: Bool
    @Binding var status: String

    let workStage: BuildWorkStage
    let spinAnchorAngle: Double
    let spinTransitionStart: Date
    let spinStartSpeed: Double
    let spinTargetSpeed: Double

    @State private var showingEffectPicker = false
    @State private var managingEffectLibrary = false
    @State private var selectedEffectLibraryNames: Set<String> = []
    @State private var showingBatchDeleteEffectConfirmation = false
    @State private var svgSpecCopied = false
    @State private var showingSVGPasteEditor = false
    @State private var svgSourceDraft = ""
    @State private var svgSourceValidation = ""
    @State private var customSectionExpanded = false
    @FocusState private var svgSourceEditorFocused: Bool

    private var selectedTheme: BMCentralTheme {
        BMCentralTheme(rawValue: centralThemeRaw) ?? .sharinganPro
    }

    private func spinAngle(at date: Date) -> Double {
        BMCentralMotionEngine.angle(
            at: date,
            anchorAngle: spinAnchorAngle,
            transitionStart: spinTransitionStart,
            startSpeed: spinStartSpeed,
            targetSpeed: spinTargetSpeed
        )
    }

    private func effectURL(name: String) -> URL? { BMCentralEffectLibraryStore.url(for: name) }

    private func saveSVG(_ raw: String) throws -> URL {
        let dir = try BMCentralEffectLibraryStore.directory()
        let result = try BMSVGSourceStore.save(raw, directory: dir, currentLibraryNames: customEffectLibraryNames)
        customEffectLibraryNames = result.libraryNames
        BMCentralEffectLibraryStore.saveNames(result.libraryNames)
        return result.url
    }

    private func removeEffect(_ name: String) {
        customEffectLibraryNames = BMCentralEffectLibraryStore.remove(name: name, currentNames: customEffectLibraryNames)
        if customEffectURL?.lastPathComponent == name {
            if let next = customEffectLibraryNames.first, let url = effectURL(name: next) {
                customEffectURL = url
                UserDefaults.standard.set(next, forKey: BMPersistedFileKind.effect.defaultsKey)
            } else {
                customEffectURL = nil
                customEffectEnabled = false
                UserDefaults.standard.removeObject(forKey: BMPersistedFileKind.effect.defaultsKey)
                UserDefaults.standard.set(false, forKey: "central-effect-custom-enabled")
            }
        }
    }

    private func removeSelectedEffects() {
        let ordered = customEffectLibraryNames.filter { selectedEffectLibraryNames.contains($0) }
        for name in ordered { removeEffect(name) }
        selectedEffectLibraryNames.removeAll()
        managingEffectLibrary = false
    }

    private func validateSVGDraft() {
        let result = BMSVGSourceStore.validationMessage(for: svgSourceDraft)
        svgSourceDraft = result.normalized
        svgSourceValidation = result.message
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            preview
            builtInThemes
            customMaterialsSection
        }
        .sheet(isPresented: $showingEffectPicker) {
            MultiDocumentPicker(contentTypes: [.png, .jpeg, .gif, UTType(filenameExtension: "apng") ?? .png, UTType(filenameExtension: "svg") ?? .data]) { urls in
                do {
                    var imported: [URL] = []
                    for url in urls.prefix(30) {
                        if BMSVGInspector.isSVG(url) {
                            let inspection = BMSVGInspector.inspect(url)
                            guard inspection.valid else { throw BMContentSupport.error(inspection.reason ?? "SVG 无法解析。") }
                            if inspection.animated {
                                customMotionMode = .intrinsic
                                UserDefaults.standard.set(BMCentralMotionMode.intrinsic.rawValue, forKey: "central-effect-motion-mode-v2")
                            }
                        }
                        let result = try BMCentralEffectLibraryStore.importFile(url, currentNames: customEffectLibraryNames)
                        customEffectLibraryNames = result.libraryNames
                        imported.append(result.url)
                    }
                    if let first = imported.first {
                        customEffectURL = first
                        customEffectEnabled = true
                        UserDefaults.standard.set(true, forKey: "central-effect-custom-enabled")
                        UserDefaults.standard.set(first.lastPathComponent, forKey: BMPersistedFileKind.effect.defaultsKey)
                    }
                    status = "✅ 已导入 \(imported.count) 个中央素材，可在素材仓库中随时切换。"
                } catch {
                    status = "❌ 特效素材保存失败：\(error.localizedDescription)"
                }
                showingEffectPicker = false
            } onCancel: { showingEffectPicker = false }
        }
        .onDisappear {
            svgSourceEditorFocused = false
            if svgSourceDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                svgSourceDraft = ""
                svgSourceValidation = ""
                showingSVGPasteEditor = false
            }
        }
    }

    private var preview: some View {
        HStack {
            Spacer()
            TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: false)) { context in
                let t = context.date.timeIntervalSinceReferenceDate
                BMCentralEffectRenderer(
                    size: 104,
                    spin: spinAngle(at: context.date),
                    time: t,
                    customEffectEnabled: customEffectEnabled,
                    customEffectURL: customEffectURL,
                    customEffectRotates: customEffectRotates,
                    customMotionMode: customMotionMode,
                    customFixedSpeed: customFixedSpeed,
                    customEffectScale: customEffectScale,
                    customCircleCorrection: customCircleCorrection,
                    theme: selectedTheme
                )
            }
            Spacer()
        }
    }

    private var builtInThemes: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("6 个内置动态素材").font(.headline)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(BMCentralTheme.allCases) { theme in
                    Button {
                        centralThemeRaw = theme.rawValue
                        customEffectEnabled = false
                        UserDefaults.standard.set(theme.rawValue, forKey: "central-effect-theme-v1")
                        UserDefaults.standard.set(false, forKey: "central-effect-custom-enabled")
                    } label: {
                        HStack(spacing: 9) {
                            Image(systemName: theme.systemIcon).foregroundColor(theme.baseColor).frame(width: 26)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(theme.title).font(.caption.weight(.semibold)).foregroundColor(.primary)
                                Text(theme.subtitle).font(.system(size: 9)).foregroundColor(.secondary).lineLimit(1)
                            }
                            Spacer(minLength: 0)
                            if !customEffectEnabled && centralThemeRaw == theme.rawValue {
                                Image(systemName: "checkmark.circle.fill").foregroundColor(.blue)
                            }
                        }
                        .padding(10)
                        .background(Color.secondary.opacity(0.08))
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }.accessibilityIdentifier("ui.a90bd1286275")
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var customMaterialsSection: some View {
        DisclosureGroup(isExpanded: $customSectionExpanded) {
            VStack(alignment: .leading, spacing: 14) {
                svgEditor
                Divider()
                library
                effectOptions
                materialGuide
            }
            .padding(.top, 10)
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "photo.stack.fill")
                    .foregroundColor(BMTheme.palette.accent)
                VStack(alignment: .leading, spacing: 2) {
                    Text("自定义素材").font(.headline)
                    Text(customEffectLibraryNames.isEmpty ? "暂无素材 · 点开后导入" : "\(customEffectLibraryNames.count)/30 · 点开管理")
                        .font(.caption2).foregroundColor(.secondary)
                }
                Spacer()
                if customEffectEnabled {
                    Text("使用中").font(.caption2.weight(.semibold)).foregroundColor(.green)
                }
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.07))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private var svgEditor: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("直接粘贴 SVG 代码").font(.headline)
                    Text("不用先保存到相册或文件，也不会被转换成 PNG。").font(.caption2).foregroundColor(.secondary)
                }
                Spacer()
                if showingSVGPasteEditor {
                    Button {
                        svgSourceEditorFocused = false
                        svgSourceValidation = ""
                        if svgSourceDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { svgSourceDraft = "" }
                        showingSVGPasteEditor = false
                    } label: { Label("收起", systemImage: "chevron.up").font(.caption.weight(.semibold)) }.accessibilityIdentifier("ui.98a74eff11c5")
                    .buttonStyle(BMCompactButtonStyle())
                } else {
                    Image(systemName: "chevron.left.forwardslash.chevron.right").foregroundColor(BMTheme.palette.accent)
                }
            }
            if showingSVGPasteEditor {
                TextEditor(text: $svgSourceDraft)
                    .focused($svgSourceEditorFocused)
                    .font(.system(.caption, design: .monospaced))
                    .frame(minHeight: 180, maxHeight: 280)
                    .padding(8)
                    .background(Color.secondary.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                if !svgSourceValidation.isEmpty {
                    Text(svgSourceValidation).font(.caption).foregroundColor(svgSourceValidation.hasPrefix("✅") ? .green : .red)
                }
                HStack(spacing: 10) {
                    Button {
                        if let text = UIPasteboard.general.string {
                            svgSourceDraft = BMSVGSourceStore.normalize(text)
                            validateSVGDraft()
                        } else { svgSourceValidation = "❌ 剪贴板里没有文本。" }
                    } label: { Label("从剪贴板粘贴", systemImage: "doc.on.clipboard") }.accessibilityIdentifier("ui.8627d15ee2a5")
                    .buttonStyle(BMCompactButtonStyle())
                    Button { validateSVGDraft() } label: { Label("检查", systemImage: "checkmark.shield") }.accessibilityIdentifier("ui.7eb885d6d643")
                        .buttonStyle(BMCompactButtonStyle())
                }
                Button {
                    do {
                        let url = try saveSVG(svgSourceDraft)
                        customEffectURL = url
                        customEffectEnabled = true
                        UserDefaults.standard.set(url.lastPathComponent, forKey: BMPersistedFileKind.effect.defaultsKey)
                        UserDefaults.standard.set(true, forKey: "central-effect-custom-enabled")
                        let info = BMSVGInspector.inspect(url)
                        if info.animated {
                            customMotionMode = .intrinsic
                            UserDefaults.standard.set(BMCentralMotionMode.intrinsic.rawValue, forKey: "central-effect-motion-mode-v2")
                        }
                        status = "✅ SVG 代码已直接写入 BuildMate 素材仓库，未经过 PNG 转换。"
                        svgSourceEditorFocused = false
                        svgSourceDraft = ""
                        svgSourceValidation = ""
                        showingSVGPasteEditor = false
                    } catch { svgSourceValidation = "❌ \(error.localizedDescription)" }
                } label: { Label("保存为 SVG 素材并启用", systemImage: "square.and.arrow.down.fill").frame(maxWidth: .infinity) }.accessibilityIdentifier("ui.e53fbae016fa")
                    .buttonStyle(BMCompactButtonStyle())
                    .disabled(svgSourceDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            } else {
                Button {
                    svgSourceDraft = ""
                    svgSourceValidation = ""
                    showingSVGPasteEditor = true
                    svgSourceEditorFocused = true
                } label: { Label("打开 SVG 代码输入", systemImage: "chevron.left.forwardslash.chevron.right").frame(maxWidth: .infinity) }.accessibilityIdentifier("ui.a20c8ab83af2")
                    .buttonStyle(BMCompactButtonStyle())
            }
        }
        .padding(12)
        .background(Color.secondary.opacity(0.07))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    @ViewBuilder private var library: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("我的素材仓库").font(.headline)
                Text(customEffectLibraryNames.isEmpty ? "导入后会自动保存到这里" : "长按任意素材进入整理模式").font(.caption2).foregroundColor(.secondary)
            }
            Spacer()
            Text("\(customEffectLibraryNames.count)/30").font(.caption).foregroundColor(.secondary)
            if managingEffectLibrary {
                Button("完成") { managingEffectLibrary = false; selectedEffectLibraryNames.removeAll() }.accessibilityIdentifier("ui.8abc328407b0")
                    .font(.subheadline.weight(.semibold)).buttonStyle(.plain).foregroundColor(BMTheme.palette.accent)
            }
        }
        if customEffectLibraryNames.isEmpty {
            BMEmptyState(icon: "photo.on.rectangle.angled", title: "暂无自定义素材", message: "支持 PNG / JPG / GIF / APNG / SVG。导入后点一下即可切换。", actionTitle: "导入素材", action: { showingEffectPicker = true })
        } else {
            HStack(spacing: 10) {
                Button { showingEffectPicker = true } label: { Label("导入素材", systemImage: "plus") }.accessibilityIdentifier("ui.e6debc0266fa").buttonStyle(BMCompactButtonStyle())
                Spacer()
                if managingEffectLibrary {
                    Button(selectedEffectLibraryNames.count == customEffectLibraryNames.count ? "取消全选" : "全选") {
                        selectedEffectLibraryNames = selectedEffectLibraryNames.count == customEffectLibraryNames.count ? [] : Set(customEffectLibraryNames)
                    }.accessibilityIdentifier("ui.e3f9d80348f2").font(.caption.weight(.semibold)).buttonStyle(.plain).foregroundColor(BMTheme.palette.accent)
                    if !selectedEffectLibraryNames.isEmpty {
                        Button(role: .destructive) { showingBatchDeleteEffectConfirmation = true } label: { Text("删除 \(selectedEffectLibraryNames.count)").font(.caption.weight(.semibold)) }.accessibilityIdentifier("ui.3c353fd92d3d").buttonStyle(.plain)
                    }
                }
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 74), spacing: 10)], spacing: 10) {
                ForEach(customEffectLibraryNames, id: \.self) { name in
                    if let url = effectURL(name: name) {
                        ZStack(alignment: .topLeading) {
                            Button {
                                if managingEffectLibrary {
                                    if selectedEffectLibraryNames.contains(name) { selectedEffectLibraryNames.remove(name) } else { selectedEffectLibraryNames.insert(name) }
                                } else {
                                    customEffectURL = url; customEffectEnabled = true
                                    UserDefaults.standard.set(name, forKey: BMPersistedFileKind.effect.defaultsKey)
                                    UserDefaults.standard.set(true, forKey: "central-effect-custom-enabled")
                                }
                            } label: {
                                ZStack(alignment: .topTrailing) {
                                    RoundedRectangle(cornerRadius: BMDesign.Radius.control, style: .continuous).fill(BMTheme.palette.elevated).frame(height: 78)
                                    BMCentralMediaView(url: url, size: 62).frame(maxWidth: .infinity, maxHeight: .infinity)
                                    if (selectedEffectLibraryNames.contains(name) && managingEffectLibrary) || (customEffectURL?.lastPathComponent == name && customEffectEnabled && !managingEffectLibrary) {
                                        Image(systemName: "checkmark.circle.fill").font(.system(size: 19, weight: .semibold)).foregroundColor(BMTheme.palette.accent).background(Circle().fill(Color(uiColor: .systemBackground))).padding(5)
                                    }
                                }
                            }.accessibilityIdentifier("ui.eb3bafe196cf").buttonStyle(.plain)
                                .simultaneousGesture(LongPressGesture(minimumDuration: 0.45).onEnded { _ in if !managingEffectLibrary { managingEffectLibrary = true } })
                            if managingEffectLibrary {
                                Button(role: .destructive) {
                                    removeEffect(name); selectedEffectLibraryNames.remove(name)
                                    if customEffectLibraryNames.isEmpty { managingEffectLibrary = false }
                                } label: { Image(systemName: "minus").font(.system(size: 13, weight: .bold)).foregroundColor(.white).frame(width: 25, height: 25).background(Color.red, in: Circle()) }.accessibilityIdentifier("ui.bd7ad31c3081")
                                    .buttonStyle(.plain).offset(x: -7, y: -7)
                            }
                        }
                    }
                }
            }
            Text(managingEffectLibrary ? "整理模式：点左上角减号单删；也可勾选多个后批量删除。" : "点一下切换；长按任意素材进入整理模式。最多保留 30 个素材。")
                .font(.caption).foregroundColor(.secondary)
                .alert("删除所选素材？", isPresented: $showingBatchDeleteEffectConfirmation) {
                    Button("取消", role: .cancel) {}.accessibilityIdentifier("ui.01f41e9f2af8")
                    Button("删除 \(selectedEffectLibraryNames.count) 个", role: .destructive) { removeSelectedEffects() }.accessibilityIdentifier("ui.2c6feacefceb")
                } message: { Text("删除后无法恢复。正在使用的素材被删除时会自动切换到剩余素材。") }
        }
    }

    @ViewBuilder private var effectOptions: some View {
        if let effectURL = customEffectURL {
            Toggle("使用自定义素材", isOn: $customEffectEnabled).accessibilityIdentifier("ui.a100ce5e1a9b").onChange(of: customEffectEnabled) { UserDefaults.standard.set($0, forKey: "central-effect-custom-enabled") }
            VStack(alignment: .leading, spacing: 9) {
                HStack { Text("素材铺满比例").font(.subheadline.weight(.semibold)); Spacer(); Text("\(Int(customEffectScale * 100))%").font(.caption.monospacedDigit()).foregroundColor(.secondary) }
                Slider(value: $customEffectScale, in: 0.80...1.00, step: 0.01).onChange(of: customEffectScale) { UserDefaults.standard.set($0, forKey: "central-effect-scale-v1") }
                Toggle("圆形校正（推荐）", isOn: $customCircleCorrection).accessibilityIdentifier("ui.1e49d5369e16").onChange(of: customCircleCorrection) { UserDefaults.standard.set($0, forKey: "central-effect-circle-correction-v1") }
                Text("运动模式").font(.subheadline.weight(.semibold))
                Picker("运动模式", selection: $customMotionMode) { ForEach(BMCentralMotionMode.allCases) { mode in Text(mode.title).tag(mode) } }.accessibilityIdentifier("ui.04d5ed6a2b84")
                    .pickerStyle(.segmented).onChange(of: customMotionMode) { UserDefaults.standard.set($0.rawValue, forKey: "central-effect-motion-mode-v2") }
                Text(customMotionMode.subtitle).font(.caption).foregroundColor(.secondary)
                if customMotionMode == .fixed {
                    HStack { Text("固定转速"); Slider(value: $customFixedSpeed, in: 0...240, step: 6); Text("\(Int(customFixedSpeed))°/s").monospacedDigit().frame(width: 62, alignment: .trailing) }
                        .font(.caption).onChange(of: customFixedSpeed) { UserDefaults.standard.set($0, forKey: "central-effect-fixed-speed-v2") }
                }
                Toggle("允许 BuildMate 外层旋转", isOn: $customEffectRotates).accessibilityIdentifier("ui.b6007ffc0b91").font(.caption).disabled(customMotionMode == .intrinsic).onChange(of: customEffectRotates) { UserDefaults.standard.set($0, forKey: "central-effect-rotate-v1") }
                if BMSVGInspector.isSVG(effectURL) {
                    let info = BMSVGInspector.inspect(effectURL)
                    Label(info.animated ? "已识别：动态 SVG" : "已识别：静态 SVG", systemImage: info.animated ? "waveform.path.ecg" : "checkmark.seal.fill")
                        .font(.caption.weight(.semibold)).foregroundColor(info.valid ? .green : .red)
                }
            }.padding(12).background(Color.secondary.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    private var materialGuide: some View {
        NavigationLink {
            BMSettingsDetailPage(title: "素材使用说明") {
                VStack(alignment: .leading, spacing: 14) {
                    BMPlainCard {
                        VStack(alignment: .leading, spacing: 9) {
                            Label("推荐规格", systemImage: "info.circle.fill").font(.headline)
                            Text("• 静态：PNG / JPG / JPEG，推荐 1024×1024，透明 PNG 最佳。")
                            Text("• 动态：GIF / APNG；矢量：SVG。SVG 保持矢量清晰度并支持常见 SMIL/CSS 自身动画。")
                            Text("• 圆形主体建议占画布 96%～100%；非圆形旋转素材建议 90%～94%，并留透明安全边距。")
                            Text("• 三种模式：跟随任务 / 固定速度 / 仅素材自身动画。动态 SVG 默认使用自身动画。")
                            Text("• SVG 含脚本、网页对象或远程资源会拒绝导入；异常素材只显示安全占位，不影响编译。")
                        }.font(.caption).foregroundColor(.secondary)
                    }
                    BMPlainCard {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("SVG 制作规范").font(.headline)
                            Text("需要制作 SVG 素材时，可复制完整规范用于设计或生成工具。").font(.caption).foregroundColor(.secondary)
                            Button {
                                UIPasteboard.general.string = bmAISVGMaterialSpec
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                svgSpecCopied = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { svgSpecCopied = false }
                            } label: { Label(svgSpecCopied ? "已复制素材规范" : "复制 SVG 制作规范", systemImage: svgSpecCopied ? "checkmark.circle.fill" : "doc.on.doc").frame(maxWidth: .infinity) }.accessibilityIdentifier("ui.a8d0b950614d")
                                .buttonStyle(BMCompactButtonStyle())
                        }
                    }
                }
            }
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "book.closed.fill").foregroundColor(BMTheme.palette.accent).frame(width: 34, height: 34).background(BMTheme.palette.accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                VStack(alignment: .leading, spacing: 2) { Text("素材使用说明").font(.subheadline.weight(.semibold)).foregroundColor(.primary); Text("规格 · SVG 安全规则 · 素材制作规范").font(.caption2).foregroundColor(.secondary) }
                Spacer(); Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundColor(.secondary)
            }.padding(12).background(Color.secondary.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }.accessibilityIdentifier("ui.2a6a307c1c6e").buttonStyle(.plain)
    }
}
