import SwiftUI

struct ArtifactDeliveryCenterView: View {
    let focusRunID: String?
    @State private var records: [BMArtifactDeliveryRecord] = []
    @State private var shareRequest: ArtifactShareRequest?

    init(focusRunID: String? = nil) {
        self.focusRunID = focusRunID
    }

    var body: some View {
        List {
            Section {
                if let focusRunID, records.contains(where: { $0.runID == focusRunID }) {
                    Label("已定位本次任务产物", systemImage: "scope")
                        .font(.caption.weight(.semibold))
                        .foregroundColor(.blue)
                }
                if records.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("暂无已登记产物", systemImage: "shippingbox")
                            .font(.headline)
                        Text("以后云编译成功后，BuildMate 会把已验证 IPA 持久保存到自己的产物目录。返回待机、切到其他 App 或重新打开 BuildMate，记录都不会因为工作台复位而消失。")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    .padding(.vertical, 8)
                } else {
                    ForEach(records) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(alignment: .top) {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.artifactName).font(.subheadline.weight(.semibold)).lineLimit(2)
                                    Text("\(item.provider) · Run \(item.shortRunID)")
                                        .font(.caption2.monospaced()).foregroundColor(.secondary)
                                }
                                Spacer()
                                Text(item.stateTitle)
                                    .font(.caption2.weight(.bold))
                                    .padding(.horizontal, 8).padding(.vertical, 4)
                                    .background(stateColor(item).opacity(0.12), in: Capsule())
                                    .foregroundColor(stateColor(item))
                            }
                            if item.byteCount > 0 {
                                Text(ByteCountFormatter.string(fromByteCount: Int64(item.byteCount), countStyle: .file))
                                    .font(.caption2).foregroundColor(.secondary)
                            }
                            HStack(spacing: 10) {
                                if let url = item.localURL {
                                    Button {
                                        // Build242: bind the URL to the presentation item itself.
                                        // On iOS 15, toggling a Bool sheet in the same run loop as
                                        // assigning an optional URL could present an empty host first.
                                        shareRequest = ArtifactShareRequest(url: url)
                                    } label: {
                                        Label(item.deliveredAt == nil ? "分享/导出" : "再次分享", systemImage: "square.and.arrow.up")
                                    }.accessibilityIdentifier("ui.140f08c66e43")
                                    .buttonStyle(.borderedProminent)
                                }
                                if let buildURL = item.buildURL, let url = URL(string: buildURL) {
                                    Link(destination: url) {
                                        Label("原构建", systemImage: "arrow.up.right.square")
                                    }.accessibilityIdentifier("ui.d39cf5878120").buttonStyle(.bordered)
                                }
                                Spacer()
                                Button(role: .destructive) {
                                    BMArtifactDeliveryStore.remove(id: item.id, deleteLocalFile: true)
                                    reload()
                                } label: { Image(systemName: "trash") }.accessibilityIdentifier("ui.716a29d0a748")
                                .buttonStyle(.borderless)
                            }
                        }
                        .padding(.vertical, 5)
                    }
                }
            } header: {
                Text("产物收件箱")
            } footer: {
                Text("删除这里只删除 BuildMate 本机缓存与记录，不删除 GitHub/Codemagic 云端构建。")
            }
        }
        .navigationTitle("产物中心")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: reload)
        .sheet(item: $shareRequest) { request in
            ActivityShareSheet(items: [request.url]) { completed in
                guard completed else { return }
                DispatchQueue.main.async {
                    BMArtifactDeliveryStore.markDelivered(localURL: request.url)
                    reload()
                }
            }
        }
    }

    private func reload() {
        let all = BMArtifactDeliveryStore.load()
        guard let focusRunID, !focusRunID.isEmpty else { records = all; return }
        records = all.sorted { lhs, rhs in
            let lm = lhs.runID == focusRunID
            let rm = rhs.runID == focusRunID
            if lm != rm { return lm && !rm }
            return lhs.updatedAt > rhs.updatedAt
        }
    }
    private func stateColor(_ item: BMArtifactDeliveryRecord) -> Color {
        if item.isLocalReady { return .green }
        if item.buildURL != nil { return .orange }
        return .secondary
    }
}


private struct ArtifactShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}
