import SwiftUI

struct BMHomeHeroView: View {
    let overallReady: Bool
    let workspaceName: String
    let branchLabel: String
    let sourceProviderLabel: String
    let sourceReady: Bool
    let compilerLabel: String
    let compilerReady: Bool
    let environmentDestination: AnyView

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .center, spacing: 12) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("BuildMate")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                    Text("源码 · 编译 · 发布")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 12)
                ZStack(alignment: .bottomTrailing) {
                    Image(systemName: "hammer.fill")
                        .font(.system(size: 21, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 44, height: 44)
                        .background(LinearGradient(colors: [.blue, .indigo], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .shadow(color: .blue.opacity(0.14), radius: 7, y: 3)
                    Circle()
                        .fill(overallReady ? Color.green : Color.gray.opacity(0.75))
                        .frame(width: 11, height: 11)
                        .overlay(Circle().stroke(Color(uiColor: .systemBackground), lineWidth: 2))
                        .offset(x: 2, y: 2)
                }
            }
            NavigationLink(destination: environmentDestination) {
                statusBar
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("home.environment.entry")
        }
        .padding(.top, 10)
    }

    private var statusBar: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Label("环境", systemImage: "square.grid.2x2.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                Spacer(minLength: 6)
                Text(branchLabel)
                    .font(.caption2.monospaced().weight(.semibold))
                    .foregroundColor(workspaceName == "未选择项目" ? .secondary : .primary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.secondary.opacity(0.10))
                    .clipShape(Capsule())
                    .lineLimit(1)
            }
            Divider().padding(.vertical, 7)
            HStack(spacing: 8) {
                compactStatus(title: "源码", value: sourceProviderLabel, icon: "point.3.connected.trianglepath.dotted", ready: sourceReady)
                Divider().frame(height: 14)
                compactStatus(title: "编译", value: compilerLabel, icon: "hammer.fill", ready: compilerReady)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
        .background(Color(.secondarySystemBackground).opacity(0.92))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.primary.opacity(0.045), lineWidth: 1))
    }

    private func compactStatus(title: String, value: String, icon: String, ready: Bool) -> some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .font(.caption2.weight(.semibold))
                .foregroundColor(ready ? .blue : .secondary)
            Text("\(title) \(value)")
                .font(.caption2.weight(.semibold))
                .foregroundColor(ready ? .primary : .secondary)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity)
    }
}
