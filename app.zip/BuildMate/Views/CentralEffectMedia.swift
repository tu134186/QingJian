import SwiftUI
import UIKit
import ImageIO
import WebKit

// Build122：自定义中央素材运动策略。
enum BMCentralMotionMode: String, CaseIterable, Identifiable {
    case taskLinked
    case fixed
    case intrinsic
    var id: String { rawValue }
    var title: String {
        switch self {
        case .taskLinked: return "跟随任务"
        case .fixed: return "固定速度"
        case .intrinsic: return "仅素材自身动画"
        }
    }
    var subtitle: String {
        switch self {
        case .taskLinked: return "随上传、编译、打包、下载阶段渐进加速"
        case .fixed: return "BuildMate 只按你设定的恒定速度旋转"
        case .intrinsic: return "不叠加外层旋转，完整保留 SVG/GIF/APNG 自身动画"
        }
    }
}

enum BMSVGInspector {
    static func isSVG(_ url: URL) -> Bool { url.pathExtension.lowercased() == "svg" }

    static func inspect(_ url: URL) -> (valid: Bool, animated: Bool, reason: String?) {
        guard isSVG(url) else { return (true, false, nil) }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url), data.count <= 5_000_000,
              let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) else {
            return (false, false, "SVG 无法读取或文件过大（上限 5 MB）")
        }
        return inspect(text: text)
    }

    static func inspect(text: String) -> (valid: Bool, animated: Bool, reason: String?) {
        guard let bytes = text.data(using: .utf8), bytes.count <= 5_000_000 else {
            return (false, false, "SVG 代码过大（上限 5 MB）")
        }
        let lower = text.lowercased()
        guard lower.contains("<svg") else { return (false, false, "代码中没有有效的 <svg> 根元素") }
        guard lower.contains("</svg>") else { return (false, false, "SVG 代码不完整：缺少 </svg> 结束标签") }
        // 中央素材不需要脚本、嵌入网页或远程资源；拒绝这些内容，避免导入素材偷偷联网/执行脚本。
        let forbidden = ["<script", "<foreignobject", "javascript:", "href=\"http://", "href=\"https://", "href='http://", "href='https://", "url(http://", "url(https://"]
        if forbidden.contains(where: { lower.contains($0) }) {
            return (false, false, "SVG 含脚本、网页对象或远程资源，已为安全起见拒绝")
        }
        let animated = lower.contains("<animate") || lower.contains("<animatetransform") ||
            lower.contains("<animatemotion") || lower.contains("@keyframes") ||
            lower.contains("animation:") || lower.contains("animation-name:")
        return (true, animated, nil)
    }
}

struct BMCentralMediaView: View {
    let url: URL
    let size: CGFloat
    var circleCorrectionEnabled: Bool = true

    var body: some View {
        Group {
            if BMSVGInspector.isSVG(url) {
                let result = BMSVGInspector.inspect(url)
                if result.valid {
                    BMSVGWebView(url: url, autoCenter: circleCorrectionEnabled)
                } else {
                    BMCentralMediaFallback()
                }
            } else if let image = BMCentralMediaLoader.image(at: url, autoCenter: circleCorrectionEnabled) {
                Image(uiImage: image)
                    .resizable()
                    .interpolation(.high)
                    .antialiased(true)
                    .aspectRatio(contentMode: circleCorrectionEnabled ? .fill : .fit)
            } else {
                BMCentralMediaFallback()
            }
        }
        .frame(width: size, height: size)
        .clipped()
        .clipShape(Circle())
        .contentShape(Circle())
    }
}

private struct BMCentralMediaFallback: View {
    var body: some View {
        Image(systemName: "eye.fill")
            .resizable()
            .scaledToFit()
            .foregroundColor(.red)
            .padding(18)
    }
}

/// WKWebView 直接交给 WebKit 渲染 SVG，因此静态 SVG 保持矢量清晰度，SMIL/CSS 动画也能原样播放。
/// WebView 只读取已复制到 App 沙盒的单个 SVG 文件；导入前已拒绝脚本/远程资源。
private struct BMSVGWebView: UIViewRepresentable {
    let url: URL
    let autoCenter: Bool

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        // 用户 SVG 自带脚本在导入检查阶段已被拒绝。这里仅允许 BuildMate 自己的本地
        // 几何校正脚本读取 getBBox()，用于把视觉主体自动移回旋转中心。
        config.defaultWebpagePreferences.allowsContentJavaScript = autoCenter
        let view = WKWebView(frame: .zero, configuration: config)
        view.isOpaque = false
        view.backgroundColor = .clear
        view.scrollView.backgroundColor = .clear
        view.scrollView.isScrollEnabled = false
        view.scrollView.bounces = false
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.isUserInteractionEnabled = false
        load(url, into: view)
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        if context.coordinator.loadedURL != url {
            load(url, into: uiView)
            context.coordinator.loadedURL = url
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator(url: url) }
    final class Coordinator { var loadedURL: URL?; init(url: URL?) { loadedURL = url } }

    private func load(_ url: URL, into view: WKWebView) {
        // 包一层本地 HTML 让 SVG 在圆形容器里等比居中，不修改 SVG 原始颜色与动画。
        guard let data = try? Data(contentsOf: url),
              let svg = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) else { return }
        let html = """
        <!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1\">
        <style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent}body{display:flex;align-items:center;justify-content:center}svg{width:100%;height:100%;max-width:100%;max-height:100%;display:block;overflow:hidden}</style></head><body>\(svg)
        \(autoCenter ? """
        <script>
        (() => {
          const s=document.querySelector('svg'); if(!s) return;
          try {
            const b=s.getBBox(); if(!(b.width>0 && b.height>0)) return;
            const side=Math.max(b.width,b.height);
            const pad=side*0.015;
            const cx=b.x+b.width/2, cy=b.y+b.height/2, half=side/2+pad;
            s.setAttribute('viewBox', `${cx-half} ${cy-half} ${half*2} ${half*2}`);
            s.setAttribute('preserveAspectRatio','xMidYMid meet');
          } catch(e) {}
        })();
        </script>
        """ : "")</body></html>
        """
        view.loadHTMLString(html, baseURL: nil)
    }
}

enum BMCentralMediaLoader {
    private static let cache = NSCache<NSString, UIImage>()

    static func image(at url: URL, autoCenter: Bool = false) -> UIImage? {
        let key = "\(url.path)|center=\(autoCenter)" as NSString
        if let cached = cache.object(forKey: key) { return cached }
        let ext = url.pathExtension.lowercased()
        let sourceImage: UIImage?
        if ext == "gif" || ext == "apng" || ext == "png" {
            sourceImage = animatedImage(at: url, autoCenter: autoCenter)
        } else {
            sourceImage = UIImage(contentsOfFile: url.path).map { autoCenter ? centeredSquare($0) : $0 }
        }
        if let sourceImage { cache.setObject(sourceImage, forKey: key) }
        return sourceImage
    }

    private static func animatedImage(at url: URL, autoCenter: Bool) -> UIImage? {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let count = CGImageSourceGetCount(source)
        var raw: [UIImage] = []
        var duration: TimeInterval = 0
        for index in 0..<count {
            guard let cg = CGImageSourceCreateImageAtIndex(source, index, nil) else { continue }
            raw.append(UIImage(cgImage: cg))
            if count > 1 { duration += frameDuration(source: source, index: index) }
        }
        guard !raw.isEmpty else { return nil }
        let frames = autoCenter ? centeredFrames(raw) : raw
        if frames.count == 1 { return frames[0] }
        if duration <= 0 { duration = Double(frames.count) / 24.0 }
        return UIImage.animatedImage(with: frames, duration: duration)
    }

    // Build129：透明 PNG/GIF/APNG 使用所有帧的 alpha 并集作为统一视觉边界，
    // 再放进严格正方形画布。所有帧共用同一裁切框，避免动画自身产生二次抖动。
    private static func centeredFrames(_ images: [UIImage]) -> [UIImage] {
        let bounds = images.compactMap { $0.cgImage.flatMap(alphaBounds) }
        guard let first = bounds.first else { return images.map(centeredSquare) }
        let union = bounds.dropFirst().reduce(first) { $0.union($1) }
        return images.map { centeredSquare($0, contentBounds: union) }
    }

    private static func centeredSquare(_ image: UIImage) -> UIImage {
        centeredSquare(image, contentBounds: image.cgImage.flatMap(alphaBounds))
    }

    private static func centeredSquare(_ image: UIImage, contentBounds: CGRect?) -> UIImage {
        guard let cg = image.cgImage, let b = contentBounds, b.width > 1, b.height > 1 else { return image }
        // 全画布都不透明（常见 JPG）时保持原图，避免误把背景当主体。
        if b.width >= CGFloat(cg.width) * 0.995 && b.height >= CGFloat(cg.height) * 0.995 { return image }
        let side = ceil(max(b.width, b.height) * 1.03)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = false
        return UIGraphicsImageRenderer(size: CGSize(width: side, height: side), format: format).image { _ in
            let x = (side - b.width) / 2
            let y = (side - b.height) / 2
            let src = UIImage(cgImage: cg.cropping(to: b.integral) ?? cg, scale: 1, orientation: .up)
            src.draw(in: CGRect(x: x, y: y, width: b.width, height: b.height))
        }
    }

    private static func alphaBounds(_ cg: CGImage) -> CGRect? {
        let w = cg.width, h = cg.height
        guard w > 0, h > 0 else { return nil }
        var bytes = [UInt8](repeating: 0, count: w * h)
        guard let ctx = CGContext(data: &bytes, width: w, height: h, bitsPerComponent: 8,
                                  bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(),
                                  bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return nil }
        ctx.setBlendMode(.copy)
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        // 灰度上下文无法可靠表达 alpha；改用源图 alphaInfo 判断，无 alpha 时直接返回全幅。
        let alpha = cg.alphaInfo
        guard alpha != .none && alpha != .noneSkipFirst && alpha != .noneSkipLast else {
            return CGRect(x: 0, y: 0, width: w, height: h)
        }
        var rgba = [UInt8](repeating: 0, count: w * h * 4)
        guard let rgbaCtx = CGContext(data: &rgba, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        rgbaCtx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
        var minX = w, minY = h, maxX = -1, maxY = -1
        for y in 0..<h { for x in 0..<w where rgba[(y*w+x)*4+3] > 8 {
            minX=min(minX,x); maxX=max(maxX,x); minY=min(minY,y); maxY=max(maxY,y)
        }}
        guard maxX >= minX, maxY >= minY else { return nil }
        return CGRect(x: minX, y: minY, width: maxX-minX+1, height: maxY-minY+1)
    }

    private static func frameDuration(source: CGImageSource, index: Int) -> TimeInterval {
        guard let props = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any] else { return 1.0 / 24.0 }
        let gif = props[kCGImagePropertyGIFDictionary] as? [CFString: Any]
        let png = props[kCGImagePropertyPNGDictionary] as? [CFString: Any]
        let candidates: [Any?] = [gif?[kCGImagePropertyGIFUnclampedDelayTime], gif?[kCGImagePropertyGIFDelayTime], png?[kCGImagePropertyAPNGUnclampedDelayTime], png?[kCGImagePropertyAPNGDelayTime]]
        for value in candidates { if let n = value as? NSNumber, n.doubleValue >= 0.02 { return n.doubleValue } }
        return 1.0 / 24.0
    }
}

/// Build121/122：三勾玉使用独立矢量形状。
struct BMSharinganTomoeShape: Shape {
    func path(in rect: CGRect) -> Path {
        let sx = rect.width / 18.0
        let sy = rect.height / 15.0
        func point(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x * sx, y: y * sy) }
        var path = Path()
        path.addEllipse(in: CGRect(x: 0.5 * sx, y: 2.0 * sy, width: 10.0 * sx, height: 10.0 * sy))
        path.move(to: point(7.0, 3.0))
        path.addCurve(to: point(17.5, 3.2), control1: point(11.0, 1.2), control2: point(15.8, 1.3))
        path.addCurve(to: point(11.0, 9.5), control1: point(16.7, 6.8), control2: point(14.2, 9.0))
        path.addCurve(to: point(7.0, 8.8), control1: point(9.5, 9.8), control2: point(8.2, 9.4))
        path.closeSubpath()
        return path
    }
}

struct BMPerfectSharinganView: View {
    let spin: Double
    let accent: Color

    var body: some View {
        ZStack {
            Circle().fill(Color(red: 0.52, green: 0.015, blue: 0.025))
            Circle().fill(RadialGradient(colors: [Color.red.opacity(0.96), accent, Color(red: 0.38, green: 0.01, blue: 0.02)], center: .center, startRadius: 5, endRadius: 42))
                .padding(3)
            Circle().stroke(Color.black.opacity(0.92), lineWidth: 2.2).padding(5)
            Circle().stroke(Color.black.opacity(0.72), lineWidth: 1.4).frame(width: 53, height: 53)
            Circle().stroke(Color.black.opacity(0.62), lineWidth: 1.1).frame(width: 31, height: 31)
            ForEach(0..<3, id: \.self) { i in
                BMPerfectTomoeShape()
                    .fill(Color.black)
                    .frame(width: 15, height: 15)
                    .offset(y: -26)
                    .rotationEffect(.degrees(Double(i) * 120))
            }
            Circle().fill(Color.black).frame(width: 19, height: 19)
            Circle().fill(Color.white.opacity(0.94)).frame(width: 6, height: 6)
        }
        .frame(width: 84, height: 84)
        .clipShape(Circle())
        .rotationEffect(.degrees(spin))
        .shadow(color: accent.opacity(0.62), radius: 7)
    }
}

private struct BMPerfectTomoeShape: Shape {
    func path(in rect: CGRect) -> Path {
        let c = CGPoint(x: rect.midX, y: rect.midY)
        let r = min(rect.width, rect.height)
        var p = Path()
        p.addEllipse(in: CGRect(x: c.x-r*0.28, y: c.y-r*0.28, width: r*0.56, height: r*0.56))
        p.move(to: CGPoint(x: c.x+r*0.10, y: c.y-r*0.12))
        p.addCurve(to: CGPoint(x: c.x+r*0.48, y: c.y-r*0.34), control1: CGPoint(x: c.x+r*0.25, y: c.y-r*0.16), control2: CGPoint(x: c.x+r*0.39, y: c.y-r*0.26))
        p.addCurve(to: CGPoint(x: c.x+r*0.23, y: c.y+r*0.27), control1: CGPoint(x: c.x+r*0.49, y: c.y-r*0.02), control2: CGPoint(x: c.x+r*0.39, y: c.y+r*0.18))
        p.closeSubpath()
        return p
    }
}

enum BMCentralTheme: String, CaseIterable, Identifiable {
    case sharinganPro, aiReactor, mechanicalTurbine, quantumHex, plasmaVortex, darkGoldGyro
    var id: String { rawValue }
    var title: String {
        switch self {
        case .sharinganPro: return "写轮眼 Pro"
        case .aiReactor: return "能量反应堆"
        case .mechanicalTurbine: return "机械涡轮核心"
        case .quantumHex: return "量子六棱核心"
        case .plasmaVortex: return "等离子星环"
        case .darkGoldGyro: return "暗金陀螺仪"
        }
    }
    var subtitle: String {
        switch self {
        case .sharinganPro: return "瞳孔 / 勾玉 / 能量环分层联动"
        case .aiReactor: return "双向轨道 / 能量节点 / 核心脉冲"
        case .mechanicalTurbine: return "多层转子 / 叶片 / 机械刻度"
        case .quantumHex: return "六棱轨道 / 量子节点 / 双层反转"
        case .plasmaVortex: return "星环涡流 / 电弧节点 / 核心收束"
        case .darkGoldGyro: return "暗金刻度 / 三轴陀螺 / 中心锁定"
        }
    }
    var systemIcon: String {
        switch self {
        case .sharinganPro: return "eye.fill"
        case .aiReactor: return "atom"
        case .mechanicalTurbine: return "gearshape.2.fill"
        case .quantumHex: return "hexagon.fill"
        case .plasmaVortex: return "hurricane"
        case .darkGoldGyro: return "gyroscope"
        }
    }
    var baseColor: Color {
        switch self {
        case .sharinganPro: return Color(red: 0.95, green: 0.08, blue: 0.12)
        case .aiReactor: return Color(red: 0.08, green: 0.68, blue: 1.0)
        case .mechanicalTurbine: return Color(red: 1.0, green: 0.55, blue: 0.10)
        case .quantumHex: return Color(red: 0.64, green: 0.30, blue: 1.0)
        case .plasmaVortex: return Color(red: 0.08, green: 0.92, blue: 0.94)
        case .darkGoldGyro: return Color(red: 0.96, green: 0.72, blue: 0.22)
        }
    }
    static func migrated(rawValue: String) -> BMCentralTheme {
        if let current = BMCentralTheme(rawValue: rawValue) { return current }
        switch rawValue {
        case "techCore", "neuralRing", "successEnergy": return .aiReactor
        case "compileTurbine", "blackGold": return .mechanicalTurbine
        default: return .sharinganPro
        }
    }
}
