import SwiftUI

struct BMActiveWorkBanner: View {
    let workStage: BuildWorkStage
    let workDetail: String
    let busy: Bool
    let workStartedAt: Date?
    let aiRound: Int
    let maxRepairRounds: Int
    let onResume: () -> Void
    let onReturnIdle: () -> Void

    var body: some View {
        TimelineView(.periodic(from: .now, by: 0.05)) { context in
            let elapsed = workStartedAt.map { max(0, Int(context.date.timeIntervalSince($0))) } ?? 0
            let isAI = [.aiReading, .aiAnalyzing, .aiPatching, .aiRebuilding, .aiRetrying].contains(workStage)
            let phase = context.date.timeIntervalSinceReferenceDate
            let gearAngle = (phase.truncatingRemainder(dividingBy: 1.15) / 1.15) * 360.0
            let iconWobble = sin(phase * 7.0) * 9.0
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(Color.white.opacity(0.20)).frame(width: 54, height: 54)
                    Image(systemName: workStage.icon).font(.title2.bold()).foregroundColor(.white)
                        .rotationEffect(.degrees(busy && !isAI ? iconWobble : 0))
                        .scaleEffect(busy && isAI ? (1.0 + 0.06 * sin(phase * 5.0)) : 0.94)
                    if busy && !isAI {
                        Image(systemName: "gearshape.fill").font(.caption).foregroundColor(.white).offset(x: 19, y: 18).rotationEffect(.degrees(gearAngle))
                    }
                }
                VStack(alignment: .leading, spacing: 4) {
                    Text(workStage.title).font(.headline).foregroundColor(.white)
                    if !workDetail.isEmpty { Text(workDetail).font(.caption).foregroundColor(.white.opacity(0.90)).lineLimit(2) }
                    HStack(spacing: 8) {
                        if busy { Text(String(format: "已运行 %02d:%02d", elapsed / 60, elapsed % 60)) }
                        if aiRound > 0 { Text("AI 第 \(aiRound)/\(maxRepairRounds) 轮") }
                    }.font(.caption2.weight(.semibold)).foregroundColor(.white.opacity(0.80))
                }
                Spacer()
                if busy {
                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .white)).scaleEffect(0.90).frame(width: 34, height: 34).accessibilityLabel("任务运行中")
                } else if workStage == .recovering {
                    Button(action: onResume) { Text("重新同步").font(.caption.weight(.semibold)).foregroundColor(.white).padding(.horizontal, 10).padding(.vertical, 7).background(Color.white.opacity(0.18), in: Capsule()) }.accessibilityIdentifier("ui.6c2afa137589").buttonStyle(.plain)
                } else if workStage == .artifactPending || workStage == .success || workStage == .failed || workStage == .cancelled {
                    Button(action: onReturnIdle) { Text("返回待机").font(.caption.weight(.semibold)).foregroundColor(.white).padding(.horizontal, 10).padding(.vertical, 7).background(Color.white.opacity(0.18)).clipShape(Capsule()) }.accessibilityIdentifier("ui.aaed3698f640").buttonStyle(.plain)
                }
            }
            .padding(16).background(gradient).clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
        }
    }

    private var gradient: LinearGradient {
        let colors: [Color]
        switch workStage {
        case .failed: colors = [.red, .orange]
        case .cancelled: colors = [.gray, .secondary]
        case .artifactPending: colors = [.orange, .teal]
        case .success: colors = [.green, .teal]
        case .aiReading, .aiAnalyzing, .aiPatching, .aiRebuilding, .aiRetrying: colors = [.purple, .indigo]
        default: colors = [.blue, .cyan]
        }
        return LinearGradient(colors: colors, startPoint: .leading, endPoint: .trailing)
    }
}

struct BMDuplicateCompileConfirmCard: View {
    let message: String
    let onCancel: () -> Void
    let onContinue: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "shield.lefthalf.filled").font(.title3.bold()).foregroundColor(.orange)
                VStack(alignment: .leading, spacing: 2) { Text("再次云端编译？").font(.headline); Text("重复源码保护已拦截本次任务").font(.caption).foregroundColor(.secondary) }
                Spacer()
            }
            Text(message).font(.caption).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
            Text("继续只放行这一次，不会关闭以后重复源码保护，也不会因为改 ZIP 文件名绕过 SHA-256。").font(.caption2).foregroundColor(.secondary)
            HStack(spacing: 10) {
                Button(action: onCancel) { Text("取消").frame(maxWidth: .infinity) }.accessibilityIdentifier("ui.1c8a794faa01").buttonStyle(.bordered)
                Button(action: onContinue) { Label("继续编译一次", systemImage: "bolt.fill").frame(maxWidth: .infinity) }.accessibilityIdentifier("ui.32499684da53").buttonStyle(.borderedProminent)
            }
        }
        .padding(14).background(Color(uiColor: .secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.orange.opacity(0.22), lineWidth: 1))
    }
}
