import SwiftUI

/// Build186: repository/project selection sheets extracted from ContentView.
struct BMRepositoryPickerSheet: View {
    let repositories: [GitHubRepository]
    let selectedOwner: String
    let selectedRepo: String
    @Binding var search: String
    let onSelect: (GitHubRepository) -> Void
    let onClose: () -> Void

    private var filtered: [GitHubRepository] {
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return repositories }
        return repositories.filter { $0.fullName.localizedCaseInsensitiveContains(q) || $0.name.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        NavigationView {
            List(filtered) { item in
                Button { onSelect(item) } label: {
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(item.name).font(.headline).foregroundColor(.primary)
                            Text(item.fullName + " · " + item.defaultBranch).font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                        if item.isPrivate { Image(systemName: "lock.fill").foregroundColor(.secondary) }
                        if item.owner == selectedOwner && item.name == selectedRepo { Image(systemName: "checkmark.circle.fill").foregroundColor(.blue) }
                    }
                }.accessibilityIdentifier("ui.64f0d8aa65dc").buttonStyle(.plain)
            }
            .searchable(text: $search, prompt: "搜索仓库")
            .navigationTitle("选择源码仓库")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭", action: onClose).accessibilityIdentifier("ui.e271a66cb220") } }
        }
    }
}

struct BMProjectPickerSheet: View {
    let repositories: [GitHubRepository]
    let tokenAvailable: Bool
    let token: String
    let checking: Bool
    let selectedOwner: String
    let selectedRepo: String
    @Binding var search: String
    let onSelect: (GitHubRepository) -> Void
    let onCreate: () -> Void
    let onRefresh: () -> Void
    let onDeleted: (GitHubRepository) -> Void
    let onClose: () -> Void

    @State private var deleteTarget: GitHubRepository?
    @State private var deleteConfirmText = ""
    @State private var deleting = false
    @State private var deleteErrorText = ""

    private var filtered: [GitHubRepository] {
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return repositories }
        return repositories.filter { $0.fullName.localizedCaseInsensitiveContains(q) || $0.name.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        NavigationView {
            List {
                if repositories.isEmpty {
                    Section { HStack(spacing: 10) { ProgressView(); Text(tokenAvailable ? "正在读取 GitHub 可访问仓库…" : "请先连接 GitHub").foregroundColor(.secondary) } }
                } else {
                    Section("GitHub 可访问仓库 · \(filtered.count)") {
                        ForEach(filtered) { item in
                            HStack(spacing: 10) {
                                Button { onSelect(item) } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: "folder.fill").foregroundColor(.blue).frame(width: 34, height: 34).background(Color.blue.opacity(0.1)).clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
                                        VStack(alignment: .leading, spacing: 3) {
                                            HStack(spacing: 6) { Text(item.name).font(.headline).foregroundColor(.primary); if item.isPrivate { Image(systemName: "lock.fill").font(.caption2).foregroundColor(.secondary) } }
                                            Text(item.fullName + " · " + item.defaultBranch).font(.caption).foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        if item.owner == selectedOwner && item.name == selectedRepo { Image(systemName: "checkmark.circle.fill").foregroundColor(.green) }
                                    }
                                }.accessibilityIdentifier("ui.54917535b72e").buttonStyle(.plain)
                                Menu {
                                    Button(role: .destructive) {
                                        deleteTarget = item
                                        deleteConfirmText = ""
                                        deleteErrorText = ""
                                    } label: { Label("永久删除仓库", systemImage: "trash") }
                                } label: {
                                    Image(systemName: "ellipsis.circle").font(.title3).foregroundColor(.secondary)
                                }
                                .disabled(deleting || !tokenAvailable)
                            }
                        }
                    }
                }
            }
            .searchable(text: $search, prompt: "搜索源码仓库")
            .navigationTitle("切换项目")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("关闭", action: onClose).accessibilityIdentifier("ui.7684072daca2") }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button(action: onCreate) { Image(systemName: "plus") }.accessibilityIdentifier("ui.23efd935afc8").disabled(!tokenAvailable)
                    Button(action: onRefresh) { Image(systemName: "arrow.clockwise") }.accessibilityIdentifier("ui.aa9275e403b2").disabled(!tokenAvailable || checking)
                }
            }
            .sheet(item: $deleteTarget) { item in
                NavigationView {
                    Form {
                        Section("永久删除") {
                            Text(item.fullName).font(.headline).textSelection(.enabled)
                            Text("输入仓库名称 \(item.name) 确认。删除会永久删除 GitHub 上的源码和相关历史。")
                                .font(.footnote).foregroundColor(.secondary)
                            TextField(item.name, text: $deleteConfirmText)
                                .textInputAutocapitalization(.never).autocorrectionDisabled(true)
                        }
                        if !deleteErrorText.isEmpty { Section { Text(deleteErrorText).foregroundColor(.red).font(.footnote) } }
                        Section {
                            Button(deleting ? "正在删除…" : "永久删除 \(item.name)", role: .destructive) { Task { await deleteRepository(item) } }
                                .disabled(deleting || deleteConfirmText != item.name || token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                    }
                    .navigationTitle("确认删除仓库").navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { if !deleting { deleteTarget = nil } } } }
                }
            }
        }
    }

    @MainActor
    private func deleteRepository(_ item: GitHubRepository) async {
        deleting = true; deleteErrorText = ""
        defer { deleting = false }
        do {
            let service = GitHubService(owner: item.owner, repo: item.name, token: token)
            let verified = try await service.repoInfo()
            guard verified.fullName.caseInsensitiveCompare(item.fullName) == .orderedSame else {
                deleteErrorText = "安全校验失败：GitHub 返回仓库与当前选择不一致。"; return
            }
            try await service.deleteRepository()
            onDeleted(item)
            deleteTarget = nil
        } catch {
            let message = error.localizedDescription
            if message.contains("403") {
                deleteErrorText = "删除失败：GitHub Token 需要目标仓库的 Administration · Read and write 权限。"
            } else { deleteErrorText = "删除失败：\(message)" }
        }
    }
}

struct BMNewProjectSheet: View {
    @Binding var name: String
    @Binding var description: String
    @Binding var isPrivate: Bool
    let tokenAvailable: Bool
    let githubLogin: String
    let creating: Bool
    let progress: String
    let onCreate: () -> Void
    let onClose: () -> Void

    var body: some View {
        NavigationView {
            Form {
                Section("新项目") {
                    TextField("GitHub 仓库名称", text: $name).textInputAutocapitalization(.never).autocorrectionDisabled(true)
                    TextField("项目说明（可选）", text: $description)
                    Toggle("私有仓库", isOn: $isPrivate).accessibilityIdentifier("ui.d400afe9e4f7")
                }
                Section("源码平台 · GitHub") {
                    HStack {
                        Text("Token"); Spacer()
                        if tokenAvailable { Label(githubLogin.isEmpty ? "已保存，创建时验证" : githubLogin, systemImage: "checkmark.circle.fill").foregroundColor(.green) }
                        else { Label("未连接", systemImage: "exclamationmark.triangle.fill").foregroundColor(.orange) }
                    }
                    if !tokenAvailable { Text("仓库名称可以先填写；点击创建时会明确提示先去设置连接 GitHub，不再让按钮一直灰掉。").font(.footnote).foregroundColor(.secondary) }
                }
                Section { Text("BuildMate 会在当前 GitHub 源码适配器中创建仓库并初始化默认分支。真实编译使用 Codemagic、Bitrise 或私人 Mac Provider。").font(.footnote).foregroundColor(.secondary) }
                if !progress.isEmpty { Section("创建进度") { HStack(spacing: 10) { if creating { ProgressView() }; Text(progress).font(.footnote).foregroundColor(.secondary) } } }
                Section {
                    Button(action: onCreate) { HStack { Spacer(); if creating { ProgressView().padding(.trailing, 6) }; Text(creating ? "正在创建…" : "创建并初始化项目").fontWeight(.semibold); Spacer() } }.accessibilityIdentifier("ui.976a7b324299")
                        .disabled(creating || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .navigationTitle("新建项目").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { if !creating { onClose() } }.accessibilityIdentifier("ui.8926b773adcc") } }
        }
    }
}
