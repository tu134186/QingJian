import SwiftUI
import UniformTypeIdentifiers

struct BMBackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.data, .zip, .item] }
    var data: Data
    init(data: Data = Data()) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}

struct BackupRestoreView: View {
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var exportDocument = BMBackupDocument()
    @State private var showingExporter = false
    @State private var showingImporter = false
    @State private var status = ""
    @State private var pendingRestoreData: Data?
    @State private var preview: BMBackupPreview?
    @State private var showingRestoreConfirmation = false

    var body: some View {
        Form {
            Section("备份密码") {
                SecureField("至少 6 位", text: $password)
                SecureField("再次输入密码", text: $confirmPassword)
                Text("凭据会加密保存；BuildMate 无法找回备份密码。")
                    .font(.caption).foregroundColor(.secondary)
            }

            Section("备份操作") {
                HStack(spacing: 12) {
                    Button { exportBackup() } label: {
                        Label("导出备份", systemImage: "square.and.arrow.up")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    Button {
                        status = "正在打开备份文件…"
                        showingImporter = true
                    } label: {
                        Label("恢复备份", systemImage: "square.and.arrow.down")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                DisclosureGroup("备份说明") {
                    Text("支持 BuildMate 自己导出的 .bmbak 和 ZIP。恢复前先预览，只迁移当前仍支持的 GitHub / Codemagic / Mac 配置、必要凭据和中央素材；旧 AI、中枢、自动调度与页面状态不会恢复。")
                        .font(.caption).foregroundColor(.secondary)
                }
                if BMBackupRestoreService.canRollback() {
                    Button("撤销上一次恢复") { rollback() }.foregroundColor(.orange)
                }
            }

            if let preview {
                Section("恢复预览") {
                    HStack { Text("来源"); Spacer(); Text("V\(preview.sourceVersion) · Build \(preview.sourceBuild)").foregroundColor(.secondary) }
                    Text(preview.summary).font(.footnote)
                    Button("确认恢复") { showingRestoreConfirmation = true }
                        .buttonStyle(.borderedProminent)
                }
            }

            if !status.isEmpty { Section("结果") { Text(status).font(.footnote) } }
        }
        .navigationTitle("备份与恢复")
        .navigationBarTitleDisplayMode(.inline)
        .fileExporter(isPresented: $showingExporter, document: exportDocument, contentType: .data, defaultFilename: "BuildMate-Backup.bmbak") { result in
            if case .failure(let error) = result { status = "❌ 导出失败：\(error.localizedDescription)" }
            else { status = "✅ 备份已导出。" }
        }
        .sheet(isPresented: $showingImporter) {
            DocumentPicker(contentTypes: [.item, .zip, .data]) { url in
                showingImporter = false
                status = "正在读取备份…"
                DispatchQueue.main.async { inspect(url) }
            } onCancel: {
                showingImporter = false
                if status == "正在打开备份文件…" { status = "已取消选择备份。" }
            }
        }
        .confirmationDialog("恢复这份备份？", isPresented: $showingRestoreConfirmation, titleVisibility: .visible) {
            Button("恢复", role: .destructive) { commitRestore() }
            Button("取消", role: .cancel) { }
        } message: {
            Text("只迁移当前仍支持的数据；不会恢复旧 UI、AI、中枢、自动调度或旧编译逻辑。")
        }
    }

    private func exportBackup() {
        guard password == confirmPassword else { status = "❌ 两次输入的备份密码不一致。"; return }
        do {
            exportDocument = BMBackupDocument(data: try BMBackupRestoreService.makeBackup(password: password))
            showingExporter = true
        } catch { status = "❌ \(error.localizedDescription)" }
    }

    private func inspect(_ url: URL) {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            let p = try BMBackupRestoreService.preview(data: data, password: password)
            pendingRestoreData = data
            preview = p
            status = "✅ 已识别备份，确认后再写入当前配置。"
        } catch {
            pendingRestoreData = nil
            preview = nil
            status = "❌ 无法读取备份：\(error.localizedDescription)"
        }
    }

    private func commitRestore() {
        guard let data = pendingRestoreData else { status = "❌ 请重新选择备份文件。"; return }
        do {
            let payload = try BMBackupRestoreService.restore(data: data, password: password)
            preview = nil
            pendingRestoreData = nil
            status = "✅ 恢复完成：兼容迁移配置与凭据，自定义中央素材 \(payload.centralEffects.count) 个。建议重新打开 BuildMate。"
        } catch { status = "❌ 恢复失败：\(error.localizedDescription)" }
    }

    private func rollback() {
        do {
            _ = try BMBackupRestoreService.rollback(password: password)
            preview = nil
            pendingRestoreData = nil
            status = "✅ 已恢复到导入前的配置快照。建议重新打开 BuildMate。"
        } catch { status = "❌ 回滚失败：\(error.localizedDescription)" }
    }
}
