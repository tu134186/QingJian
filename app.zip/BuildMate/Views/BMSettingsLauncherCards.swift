import SwiftUI

// Build214–219: 设置页导航壳独立。
// 只承载标题/副标题/图标与 AnyView destination，不持有业务状态，不发网络请求。
struct BMSourcePlatformLauncherCard: View {
    let subtitle: String
    let destination: AnyView
    var body: some View {
        BMSettingsNavigationCard(title: "源码平台", subtitle: subtitle, icon: "icloud.and.arrow.up.fill") { destination }
    }
}

struct BMCentralEffectLauncherCard: View {
    let subtitle: String
    let destination: AnyView
    var body: some View {
        BMSettingsNavigationCard(title: "中央特效", subtitle: subtitle, icon: "eye.fill") { destination }
    }
}

struct BMAdvancedOverrideLauncherCard: View {
    let subtitle: String
    let destination: AnyView
    var body: some View {
        BMSettingsNavigationCard(title: "高级覆盖", subtitle: subtitle, icon: "slider.horizontal.3") { destination }
    }
}


struct BMBackupRestoreLauncherCard: View {
    var body: some View {
        BMSettingsNavigationCard(title: "备份与恢复", subtitle: "加密备份 Token / 编译配置 / 中央素材", icon: "externaldrive.badge.timemachine") { AnyView(BackupRestoreView()) }
    }
}
