import SwiftUI
import UIKit

struct TaskBlackBoxView: View {
    @StateObject private var store = BMTaskBlackBox.shared
    var taskID: String? = nil
    var sourceSHA: String? = nil
    @State private var showingClearConfirm = false
    @State private var recoveryNotice = ""

    private var ghosts: [BMGhostTask] {
        let all = BMTaskRecoveryCenter.ghostTasks()
        guard let sha = sourceSHA, !sha.isEmpty else { return all }
        return all.filter { $0.task.sourceSHA256 == sha }
    }
    private var resolvedTaskID: String? {
        if let taskID = taskID { return taskID }
        if sourceSHA != nil { return nil }
        return store.latestTaskID
    }
    private var recent: [BMBlackBoxEvent] {
        let base: [BMBlackBoxEvent]
        if let id = resolvedTaskID {
            base = store.events(for: id)
        } else if let sha = sourceSHA, !sha.isEmpty {
            base = store.events.filter { $0.taskID != "APP" && $0.sourceSHA256 == sha }
        } else {
            base = store.events.filter { $0.taskID != "APP" }
        }
        return Array(base.suffix(250).reversed())
    }

    var body: some View {
        List {
            Section {
                Text(resolvedTaskID.map { "当前只显示任务 \($0)，不会混入其他任务。失败任务的诊断导出统一从工作台 BUG 报告或任务详情进入。" } ?? (sourceSHA?.isEmpty == false ? "当前只显示这份源码的任务与恢复项；其他源码的历史任务仍保留，但不会混入当前智能体。" : "暂无具体任务；真正启动编译、AI 或恢复任务后会自动生成 Task ID。"))
                    .font(.footnote)
                    .foregroundColor(.secondary)
            } header: { Text("任务黑匣子") }

            if !ghosts.isEmpty {
                Section("待恢复 / 幽灵任务 · \(ghosts.count)") {
                    ForEach(ghosts.prefix(8)) { ghost in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack { Text(ghost.kind.rawValue).font(.subheadline.weight(.semibold)); Spacer(); Text(ghost.task.id).font(.caption2.monospaced()).foregroundColor(.secondary) }
                            Text(ghost.reason).font(.caption).foregroundColor(.secondary)
                            Button(BMTaskRecoveryCenter.plan(for: ghost.task).title) {
                                if let plan = BMTaskRecoveryCenter.prepareResume(taskID: ghost.task.id) { recoveryNotice = "✅ \(ghost.task.id)：\(plan.title)已准备" }
                            }.accessibilityIdentifier("ui.c2661d4582df").buttonStyle(.bordered)
                        }.padding(.vertical, 3)
                    }
                    if !recoveryNotice.isEmpty { Text(recoveryNotice).font(.caption).foregroundColor(.secondary) }
                }
            }

            Section("本次时间线 · \(recent.count)") {
                if recent.isEmpty {
                    Text("暂无事件。下一次任务开始后会自动记录。")
                        .foregroundColor(.secondary)
                } else {
                    ForEach(recent) { event in
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text("#\(event.sequence) · \(event.stage)")
                                    .font(.subheadline.weight(.semibold))
                                Spacer()
                                Text(event.level)
                                    .font(.caption2)
                                    .foregroundColor(event.level == "ERROR" ? .red : .secondary)
                            }
                            Text(event.message)
                                .font(.caption)
                                .textSelection(.enabled)
                            Text(event.date.formatted(date: .omitted, time: .standard))
                                .font(.caption2)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 3)
                    }
                }
            }

            Section {
                Button(role: .destructive) { showingClearConfirm = true } label: {
                    Label("清空全部历史黑匣子", systemImage: "trash")
                }.accessibilityIdentifier("ui.2d79db298359")
            } footer: {
                Text("平时无需清空。历史记录是任务恢复和异常追踪证据，只有明确要删除时再使用。")
            }
        }
        .navigationTitle("任务时间线")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("确定清空历史黑匣子？", isPresented: $showingClearConfirm, titleVisibility: .visible) {
            Button("清空全部历史", role: .destructive) { store.clear() }.accessibilityIdentifier("ui.4a61771c8070")
            Button("取消", role: .cancel) {}.accessibilityIdentifier("ui.ea6d726fe2fc")
        } message: {
            Text("此操作会删除所有历史任务黑匣子记录，无法恢复。")
        }
    }
}

struct BMDiagnosticSharePayload: Identifiable {
    let id = UUID()
    let url: URL
}

struct BMBlackBoxShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
