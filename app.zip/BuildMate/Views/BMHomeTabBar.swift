import SwiftUI

struct BMHomeTabBar: View {
    @Binding var selection: Int
    private let items: [(String, String)] = [("首页", "bolt"), ("发布", "paperplane.fill"), ("任务", "list.bullet.rectangle"), ("设置", "gearshape")]

    var body: some View {
        HStack(spacing: 2) {
            ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                button(index, title: item.0, icon: item.1)
            }
        }
        .padding(.horizontal, 8).padding(.top, 6).padding(.bottom, 5)
        .frame(minHeight: BMDesign.Size.tabHeight)
        .background(.ultraThinMaterial)
        .overlay(Rectangle().fill(BMTheme.palette.separator).frame(height: 0.5), alignment: .top)
    }

    private func button(_ index: Int, title: String, icon: String) -> some View {
        let selected = selection == index
        return Button { withAnimation(BMDesign.Motion.fast) { selection = index } } label: {
            VStack(spacing: 3) {
                ZStack {
                    if selected { Capsule().fill(BMTheme.palette.accent.opacity(0.11)).frame(width: 42, height: 27) }
                    Image(systemName: icon).font(.system(size: BMDesign.Size.tabIcon, weight: selected ? .semibold : .medium))
                }.frame(height: 27)
                Text(title).font(.caption2.weight(selected ? .semibold : .medium))
            }
            .foregroundColor(selected ? BMTheme.palette.accent : .secondary)
            .frame(maxWidth: .infinity).contentShape(Rectangle())
        }.accessibilityIdentifier("ui.2343efd9cd7d").buttonStyle(.plain)
    }
}
