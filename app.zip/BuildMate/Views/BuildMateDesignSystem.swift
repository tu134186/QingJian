import SwiftUI

// MARK: - BuildMate Design System / Theme Engine
// Build134: 全 App “校服”层。业务页面只描述内容，颜色/圆角/间距/动画从这里取。
// 未来切换新的 iOS 视觉语言时优先替换 Token / Theme，不逐页重写业务 UI。
enum BMDesign {
    enum Spacing {
        static let page: CGFloat = 16
        static let section: CGFloat = 12
        static let card: CGFloat = 16
        static let row: CGFloat = 12
        static let compact: CGFloat = 8
    }
    enum Radius {
        static let card: CGFloat = 20
        static let control: CGFloat = 14
        static let compact: CGFloat = 12
    }
    enum Motion {
        static let fast = Animation.easeOut(duration: 0.16)
        static let standard = Animation.easeInOut(duration: 0.22)
        static let spring = Animation.interpolatingSpring(stiffness: 300, damping: 30)
    }
    enum Size {
        static let controlHeight: CGFloat = 46
        static let tabIcon: CGFloat = 19
        static let tabHeight: CGFloat = 58
        static let leadingIcon: CGFloat = 28
    }
}

enum BMThemeStyle: String, CaseIterable, Identifiable {
    case system = "系统经典"
    case graphite = "深色专业"
    var id: String { rawValue }
}

struct BMThemePalette {
    let accent: Color
    let page: Color
    let card: Color
    let elevated: Color
    let separator: Color
    let shadow: Color

    static func resolve(_ style: BMThemeStyle) -> BMThemePalette {
        switch style {
        case .system:
            return .init(
                accent: .blue,
                page: Color(uiColor: .systemGroupedBackground),
                card: Color(uiColor: .secondarySystemGroupedBackground),
                elevated: Color(uiColor: .tertiarySystemGroupedBackground),
                separator: Color.primary.opacity(0.055),
                shadow: Color.black.opacity(0.045)
            )
        case .graphite:
            return .init(
                accent: .indigo,
                page: Color(uiColor: .systemGroupedBackground),
                card: Color(uiColor: .secondarySystemGroupedBackground),
                elevated: Color(uiColor: .tertiarySystemGroupedBackground),
                separator: Color.primary.opacity(0.07),
                shadow: Color.black.opacity(0.06)
            )
        }
    }
}

enum BMTheme {
    static var style: BMThemeStyle {
        BMThemeStyle(rawValue: UserDefaults.standard.string(forKey: "bm-theme-style-v1") ?? "") ?? .system
    }
    static var palette: BMThemePalette { .resolve(style) }
}

struct BMPageBackground: View {
    var body: some View { BMTheme.palette.page.ignoresSafeArea() }
}

struct BMUnifiedCard<Content: View>: View {
    let title: String
    let icon: String
    let content: Content
    init(_ title: String, icon: String, @ViewBuilder content: () -> Content) {
        self.title = title; self.icon = icon; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: BMDesign.Spacing.section) {
            Label(title, systemImage: icon).font(.headline)
            content
        }
        .padding(BMDesign.Spacing.card)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(BMTheme.palette.card)
        .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous).stroke(BMTheme.palette.separator, lineWidth: 1))
        .shadow(color: BMTheme.palette.shadow, radius: 12, y: 5)
    }
}

struct BMPlainCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content
            .padding(BMDesign.Spacing.card)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(BMTheme.palette.card)
            .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous).stroke(BMTheme.palette.separator, lineWidth: 1))
            .shadow(color: BMTheme.palette.shadow, radius: 12, y: 5)
    }
}

struct BMUnifiedRow: View {
    let title: String; let subtitle: String; let icon: String; var tint: Color = BMTheme.palette.accent
    var body: some View {
        HStack(spacing: BMDesign.Spacing.row) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(tint)
                .frame(width: BMDesign.Size.leadingIcon, height: BMDesign.Size.leadingIcon)
                .background(tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundColor(.primary)
                if !subtitle.isEmpty { Text(subtitle).font(.caption).foregroundColor(.secondary).lineLimit(2) }
            }
            Spacer(); Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
        }.contentShape(Rectangle())
    }
}

struct BMSectionTitle: View {
    let title: String; let icon: String; var tint: Color = BMTheme.palette.accent
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon).font(.system(size: 17, weight: .semibold)).foregroundColor(tint).frame(width: 24)
            Text(title).font(.headline)
            Spacer(minLength: 0)
        }
    }
}

struct BMEmptyState: View {
    let icon: String; let title: String; let message: String
    var actionTitle: String? = nil; var action: (() -> Void)? = nil
    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: icon).font(.system(size: 30, weight: .medium)).foregroundColor(.secondary)
            Text(title).font(.headline)
            Text(message).font(.caption).foregroundColor(.secondary).multilineTextAlignment(.center)
            if let actionTitle, let action {
                Button(actionTitle, action: action).accessibilityIdentifier("ui.97c4b9699ff8").buttonStyle(.borderedProminent).controlSize(.small)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 26)
    }
}

struct BMStatusBadge: View {
    let title: String; let color: Color
    var body: some View {
        HStack(spacing: 5) { Circle().fill(color).frame(width: 7, height: 7); Text(title).font(.caption.weight(.semibold)) }
            .padding(.horizontal, 9).padding(.vertical, 6)
            .background(color.opacity(0.10), in: Capsule())
            .foregroundColor(color)
    }
}

struct BMStatusDot: View {
    let ready: Bool
    var body: some View { Circle().fill(ready ? Color.green : Color.gray).frame(width: 8, height: 8) }
}

struct BMShareButton<LabelContent: View>: View {
    let item: URL
    let label: LabelContent
    @State private var showing = false
    init(item: URL, @ViewBuilder label: () -> LabelContent) { self.item = item; self.label = label() }
    var body: some View {
        Button { showing = true } label: { label }.accessibilityIdentifier("ui.ec4e612c278d")
            .sheet(isPresented: $showing) { BMSystemShareSheet(items: [item]) }
    }
}

private struct BMSystemShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct BMKeyValueRow: View {
    let key: String; let value: String
    init(_ key: String, value: String) { self.key = key; self.value = value }
    var body: some View { HStack(alignment: .firstTextBaseline) { Text(key); Spacer(minLength: 12); Text(value).foregroundColor(.secondary).multilineTextAlignment(.trailing) } }
}
