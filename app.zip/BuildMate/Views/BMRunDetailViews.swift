import SwiftUI

struct BMRunPipelineCard: View {
    let workStage: BuildWorkStage
    let busy: Bool
    let aiRound: Int
    let maxRepairRounds: Int
    let workDetail: String
    private let steps: [(String, String)] = [("准备", "doc.zipper"), ("上传", "icloud.and.arrow.up"), ("工作流", "arrow.triangle.branch"), ("Run", "play.circle"), ("Xcode", "chevron.left.forwardslash.chevron.right"), ("打包", "shippingbox"), ("下载", "square.and.arrow.down"), ("完成", "checkmark.circle")]

    var body: some View {
        let current = workStage.pipelineIndex
        return BMCard {
            VStack(alignment: .leading, spacing: 12) {
                BMContentSectionTitle("真实编译流水线", icon: "point.3.connected.trianglepath.dotted")
                Text("只跟随 BuildMate / GitHub 的真实阶段变化，不使用虚构百分比。").font(.caption).foregroundColor(.secondary)
                ForEach(Array(steps.enumerated()), id: \.offset) { index, step in
                    let number = index + 1
                    HStack(spacing: 10) {
                        Image(systemName: workStage == .failed && number == current ? "xmark.circle.fill" : (number < current || workStage == .success ? "checkmark.circle.fill" : step.1))
                            .frame(width: 24).foregroundColor(number < current || workStage == .success ? .green : (number == current ? (workStage == .failed ? .red : .blue) : .secondary))
                        Text(step.0).font(.subheadline.weight(number == current ? .semibold : .regular))
                        Spacer()
                        if number == current && busy { ProgressView().scaleEffect(0.75) }
                        else if number < current || workStage == .success { Text("完成").font(.caption2).foregroundColor(.green) }
                    }
                }
            }
        }
    }
}

struct BMCurrentRunCard: View {
    let report: BuildReport?
    let latestRunID: Int64?
    let workDetail: String
    let aiRound: Int
    let maxRepairRounds: Int
    let busy: Bool

    var body: some View {
        BMCard {
            VStack(alignment: .leading, spacing: 8) {
                BMContentSectionTitle("运行详情", icon: "waveform.path.ecg")
                if let report, report.runID == latestRunID {
                    if let projectType = report.projectType { Text("工程：\(projectType)") }
                    if let scheme = report.scheme { Text("Scheme：\(scheme)") }
                    if let version = report.version { Text("版本：\(version) · Build \(report.build ?? "?")") }
                    if let artifact = report.ipaName ?? report.debName { Text("产物：\(artifact)") }
                    if !report.ok, let diagnosis = report.diagnosis, !diagnosis.isEmpty { Text("判断：\(diagnosis)") }
                    HStack(spacing: 8) {
                        if let runID = report.runID { Text("Run #\(runID)") }
                        if report.hasVerifiedArtifact { Text("· 产物已验证") }
                    }.font(.caption).foregroundColor(.secondary)
                } else if let latestRunID {
                    Text("Run #\(latestRunID)").font(.subheadline.weight(.semibold))
                    Text(workDetail.isEmpty ? "正在等待本次 Run 报告同步。" : workDetail).font(.caption).foregroundColor(.secondary).lineLimit(2)
                } else {
                    Text("本次运行开始后，这里只显示工程、Scheme、版本、Run 与产物等技术详情。").font(.caption).foregroundColor(.secondary)
                }
            }.font(.subheadline).textSelection(.enabled)
        }
    }
}
