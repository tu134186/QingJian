import SwiftUI
import UniformTypeIdentifiers
import UIKit

extension ContentView {
    @MainActor func openFailureReport() {
        if diagnosticReportURL == nil {
            diagnosticReportURL = makeDiagnosticReport(reason: status.isEmpty ? "当前任务失败，尚未取得完整云端报告。" : status, includeAI: false)
        }
        showingBuildFailureReport = true
    }

    /// Build1037：源码体检功能已移除。
    /// 编译前这里只负责读取当前 ZIP、计算 SHA 与保存恢复点；
    /// 不判断“源码是否正确”，真实错误统一交给 GitHub/Codemagic/Xcode/Theos 返回。
    @MainActor func prepareCurrentSourceForCompile() -> String? {
        guard let sourceURL else {
            status = "❌ 请先选择源码 ZIP。"
            return nil
        }
        guard FileManager.default.fileExists(atPath: sourceURL.path) else {
            self.sourceURL = nil
            sourceSizeText = ""
            status = "❌ 项目源码文件已失效，请重新选择源码 ZIP。"
            return nil
        }
        do {
            let data = try readSecurityScoped(sourceURL)
            let sha = GitHubService.sha256Hex(data)
            sourceLocalSHA256 = sha
            UserDefaults.standard.set(sha, forKey: "current-source-sha256-v1")
            sourceTraceText = "源码已读取 · \(sha.prefix(12))… · \(data.count) B"
            if (try? SmartBuildSupportStore.saveRecovery(data: data, sourceName: sourceURL.lastPathComponent, sha256: sha)) == nil {
                sourceTraceText += " · 恢复点保存失败"
            }
            return sha
        } catch {
            status = "❌ 源码 ZIP 读取失败：\(error.localizedDescription)"
            return nil
        }
    }

    @MainActor func smartRecordTerminal(sha256: String, sourceName: String, provider: String, success: Bool, runID: Int64?, artifactName: String?) {
        SmartBuildStore.record(SmartBuildFingerprint(sha256: sha256, sourceName: sourceName, versionHint: nil, buildHint: nil, outcome: success ? .success : .failed, provider: provider, date: Date(), runID: runID, artifactName: artifactName))
        SmartBuildStore.mutateUsage { value in
            if success { value.successes += 1 } else { value.failures += 1 }
        }
    }

    @MainActor func smartRecordArtifactPending(sha256: String, sourceName: String, provider: String) {
        SmartBuildStore.record(SmartBuildFingerprint(sha256: sha256, sourceName: sourceName, versionHint: nil, buildHint: nil, outcome: .artifactPending, provider: provider, date: Date(), runID: nil, artifactName: nil))
        // Build1039：云 Build 成功但 IPA 尚未回传，不计入完整成功，也不计作源码编译失败。
    }

    // V3.0：目标驱动 Agent 执行入口。只编排已有稳定执行器，不复制 Provider 实现。
    // 第一次先获得真实 Xcode 证据；源码失败且 AI 已配置时自动进入修复。
    // AI Patch 通过本地门禁后会停在云编译批准点，绝不静默创建下一 Run。
    @MainActor func runAgentGoal() async {
        // Build1016：彻底停用旧 Agent/UnifiedTask 中枢调度；兼容入口只执行一次明确编译。
        guard sourceURL != nil else { status = "请先选择源码 ZIP。"; return }
        await startSelectedCompile()
    }

    @MainActor func launchSelectedCompile() {
        guard activeCompileTask == nil else {
            status = "当前已有编译任务正在运行。"
            return
        }
        let task = Task { @MainActor in
            await startSelectedCompile()
            activeCompileTask = nil
        }
        activeCompileTask = task
    }

    @MainActor func startSelectedCompile() async {
        // Build1014: 编译平台必须由用户明确选择。已彻底移除旧的自动选平台链和失败后跨平台切换。
        let stored = UserDefaults.standard.string(forKey: "cloud-compiler-v1")
        let parsed = stored.flatMap { BMCloudCompiler(rawValue: $0) }
        var selected = parsed ?? .codemagic
        // Build1018：正式编译只允许 GitHub Actions / Codemagic。旧平台值只做一次迁移，不再参与调度。
        if selected != .github && selected != .codemagic {
            selected = .codemagic
            UserDefaults.standard.set(BMCloudCompiler.codemagic.rawValue, forKey: "cloud-compiler-v1")
        }
        cloudCompiler = selected
        activeCloudProvider = selected.rawValue
        activeCloudBuildID = ""
        runURL = nil
        latestRunID = nil
        report = nil
        lastAgentRepairContext = nil
        status = "⏳ 已收到编译指令 · 正在读取当前源码…"
        guard prepareCurrentSourceForCompile() != nil else { return }
        // Build1016：编译主链直接进入用户所选 Provider，不创建 UnifiedTask/审批任务。
        activeUnifiedTask = nil

        switch selected {
        case .codemagic:
            _ = await startCodemagicCompile()
        case .bitrise:
            _ = await startBitriseCompile()
        case .selfHosted:
            lastCloudFailureKind = .auth
            lastCloudFailureMessage = "自托管 Mac Agent 尚未部署"
            status = "ℹ️ 自托管 Mac 已建立配置/检测适配层；正式 Agent 尚未部署，请选择 Codemagic 或 Bitrise。"
        case .github:
            _ = await startGitHubActionsCompile()
        }
    }

    @MainActor func requestStopCurrentWork() {
        guard busy || workStage == .recovering || activeCompileTask != nil else {
            status = "当前没有正在运行的任务。"
            return
        }
        if stopRequested {
            status = "⏹ 停止请求已生效。"
            workDetail = activeCloudBuildID.isEmpty ? "本地任务已取消，不会继续进入云端" : "本地已停止；云端取消请求已发送"
            return
        }

        stopRequested = true
        let providerAtStop = activeCloudProvider
        let buildIDAtStop = activeCloudBuildID

        if let recovery = CodemagicRunRecoveryStore.load(), !recovery.isBuildTerminal {
            CodemagicRunRecoveryStore.mutate { $0.userStopRequested = true }
            BMTaskBlackBox.shared.record(taskID: recovery.taskID, taskType: "CodemagicCompile", level: "WARN", stage: "user.stop.requested", message: "用户点击停止；立即取消本地顶层任务、轮询和下载，禁止自动恢复。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "BuildMate")
        }

        // Build1025：停止必须先终止本地顶层编译 Task。旧版只取消 Codemagic 轮询，
        // GitHub 在准备/上传阶段没有可取消句柄，导致界面长期卡在“正在停止”。
        activeCompileTask?.cancel()
        activeCodemagicPollingTask?.cancel()
        activeCodemagicCancellation?.cancel()

        // UI 立即收口。即使云端取消接口稍后返回，也不再让本地状态卡住。
        busy = false
        workPulse = false
        workStage = .cancelled
        status = "⏹ 任务已停止。"
        workDetail = buildIDAtStop.isEmpty ? "已取消准备/上传阶段，不会创建新的云端 Run" : "本地已停止，正在请求取消云端 Run"

        if !buildIDAtStop.isEmpty {
            Task { @MainActor in
                await cancelCloudBuild(provider: providerAtStop, buildID: buildIDAtStop)
            }
        } else {
            activeCloudProvider = ""
            activeCloudBuildID = ""
        }
    }

    @MainActor func cancelCloudBuild(provider: String, buildID: String) async {
        guard !buildID.isEmpty else { return }
        do {
            if provider == BMCloudCompiler.codemagic.rawValue {
                let cfg = CodemagicStoredConfig.load()
                guard cfg.isReady else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "Codemagic 配置已失效"]) }
                try await CodemagicService(token: cfg.token, appID: cfg.appID, workflowID: cfg.workflowID, branch: cfg.branch).cancelBuild(id: buildID)
            } else if provider == BMCloudCompiler.bitrise.rawValue {
                let cfg = BitriseStoredConfig.load()
                guard cfg.isReady else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "Bitrise 配置已失效"]) }
                try await BitriseService(token: cfg.token, appSlug: cfg.appSlug, workflow: cfg.workflow, branch: cfg.branch).abort(buildSlug: buildID)
            } else if provider == BMCloudCompiler.github.rawValue {
                guard let runID = Int64(buildID) else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "GitHub Run ID 无效"]) }
                let g = BMGitHubActionsStoredConfig.load()
                guard g.isReady else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "GitHub Actions 编译配置已失效"]) }
                try await GitHubService(owner: g.owner, repo: g.repo, token: g.token).cancelWorkflowRun(id: runID)
            }
            status = "⏹ 任务已停止；云端取消请求已发送。"
            workDetail = "本地状态已收口，不会自动进入后续阶段"
        } catch {
            // 本地已经停止，远端取消失败只作为提示，不把工作台重新拉回 busy。
            status = "⏹ 本地已停止；云端取消请求失败：\(error.localizedDescription)"
            workDetail = "可点云端运行确认 Run 状态；BuildMate 不会自动继续"
        }
        if activeCloudBuildID == buildID {
            activeCloudProvider = ""
            activeCloudBuildID = ""
        }
    }

    @MainActor func throwIfStopRequested() throws {
        if stopRequested {
            workStage = .cancelled
            workDetail = "用户已停止任务"
            status = "⏹ 任务已停止。不会继续启动后续编译阶段。"
            throw NSError(domain: "BuildMate.Cancelled", code: -999, userInfo: [NSLocalizedDescriptionKey: "用户已停止任务"])
        }
    }

    @MainActor func cancelActiveCloudBuild() async {
        guard (busy || workStage == .recovering), !activeCloudBuildID.isEmpty else {
            status = "当前没有可停止的云端编译。"
            return
        }
        let provider = activeCloudProvider
        let buildID = activeCloudBuildID
        status = "正在停止 \(provider) 云端任务…"
        do {
            if provider == BMCloudCompiler.codemagic.rawValue {
                let cfg = CodemagicStoredConfig.load()
                guard cfg.isReady else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "Codemagic 配置已失效"]) }
                try await CodemagicService(token: cfg.token, appID: cfg.appID, workflowID: cfg.workflowID, branch: cfg.branch).cancelBuild(id: buildID)
            } else if provider == BMCloudCompiler.bitrise.rawValue {
                let cfg = BitriseStoredConfig.load()
                guard cfg.isReady else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "Bitrise 配置已失效"]) }
                try await BitriseService(token: cfg.token, appSlug: cfg.appSlug, workflow: cfg.workflow, branch: cfg.branch).abort(buildSlug: buildID)
            } else if provider == BMCloudCompiler.github.rawValue {
                guard let runID = Int64(buildID) else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "GitHub Run ID 无效"]) }
                let g = BMGitHubActionsStoredConfig.load()
                guard g.isReady else { throw NSError(domain: "BuildMate", code: 1, userInfo: [NSLocalizedDescriptionKey: "GitHub Actions 编译配置已失效"]) }
                try await GitHubService(owner: g.owner, repo: g.repo, token: g.token).cancelWorkflowRun(id: runID)
            } else {
                status = "当前 \(provider) 暂未接入 APP 内停止接口。"
                return
            }
            status = "⏹ 已向 \(provider) 发送停止请求。"
            workDetail = "已发送停止请求；本地轮询已停止，不会自动重新启动"
            if provider == BMCloudCompiler.codemagic.rawValue, let recovery = CodemagicRunRecoveryStore.load(), recovery.buildID == buildID {
                CodemagicRunRecoveryStore.mutate { $0.userStopRequested = true }
                BMTaskBlackBox.shared.record(taskID: recovery.taskID, taskType: "CodemagicCompile", level: "WARN", stage: "cloud.cancel.accepted", message: "Codemagic 取消接口已接受请求；保持用户停止熔断。", sourceSHA256: recovery.sourceSHA256, runID: buildID, provider: "Codemagic")
            }
        } catch {
            status = "❌ 停止失败：\(error.localizedDescription)"
        }
    }

    @MainActor func startGitHubActionsCompile() async -> Bool {
        guard !busy else { return false }
        stopRequested = false
        guard let sourceURL else { status = "❌ 请先选择源码 ZIP。"; return false }
        let gConfig = BMGitHubActionsStoredConfig.load()
        guard gConfig.isReady else {
            lastCloudFailureKind = .auth
            lastCloudFailureMessage = "GitHub Actions 编译配置未完成"
            status = "❌ 请先到设置 → 编译平台 → GitHub Actions，填写并测试独立编译配置。"
            return false
        }

        let blackBoxTaskID = BMTaskBlackBox.shared.newTask(type: "GitHubActionsCompile", provider: "GitHub Actions", sourceSHA256: sourceLocalSHA256.isEmpty ? nil : sourceLocalSHA256, sourceLabel: sourceURL.lastPathComponent)
        activeBlackBoxTaskID = blackBoxTaskID
        BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "GitHubActionsCompile", stage: "accepted", message: "用户明确选择 GitHub Actions 并发起编译；无自动平台切换。")

        busy = true
        workStartedAt = Date()
        workPulse = true
        workStage = .preparing
        report = nil
        downloadedArtifact = nil
        diagnosticReportURL = nil
        latestRunID = nil
        runURL = nil
        defer {
            busy = false
            workPulse = false
            activeCloudProvider = ""
            activeCloudBuildID = ""
        }

        do {
            var activeConfig = gConfig
            var gh = GitHubService(owner: activeConfig.owner, repo: activeConfig.repo, token: activeConfig.token)

            do {
                _ = try await gh.repoInfo()
            } catch {
                let ns = error as NSError
                let legacyToken = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
                let legacyOwner = owner.trimmingCharacters(in: .whitespacesAndNewlines)
                let legacyRepo = repo.trimmingCharacters(in: .whitespacesAndNewlines)
                let canFallback = ns.domain == "GitHub" && ns.code == 401 &&
                    !legacyToken.isEmpty && legacyToken != activeConfig.token &&
                    !legacyOwner.isEmpty && !legacyRepo.isEmpty

                guard canFallback else { throw error }

                let legacyService = GitHubService(owner: legacyOwner, repo: legacyRepo, token: legacyToken)
                _ = try await legacyService.repoInfo()

                // Build1024：仅在独立 Actions Token 失效(401)时回退到此前已验证可用的 GitHub Token，
                // 验证成功后一次性迁移到新的独立编译槽位。源码平台与编译平台仍保持独立保存。
                KeychainStore.save(legacyToken, key: "github-actions-token")
                UserDefaults.standard.set(legacyOwner, forKey: "github-actions-owner")
                UserDefaults.standard.set(legacyRepo, forKey: "github-actions-repo")
                UserDefaults.standard.set(activeConfig.branch, forKey: "github-actions-branch")
                activeConfig = BMGitHubActionsStoredConfig(token: legacyToken, owner: legacyOwner, repo: legacyRepo, branch: activeConfig.branch)
                gh = legacyService
                status = "✅ GitHub Actions 凭据已自动恢复，继续编译…"
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "GitHubActionsCompile", level: "INFO", stage: "auth.legacy.migrated", message: "独立 Actions Token 返回 401；已验证旧 GitHub Token 可用并迁移到独立 Actions 配置。", sourceSHA256: sourceLocalSHA256.isEmpty ? nil : sourceLocalSHA256, provider: "GitHub Actions")
            }

            let previousRun = try await gh.latestWorkflowRun()
            let zip = try readSecurityScoped(sourceURL)

            status = "1/4 上传并校验源码…"
            workDetail = "GitHub · app.zip"
            let receipt = try await gh.putAndVerify(path: "app.zip", data: zip, message: "BuildMate Build1018: GitHub Actions source", branch: gConfig.branch)
            sourceLocalSHA256 = receipt.localSHA256
            sourceRemoteSHA256 = receipt.remoteSHA256
            try throwIfStopRequested()

            let dispatchHead = try await gh.branchHeadSHA(branch: gConfig.branch)
            sourceDispatchHeadSHA = dispatchHead
            status = "2/4 启动 GitHub Actions…"
            workStage = .dispatching
            activeCloudProvider = BMCloudCompiler.github.rawValue
            try await gh.dispatch(branch: gConfig.branch, mode: "full", expectedSourceSHA256: receipt.localSHA256, expectedSourceBytes: zip.count, sourceName: sourceURL.lastPathComponent, expectedHeadSHA: dispatchHead)
            try throwIfStopRequested()

            status = "3/4 GitHub Actions 编译中…"
            workStage = .compiling
            let finalRun = try await gh.waitForNewCompletedRun(after: previousRun?.id, timeoutSeconds: 2100) { run in
                Task { @MainActor in
                    self.latestRunID = run.id
                    self.activeCloudBuildID = String(run.id)
                    self.runURL = run.htmlURL
                    self.workDetail = "GitHub Actions · Run #\(run.id) · \(run.readableState)"
                    if run.status == "queued" { self.workStage = .queued }
                    else if run.status == "in_progress" { self.workStage = .compiling }
                }
            }
            latestRunID = finalRun.id
            activeCloudBuildID = String(finalRun.id)
            runURL = finalRun.htmlURL

            if finalRun.conclusion == "success" {
                status = "4/4 ✅ GitHub Actions 编译成功 · Run #\(finalRun.id)"
                workStage = .success
                workDetail = "GitHub Actions · Run #\(finalRun.id) 已成功"
                if let r = try await gh.buildReport(branch: gConfig.branch), r.runID == finalRun.id {
                    report = r
                    if r.hasVerifiedArtifact { rememberPendingArtifact(runID: finalRun.id, runURL: finalRun.htmlURL, report: r) }
                }
                smartRecordTerminal(sha256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, provider: BMCloudCompiler.github.rawValue, success: true, runID: finalRun.id, artifactName: report?.artifactName ?? report?.ipaName)
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "GitHubActionsCompile", level: "INFO", stage: "completed", message: "GitHub Actions 编译成功。", sourceSHA256: sourceLocalSHA256, runID: String(finalRun.id), provider: "GitHub Actions")
                return true
            }

            let r = try? await gh.buildReport(branch: gConfig.branch)
            if r?.runID == finalRun.id { report = r }
            let reason = report?.diagnosis ?? "GitHub Actions Run #\(finalRun.id) 结束：\(finalRun.conclusion ?? "unknown")"
            lastCloudFailureKind = .source
            lastCloudFailureMessage = reason
            workStage = finalRun.conclusion == "cancelled" ? .cancelled : .failed
            status = finalRun.conclusion == "cancelled" ? "⏹ GitHub Actions 已取消 · Run #\(finalRun.id)" : "❌ GitHub Actions 编译失败 · Run #\(finalRun.id)"
            diagnosticReportURL = makeDiagnosticReport(reason: reason, includeAI: false)
            smartRecordTerminal(sha256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, provider: BMCloudCompiler.github.rawValue, success: false, runID: finalRun.id, artifactName: nil)
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "GitHubActionsCompile", level: "ERROR", stage: "failed", message: reason, sourceSHA256: sourceLocalSHA256, runID: String(finalRun.id), provider: "GitHub Actions")
            return false
        } catch {
            if stopRequested || error is CancellationError || (error as NSError).domain == "BuildMate.Cancelled" {
                workStage = .cancelled
                workDetail = "用户已停止 GitHub Actions 编译"
                status = "⏹ GitHub Actions 编译已停止。"
                return false
            }
            let kind = BuildFailureKind.classify(error.localizedDescription)
            lastCloudFailureKind = kind
            lastCloudFailureMessage = error.localizedDescription
            workStage = .failed
            status = "❌ GitHub Actions · \(kind.rawValue)：\(error.localizedDescription)"
            diagnosticReportURL = makeDiagnosticReport(reason: status, includeAI: false)
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "GitHubActionsCompile", level: "ERROR", stage: "failed", message: error.localizedDescription, sourceSHA256: sourceLocalSHA256.isEmpty ? nil : sourceLocalSHA256, runID: activeCloudBuildID.isEmpty ? nil : activeCloudBuildID, provider: "GitHub Actions")
            return false
        }
    }

    @MainActor func startBitriseCompile() async -> Bool {
        guard !busy, let sourceURL else { return false }
        stopRequested = false
        guard credentialsReady else { lastCloudFailureKind = .auth; lastCloudFailureMessage = "当前源码平台未就绪（GitHub Adapter）"; status = "❌ 当前源码平台未就绪。Bitrise 只负责编译；本版本由 GitHub Source Adapter 同步 app.zip。"; return false }
        let cfg = BitriseStoredConfig.load(); guard cfg.isReady else { lastCloudFailureKind = .auth; lastCloudFailureMessage = "Bitrise 未配置"; status = "❌ 请先到设置 → 编译平台配置 Bitrise。"; return false }
        busy=true; workStartedAt=Date(); workPulse=true; workStage = .preparing; report=nil; downloadedArtifact=nil; diagnosticReportURL=nil; latestRunID=nil; runURL=nil
        defer { busy=false; workPulse=false; activeCloudProvider = ""; activeCloudBuildID = "" }
        do {
            let storedToken=KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines); if !storedToken.isEmpty { token=storedToken }
            let gh=GitHubService(owner:owner,repo:repo,token:token); status="1/5 上传并锁定源码…"; let info=try await gh.repoInfo(); try throwIfStopRequested(); let zip=try readSecurityScoped(sourceURL)
            let receipt=try await gh.putAndVerify(path:"app.zip",data:zip,message:"BuildMate Build86: Bitrise source",branch:info.defaultBranch); sourceLocalSHA256=receipt.localSHA256; sourceRemoteSHA256=receipt.remoteSHA256; try throwIfStopRequested()
            _ = try await gh.putIfChanged(path:"bitrise.yml", data:Data(BitriseWorkflowTemplate.yaml.utf8), message:"BuildMate Build86: sync Bitrise workflow", branch:info.defaultBranch)
            try throwIfStopRequested(); status="2/5 启动 Bitrise…"; workStage = .dispatching; let br=BitriseService(token:cfg.token,appSlug:cfg.appSlug,workflow:cfg.workflow,branch:cfg.branch); SmartBuildStore.mutateUsage{$0.bitriseRuns += 1}; let slug=try await br.startBuild(); activeCloudProvider = BMCloudCompiler.bitrise.rawValue; activeCloudBuildID = slug; runURL="https://app.bitrise.io/build/\(slug)"
            status="3/5 Bitrise Xcode 编译中…"; workStage = .compiling; let final=try await br.wait(slug){u in Task{@MainActor in self.workDetail="Bitrise · \(u.text)"}}
            guard final.succeeded else { throw BMContentSupport.error("Bitrise 源码编译失败：\(final.statusText)") }
            status="4/5 获取 IPA…"; workStage = .downloading; let (name,data)=try await br.ipa(buildSlug:slug)
            let safe=name.lowercased().hasSuffix(".ipa") ? name:"BuildMate-Bitrise.ipa"; let destination=FileManager.default.temporaryDirectory.appendingPathComponent(safe); try data.write(to:destination,options:.atomic); downloadedArtifact=destination;artifactFileName=safe;artifactCategory="IPA"
            status="5/5 ✅ Bitrise 编译完成，IPA 已抓取。";workStage = .success;smartRecordTerminal(sha256:sourceLocalSHA256,sourceName:sourceURL.lastPathComponent,provider:BMCloudCompiler.bitrise.rawValue,success:true,runID:nil,artifactName:safe); SmartBuildSupportStore.recordSuccess(provider: BMCloudCompiler.bitrise.rawValue); activeCloudProvider = ""; activeCloudBuildID = ""; return true
        } catch {
            if stopRequested || error is CancellationError || (error as NSError).domain == "BuildMate.Cancelled" {
                workStage = .cancelled; workDetail = "用户已停止 Bitrise 编译"; status = "⏹ Bitrise 编译已停止。"; return false
            }
            let kind = BuildFailureKind.classify(error.localizedDescription); lastCloudFailureKind = kind; lastCloudFailureMessage = error.localizedDescription; SmartBuildSupportStore.recordFailure(provider: BMCloudCompiler.bitrise.rawValue, kind: kind, message: error.localizedDescription); workStage = .failed; status="❌ Bitrise · \(kind.rawValue)：\(error.localizedDescription)"; if !sourceLocalSHA256.isEmpty { smartRecordTerminal(sha256:sourceLocalSHA256,sourceName:sourceURL.lastPathComponent,provider:BMCloudCompiler.bitrise.rawValue,success:false,runID:nil,artifactName:nil) }; diagnosticReportURL=makeDiagnosticReport(reason:"Bitrise · \(kind.rawValue)：\(error.localizedDescription)",includeAI:false);showingFailureActionAlert=diagnosticReportURL != nil; activeCloudProvider = ""; activeCloudBuildID = ""; return false
        }
    }

    @MainActor func startCodemagicCompile() async -> Bool {
        guard !busy else { return false }
        stopRequested = false
        guard let sourceURL else { status = "❌ 请先选择源码 ZIP。"; return false }

        // Build1036：App 重启后不能用尚未同步的 @State token 把编译按钮锁死。
        // 每次真正发起 Codemagic 前，直接从 Keychain 读取 Source GitHub Token；owner/repo 来自持久配置。
        let storedSourceToken = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
        if !storedSourceToken.isEmpty { token = storedSourceToken }
        guard !owner.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !repo.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !storedSourceToken.isEmpty else {
            lastCloudFailureKind = .auth
            lastCloudFailureMessage = "当前源码平台未就绪（GitHub Adapter）"
            status = "❌ 源码 GitHub 配置不完整。请到设置 → 源码平台重新连接；不会创建 Codemagic Build。"
            activeUnifiedTask = nil
            return false
        }

        let cmConfig = CodemagicStoredConfig.load()
        guard cmConfig.isReady else {
            lastCloudFailureKind = .auth
            lastCloudFailureMessage = "Codemagic 未配置"
            status = "❌ 请先到设置 → 编译平台，填写并测试 Codemagic。"
            activeUnifiedTask = nil
            return false
        }

        let blackBoxTaskID = BMTaskBlackBox.shared.newTask(type: "CodemagicCompile", provider: "Codemagic", sourceSHA256: sourceLocalSHA256.isEmpty ? nil : sourceLocalSHA256, sourceLabel: sourceURL.lastPathComponent)
        activeBlackBoxTaskID = blackBoxTaskID
        BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "accepted", message: "用户明确发起 Codemagic 编译；黑匣子仅记录，不参与调度。")

        busy = true
        workStartedAt = Date()
        workPulse = true
        workStage = .preparing
        workDetail = "准备 Codemagic 多云编译"
        report = nil
        downloadedArtifact = nil
        diagnosticReportURL = nil
        latestRunID = nil
        runURL = nil
        defer { busy = false; workPulse = false; activeCloudProvider = ""; activeCloudBuildID = "" }
        // Build145：失败归因必须跟随真实正在执行的阶段，不能在拿到 Build ID 前一律写成 Codemagic。
        var failureProvider = "GitHub"
        var failureStage = "github.prepare"

        do {
            let storedToken = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
            if !storedToken.isEmpty { token = storedToken }
            saveCredentials()

            let gh = GitHubService(owner: owner, repo: repo, token: token)
            let cm = CodemagicService(token: cmConfig.token, appID: cmConfig.appID, workflowID: cmConfig.workflowID, branch: cmConfig.branch)

            // Build222：真正创建云端 Run 前先做“零分钟体检”。
            // 先验证 GitHub Token/仓库写权限与 Codemagic API 配置；任一失败都在上传大 ZIP、POST /builds 之前终止。
            status = "1/6 云编译前零分钟体检…"
            workDetail = "验证 GitHub 登录/写权限 + Codemagic API · 不创建 Run"
            failureProvider = "GitHub"
            failureStage = "cloud.preflight.github"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "cloud.preflight.begin", message: "开始零分钟体检；只调用 GitHub/Codemagic 读取型 API，不创建云端 Build。", provider: "BuildMate")
            let githubPreflight = try await BMCloudMinutePreflight.validateGitHub(gh)
            try throwIfStopRequested()
            let info = githubPreflight.repository
            failureProvider = "Codemagic"
            failureStage = "cloud.preflight.codemagic"
            _ = try await BMCloudMinutePreflight.validateCodemagic(cm)
            try throwIfStopRequested()
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "cloud.preflight.passed", message: "零分钟体检通过：GitHub @\(githubPreflight.login) · \(info.fullName) 可写 · Codemagic API 可达。", provider: "BuildMate")

            status = "1/6 读取源码并检查 GitHub…"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "github.prepare", message: "凭据体检通过，读取本地源码并准备同步 app.zip。", provider: "GitHub")
            workDetail = "Codemagic 通过 GitHub 仓库读取 app.zip"
            failureProvider = "GitHub"
            failureStage = "github.source.readLocal"
            let zip = try readSecurityScoped(sourceURL)
            guard zip.count > 100 else { throw BMContentSupport.error("源码 ZIP 看起来是空文件。") }

            status = "2/6 上传源码并校验指纹…"
            workStage = .uploading
            workDetail = "本地 SHA-256 → GitHub app.zip → 远端回读"
            failureProvider = "GitHub"
            failureStage = "github.source.uploadVerify"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "github.source.upload.begin", message: "开始写入 app.zip；若响应 400/409/超时，将先回读远端指纹再决定是否安全重试。", provider: "GitHub")
            let receipt = try await gh.putAndVerify(path: "app.zip", data: zip, message: "BuildMate Build149: Codemagic source", branch: info.defaultBranch)
            try throwIfStopRequested()
            sourceLocalSHA256 = receipt.localSHA256
            sourceRemoteSHA256 = receipt.remoteSHA256
            sourceUploadCommitSHA = receipt.commitSHA ?? ""
            sourceTraceText = "Codemagic 源码已锁定 · SHA-256 \(receipt.localSHA256.prefix(12))… · \(receipt.byteCount) B"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "source.locked", message: "本地与 GitHub app.zip 指纹一致，commit=\(receipt.commitSHA ?? "unknown")，bytes=\(receipt.byteCount)。", sourceSHA256: receipt.localSHA256, provider: "GitHub")

            status = "3/6 同步 Codemagic 工作流…"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "workflow.sync", message: "同步 codemagic.yaml 与 build-config.json，Workflow ID=\(cmConfig.workflowID)。", provider: "GitHub")
            workDetail = "自动维护 codemagic.yaml · Workflow ID 保持 \(cmConfig.workflowID)"
            failureProvider = "GitHub"
            failureStage = "github.workflow.codemagicYaml"
            _ = try await gh.putIfChanged(
                path: "codemagic.yaml",
                data: Data(CodemagicWorkflowTemplate.yaml.utf8),
                message: "BuildMate Build90: sync Codemagic workflow",
                branch: info.defaultBranch
            )

            let cfg = BuildConfig(displayName: useOverrides ? BMContentSupport.cleaned(displayName) : nil,
                                  bundleID: useOverrides ? BMContentSupport.cleaned(bundleID) : nil,
                                  version: useOverrides ? BMContentSupport.cleaned(version) : nil,
                                  build: useOverrides && overrideBuild ? build : nil,
                                  productName: useOverrides ? BMContentSupport.cleaned(productName) : nil)
            failureProvider = "GitHub"
            failureStage = "github.workflow.buildConfig"
            try await gh.put(path: "build-config.json", data: try JSONEncoder().encode(cfg), message: "BuildMate Build149: update config", branch: info.defaultBranch)
            if let iconURL {
                failureProvider = "GitHub"
                failureStage = "github.workflow.overrideIcon"
                try await gh.put(path: "override-icon.png", data: try readSecurityScoped(iconURL), message: "BuildMate Build149: update icon", branch: info.defaultBranch)
            }

            try throwIfStopRequested()
            status = "4/6 启动 Codemagic…"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "codemagic.dispatch", message: "准备调用官方 REST POST /builds；workflow=\(cmConfig.workflowID)，branch=\(cmConfig.branch)。", sourceSHA256: sourceLocalSHA256, provider: "Codemagic")
            workStage = .dispatching
            workDetail = "调用 Codemagic REST API · \(cmConfig.workflowID) · \(cmConfig.branch)"
            failureProvider = "Codemagic"
            failureStage = "codemagic.dispatch"
            SmartBuildStore.mutateUsage { $0.codemagicRuns += 1 }
            // Build1042：恢复已验证过的任务专属 Artifact Return Bridge。
            // Relay 只回传成品与 receipt，不参与编译调度/AI/自动重试。
            let relayBranch = "buildmate-relay/\(blackBoxTaskID.lowercased())"
            let relayPath = ".buildmate/relay/\(blackBoxTaskID)/artifact-return-receipt.json"
            let buildID = try await cm.startBuild(
                taskID: blackBoxTaskID,
                unifiedTaskID: activeUnifiedTask?.id,
                sourceSHA256: sourceLocalSHA256,
                relayRepo: "\(owner)/\(repo)",
                relayBranch: relayBranch,
                relayPath: relayPath
            )
            if let unified = activeUnifiedTask { activeUnifiedTask = BMTaskExecutionCoordinator.bindRun(unified, runID: buildID) }
            activeCloudProvider = BMCloudCompiler.codemagic.rawValue
            activeCloudBuildID = buildID
            failureProvider = "Codemagic"
            failureStage = "codemagic.accepted"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "codemagic.accepted", message: "Codemagic 已返回 buildId。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            runURL = "https://codemagic.io/app/\(cmConfig.appID)/build/\(buildID)"
            CodemagicRunRecoveryStore.save(.init(taskID: blackBoxTaskID, buildID: buildID, buildURL: runURL, sourceSHA256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, buildState: .unknown, artifactState: .notStarted, lastRemoteStatus: "accepted", firstError: nil, networkFailures: 0, createdAt: Date(), updatedAt: Date()))
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "runtime.target", message: "执行端=V\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?") Build \(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "?")；目标源码=\(sourceURL.lastPathComponent)。目标源码逻辑只有安装新 IPA 后才成为执行逻辑。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "BuildMate")

            status = "5/6 Codemagic Xcode 编译中…"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "codemagic.polling", message: "开始轮询真实云端 Build 状态。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            workStage = .queued
            workDetail = "Build \(String(buildID.prefix(8))) · 每 5 秒自动检查"
            let pollingTask = Task<CodemagicBuildState, Error> {
                try await cm.waitForCompletion(id: buildID, timeoutSeconds: 1800) { state in
                Task { @MainActor in
                    // Build146：迟到的轮询回调绝不能把 failed/success/cancelled 回写成 packaging/compiling。
                    guard self.activeCloudBuildID == state.id else { return }
                    guard ![BuildWorkStage.success, .failed, .cancelled].contains(self.workStage) else { return }
                    let snapshot = BMCodemagicRunPresentation.snapshot(for: state)
                    self.status = snapshot.status
                    self.runURL = state.buildURL
                    self.workStage = snapshot.stage
                    self.workDetail = snapshot.detail
                    // Build184：远端失败/取消/超时/跳过一旦成为权威终态，首页和云编译页立即停止“运行中”。
                    // 错误报告/诊断包继续在后续异步补充，不再阻塞 UI 终态同步。
                    if snapshot.shouldStopBusyImmediately {
                        self.busy = false
                        self.workPulse = false
                    }
                    CodemagicRunRecoveryStore.mutate { record in
                        guard record.buildID == state.id else { return }
                        record.lastRemoteStatus = state.status
                        record.buildState = BMCodemagicBuildAuthority(remoteStatus: state.normalizedStatus)
                        if state.normalizedStatus == "network_unknown" { record.networkFailures += 1 }
                    }
                    }
                }
            }
            activeCodemagicPollingTask = pollingTask
            defer { activeCodemagicPollingTask = nil }
            let final = try await pollingTask.value

            let finalStatus = final.status.lowercased()
            if ["failed", "canceled", "timeout", "skipped"].contains(finalStatus) {
                workStage = finalStatus == "canceled" ? .cancelled : .failed
                workPulse = false
                busy = false
                let terminalStage = "build.\(finalStatus)"
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: finalStatus == "canceled" ? "WARN" : "ERROR", stage: terminalStage, message: "Codemagic 云端真实终态：status=\(final.status)。进入只读诊断回收，不会创建第二个 Run。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                var reason = finalStatus == "canceled" ? "Codemagic 云端构建已取消" : "Codemagic 真实编译失败 · status=\(final.status)"
                var kind: BuildFailureKind = .platform
                if let errorArtifact = final.artifacts.first(where: { item in
                    let n = item.name.lowercased(); return n.contains("compile-errors") || n == "build-result.txt" || n.contains("compile.log")
                }), let errorData = try? await cm.downloadRawArtifact(errorArtifact), let errorText = String(data: errorData, encoding: .utf8) {
                    let parsed = BuildGuardStore.parseCompileErrors(errorText, provider: "Codemagic", buildID: buildID)
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "build.failureContext", message: String(errorText.suffix(8000)), sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                    if parsed.trueErrorCount > 0 { kind = .source; reason = "Codemagic 真实错误 \(parsed.trueErrorCount) 个 · \(parsed.headline)" }
                }
                if let contextArtifact = final.artifacts.first(where: { $0.name.lowercased().contains("repair-context") }),
                   let contextData = try? await cm.downloadRawArtifact(contextArtifact),
                   let context = try? JSONDecoder().decode(RepairContext.self, from: contextData) {
                    lastAgentRepairContext = context
                    if !context.files.isEmpty { kind = .source; reason = "Codemagic 真实源码错误 · 已取得源码上下文" }
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "BuildDiagnostic", stage: "diagnostic.ready", message: "已取得 Codemagic 错误上下文，文件上下文 \(context.files.count) 个。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                }

                // Build1032：failed 后只读追踪同一个 Codemagic buildId 的诊断 Artifact。
                // 不再依赖 Git Relay / receipt / direct relay，也绝不重新 POST /builds。
                if lastAgentRepairContext == nil && finalStatus == "failed" {
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "BuildDiagnostic", stage: "diagnostic.recovery.begin", message: "真实 Build 已失败；继续只读追踪同一 Run 的诊断后处理，最长 180 秒，不创建第二个 Run。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "DiagnosticRecovery")
                    let recovered = await BMCodemagicFailureDiagnosticRecovery.recover(
                        buildID: buildID,
                        taskID: blackBoxTaskID,
                        sourceSHA256: sourceLocalSHA256,
                        codemagic: cm,
                        timeoutSeconds: 180
                    )
                    if let context = recovered.context {
                        lastAgentRepairContext = context
                        kind = .source
                        reason = "Codemagic 真实源码错误 · 已取得源码上下文"
                        if let text = recovered.compileErrorText, !text.isEmpty {
                            let parsed = BuildGuardStore.parseCompileErrors(text, provider: recovered.evidenceProvider, buildID: buildID)
                            if parsed.trueErrorCount > 0 { reason = "Codemagic 真实错误 \(parsed.trueErrorCount) 个 · \(parsed.headline)" }
                            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "build.failureContext", message: String(text.suffix(8000)), sourceSHA256: sourceLocalSHA256, runID: buildID, provider: recovered.evidenceProvider)
                        }
                        BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "BuildDiagnostic", stage: "diagnostic.ready", message: "诊断后处理第 \(recovered.attempts) 次读取取得 repair-context，文件上下文 \(context.files.count) 个；证据通道=\(recovered.evidenceProvider)。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: recovered.evidenceProvider)
                    } else if let text = recovered.compileErrorText, !text.isEmpty {
                        let parsed = BuildGuardStore.parseCompileErrors(text, provider: recovered.evidenceProvider, buildID: buildID)
                        BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "build.failureContext", message: String(text.suffix(8000)), sourceSHA256: sourceLocalSHA256, runID: buildID, provider: recovered.evidenceProvider)
                        if parsed.trueErrorCount > 0 {
                            kind = .source
                            reason = "Codemagic 真实错误 \(parsed.trueErrorCount) 个 · 已拿到错误文本，但源码片段上下文仍未回传"
                        }
                        BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "BuildDiagnostic", level: "WARN", stage: "diagnostic.partial", message: "已取得真实 compile-errors，但 源码片段上下文未就绪。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: recovered.evidenceProvider)
                    } else {
                        BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "BuildDiagnostic", level: "WARN", stage: "diagnostic.relay.missing", message: "180 秒诊断后处理窗口结束；Artifact、receipt、Direct Relay 均未返回真实上下文。保留原 Run 与诊断包。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "DiagnosticRecovery")
                    }
                }
                lastCloudFailureKind = kind; lastCloudFailureMessage = reason
                SmartBuildSupportStore.recordFailure(provider: BMCloudCompiler.codemagic.rawValue, kind: kind, message: reason)
                status = finalStatus == "canceled" ? "⏹ \(reason)" : "❌ \(reason)"
                workDetail = reason
                diagnosticReportURL = makeDiagnosticReport(reason: reason + " · Build " + buildID, includeAI: false)
                showingFailureActionAlert = diagnosticReportURL != nil
                CodemagicRunRecoveryStore.mutate { $0.buildState = BMCodemagicBuildAuthority(remoteStatus: finalStatus); $0.artifactState = .notApplicable }
                // Build166：远端终态已经确认，Run checkpoint 必须关闭，避免重启后再次进入“网络恢复中”。
                CodemagicRunRecoveryStore.clear()
                if let unified = activeUnifiedTask {
                    if finalStatus == "canceled" {
                        BMTaskExecutionCoordinator.cancel(unified, message: reason)
                        activeUnifiedTask = nil
                    } else {
                        BMTaskExecutionCoordinator.close(unified, success: false, message: reason)
                        activeUnifiedTask = nil
                    }
                }
                return false
            }

            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "build.succeeded", message: "Codemagic 云端构建成功，开始单次 Artifact 回传。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")

            // Build139：先读取 Codemagic 主脚本阶段生成的 Secret 预检 Artifact。
            // 只记录 true/false、Task/Source/Build 关联信息，绝不包含 Token 明文。
            if let preflight = final.artifacts.first(where: { $0.name.lowercased().contains("artifact-return-preflight") }) {
                do {
                    let preflightData = try await cm.downloadRawArtifact(preflight)
                    let preflightText = String(data: preflightData, encoding: .utf8) ?? "<非 UTF-8 预检收据>"
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.server.preflight", message: String(preflightText.prefix(1800)), sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                } catch {
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "artifact.server.preflight.unreadable", message: "发现服务器预检 Artifact，但读取失败：\(error.localizedDescription)", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                }
            } else {
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "artifact.server.preflight.missing", message: "Build API 未返回 artifact-return-preflight.json；需结合 post-publish 日志继续判断。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            }

            let serverEvidence = await cm.artifactReturnEvidence(buildID: buildID)
            if serverEvidence.isEmpty {
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "artifact.server.receipt.notExposed", message: "Codemagic Build API/v3 当前未暴露 post-publish BUILDMATE_ARTIFACT_* 日志标记；这不等于脚本未执行。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            } else {
                for line in serverEvidence.prefix(12) {
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.server.receipt", message: line, sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                }
            }

            // Build1042：第一优先读取 Codemagic publishing 主动写回的任务专属 Git Relay。
            // 这是历史成功链恢复：云端主动回传真实二进制 + receipt，App 不再猜临时 Artifact URL。
            let relayRecovery = CodemagicArtifactRecoveryRecord(buildID: buildID, artifactName: "", buildURL: final.buildURL, sourceSHA256: sourceLocalSHA256, createdAt: Date(), taskID: blackBoxTaskID, relayBranch: relayBranch, relayPath: relayPath)
            CodemagicArtifactRecoveryStore.save(relayRecovery)
            do {
                status = "6/6 接收 Codemagic 产物回传…"
                workStage = .downloading
                workDetail = "Artifact Return Bridge · 同一 Build · 不重新编译"
                let relay = try await BMArtifactReturnBridge.fetch(github: gh, recovery: relayRecovery, expectedTaskID: blackBoxTaskID)
                let safeName = relay.name
                let verification = relay.kind == "DEB" ? BuildGuardStore.verifyDEB(data: relay.data, name: safeName) : BuildGuardStore.verifyIPA(data: relay.data, name: safeName)
                guard verification.passed else { throw BMContentSupport.error("\(relay.kind) Relay 成品验证未通过：" + verification.notes.joined(separator: "；")) }
                let destination = try BMLocalFileStore.persistVerifiedArtifactData(relay.data, fileName: safeName, provider: "Codemagic", runID: buildID)
                downloadedArtifact = destination
                _ = BMArtifactDeliveryStore.upsert(provider: "Codemagic", runID: buildID, sourceSHA256: sourceLocalSHA256, artifactName: safeName, localURL: destination, buildURL: final.buildURL, verified: true, byteCount: relay.data.count)
                artifactFileName = safeName
                artifactCategory = relay.kind
                UserDefaults.standard.set(safeName, forKey: "artifact-file-name")
                UserDefaults.standard.set(relay.kind, forKey: "artifact-category")
                CodemagicArtifactRecoveryStore.clear()
                CodemagicRunRecoveryStore.clear()
                workStage = .success
                workDetail = "\(relay.kind) 已通过 Artifact Return Bridge 回传 · \(relay.data.count / 1024) KB"
                status = "✅ Codemagic 编译成功 · \(relay.kind) 已回传。"
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.relay.completed", message: "publishing Relay 回传成功：\(safeName)，\(relay.data.count) B，receipt SHA-256 已校验。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                smartRecordTerminal(sha256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, provider: BMCloudCompiler.codemagic.rawValue, success: true, runID: nil, artifactName: safeName)
                if let unified = activeUnifiedTask { BMTaskExecutionCoordinator.close(unified, success: true, message: "Codemagic \(relay.kind) 回传成功。") }
                activeUnifiedTask = nil
                return true
            } catch {
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "artifact.relay.fallback", message: "Artifact Return Bridge 暂未取得成品：\(error.localizedDescription)。仅回退当前 Build 的官方 Artifact API，不创建新 Build。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            }

            // Build1042：Relay 暂不可用时才回退 Codemagic Artifact API；不再让 API 临时链成为第一主链。
            guard let artifact = final.artifacts.first(where: { $0.isDeliverable }) else {
                CodemagicArtifactRecoveryStore.save(.init(buildID: buildID, artifactName: "", buildURL: final.buildURL, sourceSHA256: sourceLocalSHA256, createdAt: Date(), taskID: blackBoxTaskID, relayBranch: relayBranch, relayPath: relayPath))
                CodemagicRunRecoveryStore.mutate { $0.buildState = .finished; $0.artifactState = .locating; $0.lastRemoteStatus = final.status }
                // Build 已完成后只保留 Artifact Recovery；Run Recovery 不再负责恢复，避免 finished 被重复轮询。
                CodemagicRunRecoveryStore.clear()
                workStage = .artifactPending
                let reason = "Codemagic Build 已成功 finished，但可下载产物暂未可见；Build 成功事实保持不变。"
                lastCloudFailureKind = .artifact
                lastCloudFailureMessage = reason
                SmartBuildSupportStore.recordFailure(provider: BMCloudCompiler.codemagic.rawValue, kind: .artifact, message: reason)
                status = "⚠️ 云端编译成功，产物回传暂未完成。"
                workDetail = "已保留同一 Build 的恢复入口；不会重新编译，也不会切换其他云平台"
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "artifact.notVisibleAfterGrace", message: reason, sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                diagnosticReportURL = makeDiagnosticReport(reason: reason + " · Build \(buildID)", includeAI: false)
                showingFailureActionAlert = diagnosticReportURL != nil
                return false
            }

            let artifactKind = artifact.deliverableKind
            status = "6/6 下载并验证 \(artifactKind)…"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.download", message: "云端 Build 已结束并检测到 \(artifactKind)；本次只执行 1 轮官方 Artifact 获取，失败立即回到产物待获取。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.raw", message: "Builds API 已返回 \(artifactKind) Artifact 地址；类型=\(cm.artifactURLDescription(artifact))。完整签名 URL 不写入诊断。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            if let resolved = try? cm.resolvedArtifactURLString(artifact) {
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.url.resolved", message: "Artifact 地址已解析；\(cm.redactedArtifactURLString(resolved))。本次只抓取 1 轮，不自动重复。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            }
            CodemagicArtifactRecoveryStore.save(.init(buildID: buildID, artifactName: artifact.name, buildURL: final.buildURL, sourceSHA256: sourceLocalSHA256, createdAt: Date(), taskID: blackBoxTaskID, relayBranch: relayBranch, relayPath: relayPath))
            workStage = .downloading
            workDetail = "Codemagic Artifact 单次抓取 · 失败立即停止，不重新编译"
            let cancellation = CodemagicCancellationController()
            activeCodemagicCancellation = cancellation
            defer { if activeCodemagicCancellation === cancellation { activeCodemagicCancellation = nil } }
            var artifactData: Data
            var artifactName = artifact.name
            var artifactAttempts = 1
            do {
                let result = try await cm.downloadArtifact(buildID: buildID, preferredName: artifact.name, cancellation: cancellation) { attempt, message in
                    BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.retry", message: "#\(attempt) · \(message)", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                    Task { @MainActor in
                        self.workDetail = message
                        self.status = "6/6 产物回传中 · 单次抓取"
                    }
                }
                artifactData = result.data
                artifactName = result.artifact.name
                artifactAttempts = result.attempts
            } catch {
                // Build1031：云端 Build 已成功时，Artifact 下载失败只能进入“成功·待获取”，
                // 绝不能把已成功的 Xcode Build 改写成失败，也不再依赖 Git Relay。
                if cancellation.isCancelled { throw CancellationError() }
                let reason = "Codemagic 编译已成功，\(artifactKind) 暂未能通过官方 Artifact API 下载：\(error.localizedDescription)"
                CodemagicArtifactRecoveryStore.save(.init(buildID: buildID, artifactName: artifact.name, buildURL: final.buildURL, sourceSHA256: sourceLocalSHA256, createdAt: Date(), taskID: blackBoxTaskID, relayBranch: relayBranch, relayPath: relayPath))
                CodemagicRunRecoveryStore.clear()
                workStage = .artifactPending
                workDetail = "Build \(String(buildID.prefix(8))) 已成功 · \(artifactKind) 待获取 · 可点右上角“重抓产物”"
                status = "✅ Codemagic 编译成功 · \(artifactKind) 待获取。"
                lastCloudFailureKind = .artifact
                lastCloudFailureMessage = reason
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "artifact.pending", message: reason, sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                diagnosticReportURL = makeDiagnosticReport(reason: reason + " · Build " + buildID, includeAI: false)
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "completed", message: "云端编译成功；\(artifactKind) 待获取。当前任务已收口，可稍后手动重抓。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
                smartRecordArtifactPending(sha256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, provider: BMCloudCompiler.codemagic.rawValue)
                if let unified = activeUnifiedTask { BMTaskExecutionCoordinator.close(unified, success: true, message: "Codemagic 编译成功；\(artifactKind) 待获取。") }
                activeUnifiedTask = nil
                return true
            }
            let data = artifactData
            let isDEB = artifactName.lowercased().hasSuffix(".deb") || artifact.isDEB
            let kind = isDEB ? "DEB" : "IPA"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "artifact.downloaded", message: "Artifact 下载完成：\(artifactName)，\(data.count) B，链路尝试 \(artifactAttempts)；开始 \(kind) 完整性验证。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            let safeName: String
            let verification: BMIPAVerification
            if isDEB {
                safeName = artifactName.lowercased().hasSuffix(".deb") ? artifactName : "BuildMate-Codemagic.deb"
                verification = BuildGuardStore.verifyDEB(data: data, name: safeName)
            } else {
                safeName = artifactName.lowercased().hasSuffix(".ipa") ? artifactName : "BuildMate-Codemagic.ipa"
                verification = BuildGuardStore.verifyIPA(data: data, name: safeName)
            }
            guard verification.passed else { throw BMContentSupport.error("\(kind) 成品验证未通过：" + verification.notes.joined(separator: "；")) }
            let destination = try BMLocalFileStore.persistVerifiedArtifactData(data, fileName: safeName, provider: "Codemagic", runID: buildID)
            downloadedArtifact = destination
            _ = BMArtifactDeliveryStore.upsert(provider: "Codemagic", runID: buildID, sourceSHA256: sourceLocalSHA256, artifactName: safeName, localURL: destination, buildURL: final.buildURL, verified: true, byteCount: data.count)
            artifactFileName = safeName
            artifactCategory = kind
            UserDefaults.standard.set(safeName, forKey: "artifact-file-name")
            UserDefaults.standard.set(kind, forKey: "artifact-category")
            workStage = .success
            workDetail = "Codemagic \(kind) 已下载到 BuildMate · \(data.count / 1024) KB"
            status = "✅ Codemagic 编译完成，\(kind) 已抓取并进入产物中心。"
            BMBuildNotificationCenter.send(title: "BuildMate 编译完成", body: "Codemagic 已完成，\(kind) 已验证并保存到产物中心：\(safeName)", identifier: "build-success-\(buildID)")
            smartRecordTerminal(sha256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, provider: BMCloudCompiler.codemagic.rawValue, success: true, runID: nil, artifactName: safeName)
            SmartBuildSupportStore.recordSuccess(provider: BMCloudCompiler.codemagic.rawValue)
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", stage: "completed", message: "Codemagic 编译与 \(kind) 下载验证成功：\(safeName)。", sourceSHA256: sourceLocalSHA256, runID: buildID, provider: "Codemagic")
            if let unified = activeUnifiedTask { BMTaskExecutionCoordinator.close(unified, success: true, message: "Codemagic 编译与 \(kind) 下载验证成功：\(safeName)。") }
            activeUnifiedTask = nil
            CodemagicArtifactRecoveryStore.clear()
            CodemagicRunRecoveryStore.clear()
            activeCloudProvider = ""
            activeCloudBuildID = ""
            return true
        } catch {
            if stopRequested || error is CancellationError || (error as NSError).domain == "BuildMate.Cancelled" {
                workStage = .cancelled
                workDetail = activeCloudBuildID.isEmpty ? "用户已停止 Codemagic 任务" : "本地轮询已停止，并已请求取消云端 Build"
                status = "⏹ Codemagic 任务已停止；不会自动重新启动。"
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "cancelled", message: "用户停止了 Codemagic 编译/产物回传；已取消当前请求并阻止后续重试。", sourceSHA256: sourceLocalSHA256, runID: activeCloudBuildID.isEmpty ? nil : activeCloudBuildID, provider: "Codemagic")
                diagnosticReportURL = makeDiagnosticReport(reason: workDetail + " · Build " + activeCloudBuildID, includeAI: false)
                if let unified = activeUnifiedTask { BMTaskExecutionCoordinator.cancel(unified, message: workDetail) }
                activeUnifiedTask = nil
                return false
            }
            var kind = BuildFailureKind.classify(error.localizedDescription)
            // Build166：已经拿到 buildId 后的网络异常不是“编译失败”。暂停主动轮询并保留 checkpoint，等待下一次前台恢复同一 Run。
            if !activeCloudBuildID.isEmpty && kind == .network, let recovery = CodemagicRunRecoveryStore.load(), recovery.buildID == activeCloudBuildID {
                workStage = .recovering
                workDetail = "网络暂不可用 · 原 Run 已保存 · 不重新编译"
                status = "📡 已暂停自动轮询；恢复网络后会继续同步同一 Codemagic Run。"
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "network.polling.paused", message: error.localizedDescription, sourceSHA256: sourceLocalSHA256, runID: activeCloudBuildID, provider: "Codemagic")
                CodemagicRunRecoveryStore.mutate { record in
                    if record.firstError == nil { record.firstError = error.localizedDescription }
                    record.networkFailures += 1
                    record.buildState = .networkUnknown
                }
                return false
            }
            workStage = .failed
            // Build145：拿到 Codemagic buildId 之前，按当前真实阶段区分 GitHub / Codemagic。
            // GitHub 400/401/写入超时不再被误记成 Codemagic 故障。
            if activeCloudBuildID.isEmpty && failureProvider == "GitHub" {
                let ns = error as NSError
                if ns.code == 401 || ns.code == 403 || ns.code == 404 || kind == .auth {
                    kind = .auth
                } else if ns.domain == "GitHub.Network" || kind == .network {
                    kind = .network
                }
            }
            if activeCloudBuildID.isEmpty && failureStage.hasPrefix("cloud.preflight") {
                SmartBuildStore.mutateUsage { value in
                    value.localBlocks += 1
                    value.estimatedMacMinutesSaved += 3
                }
                BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "WARN", stage: "cloud.preflight.blocked", message: "云前零分钟体检已阻断本次正式 Build；未调用 POST /builds。", sourceSHA256: sourceLocalSHA256, provider: "BuildMate")
            }
            lastCloudFailureKind = kind
            lastCloudFailureMessage = error.localizedDescription
            SmartBuildSupportStore.recordFailure(provider: failureProvider, kind: kind, message: error.localizedDescription)
            workDetail = "\(failureProvider) · \(failureStage) · \(kind.rawValue) · \(error.localizedDescription)"
            let failedStage = activeCloudBuildID.isEmpty ? failureStage : "cloud.afterBuildId"
            BMTaskBlackBox.shared.record(taskID: blackBoxTaskID, taskType: "CodemagicCompile", level: "ERROR", stage: failedStage, message: error.localizedDescription, sourceSHA256: sourceLocalSHA256, runID: activeCloudBuildID.isEmpty ? nil : activeCloudBuildID, provider: activeCloudBuildID.isEmpty ? failureProvider : "Codemagic")
            status = "❌ \(failureProvider) · \(kind.rawValue)：\(error.localizedDescription)"
            BMBuildNotificationCenter.send(title: "BuildMate 编译异常", body: "\(failureProvider) · \(kind.rawValue)：\(error.localizedDescription)", identifier: "build-failure-\(blackBoxTaskID)")
            if !sourceLocalSHA256.isEmpty { smartRecordTerminal(sha256: sourceLocalSHA256, sourceName: sourceURL.lastPathComponent, provider: failureProvider, success: false, runID: nil, artifactName: nil) }
            diagnosticReportURL = makeDiagnosticReport(reason: "\(failureProvider) · 阶段=\(failedStage) · \(kind.rawValue)：\(error.localizedDescription)", includeAI: false)
            showingFailureActionAlert = diagnosticReportURL != nil
            if let unified = activeUnifiedTask { BMTaskExecutionCoordinator.close(unified, success: false, message: workDetail) }
            activeUnifiedTask = nil
            activeCloudProvider = ""
            activeCloudBuildID = ""
            return false
        }
    }

    @MainActor func retryCodemagicArtifact(_ recovery: CodemagicArtifactRecoveryRecord) async {
        guard !busy else { return }
        stopRequested = false
        let config = CodemagicStoredConfig.load()
        guard config.isReady else {
            status = "❌ Codemagic 配置不可用，无法重新抓取产物。"
            return
        }
        busy = true
        workStage = .downloading
        workStartedAt = Date()
        activeCloudProvider = "Codemagic"
        activeCloudBuildID = recovery.buildID
        runURL = recovery.buildURL
        status = "正在从已完成的 Codemagic Build 重新抓取产物…"
        workDetail = "Build \(String(recovery.buildID.prefix(8))) · 不会重新编译"
        let taskID = BMTaskBlackBox.shared.taskID(runID: recovery.buildID, sourceSHA256: recovery.sourceSHA256) ?? ("BM-ART-" + String(UUID().uuidString.prefix(8)))
        BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", stage: "artifact.recovery.start", message: "重新抓取已完成 Build 的产物，不触发新 Build。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
        defer { busy = false }

        do {
            let cm = CodemagicService(token: config.token, appID: config.appID, workflowID: config.workflowID, branch: config.branch)

            // Build1042：手动“重抓产物”也优先读取同一 Task 的 Relay，不重新编译。
            if recovery.relayBranch != nil, recovery.relayPath != nil {
                do {
                    let relayToken = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
                    if !relayToken.isEmpty, !owner.isEmpty, !repo.isEmpty {
                        let relayGH = GitHubService(owner: owner, repo: repo, token: relayToken)
                        let relay = try await BMArtifactReturnBridge.fetch(github: relayGH, recovery: recovery, expectedTaskID: recovery.taskID)
                        let verification = relay.kind == "DEB" ? BuildGuardStore.verifyDEB(data: relay.data, name: relay.name) : BuildGuardStore.verifyIPA(data: relay.data, name: relay.name)
                        guard verification.passed else { throw BMContentSupport.error("\(relay.kind) Relay 成品验证未通过：" + verification.notes.joined(separator: "；")) }
                        let destination = try BMLocalFileStore.persistVerifiedArtifactData(relay.data, fileName: relay.name, provider: "Codemagic", runID: recovery.buildID)
                        downloadedArtifact = destination
                        _ = BMArtifactDeliveryStore.upsert(provider: "Codemagic", runID: recovery.buildID, sourceSHA256: recovery.sourceSHA256, artifactName: relay.name, localURL: destination, buildURL: recovery.buildURL, verified: true, byteCount: relay.data.count)
                        artifactFileName = relay.name
                        artifactCategory = relay.kind
                        UserDefaults.standard.set(relay.name, forKey: "artifact-file-name")
                        UserDefaults.standard.set(relay.kind, forKey: "artifact-category")
                        CodemagicArtifactRecoveryStore.clear()
                        workStage = .success
                        workDetail = "\(relay.kind) 已从原 Build 的 Artifact Return Bridge 回传 · \(relay.data.count / 1024) KB"
                        status = "✅ \(relay.kind) 已重新抓取成功并进入产物中心。"
                        BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", stage: "artifact.relay.completed", message: "无需重新编译，Relay 回传成功：\(relay.name)。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
                        activeCloudProvider = ""
                        activeCloudBuildID = ""
                        return
                    }
                } catch {
                    BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", level: "WARN", stage: "artifact.relay.fallback", message: "Relay 暂不可读：\(error.localizedDescription)；继续同一 Build 官方 Artifact API。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
                }
            }

            let cancellation = CodemagicCancellationController()
            activeCodemagicCancellation = cancellation
            defer { if activeCodemagicCancellation === cancellation { activeCodemagicCancellation = nil } }
            let result = try await cm.downloadArtifact(buildID: recovery.buildID, preferredName: recovery.artifactName, cancellation: cancellation) { attempt, message in
                BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", stage: "artifact.recovery.retry", message: "#\(attempt) · \(message)", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
                Task { @MainActor in
                    self.status = "重新抓取产物 · 单次抓取"
                    self.workDetail = message
                }
            }
            let isDEB = result.artifact.isDEB || result.artifact.name.lowercased().hasSuffix(".deb")
            let kind = isDEB ? "DEB" : "IPA"
            let safeName: String
            let verification: BMIPAVerification
            if isDEB {
                safeName = result.artifact.name.lowercased().hasSuffix(".deb") ? result.artifact.name : (recovery.artifactName.lowercased().hasSuffix(".deb") ? recovery.artifactName : "BuildMate-Codemagic.deb")
                verification = BuildGuardStore.verifyDEB(data: result.data, name: safeName)
            } else {
                safeName = result.artifact.name.lowercased().hasSuffix(".ipa") ? result.artifact.name : (recovery.artifactName.lowercased().hasSuffix(".ipa") ? recovery.artifactName : "BuildMate-Codemagic.ipa")
                verification = BuildGuardStore.verifyIPA(data: result.data, name: safeName)
            }
            guard verification.passed else { throw BMContentSupport.error("\(kind) 成品验证未通过：" + verification.notes.joined(separator: "；")) }
            let destination = try BMLocalFileStore.persistVerifiedArtifactData(result.data, fileName: safeName, provider: "Codemagic", runID: recovery.buildID)
            downloadedArtifact = destination
            _ = BMArtifactDeliveryStore.upsert(provider: "Codemagic", runID: recovery.buildID, sourceSHA256: recovery.sourceSHA256, artifactName: safeName, localURL: destination, buildURL: recovery.buildURL, verified: true, byteCount: result.data.count)
            artifactFileName = safeName
            artifactCategory = kind
            UserDefaults.standard.set(safeName, forKey: "artifact-file-name")
            UserDefaults.standard.set(kind, forKey: "artifact-category")
            CodemagicArtifactRecoveryStore.clear()
            workStage = .success
            workDetail = "\(kind) 已从旧 Build 回传到 BuildMate · \(result.data.count / 1024) KB"
            status = "✅ \(kind) 已重新抓取成功并进入产物中心。"
            BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", stage: "completed", message: "无需重新编译，\(kind) 回传成功：\(safeName)。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
        } catch {
            if stopRequested || error is CancellationError {
                workStage = .cancelled
                status = "⏹ 产物抓取已停止。"
                workDetail = "用户停止了产物回传；云端 Build 与 Artifact Recovery 记录均保留"
                BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", level: "WARN", stage: "cancelled", message: "用户停止产物重新抓取；已取消当前请求并阻止后续重试。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
                diagnosticReportURL = makeDiagnosticReport(reason: workDetail + " · Build " + recovery.buildID, includeAI: false)
                return
            }
            workStage = .artifactPending
            status = "✅ 云端编译成功 · 产物仍待获取。"
            workDetail = "本次重抓未成功；不会改写 Build 成功状态，可稍后再次点“重抓产物”。"
            BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", level: "WARN", stage: "artifact.recovery.pending", message: error.localizedDescription, sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
            diagnosticReportURL = makeDiagnosticReport(reason: "Codemagic 编译成功，产物重抓仍未完成：" + error.localizedDescription + " · Build " + recovery.buildID, includeAI: false)
            BMTaskBlackBox.shared.record(taskID: String(taskID), taskType: "CodemagicArtifactRecovery", level: "WARN", stage: "completed", message: "本次重抓已结束；云端 Build 成功事实保持，产物仍待获取。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
        }
        activeCloudProvider = ""
        activeCloudBuildID = ""
    }

    @MainActor func start(mode: String) async -> GitHubWorkflowRun? {
        // 旧 start(mode:) 兼容入口继续熔断，防止历史恢复器自动触发；用户手动 GitHub Actions 编译走 startGitHubActionsCompile()。
        BMExecutionSafetyFuse.recordBlockedGitHubDispatch(reason: "legacy start(mode: \(mode))")
        UserDefaults.standard.set(false, forKey: "autopilot-pending-v1")
        workStage = .cancelled
        status = "🧯 已拦截旧自动调度入口：未创建新的 GitHub Workflow Run。"
        workDetail = "GitHub Actions 手动编译仍可用；这里只禁止旧中枢/恢复器自动 dispatch"
        return nil
    }

    // Build1023：纯编译模式。失败只输出真实诊断，不在 App 内执行自动修复。

    @MainActor func makeDiagnosticReport(reason: String, includeAI: Bool = false) -> URL? {
        var lines: [String] = []
        lines.append("BuildMate 编译诊断报告")
        let executingVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
        let executingBuild = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "?"
        lines.append("执行端：BuildMate V\(executingVersion) · Build \(executingBuild)")
        let sourceName = sourceURL?.lastPathComponent ?? "未选择源码"
        if let match = sourceName.range(of: #"V\d+(?:\.\d+)+-Build\d+"#, options: .regularExpression) {
            let target = String(sourceName[match]).replacingOccurrences(of: "-Build", with: " · Build ")
            lines.append("目标源码：\(target)")
        } else {
            lines.append("目标源码：\(sourceName)")
        }
        lines.append("时间：\(Date())")
        lines.append("仓库：\(owner)/\(repo)")
        if !sourceTraceText.isEmpty { lines.append("源码链路：\(sourceTraceText)") }
        if !sourceLocalSHA256.isEmpty { lines.append("本地 ZIP SHA-256：\(sourceLocalSHA256)") }
        if !sourceRemoteSHA256.isEmpty { lines.append("GitHub app.zip SHA-256：\(sourceRemoteSHA256)") }
        if !sourceUploadCommitSHA.isEmpty { lines.append("app.zip Commit：\(sourceUploadCommitSHA)") }
        if !sourceDispatchHeadSHA.isEmpty { lines.append("派发前 HEAD：\(sourceDispatchHeadSHA)") }
        if let latestRunID { lines.append("Run：#\(latestRunID)") }
        lines.append("停止/失败原因：\(reason)")
        if let lastEvent = BMTaskBlackBox.shared.events.last {
            lines.append("黑匣子最后事件：#\(lastEvent.sequence) · \(lastEvent.taskType)/\(lastEvent.stage) · \(lastEvent.message)")
        }
        // Build1009: root-cause evidence is build-scoped. Never leak a previous Build's
        // cached diagnostic into the current report. The expected Codemagic Build ID is
        // taken from the active run, or (for recovery paths) from the explicit reason text.
        let expectedDiagnosticBuildID: String? = {
            let active = activeCloudBuildID.trimmingCharacters(in: .whitespacesAndNewlines)
            if !active.isEmpty { return active }
            if let range = reason.range(of: #"Build\s+([A-Za-z0-9_-]+)"#, options: .regularExpression) {
                return String(reason[range]).replacingOccurrences(of: #"^Build\s+"#, with: "", options: .regularExpression)
            }
            return nil
        }()
        if let d = BuildGuardStore.diagnostic(forBuildID: expectedDiagnosticBuildID), d.trueErrorCount > 0 {
            lines.append("\n=== 自动根因提炼 ===")
            lines.append("诊断绑定 Build：\(d.buildID ?? "未知")")
            lines.append("真实错误：\(d.trueErrorCount) · 级联/后续错误：\(d.cascadeErrorCount) · Warning：\(d.warningCount)")
            if let root = d.rootCause {
                let location = root.file.map { "\($0)\(root.line.map { ":\($0)" } ?? "")" } ?? "未知文件"
                lines.append("首要根因：\(location) · \(root.message)")
            }
            lines.append("说明：优先修复首要根因后再重新编译；后续错误可能由首错级联产生，不按错误数量盲目打补丁。")
        } else if let cached = BuildGuardStore.latestDiagnostic(), cached.trueErrorCount > 0 {
            let cachedID = cached.buildID ?? "未知"
            lines.append("\n=== 诊断证据隔离 ===")
            lines.append("已排除旧诊断：缓存 Build \(cachedID) 与当前 Build \(expectedDiagnosticBuildID ?? "未绑定") 不一致，不作为本次根因。")
        }
        if let report {
            lines.append("\n=== 真实编译报告 ===")
            lines.append(report.summary)
        }
        if let context = lastRepairContext {
            lines.append("\n=== 真实错误上下文 ===")
            if let signature = context.errorSignature { lines.append("错误签名：\(signature)") }
            if let diagnosis = context.diagnosis { lines.append("诊断：\(diagnosis)") }
            if let errors = context.compileErrors, !errors.isEmpty {
                lines.append("\n--- 编译错误/日志 ---")
                lines.append(errors)
            }
            for file in context.files {
                lines.append("\n--- 源码片段：\(file.path)\(file.line.map { ":\($0)" } ?? "") ---")
                lines.append(file.snippet)
            }
        }
        lines.append("\n注意：本报告不包含 GitHub Token；可能包含本次故障相关源码片段，请仅分享给你信任的调试对象。")
        let prefix = "BuildMate-Build-Diagnostic"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(prefix)-\(latestRunID ?? 0).txt")
        do { try lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8); return url }
        catch { return nil }
    }

}
