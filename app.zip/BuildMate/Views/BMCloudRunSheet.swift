import SwiftUI
import SafariServices

/// 云端运行详情统一使用可下滑关闭的 Sheet。
/// 只展示已有 Run URL，不创建任务、不轮询、不改变编译状态。
struct BMCloudRunSheet: View {
    let url: URL
    let onClose: () -> Void

    var body: some View {
        NavigationView {
            BMSafariView(url: url)
                .ignoresSafeArea(edges: .bottom)
                .navigationTitle("云端运行")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("完成", action: onClose)
                    }
                }
        }
    }
}

private struct BMSafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        let controller = SFSafariViewController(url: url)
        controller.dismissButtonStyle = .close
        return controller
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}
