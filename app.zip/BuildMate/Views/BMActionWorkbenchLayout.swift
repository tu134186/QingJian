import SwiftUI

struct BMActionWorkbenchLayout: View {
    let banner: AnyView?
    let duplicateConfirm: AnyView?
    let compileAction: AnyView
    let artifactAction: AnyView
    let report: AnyView
    let nextStep: AnyView
    let centralOrb: AnyView
    let smartDetail: AnyView?

    var body: some View {
        BMCard {
            VStack(alignment: .leading, spacing: 12) {
                BMContentSectionTitle("智能工作台", icon: "bolt.fill")
                if let banner { banner }
                if let duplicateConfirm { duplicateConfirm }

                if let smartDetail {
                    // V4.1：普通编译与智能体工作台由用户显式切换。
                    // 进入智能体模式后保持单页纵向看板，不因失败/成功状态自动退回旧四宫格。
                    HStack(spacing: 14) {
                        Circle()
                            .fill(Color(uiColor: .secondarySystemGroupedBackground))
                            .frame(width: 92, height: 92)
                            .overlay(centralOrb.frame(width: 74, height: 74))
                        VStack(alignment: .leading, spacing: 6) {
                            Text("智能体模式").font(.subheadline.weight(.semibold))
                            Text("当前页持续展示诊断、修复、门禁、审批和验证，不再跳转第二工作台。")
                                .font(.caption).foregroundColor(.secondary)
                        }
                    }
                    smartDetail
                } else {
                    ZStack {
                        VStack(spacing: 14) {
                            HStack(spacing: 14) { compileAction; artifactAction }
                            HStack(spacing: 14) { report; nextStep }
                        }
                        .frame(height: 184)
                        Circle()
                            .fill(Color(uiColor: .secondarySystemGroupedBackground))
                            .frame(width: 124, height: 124)
                            .allowsHitTesting(false)
                        centralOrb
                            .frame(width: 100, height: 100)
                            .contentShape(Circle())
                    }
                }
            }
        }
    }
}
