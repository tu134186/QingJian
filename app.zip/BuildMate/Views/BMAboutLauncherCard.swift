import SwiftUI

struct BMAboutLauncherCard: View {
    var body: some View {
        BMCard {
            NavigationLink(destination: AboutView()) {
                HStack(spacing: 12) {
                    Image(systemName: "info.circle.fill").font(.title2).foregroundColor(.blue)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("关于 BuildMate").font(.headline).foregroundColor(.primary)
                        Text("V\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?") · Build \(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "?")")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    Spacer(); Image(systemName: "chevron.right").foregroundColor(.secondary)
                }
            }.accessibilityIdentifier("ui.5bb681d21409").buttonStyle(.plain)
        }
    }
}
