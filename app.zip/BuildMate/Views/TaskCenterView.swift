import SwiftUI

struct TaskCenterView: View {
    @ObservedObject private var blackBox = BMTaskBlackBox.shared
    let legacyHistory: [BuildHistoryRecord]
    @State private var filter = "全部"

    private var tasks: [BMTaskSummary] {
        let all = BMTaskPresentation.grouped(blackBox.taskSummaries).filter { $0.taskType != "SourceLifecycle" }
        switch filter {
        case "进行中": return all.filter { !$0.completed && !$0.cancelled && !$0.hasError }
        case "异常": return all.filter { $0.hasError }
        case "已完成": return all.filter { $0.completed }
        default: return all
        }
    }

    var body: some View {
        VStack(spacing: 12) {
            Picker("任务筛选", selection: $filter) { ForEach(["全部","进行中","异常","已完成"], id: \.self) { Text($0) } }
                .accessibilityIdentifier("ui.0c88a49490d7")
                .pickerStyle(.segmented)

            if tasks.isEmpty && legacyHistory.isEmpty {
                emptyCard
            } else {
                ForEach(tasks.prefix(10)) { task in
                    NavigationLink(destination: TaskDetailView(task: task, initialSegment: task.hasError ? "诊断" : "概览")) {
                        taskCard(task)
                    }
                    .accessibilityIdentifier("ui.b3a0ab4fc024")
                    .buttonStyle(.plain)
                }

                if tasks.count > 10 {
                    NavigationLink(destination: AllTasksView(legacyHistory: legacyHistory)) {
                        Label("历史任务 · 还有 \(tasks.count - 10) 条", systemImage: "archivebox")
                            .frame(maxWidth: .infinity)
                    }
                    .accessibilityIdentifier("ui.af9031ae26ac")
                    .buttonStyle(.bordered)
                }

                if !legacyHistory.isEmpty {
                    NavigationLink(destination: BuildHistoryView(items: legacyHistory)) {
                        HStack {
                            Label("旧版编译历史", systemImage: "clock.arrow.circlepath")
                            Spacer()
                            Text("\(legacyHistory.count)").foregroundColor(.secondary)
                            Image(systemName:"chevron.right").foregroundColor(.secondary)
                        }
                        .padding(14)
                        .background(Color(uiColor:.secondarySystemGroupedBackground))
                        .clipShape(RoundedRectangle(cornerRadius:16))
                    }
                    .accessibilityIdentifier("ui.61db9a71900c")
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var emptyCard: some View {
        BMPlainCard {
            BMEmptyState(icon: "tray", title: "暂无任务记录", message: "编译任务开始后会自动出现在这里。")
        }
    }

    private func taskCard(_ task: BMTaskSummary) -> some View {
        VStack(alignment:.leading,spacing:7){
            HStack {
                Text(task.sourceLabel ?? task.taskType)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                Spacer()
                Text(task.stateTitle)
                    .font(.caption.weight(.semibold))
                    .foregroundColor(stateColor(task))
            }
            HStack {
                Text(task.provider ?? "BuildMate")
                if let run=task.runID { Text("· Run \(run.prefix(12))") }
                Spacer()
                Text(task.updatedAt.formatted(date:.omitted,time:.shortened))
            }
            .font(.caption)
            .foregroundColor(.secondary)

            HStack(spacing: 6) {
                Text(summaryLine(task))
                    .font(.caption2)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                if task.hasError {
                    Spacer(minLength: 8)
                    Text("查看原因")
                        .font(.caption2.weight(.semibold))
                        .foregroundColor(.orange)
                }
            }
        }
        .padding(14)
        .background(BMTheme.palette.card)
        .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous).stroke(BMTheme.palette.separator, lineWidth: 1))
    }

    private func stateColor(_ task: BMTaskSummary) -> Color {
        if task.completed { return .green }
        if task.cancelled { return .secondary }
        if task.hasError { return .orange }
        return .blue
    }

    private func summaryLine(_ task: BMTaskSummary) -> String {
        if task.completed, let artifact = matchingArtifact(task) {
            let kind = artifact.artifactName.lowercased().hasSuffix(".deb") ? "DEB" : (artifact.artifactName.lowercased().hasSuffix(".ipa") ? "IPA" : "产物")
            let size = artifact.byteCount > 0 ? ByteCountFormatter.string(fromByteCount: Int64(artifact.byteCount), countStyle: .file) : ""
            return size.isEmpty ? "\(kind) 已回传并校验" : "\(kind) 已回传 · \(size)"
        }
        if task.cancelled { return "用户已停止，不会自动续跑" }
        if task.hasError { return compactError(task.lastMessage) }
        if task.completed { return "任务已完成" }
        return compactProgress(task.lastMessage)
    }

    private func matchingArtifact(_ task: BMTaskSummary) -> BMArtifactDeliveryRecord? {
        guard let runID = task.runID, !runID.isEmpty else { return nil }
        return BMArtifactDeliveryStore.load().first(where: { $0.runID == runID && $0.isLocalReady })
    }

    private func compactError(_ input: String) -> String {
        let oneLine = input.replacingOccurrences(of: "\n", with: " ")
        if oneLine.localizedCaseInsensitiveContains("cannot parse response") { return "云端启动响应异常 · 未重复创建 Build" }
        if oneLine.localizedCaseInsensitiveContains("401") || oneLine.localizedCaseInsensitiveContains("Bad credentials") { return "连接凭据失效 · 请检查 Token" }
        if oneLine.count > 64 { return String(oneLine.prefix(64)) + "…" }
        return oneLine
    }

    private func compactProgress(_ input: String) -> String {
        let oneLine = input.replacingOccurrences(of: "\n", with: " ")
        if oneLine.contains("publishing Relay") { return "正在同步云端产物" }
        if oneLine.count > 58 { return String(oneLine.prefix(58)) + "…" }
        return oneLine
    }
}

struct AllTasksView: View {
    @ObservedObject private var blackBox = BMTaskBlackBox.shared
    let legacyHistory: [BuildHistoryRecord]
    private var tasks: [BMTaskSummary] { BMTaskPresentation.grouped(blackBox.taskSummaries).filter { $0.taskType != "SourceLifecycle" } }
    var body: some View {
        List {
            Section("历史任务") {
                ForEach(tasks) { t in
                    NavigationLink(destination: TaskDetailView(task:t, initialSegment: t.hasError ? "诊断" : "概览")) {
                        VStack(alignment:.leading, spacing: 3) {
                            HStack {
                                Text(t.sourceLabel ?? t.taskType).font(.headline).lineLimit(1)
                                Spacer()
                                Text(t.stateTitle).font(.caption).foregroundColor(t.completed ? .green : (t.hasError ? .orange : .secondary))
                            }
                            Text("\(t.provider ?? "BuildMate")" + (t.runID.map { " · Run \(String($0.prefix(12)))" } ?? ""))
                                .font(.caption).foregroundColor(.secondary)
                        }
                    }
                    .accessibilityIdentifier("ui.16f6769f1ab9")
                }
            }
            if !legacyHistory.isEmpty {
                Section("旧版编译记录") {
                    NavigationLink("查看 \(legacyHistory.count) 条旧记录") { BuildHistoryView(items: legacyHistory) }
                }
            }
        }
        .navigationTitle("历史任务")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TaskDetailView: View {
    let task: BMTaskSummary
    let initialSegment: String
    @ObservedObject private var blackBox = BMTaskBlackBox.shared
    @State private var segment: String

    init(task: BMTaskSummary, initialSegment: String = "概览") {
        self.task = task
        self.initialSegment = initialSegment
        _segment = State(initialValue: initialSegment)
    }

    private var artifact: BMArtifactDeliveryRecord? {
        guard let runID = task.runID, !runID.isEmpty else { return nil }
        return BMArtifactDeliveryStore.load().first(where: { $0.runID == runID && $0.isLocalReady })
    }

    var body: some View {
        VStack(spacing:0){
            Picker("详情",selection:$segment){ ForEach(["概览","时间线","诊断"],id:\.self){Text($0)} }
                .accessibilityIdentifier("ui.c18944abdb67")
                .pickerStyle(.segmented)
                .padding()
            if segment == "概览" {
                List {
                    if let artifact {
                        Section {
                            NavigationLink(destination: ArtifactDeliveryCenterView(focusRunID: artifact.runID)) {
                                Label("打开本次产物", systemImage: "shippingbox.fill")
                                    .font(.headline)
                            }
                        }
                    }
                    Section("任务") {
                        BMKeyValueRow("状态",value:task.stateTitle)
                        if let p=task.provider { BMKeyValueRow("平台",value:p) }
                        if let r=task.runID { BMKeyValueRow("Run ID",value:r) }
                        if let s=task.sourceSHA256 { BMKeyValueRow("Source SHA",value:String(s.prefix(16))+"…") }
                        BMKeyValueRow("Task ID",value:task.taskID)
                    }
                    Section("结论") { Text(task.lastMessage).font(.footnote).textSelection(.enabled) }
                }
            }
            else if segment == "时间线" {
                List(blackBox.events(for:task.taskID)) { e in
                    VStack(alignment:.leading,spacing:4){
                        Text("#\(e.sequence) · \(e.stage)").font(.subheadline.weight(.semibold))
                        Text(e.message).font(.caption).textSelection(.enabled)
                        Text(e.date.formatted(date:.omitted,time:.standard)).font(.caption2).foregroundColor(.secondary)
                    }.padding(.vertical,3)
                }
            }
            else { TaskDiagnosticView(task:task) }
        }
        .navigationTitle("任务详情")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct TaskDiagnosticView: View {
    let task: BMTaskSummary
    @State private var sharePayload: BMDiagnosticSharePayload?
    @State private var isExporting = false
    @State private var msg = ""

    var body: some View {
        List {
            Section("诊断结论") {
                Text(task.stateTitle).font(.headline)
                Text(task.lastMessage).font(.footnote).textSelection(.enabled)
            }
            Section {
                Button { exportPackage() } label: {
                    Label(isExporting ? "正在生成诊断包…" : "导出 BUG 诊断包", systemImage: "shippingbox.fill")
                        .frame(maxWidth: .infinity)
                }
                .accessibilityIdentifier("ui.6010ec5b41ea")
                .buttonStyle(.borderedProminent)
                .disabled(isExporting)
                Text("ZIP 内含结论、任务时间线和完整黑匣子；敏感凭据自动脱敏。")
                    .font(.caption)
                    .foregroundColor(.secondary)
                if !msg.isEmpty { Text(msg).font(.caption).foregroundColor(.secondary) }
            }
        }
        .sheet(item: $sharePayload) { payload in BMBlackBoxShareSheet(items: [payload.url]) }
    }

    private func exportPackage() {
        guard !isExporting else { return }
        isExporting = true
        do {
            let package = try BMDiagnosticPackageBuilder.build(taskID: task.taskID, fallbackText: task.lastMessage)
            guard FileManager.default.fileExists(atPath: package.path) else {
                throw NSError(domain: "BuildMate.DiagnosticExport", code: 3, userInfo: [NSLocalizedDescriptionKey: "诊断 ZIP 尚未写入完成。"])
            }
            let attrs = try FileManager.default.attributesOfItem(atPath: package.path)
            let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
            guard size > 0 else {
                throw NSError(domain: "BuildMate.DiagnosticExport", code: 4, userInfo: [NSLocalizedDescriptionKey: "诊断 ZIP 为 0 B。"])
            }
            isExporting = false
            msg = "✅ 诊断包已生成"
            DispatchQueue.main.async { sharePayload = BMDiagnosticSharePayload(url: package) }
        } catch {
            isExporting = false
            msg = "❌ 导出失败：\(error.localizedDescription)"
        }
    }
}
