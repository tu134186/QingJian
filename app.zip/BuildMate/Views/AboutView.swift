import SwiftUI

private struct ReleaseNote: Identifiable {
    let version: String
    let build: Int
    let title: String
    let details: [String]
    var id: String { "\(version)-\(build)" }
}

private let buildMateReleases: [ReleaseNote] = [
    .init(
        version: "V7.5.6", build: 1068,
        title: "GitHub Actions 仓库绑定修复版",
        details: [
            "修复独立 G 配置残留旧 owner/repo 时 Run 被创建到其他仓库、当前 BuildMate 仓库看不到新 Run却显示成功的问题。",
            "G 编译现在强制绑定首页当前源码 GitHub 仓库；上传 app.zip、Workflow、dispatch、Run 查询与 Artifact 下载使用同一 owner/repo。",
            "保留独立 Actions Token；7.5.3 已稳定的 Codemagic/C 编译链不做改动。"
        ]
    ),
    .init(
        version: "V7.5.5", build: 1067,
        title: "GitHub Actions 完整编译恢复版",
        details: [
            "修复新建/修复仓库时只部署 Linux 预检 Workflow、导致 GitHub Actions 真实 IPA/DEB 编译功能缺失的问题。",
            "内置 Workflow 已恢复为与源码仓库一致的完整 Multi Builder：支持 Xcode/iOS IPA、Theos DEB、产物与失败日志回传。",
            "Codemagic V7.5.3 已稳定的 IPA/DEB Artifact Return Bridge 保持冻结，不做改动。"
        ]
    ),
    .init(
        version: "V7.5.3", build: 1065,
        title: "全局入口错位收口版",
        details: [
            "修复首页“编译设置”误切到底部设置 Tab 的错位：现在直接打开 GitHub Actions / Codemagic 编译平台配置。",
            "恢复底部设置 Tab 的源码平台、编译平台与中央素材入口；源码凭据为空时跳转设置后不再落到只有备份/关于的空职责页面。",
            "继续保留 Build1056 的 GitHub Actions 旧凭据迁移；本版只做静态入口/导航收口，不触发任何云编译，不改 Codemagic / GitHub Actions 执行主链。"
        ]
    ),
    .init(
        version: "V7.4.29", build: 1057,
        title: "编译平台配置去重版",
        details: [
            "GitHub Actions / Codemagic 分段按钮只负责查看与编辑配置，不再顺手切换当前编译平台。",
            "只有明确点击“设为当前”才改变下一次编译使用的平台。",
            "开发环境移除重复连接状态卡片；Codemagic / Artifact Return Bridge / 工作台状态机未改。"
        ]
    ),
    .init(
        version: "V7.4.23", build: 1051,
        title: "编译参数收口版",
        details: [
            "高级覆盖从设置首页移除，归入开始编译流程的默认折叠高级编译选项。",
            "编译前直接显示当前源码、仓库与手动选择的编译平台；有覆盖时显示覆盖项数量。",
            "新增恢复源码原值；仅调整编译确认 UI，Codemagic IPA / DEB、publishing 与 Artifact Return Bridge 冻结链未改。"
        ]
    ),
    .init(
        version: "V7.4.22", build: 1050,
        title: "仓库入口统一版",
        details: [
            "首页切换项目与开发环境仓库管理统一使用同一套仓库列表，不再维护重复页面。",
            "统一仓库列表补上安全删除入口，删除前校验 GitHub 仓库并要求输入仓库名确认。",
            "仅调整仓库 UI 与入口；Codemagic IPA / DEB 编译、publishing 与 Artifact Return Bridge 冻结链未改。"
        ]
    ),
    .init(
        version: "V7.4.21", build: 1049,
        title: "界面与备份收口版",
        details: [
            "设置首页把源码、编译与仓库入口收口为开发环境；底层平台仍完全独立。",
            "备份恢复改用原生文档选择回调，修复选中文件后无反应；页面同步紧凑重排。",
            "自定义中央素材默认折叠，任务阶段转速明显加快；稳定的 Codemagic IPA / DEB 编译与回传链未改。"
        ]
    ),
    .init(
        version: "V7.4.20", build: 1048,
        title: "云端启动确认加强版",
        details: [
            "Codemagic 启动响应不明确时延长只读确认窗口，等待云端 Build 索引出现后直接接管。",
            "整个确认过程绝不再次 POST /builds，避免网络抖动造成重复云编译和重复分钟消耗。",
            "修正 cannot parse response / 启动未确认被显示成‘未分类异常’的问题；IPA / DEB 回传冻结链未改。"
        ]
    ),
    .init(
        version: "V7.4.19", build: 1047,
        title: "任务中心收口版",
        details: [
            "修复产物已回传校验成功但任务仍显示进行中的终态矛盾。",
            "任务卡片改为人话摘要，异常任务直接进入诊断，成功任务可直达对应产物。",
            "首页任务仅保留最近 10 条，其余进入历史任务；C→IPA / C→DEB 冻结链未改。"
        ]
    ),
    .init(
        version: "V7.4.18", build: 1046,
        title: "功能收口版",
        details: [
            "备份恢复改为兼容迁移：支持直接选择 ZIP / .bmbak，恢复前预览，旧字段自动忽略，并保留恢复前快照。",
            "版本更新页从开发流水账改为稳定版/里程碑展示；长文案与技术名词进一步收短。",
            "Codemagic → IPA / DEB 已验证主链继续冻结，本版不改编译、publishing 与 Artifact Return Bridge。"
        ]
    ),
    .init(
        version: "V7.4.15", build: 1043,
        title: "Codemagic 双产物稳定版",
        details: [
            "Codemagic → IPA 已真实编译并自动回传至产物中心。",
            "Codemagic → DEB 已真实编译并自动回传至产物中心。",
            "两条成功链作为保护基线，后续 UI 优化不得重构其底层逻辑。"
        ]
    ),
    .init(
        version: "V7.4 系列", build: 1037,
        title: "编译与产物系统重构",
        details: [
            "移除误导性的本地源码体检，真实错误交给 Xcode / Theos 构建日志判断。",
            "完成 Codemagic Artifact Return Bridge 与 IPA / DEB 统一产物回传。",
            "GitHub Actions 与 Codemagic 保持手动独立选择，不做自动跨平台调度。"
        ]
    ),
    .init(
        version: "V7.1", build: 1007,
        title: "稳定核心基线",
        details: [
            "源码管理、编译、产物、BUG 诊断/黑匣子与发布形成稳定基础。",
            "中央动态素材、备份恢复与云端构建基础设施保留。"
        ]
    ),
    .init(
        version: "V2.9.18", build: 69,
        title: "早期真实云编译基线",
        details: [
            "完成早期 IPA / DEB 云编译验证与真实错误提取。"
        ]
    )
]

private var currentBundleVersion: String {
    Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
}

private var currentBundleBuild: String {
    Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "?"
}

private var currentReleaseVersion: String { "V\(currentBundleVersion)" }

struct AboutView: View {
    var body: some View {
        List {
            Section {
                VStack(spacing: 12) {
                    Image(systemName: "hammer.fill")
                        .font(.system(size: 38, weight: .bold))
                        .foregroundColor(.white)
                        .frame(width: 76, height: 76)
                        .background(Color.blue)
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    Text("BuildMate").font(.title2.bold())
                    Text("V\(currentBundleVersion) · Build \(currentBundleBuild)")
                        .font(.subheadline).foregroundColor(.secondary)
                    Text("源码、编译、产物与发布工作台")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
            }

            Section("产品") {
                NavigationLink("版本更新") { ReleaseHistoryView() }
                    .accessibilityIdentifier("ui.3edc7bc3d9ed")
                HStack {
                    Text("当前版本")
                    Spacer()
                    Text("V\(currentBundleVersion) (\(currentBundleBuild))").foregroundColor(.secondary)
                }
            }

            Section("编译平台") {
                Label("GitHub Actions · 手动选择", systemImage: "chevron.left.forwardslash.chevron.right")
                Label("Codemagic · IPA / DEB 已验证", systemImage: "cloud.fill")
                Label("自托管 Mac · 预留", systemImage: "desktopcomputer")
                Text("平台只显示和执行你手动选择的任务，不自动切换、不自动调度。")
                    .font(.footnote).foregroundColor(.secondary)
            }

            Section("隐私与诊断") {
                Label("连接凭据保存在本机 Keychain", systemImage: "key.fill")
                Label("黑匣子只记录，不控制任务", systemImage: "doc.text.magnifyingglass")
                Text("真实构建完成且 IPA/DEB 产物验证通过后，才记为完整成功。")
                    .font(.footnote).foregroundColor(.secondary)
            }
        }
        .navigationTitle("关于 BuildMate")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ReleaseHistoryView: View {
    var body: some View {
        List(buildMateReleases) { release in
            NavigationLink {
                List {
                    Section(release.title) {
                        ForEach(release.details, id: \.self) { detail in
                            Text(detail)
                        }
                    }
                }
                .navigationTitle(release.version)
                .navigationBarTitleDisplayMode(.inline)
            } label: {
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(release.version).font(.headline)
                        if release.version == currentReleaseVersion {
                            Text("当前")
                                .font(.caption2.bold())
                                .foregroundColor(.blue)
                        }
                        Spacer()
                        if release.build > 0 {
                            Text("Build \(release.build)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    Text(release.title)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                .padding(.vertical, 2)
            }
            .accessibilityIdentifier("ui.353ff6bb3805")
        }
        .navigationTitle("版本更新")
        .navigationBarTitleDisplayMode(.inline)
    }
}
