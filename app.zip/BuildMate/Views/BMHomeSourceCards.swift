import SwiftUI
import UIKit

struct BMHomeProjectCard: View {
    let repo: String
    let owner: String
    let sourceProviderLabel: String
    let branchLabel: String
    let latestRunID: Int64?
    let onSwitch: () -> Void

    var body: some View {
        BMCard {
            HStack(spacing: 12) {
                Image(systemName: "folder.fill")
                    .font(.system(size: 18, weight: .bold)).foregroundColor(.blue)
                    .frame(width: 40, height: 40).background(Color.blue.opacity(0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(repo.isEmpty ? "尚未选择项目" : repo).font(.headline.weight(.semibold))
                    HStack(spacing: 6) {
                        Text(owner.isEmpty || repo.isEmpty ? "选择工作空间的源码位置" : "源码：\(sourceProviderLabel) · \(owner)/\(repo) · \(branchLabel)").lineLimit(1)
                        if let latestRunID { Text("· 最近 Run #\(latestRunID)").lineLimit(1) }
                    }
                    .font(.caption).foregroundColor(.secondary)
                }
                Spacer(minLength: 8)
                Button(action: onSwitch) { Label("切换", systemImage: "arrow.left.arrow.right").font(.subheadline.weight(.semibold)) }.accessibilityIdentifier("ui.2aef9b30d35c")
                    .buttonStyle(BMCompactButtonStyle())
            }
        }
    }
}

struct BMHomeSourceCard: View {
    let sourceURL: URL?
    let iconURL: URL?
    let sourceSizeText: String
    let busy: Bool
    @Binding var autoCleanup: Bool
    let onPickIcon: () -> Void
    let onPickSource: () -> Void
    let onClearSource: () -> Void
    let onAutoCleanupChanged: (Bool) -> Void

    private var sourceDisplayName: String {
        guard let raw = sourceURL?.deletingPathExtension().lastPathComponent else { return "选择源码 ZIP" }
        var name = raw.replacingOccurrences(of: "BuildMate-", with: "")
        name = name.replacingOccurrences(of: "-Build", with: " · Build")
        name = name.replacingOccurrences(of: "V", with: "V", options: [], range: name.startIndex..<min(name.endIndex, name.index(name.startIndex, offsetBy: min(1, name.count))))
        return name.isEmpty ? raw : name
    }

    var body: some View {
        BMCard {
            VStack(spacing: sourceURL == nil ? 0 : 9) {
                HStack(spacing: 11) {
                    Button(action: onPickIcon) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 11, style: .continuous)
                                .fill((sourceURL == nil ? Color.blue : Color.green).opacity(0.10))
                                .frame(width: 40, height: 40)
                            if let iconURL, let image = UIImage(contentsOfFile: iconURL.path) {
                                Image(uiImage: image).resizable().scaledToFill().frame(width: 40, height: 40)
                                    .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                            } else {
                                Image(systemName: sourceURL == nil ? "doc.zipper" : "checkmark.circle.fill")
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundColor(sourceURL == nil ? .blue : .green)
                            }
                        }
                    }.accessibilityIdentifier("ui.f091c5350456").buttonStyle(.plain)

                    Button { if !busy { onPickSource() } } label: {
                        HStack(spacing: 10) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(sourceDisplayName)
                                    .font(.headline.weight(.semibold)).foregroundColor(.primary).lineLimit(1)
                                Text(sourceURL == nil ? "源码压缩包" : (sourceSizeText.isEmpty ? "当前源码 · 已载入" : "当前源码 · \(sourceSizeText)"))
                                    .font(.caption).foregroundColor(.secondary).lineLimit(1)
                            }
                            Spacer(minLength: 6)
                            Text(sourceURL == nil ? "选择" : "切换")
                                .font(.subheadline.weight(.semibold)).foregroundColor(busy ? .secondary : .blue)
                        }.contentShape(Rectangle())
                    }.accessibilityIdentifier("ui.61bab8b3c2ea").buttonStyle(.plain).disabled(busy)
                }

                if sourceURL != nil {
                    Divider()
                    HStack(spacing: 8) {
                        Text("IPA 后清理").font(.caption.weight(.semibold))
                        Toggle("", isOn: $autoCleanup).accessibilityIdentifier("ui.bbc4f19e35aa")
                            .labelsHidden()
                            .onChange(of: autoCleanup) { onAutoCleanupChanged($0) }
                        Spacer(minLength: 4)
                        Button(role: .destructive, action: onClearSource) {
                            Label("清除", systemImage: "trash").font(.caption.weight(.semibold))
                        }.accessibilityIdentifier("ui.b630193e3e7e")
                        .buttonStyle(.bordered).disabled(busy)
                    }
                }
            }
        }
    }
}
