import SwiftUI
import UniformTypeIdentifiers
import UIKit


struct ContentView: View {
    @Environment(\.scenePhase) var scenePhase
    @State var activeBlackBoxTaskID: String?
    @State var activeUnifiedTask: BMUnifiedTaskRecord?
    @State var stopRequested = false
    @State var activeCodemagicCancellation: CodemagicCancellationController?
    @State var activeCodemagicPollingTask: Task<CodemagicBuildState, Error>?
    @State var activeCompileTask: Task<Void, Never>?
    @State var owner = UserDefaults.standard.string(forKey: "owner") ?? ""
    @State var repo = UserDefaults.standard.string(forKey: "repo") ?? ""
    @State var token = KeychainStore.read("github-token")
    // Build79：首屏只保留一个轻量的平台枚举状态。Codemagic 的 Token/App ID/Workflow/Branch
    // 全部移出 ContentView，避免 iOS 16.5 在首屏解析巨大 SwiftUI 类型树时触发 metadata/AttributeGraph 递归崩溃。
    @State var cloudCompiler: BMCloudCompiler = .codemagic
    @State var activeCloudProvider = ""
    @State var activeCloudBuildID = ""

    @State var aiProvider = BMAIProfileStore.storedProvider()
    @State var lastAIProvider = BMAIProfileStore.storedProvider()
    @State var aiEndpoint = BMAIProfileStore.storedEndpoint(BMAIProfileStore.storedProvider())
    @State var aiModel = BMAIProfileStore.storedModel(BMAIProfileStore.storedProvider())
    @State var aiKey = BMAIProfileStore.storedKey(BMAIProfileStore.storedProvider())
    @State var aiState = "未检测"
    @State var maxRepairRounds = 3
    @State var autoAIEnabled = UserDefaults.standard.bool(forKey: "auto-ai-enabled")
    @State var showingBuildConfirmation = false

    @State var useOverrides = false
    @State var displayName = ""
    @State var bundleID = ""
    @State var version = ""
    @State var productName = ""
    @State var build = 1
    @State var overrideBuild = false

    @State var sourceURL: URL?
    @State var iconURL: URL?
    @State var showingSourcePicker = false
    @State var showingIconPicker = false
    @State var customEffectLibraryNames: [String] = BMCentralEffectLibraryStore.loadNames()
    @State var customEffectURL: URL?
    @State var customEffectEnabled = UserDefaults.standard.bool(forKey: "central-effect-custom-enabled")
    @State var centralThemeRaw = UserDefaults.standard.string(forKey: "central-effect-theme-v1") ?? BMCentralTheme.sharinganPro.rawValue
    @State var customEffectRotates = UserDefaults.standard.object(forKey: "central-effect-rotate-v1") as? Bool ?? true
    @State var customMotionMode = BMCentralMotionMode(rawValue: UserDefaults.standard.string(forKey: "central-effect-motion-mode-v2") ?? "taskLinked") ?? .taskLinked
    @State var customFixedSpeed = UserDefaults.standard.object(forKey: "central-effect-fixed-speed-v2") as? Double ?? 72.0
    @State var customEffectScale = UserDefaults.standard.object(forKey: "central-effect-scale-v1") as? Double ?? 0.94
    @State var customCircleCorrection = UserDefaults.standard.object(forKey: "central-effect-circle-correction-v1") as? Bool ?? true
    @State var sourceSizeText = ""
    @State var autoCleanupSourceOnHome = BMSourceLifecycleStore.autoCleanupAfterDelivery
    @State var sourceTraceText = "尚未校验"
    @State var sourceLocalSHA256 = ""
    @State var sourceGenerationID = UserDefaults.standard.string(forKey: "current-source-generation-v1") ?? UUID().uuidString
    @State var sourceRemoteSHA256 = ""
    @State var sourceUploadCommitSHA = ""
    @State var sourceDispatchHeadSHA = ""
    @State var buildHistory: [BuildHistoryRecord] = BuildHistoryStore.load()
    @State var busy = false
    @State var checking = false
    @State var status = "选择源码 ZIP 后即可预检或开始编译。"
    @State var repoState = "未检测"
    @State var githubDiagnosticText = "尚未体检"
    @State var githubRateLimitText = "未读取"
    @State var githubLogin = ""
    @State var repositories: [GitHubRepository] = []
    @State var showingRepoPicker = false
    @State var showingProjectPicker = false
    @State var showingNewProject = false
    @State var newRepoName = ""
    @State var newRepoDescription = ""
    @State var newRepoPrivate = true
    @State var creatingProject = false
    @State var showingNewProjectAlert = false
    @State var newProjectAlertTitle = "新建项目"
    @State var newProjectAlertMessage = ""
    @State var newProjectProgress = ""
    @State var savedProjects: [BuildMateProjectProfile] = BuildMateProjectStore.load()
    @State var repoSearch = ""
    @State var runURL: String?
    @State var latestRunID: Int64?
    @State var report: BuildReport?
    @State var downloadedArtifact: URL?
    @State var pendingArtifacts: [PendingArtifactRecord] = PendingArtifactStore.load()
    @State var artifactFileName = UserDefaults.standard.string(forKey: "artifact-file-name") ?? ""
    @State var artifactCategory = UserDefaults.standard.string(forKey: "artifact-category") ?? ""
    @State var lastPlan: AIRepairPlan?
    @State var aiUsageText = ""
    @State var aiBalanceText = "未查询"
    @State var workPulse = false
    @State var showingDuplicateCompileConfirm = false
    @State var duplicateCompileMessage = ""
    @State var workStage: BuildWorkStage = .idle
    // Build107：中央写轮眼使用连续相位积分，阶段切换时保持角度/角速度连续，消除快→慢→快时的跳帧。
    @State var centralSpinAnchorAngle: Double = 0
    @State var centralSpinTransitionStart = Date()
    @State var centralSpinStartSpeed: Double = 24
    @State var centralSpinTargetSpeed: Double = 24
    @State var lastCloudFailureKind: BuildFailureKind? = nil
    @State var lastAgentRepairContext: RepairContext? = nil
    @State var lastCloudFailureMessage = ""
    @State var workDetail = ""
    @State var workStartedAt: Date?
    @State var aiRound = 0
    @State var aiRoundMessage = ""
    @State var finalRepairError = ""
    @State var lastAIRawResponse = ""
    @State var lastAIFormattedResponse = ""
    @State var diagnosticReportURL: URL?
    @State var lastRepairContext: RepairContext?
    @State var didAutoRestoreConnection = false
    @State var didAttemptAutopilotResume = false
    @State var showingFailureActionAlert = false
    @State var showingBuildFailureReport = false
    @State var showingCurrentBuildReport = false
    @State var showingArtifactShare = false
    @State var showingArtifactCenter = false
    @State var showingCentralEffectPicker = false
    @State var showingCloudRunSheet = false
    @State var showingCompilerSettings = false
    @State var cloudRunSheetURL: URL?
    @State var historyExpanded = false
    @State var showingDeleteRepoConfirmation = false
    @State var showingVisibilityConfirmation = false
    @State var currentRepoIsPrivate: Bool? = nil
    @State var visibilityChanging = false
    @State var deleteRepoText = ""

    @State var githubExpanded = false
    @State var aiExpanded = false
    @State var advancedExpanded = false
    @State var selectedMainTab = 0
    @AppStorage("home-agent-workbench-enabled-v2") var homeAgentWorkbenchEnabled = false
    @AppStorage("home-agent-workbench-generation-v2") var homeAgentWorkbenchGenerationID = ""

    var appBackgroundColor: Color { Color(uiColor: .systemGroupedBackground) }

    var failureActionTitle: String { BMHomePresentation.failureTitle(kind: lastCloudFailureKind) }

    var failureActionMessage: String {
        BMHomePresentation.failureMessage(kind: lastCloudFailureKind, provider: activeCloudProvider, buildID: activeCloudBuildID)
    }

    var body: some View {
        NavigationView {
            ZStack(alignment: .top) {
                appBackgroundColor.ignoresSafeArea()
                VStack(spacing: 0) {
                    ScrollView {
                        VStack(spacing: 12) {
                            hero
                            if selectedMainTab == 0 {
                                projectCard
                                sourceCard
                                actionCard
                                if busy || workStage != .idle || report != nil {
                                    currentRunCard
                                }
                            } else if selectedMainTab == 1 {
                                NavigationLink(destination: ReleaseWorkspaceView()) {
                                    HStack(spacing: 12) {
                                        Image(systemName: "paperplane.fill").font(.title2)
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text("应用发布").font(.headline)
                                            Text("TestFlight / App Store 发布工作台").font(.caption).foregroundColor(.secondary)
                                        }
                                        Spacer()
                                        Image(systemName: "chevron.right").foregroundColor(.secondary)
                                    }
                                    .padding(16)
                                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(uiColor: .secondarySystemGroupedBackground)))
                                }
                                .buttonStyle(.plain)
                            } else if selectedMainTab == 2 {
                                TaskCenterView(legacyHistory: buildHistory)
                            } else {
                                // Build1058: 设置 Tab 恢复为真正的设置总入口。
                                // 之前这里只剩“备份恢复/关于”，导致“源码凭据为空→设置”与首页“编译设置”发生职责错位。
                                connectionCard
                                CloudCompilerNavigationCard(selection: $cloudCompiler)
                                centralEffectCard
                                backupRestoreCard
                                aboutCard
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.bottom, 18)
                    }
                    .background(Color.clear)
                    // 防止 ScrollView 在回弹/快速上滑时把 Hero 内容绘制进顶部系统状态区。
                    .clipped()
                    mainTabBar
                }

                // 顶部系统状态区使用真正的不透明遮罩。
                // 旧版只有 1pt 高，ScrollView 回弹时大标题仍会穿到时间/灵动岛旁边。
                // 这里从安全区下沿向屏幕顶部反向覆盖，只遮系统状态区，不压住正常页面内容。
                appBackgroundColor
                    .frame(height: 120)
                    .frame(maxWidth: .infinity)
                    .offset(y: -120)
                    .ignoresSafeArea(edges: .top)
                    .allowsHitTesting(false)
                    .zIndex(100)
            }
            .safeAreaInset(edge: .top, spacing: 0) {
                // 在系统安全区下沿再留一点呼吸距离，让所有主 Tab 的内容起点保持一致。
                appBackgroundColor.frame(height: 8)
            }
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showingBuildConfirmation) {
            BMCompileLaunchSheet(
                sourceName: sourceURL?.lastPathComponent ?? "当前源码",
                repository: owner.isEmpty || repo.isEmpty ? "未选择仓库" : "\(owner)/\(repo)",
                compiler: cloudCompiler.rawValue,
                useOverrides: $useOverrides,
                displayName: $displayName,
                bundleID: $bundleID,
                version: $version,
                overrideBuild: $overrideBuild,
                build: $build,
                productName: $productName,
                onCancel: { showingBuildConfirmation = false },
                onCompile: {
                    showingBuildConfirmation = false
                    launchSelectedCompile()
                }
            )
            .bmToolSheetPresentation()
        }
        .sheet(isPresented: $showingCentralEffectPicker) {
            NavigationView {
                ScrollView {
                    centralEffectSettingsContent
                        .padding(16)
                }
                .background(Color(uiColor: .systemGroupedBackground))
                .navigationTitle("中央素材")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("完成") { showingCentralEffectPicker = false }
                    }
                }
            }
            .bmToolSheetPresentation()
        }
        .sheet(isPresented: $showingCloudRunSheet) {
            if let cloudRunSheetURL {
                BMCloudRunSheet(url: cloudRunSheetURL, onClose: { showingCloudRunSheet = false })
                    .bmToolSheetPresentation()
            }
        }
        .sheet(isPresented: $showingCompilerSettings) {
            NavigationView {
                CloudCompilerSettingsView(selection: $cloudCompiler)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button("完成") { showingCompilerSettings = false }
                        }
                    }
            }
            .bmToolSheetPresentation()
        }
        .bmRepositoryVisibilityConfirmation(
            isPresented: $showingVisibilityConfirmation,
            isPrivate: currentRepoIsPrivate,
            owner: owner,
            repo: repo,
            onChange: { makePrivate in Task { await changeCurrentRepositoryVisibility(makePrivate: makePrivate) } }
        )
        .bmRepositoryDeleteConfirmation(
            isPresented: $showingDeleteRepoConfirmation,
            owner: owner,
            repo: repo,
            onDelete: { Task { await deleteCurrentRepository() } }
        )
        .bmFailureActionAlert(
            isPresented: $showingFailureActionAlert,
            title: failureActionTitle,
            message: failureActionMessage,
            recoveryAvailable: currentWorkbenchArtifactRecovery != nil,
            onRetryArtifact: {
                if let recovery = currentWorkbenchArtifactRecovery {
                    Task { await retryCodemagicArtifact(recovery) }
                }
            },
            onOpenBugReport: {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                    showingBuildFailureReport = diagnosticReportURL != nil
                }
            }
        )
        .sheet(isPresented: $showingBuildFailureReport) {
            BuildFailureReportSheet(
                reportURL: diagnosticReportURL,
                sourceURL: sourceURL,
                runID: latestRunID,
                runURL: runURL,
                failureText: workDetail.isEmpty ? status : workDetail,
                taskID: activeBlackBoxTaskID
            )
            .bmReportSheetPresentation()
        }
        .sheet(isPresented: $showingCurrentBuildReport) {
            Group {
                if let report {
                    CurrentBuildReportSheet(report: report, runURL: runURL)
                }
            }
            .bmReportSheetPresentation()
        }
        .sheet(isPresented: $showingArtifactCenter) {
            NavigationView { ArtifactDeliveryCenterView() }
                .bmToolSheetPresentation()
        }
        .sheet(isPresented: $showingArtifactShare) {
            if let downloadedArtifact {
                ActivityShareSheet(items: [downloadedArtifact]) { completed in
                    guard completed else { return }
                    Task { @MainActor in
                        markPendingArtifactDelivered(localURL: downloadedArtifact)
                    }
                }
            }
        }
        .sheet(isPresented: $showingSourcePicker) {
            DocumentPicker(contentTypes: [.zip]) { url in
                do {
                    let savedURL = try BMLocalFileStore.persistPickedFile(url, kind: .source)
                    let newSizeText = BMContentSupport.fileSizeText(savedURL)
                    let newArtifactName = BMLocalFileStore.suggestedArtifactBaseName(for: savedURL, repository: repo)
                    // Build129：先让文件选择器完成退场，再更新工作台源码卡片，
                    // 避免 sheet dismiss 与卡片增高同时抢主线程造成“突然撑大/顿一下”。
                    showingSourcePicker = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                        withAnimation(.easeOut(duration: 0.22)) {
                            // Build1033：先切断旧任务/恢复态，再接纳新源码。
                            // 即使重新导入完全相同的 ZIP（SHA 相同），也必须从新的待机会话开始。
                            resetCurrentRunForNewInput()
                            sourceURL = savedURL
                            sourceLocalSHA256 = ""
                            sourceRemoteSHA256 = ""
                            sourceUploadCommitSHA = ""
                            sourceDispatchHeadSHA = ""
                            UserDefaults.standard.removeObject(forKey: "current-source-sha256-v1")
                            if let data = try? Data(contentsOf: savedURL) {
                                let sha = GitHubService.sha256Hex(data)
                                adoptSourceGeneration(sha256: sha, sourceName: savedURL.lastPathComponent, reason: "手动导入源码 ZIP")
                            }
                            sourceSizeText = newSizeText
                            artifactFileName = newArtifactName
                            UserDefaults.standard.set(newArtifactName, forKey: "artifact-file-name")
                            status = "✅ 已切换源码 \(savedURL.lastPathComponent)。"
                        }
                    }
                    return
                } catch {
                    sourceURL = nil
                    sourceSizeText = ""
                    status = "❌ 源码保存失败：\(BMContentSupport.friendlyFileError(error, fileName: url.lastPathComponent))"
                }
                showingSourcePicker = false
            } onCancel: {
                showingSourcePicker = false
            }
        }
        .sheet(isPresented: $showingRepoPicker) {
            BMRepositoryPickerSheet(
                repositories: repositories, selectedOwner: owner, selectedRepo: repo, search: $repoSearch,
                onSelect: { item in
                    switchToRepository(item); currentRepoIsPrivate = item.isPrivate
                    status = "✅ 已选择仓库 " + item.fullName; showingRepoPicker = false
                    Task { await refreshCurrentRepositoryVisibility() }
                },
                onClose: { showingRepoPicker = false }
            )
            .bmToolSheetPresentation()
        }

        .sheet(isPresented: $showingProjectPicker) {
            BMProjectPickerSheet(
                repositories: repositories, tokenAvailable: !token.isEmpty, token: token, checking: checking,
                selectedOwner: owner, selectedRepo: repo, search: $repoSearch,
                onSelect: { item in switchToRepository(item); showingProjectPicker = false },
                onCreate: {
                    newRepoName = ""; newRepoDescription = ""; newRepoPrivate = true; showingProjectPicker = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { showingNewProject = true }
                },
                onRefresh: { Task { await connectAndLoadRepositories(silent: true) } },
                onDeleted: { deleted in
                    repositories.removeAll { $0.owner == deleted.owner && $0.name == deleted.name }
                    savedProjects.removeAll { $0.owner == deleted.owner && $0.repo == deleted.name }
                    BuildMateProjectStore.save(savedProjects)
                    if owner == deleted.owner && repo == deleted.name {
                        owner = ""; repo = ""; latestRunID = nil; report = nil; downloadedArtifact = nil
                        UserDefaults.standard.set("", forKey: "owner"); UserDefaults.standard.set("", forKey: "repo")
                    }
                    status = "✅ 已删除 GitHub 仓库 \(deleted.fullName)"
                },
                onClose: { showingProjectPicker = false }
            )
            .task { if !token.isEmpty { await connectAndLoadRepositories(silent: true) } }
            .bmToolSheetPresentation()
        }

        .sheet(isPresented: $showingNewProject) {
            BMNewProjectSheet(
                name: $newRepoName, description: $newRepoDescription, isPrivate: $newRepoPrivate,
                tokenAvailable: !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                githubLogin: githubLogin, creating: creatingProject, progress: newProjectProgress,
                onCreate: { Task { await createAndInitializeProject() } },
                onClose: { showingNewProject = false }
            )
            .alert(newProjectAlertTitle, isPresented: $showingNewProjectAlert) {
                Button("知道了", role: .cancel) {}.accessibilityIdentifier("ui.b01d0cd17b50")
            } message: { Text(newProjectAlertMessage) }
            .bmToolSheetPresentation()
        }

        .sheet(isPresented: $showingIconPicker) {
            DocumentPicker(contentTypes: [.png]) { url in
                do {
                    let savedURL = try BMLocalFileStore.persistPickedFile(url, kind: .icon)
                    iconURL = savedURL
                    status = "✅ 已保存新图标 \(savedURL.lastPathComponent)。"
                } catch {
                    iconURL = nil
                    status = "❌ 图标保存失败：\(BMContentSupport.friendlyFileError(error, fileName: url.lastPathComponent))"
                }
                showingIconPicker = false
            } onCancel: {
                showingIconPicker = false
            }
        }

        .onReceive(NotificationCenter.default.publisher(for: .bmCloudApprovalGranted)) { note in
            // Build1016：旧云审批通知不再续跑/创建任务，仅撤销旧 lease，避免历史状态复活。
            if let taskID = note.object as? String { BMCloudApprovalLeaseStore.revoke(taskID: taskID) }
        }
        .onAppear {
            restorePersistedFiles()
            restorePendingArtifactState()
            restoreArtifactDeliveryState()
            BMBuildNotificationCenter.requestAuthorizationIfNeeded()
            Task { await restoreSessionAfterLaunch() }
        }
        .onChange(of: scenePhase) { phase in
            switch phase {
            case .active:
                BMTaskBlackBox.shared.lifecycle("scene.active", detail: "App 进入前台 active；开始恢复会话/任务检查。")
                restorePendingArtifactState()
                restoreArtifactDeliveryState()
                Task { await restoreSessionAfterForeground() }
            case .inactive:
                BMTaskBlackBox.shared.lifecycle("scene.inactive", detail: "App 进入 inactive；可能由系统弹层、插件、截图/录屏或前后台切换触发。")
            case .background:
                BMTaskBlackBox.shared.lifecycle("scene.background", detail: "App 进入后台；黑匣子仅记录，不触发 UnifiedTask/Agent 自动恢复。")
            @unknown default:
                BMTaskBlackBox.shared.lifecycle("scene.unknown", detail: "收到未知 scenePhase。")
            }
        }
    }

}


extension View {
    @ViewBuilder
    func bmToolSheetPresentation() -> some View {
        if #available(iOS 16.0, *) {
            self
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        } else {
            self
        }
    }

    @ViewBuilder
    func bmReportSheetPresentation() -> some View {
        if #available(iOS 16.0, *) {
            self
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        } else {
            self
        }
    }
}
