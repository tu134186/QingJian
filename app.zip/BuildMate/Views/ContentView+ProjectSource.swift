import SwiftUI
import UniformTypeIdentifiers
import UIKit

extension ContentView {


    var filteredRepositories: [GitHubRepository] { BMHomePresentation.filteredRepositories(repositories, query: repoSearch) }

    var credentialsReady: Bool { BMHomePresentation.credentialsReady(owner: owner, repo: repo, token: token) }
    @MainActor func openProjectPicker() {
        // 不再用可能尚未同步的 @State token 直接禁用按钮。
        // 每次点击“切换”都主动读取最近一次已保存的 Keychain Token，避免必须先进设置页才能恢复点击。
        let stored = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
        if !stored.isEmpty { token = stored }
        guard !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            status = "❌ 当前源码平台凭据为空。请到设置 → 源码平台完成 GitHub Source Adapter 授权。"
            selectedMainTab = 3
            return
        }
        showingProjectPicker = true
        if repositories.isEmpty {
            Task { await connectAndLoadRepositories(silent: true) }
        }
    }

    @MainActor func returnWorkbenchToIdle() {
        // Build229：只结束当前工作台视觉终态；先从持久产物收件箱恢复 IPA，
        // 再回 idle。绝不能因为“返回待机”把刚完成的 IPA 入口清成“源码体检”。
        restorePendingArtifactState()
        restoreArtifactDeliveryState()
        workStage = .idle
        workDetail = ""
        workStartedAt = nil
        aiRound = 0
        workPulse = false
        if let delivery = currentSourceArtifactDelivery, delivery.isLocalReady {
            status = "已返回待机。当前源码产物 \(delivery.artifactName) 已保存在 BuildMate。"
        } else if let runID = latestRunID, let pending = pendingArtifacts.first(where: { $0.runID == runID }) {
            status = "已返回待机。\(pending.displayKind) 产物记录仍保留，可继续下载/导出或开始新的编译。"
        } else if CodemagicArtifactRecoveryStore.load() != nil {
            status = "已返回待机。上一成功 Build 的 IPA 恢复入口仍保留，不会重新编译。"
        } else if report != nil {
            status = "已返回待机。上一轮报告仍保留，可继续查看或开始新的编译。"
        } else {
            status = "已返回待机，可以选择源码或开始新的编译。"
        }
    }

    @MainActor func adoptSourceGeneration(sha256: String, sourceName: String, reason: String) {
        let generation = UUID().uuidString
        sourceGenerationID = generation
        sourceLocalSHA256 = sha256
        homeAgentWorkbenchEnabled = false
        homeAgentWorkbenchGenerationID = ""
        UserDefaults.standard.set(sha256, forKey: "current-source-sha256-v1")
        UserDefaults.standard.set(generation, forKey: "current-source-generation-v1")
        // Build1016：导入源码不触发中枢任务归档/审批失效链。
        activeUnifiedTask = nil
        UserDefaults.standard.set(false, forKey: "autopilot-pending-v1")
        BMPatchDiffStore.clear()
        BMTaskBlackBox.shared.record(taskID: "SOURCE-" + String(generation.prefix(8)), taskType: "SourceLifecycle", stage: "completed", message: "\(reason)：源码导入完成；仅切换当前源码并记录黑匣子，不触发中枢调度。", sourceSHA256: sha256, sourceLabel: sourceName)
    }

    @MainActor func resetCurrentRunForNewInput() {
        // Build1033：手动切换/重新导入源码就是“新工作台会话”。
        // 历史、黑匣子、产物中心保留，但旧 Run / Artifact Recovery 绝不能重新注入当前四按钮。
        UserDefaults.standard.set(false, forKey: "autopilot-pending-v1")
        busy = false
        stopRequested = false
        activeUnifiedTask = nil
        activeCloudProvider = ""
        activeCloudBuildID = ""
        activeCompileTask = nil
        activeCodemagicPollingTask?.cancel()
        activeCodemagicPollingTask = nil
        activeCodemagicCancellation?.cancel()
        activeCodemagicCancellation = nil
        CodemagicRunRecoveryStore.clear()
        CodemagicArtifactRecoveryStore.clear()
        report = nil
        latestRunID = nil
        runURL = nil
        downloadedArtifact = nil
        lastPlan = nil
        workStage = .idle
        workDetail = ""
        workStartedAt = nil
        diagnosticReportURL = nil
        lastRepairContext = nil
        lastAgentRepairContext = nil
        showingDuplicateCompileConfirm = false
        aiRound = 0
        finalRepairError = ""
        workPulse = false
    }

    func switchToRepository(_ item: GitHubRepository) {
        owner = item.owner
        repo = item.name
        repoState = "✅ " + item.defaultBranch
        UserDefaults.standard.set(owner, forKey: "owner")
        UserDefaults.standard.set(repo, forKey: "repo")
        rememberProject(owner: item.owner, repo: item.name, branch: item.defaultBranch)
        currentRepoIsPrivate = item.isPrivate
        resetCurrentRunForNewInput()
        status = "✅ 已切换项目 " + item.fullName
        artifactCategory = item.name
        UserDefaults.standard.set(artifactCategory, forKey: "artifact-category")
    }

    @MainActor func createAndInitializeProject() async {
        // 安装/恢复后 SwiftUI 状态可能还没拿到 Keychain 最新值，点击时主动同步。
        if token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let storedToken = KeychainStore.read("github-token")
            if !storedToken.isEmpty { token = storedToken }
        }

        let requestedName = newRepoName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !requestedName.isEmpty else {
            newProjectAlertTitle = "缺少仓库名称"
            newProjectAlertMessage = "请输入 GitHub 仓库名称后再创建。"
            showingNewProjectAlert = true
            return
        }
        guard !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            newProjectAlertTitle = "GitHub 未连接"
            newProjectAlertMessage = "请先在设置中填写并连接 GitHub Token。"
            showingNewProjectAlert = true
            return
        }

        creatingProject = true
        newProjectProgress = "1/5 正在验证 GitHub 登录与 Token…"
        var targetRepository: GitHubRepository?
        var newlyCreated = false
        defer { creatingProject = false }

        do {
            KeychainStore.save(token, key: "github-token")
            let bootstrap = GitHubService(owner: owner, repo: repo, token: token)
            let account = try await bootstrap.currentAccount()
            githubLogin = account.login

            // V2.7.8：先检查同名仓库。上次若“仓库创建成功、初始化失败”，
            // 这里直接接管已有仓库继续初始化，不再重复创建。
            newProjectProgress = "2/5 正在检查仓库是否已经存在…"
            if let existing = try await bootstrap.existingRepository(owner: account.login, name: requestedName) {
                targetRepository = existing
                newlyCreated = false
            } else {
                newProjectProgress = "2/5 正在创建仓库 \(requestedName)…"
                let created = try await bootstrap.createRepository(
                    name: requestedName,
                    description: newRepoDescription,
                    isPrivate: newRepoPrivate,
                    autoInit: true
                )
                targetRepository = created
                newlyCreated = true
            }

            guard let target = targetRepository else {
                throw NSError(domain: "BuildMate", code: -23, userInfo: [NSLocalizedDescriptionKey: "无法确定目标 GitHub 仓库。"] )
            }

            // 立即切换并持久化。后续任何一步失败，都不会丢掉已经创建/发现的仓库。
            owner = target.owner
            repo = target.name
            repoState = "✅ " + target.defaultBranch
            UserDefaults.standard.set(owner, forKey: "owner")
            UserDefaults.standard.set(repo, forKey: "repo")
            rememberProject(owner: target.owner, repo: target.name, branch: target.defaultBranch)
            if !repositories.contains(where: { $0.fullName == target.fullName }) {
                repositories.insert(target, at: 0)
            }

            let gh = GitHubService(owner: target.owner, repo: target.name, token: token)
            newProjectProgress = "3/5 正在建立第一个提交并准备默认分支…"
            try await gh.ensureRepositoryInitialized(branch: target.defaultBranch)
            try await gh.waitForRepositoryReady(branch: target.defaultBranch, attempts: newlyCreated ? 12 : 6)

            newProjectProgress = "4/5 正在检查并部署 BuildMate 工作流…"
            do {
                let workflowChanged = try await gh.putIfChanged(
                    path: ".github/workflows/buildmate.yml",
                    data: Data(SmartBuildWorkflow.linuxPreflight.utf8),
                    message: "BuildMate: initialize workflow",
                    branch: target.defaultBranch
                )
                newProjectProgress = workflowChanged ? "4/5 Workflow 已更新" : "4/5 Workflow 已是最新，无需重复写入"
            } catch {
                let ns = error as NSError
                if ns.code == 404 {
                    throw NSError(domain: "BuildMate.Workflow", code: 404, userInfo: [NSLocalizedDescriptionKey:
                        "仓库与 \(target.defaultBranch) 分支都已经可以访问，但写入 .github/workflows/buildmate.yml 时 GitHub 返回 404。\n\n这通常表示当前 Token 没有被授权修改 Workflow 文件，或 Fine-grained Token 没有把这个新仓库加入 Repository access。请给该仓库 Contents: Read and write、Workflows: Read and write 权限后再点一次；BuildMate 会自动接着初始化，不会重复建仓库。"
                    ])
                }
                throw error
            }

            newProjectProgress = "5/5 正在写入项目编译配置…"
            let cfg = BuildConfig(displayName: nil, bundleID: nil, version: nil, build: nil, productName: nil)
            try await gh.put(
                path: "build-config.json",
                data: try JSONEncoder().encode(cfg),
                message: "BuildMate: initialize config",
                branch: target.defaultBranch
            )

            report = nil
            latestRunID = nil
            runURL = nil
            downloadedArtifact = nil
            lastPlan = nil
            newRepoName = ""
            newRepoDescription = ""
            newProjectProgress = "✅ 创建与初始化全部完成"
            showingNewProject = false
            status = newlyCreated
                ? "✅ 新项目 \(target.fullName) 已创建并初始化。现在选择源码 ZIP，直接编译即可。"
                : "✅ 已接管现有项目 \(target.fullName) 并补齐初始化。现在可以直接编译。"
        } catch {
            let ns = error as NSError
            let detail = friendlyNewProjectError(error)

            if let target = targetRepository {
                newProjectAlertTitle = newlyCreated ? "仓库已创建，但初始化未完成" : "仓库已找到，但初始化未完成"
                newProjectAlertMessage = "GitHub 仓库 \(target.fullName) 已经存在，BuildMate 没有重复创建。\n\n\(detail)\n\n修正权限或网络后，保留相同仓库名称再点一次“创建并初始化项目”，BuildMate 会自动识别现有仓库并从初始化阶段继续。"
                newProjectProgress = "⚠️ 仓库已保留，初始化失败"
                status = "⚠️ \(target.fullName) 初始化失败：\(detail)"
            } else {
                // 422 + “name already exists” 常见于：仓库确实存在，但 Fine-grained Token
                // 没把这个仓库放进 Repository access，所以前面的 GET 会伪装成 404。
                if ns.code == 422 && detail.lowercased().contains("already exists") {
                    newProjectAlertTitle = "仓库已存在，但 Token 看不到它"
                    newProjectAlertMessage = detail + "\n\n这个现象通常不是仓库名错误：GitHub 已经有同名仓库，但当前 Fine-grained Token 没有被授权访问它。请把 Repository access 设为 All repositories，或把该仓库加入允许列表，并开启 Contents 与 Workflows 的 Read and write。然后保持原仓库名再点一次即可。"
                } else {
                    newProjectAlertTitle = newProjectFailureTitle(code: ns.code)
                    newProjectAlertMessage = detail
                }
                newProjectProgress = "❌ 创建失败"
                status = "❌ 新建项目失败：\(detail)"
            }
            showingNewProjectAlert = true
        }
    }

    func newProjectFailureTitle(code: Int) -> String {
        switch code {
        case 401: return "Token 无效或已过期"
        case 403: return "Token 权限不足"
        case 422: return "仓库名称不可用"
        case 404: return "GitHub 资源不可访问"
        default: return "新建项目失败"
        }
    }

    func friendlyNewProjectError(_ error: Error) -> String {
        let ns = error as NSError
        let base = error.localizedDescription
        switch ns.code {
        case 401:
            return base + "\n\n请重新生成或更换 GitHub Token，然后再连接。"
        case 403:
            return base + "\n\n新建仓库需要 Token 允许创建/管理仓库。能读取或编译已有仓库，不代表一定有新建仓库权限。"
        case 422:
            return base + "\n\n常见原因：同名仓库已经存在，或仓库名称不符合 GitHub 规则。请换一个名称再试。"
        case 404:
            return base + "\n\n如果仓库已经存在：请确认 Fine-grained Token 的 Repository access 已包含这个仓库，并给 Contents 与 Workflows 开启 Read and write。BuildMate 会自动识别现有仓库、补第一个提交并继续初始化。"
        default:
            return base
        }
    }

    @MainActor func restoreSessionAfterLaunch() async {
        guard !didAutoRestoreConnection else { return }
        didAutoRestoreConnection = true
        guard !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        await connectAndLoadRepositories(silent: true)
        BMExecutionSafetyFuse.installEmergencyFuse()
        await resumePendingCodemagicRunIfNeeded()
    }

    @MainActor func restoreSessionAfterForeground() async {
        guard !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        if githubLogin.isEmpty && !checking { await connectAndLoadRepositories(silent: true) }
        // 前台恢复只同步远端报告；已结束的 Run 不重新注入工作台实时状态。
        if !owner.isEmpty && !repo.isEmpty && !checking { await refreshRunStatus(readReport: true, updateTerminalStage: false) }
        BMExecutionSafetyFuse.installEmergencyFuse()
        await resumePendingCodemagicRunIfNeeded()
    }

    @MainActor func resumePendingCodemagicRunIfNeeded(manual: Bool = false) async {
        guard !busy, var recovery = CodemagicRunRecoveryStore.load(), !recovery.isBuildTerminal else { return }
        if !manual && !recovery.allowsAutomaticResume { return }
        if manual && recovery.userStopRequested == true {
            CodemagicRunRecoveryStore.mutate { $0.userStopRequested = false }
            recovery.userStopRequested = false
            stopRequested = false
        }
        let cfg = CodemagicStoredConfig.load()
        guard cfg.isReady else { return }
        busy = true
        workStage = .recovering
        // Build166：恢复计时必须沿用原 Run 创建时间，不能每次重启都从 00:00 开始。
        workStartedAt = recovery.createdAt
        activeCloudProvider = BMCloudCompiler.codemagic.rawValue
        activeCloudBuildID = recovery.buildID
        runURL = recovery.buildURL
        status = "📡 正在恢复 Codemagic Run…"
        workDetail = "恢复同一 Run \(String(recovery.buildID.prefix(8))) · 不重新编译"
        defer { busy = false }
        do {
            let cm = CodemagicService(token: cfg.token, appID: cfg.appID, workflowID: cfg.workflowID, branch: cfg.branch)
            let pollingTask = Task<CodemagicBuildState, Error> {
                try await cm.waitForCompletion(id: recovery.buildID, timeoutSeconds: 1800, maxConsecutiveNetworkFailures: 4) { state in
                Task { @MainActor in
                    guard self.activeCloudBuildID == state.id else { return }
                    let snapshot = BMCodemagicRunPresentation.snapshot(for: state, recoveryMode: true)
                    self.status = snapshot.status
                    self.runURL = state.buildURL
                    self.workStage = snapshot.stage
                    self.workDetail = snapshot.detail
                    if snapshot.shouldStopBusyImmediately {
                        self.busy = false
                        self.workPulse = false
                    }
                    CodemagicRunRecoveryStore.mutate { record in
                        record.lastRemoteStatus = state.status
                        record.buildState = BMCodemagicBuildAuthority(remoteStatus: state.normalizedStatus)
                        if state.normalizedStatus == "network_unknown" { record.networkFailures += 1 }
                    }
                    }
                }
            }
            activeCodemagicPollingTask = pollingTask
            defer { activeCodemagicPollingTask = nil }
            let final = try await pollingTask.value
            let state = BMCodemagicBuildAuthority(remoteStatus: final.normalizedStatus)
            CodemagicRunRecoveryStore.mutate { $0.buildState = state; $0.lastRemoteStatus = final.status }
            if final.succeeded {
                let branch = "buildmate-relay/\(recovery.taskID.lowercased())"
                let path = ".buildmate/relay/\(recovery.taskID)/artifact-return-receipt.json"
                let artifactName = final.artifacts.first(where: { $0.isDeliverable })?.name ?? ""
                CodemagicArtifactRecoveryStore.save(.init(buildID: recovery.buildID, artifactName: artifactName, buildURL: final.buildURL, sourceSHA256: recovery.sourceSHA256, createdAt: recovery.createdAt, taskID: recovery.taskID, relayBranch: branch, relayPath: path))
                CodemagicRunRecoveryStore.clear()
                workStage = .downloading
                status = "✅ 云端 Build 已完成；可继续重新抓取产物。"
                workDetail = "Build 成功与 Artifact 回传分离；不会创建新 Build"
                activeCloudProvider = ""
                activeCloudBuildID = ""
            } else {
                let terminal = final.normalizedStatus
                workStage = terminal == "canceled" ? .cancelled : .failed
                status = final.readableStatus
                workDetail = "Codemagic 权威终态：\(terminal)"
                BMTaskBlackBox.shared.record(taskID: recovery.taskID, taskType: "CodemagicCompile", level: terminal == "canceled" ? "WARN" : "ERROR", stage: "recovery.terminal.\(terminal)", message: "网络恢复后确认原 Run 权威终态=\(terminal)；关闭 Run checkpoint，不创建新 Run。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
                CodemagicRunRecoveryStore.clear()
                activeCloudProvider = ""
                activeCloudBuildID = ""
            }
        } catch {
            if stopRequested || error is CancellationError {
                workStage = .cancelled
                status = "⏹ 任务已停止。"
                workDetail = "用户停止后已终止本地轮询；不会因启动/回前台自动恢复"
                CodemagicRunRecoveryStore.mutate { $0.userStopRequested = true }
                BMTaskBlackBox.shared.record(taskID: recovery.taskID, taskType: "CodemagicCompile", level: "WARN", stage: "user.stop.localPollingCancelled", message: "用户停止任务；当前 Codemagic 轮询 Task 已取消，并设置自动恢复熔断。原 Run 仅供人工重新同步。", sourceSHA256: recovery.sourceSHA256, runID: recovery.buildID, provider: "Codemagic")
                diagnosticReportURL = makeDiagnosticReport(reason: workDetail + " · Build " + recovery.buildID, includeAI: false)
                return
            }
            // Build166：弱网只暂停主动轮询，不把整个工作台永久锁死。checkpoint 保留，下一次前台/手动同步仍查询同一 Run。
            workStage = .recovering
            status = "📡 网络暂不可用，已暂停自动轮询。"
            workDetail = "原 Run 已保存 · 恢复网络后重新同步，不会新建编译"
            CodemagicRunRecoveryStore.mutate { record in
                if record.firstError == nil { record.firstError = error.localizedDescription }
                record.networkFailures += 1
                record.buildState = .networkUnknown
            }
            activeCloudProvider = ""
            activeCloudBuildID = ""
        }
    }

    @MainActor func resumePendingAutopilotIfNeeded() async {
        // Build168 紧急熔断：App 启动/前台恢复只能“查询已有真实 Run”，绝不能恢复 AI 自动执行。
        // 历史 autopilot 标记一律关闭，避免失败 -> 重启 -> 再次 dispatch 的幽灵循环。
        if UserDefaults.standard.bool(forKey: "autopilot-pending-v1") {
            UserDefaults.standard.set(false, forKey: "autopilot-pending-v1")
            BMTaskBlackBox.shared.record(taskID: activeUnifiedTask?.id ?? "SAFETY-FUSE", taskType: "ExecutionSafety", level: "WARN", stage: "fuse.autopilot.resume.blocked", message: "Build168 已阻止启动/前台自动恢复 AI 执行；恢复器只有查询权，没有创建 Run 权限。", sourceSHA256: sourceLocalSHA256.isEmpty ? nil : sourceLocalSHA256, runID: nil, provider: "BuildMate")
        }
    }

    @MainActor func connectAndLoadRepositories(silent: Bool = false) async {
        checking = true
        defer { checking = false }
        do {
            KeychainStore.save(token, key: "github-token")
            let gh = GitHubService(owner: owner, repo: repo, token: token)
            let account = try await gh.currentAccount()
            let repos = try await gh.accessibleRepositories()
            githubLogin = account.login
            repositories = repos
            let previousRepository = owner.isEmpty || repo.isEmpty ? nil : "\(owner)/\(repo)"
            if owner.isEmpty { owner = account.login }
            if let selected = repos.first(where: { $0.owner == owner && $0.name == repo }) {
                repoState = "✅ " + selected.defaultBranch
                currentRepoIsPrivate = selected.isPrivate
                rememberProject(owner: selected.owner, repo: selected.name, branch: selected.defaultBranch)
            } else if let first = repos.first {
                owner = first.owner
                repo = first.name
                repoState = "✅ " + first.defaultBranch
                currentRepoIsPrivate = first.isPrivate
                rememberProject(owner: first.owner, repo: first.name, branch: first.defaultBranch)
            }
            let currentRepository = owner.isEmpty || repo.isEmpty ? nil : "\(owner)/\(repo)"
            if previousRepository != nil && previousRepository != currentRepository {
                latestRunID = nil
                report = nil
                runURL = nil
                downloadedArtifact = nil
                lastPlan = nil
                workStage = .idle
                workDetail = ""
                workStartedAt = nil
                diagnosticReportURL = nil
                aiRound = 0
            }
            UserDefaults.standard.set(owner, forKey: "owner")
            UserDefaults.standard.set(repo, forKey: "repo")
            if !silent {
                status = repos.isEmpty ? "⚠️ Token 有效，但没有读取到可访问仓库。请检查 Repository access。" : "✅ 源码平台 GitHub 已连接：@\(account.login)，读取到 \(repos.count) 个可访问仓库。"
            }
        } catch {
            repoState = "❌"
            if !silent { status = "❌ 源码平台 GitHub：\(error.localizedDescription)" }
        }
    }


    @MainActor func runGitHubDiagnostics() async {
        guard credentialsReady else { status = "❌ 请先连接 GitHub 并选择仓库。"; return }
        checking = true
        defer { checking = false }
        let result = await GitHubService(owner: owner, repo: repo, token: token).diagnostics()
        githubRateLimitText = result.rateLimitText
        githubDiagnosticText = result.summary
        status = result.repoReadOK && result.actionsReadOK ? "✅ GitHub 基础体检通过。已检查账号、Repository access、仓库可写状态、Workflow 读取和 Actions。" : "⚠️ GitHub 体检发现问题，请查看设置里的诊断结果。"
    }

    @MainActor func testConnection() async {
        checking = true
        let started = Date()
        defer { checking = false }
        do {
            let info = try await GitHubService(owner: owner, repo: repo, token: token).repoInfo()
            repoState = "✅ \(info.defaultBranch)"
            currentRepoIsPrivate = info.isPrivate
            status = "✅ GitHub 正常：\(info.fullName) · " + (info.isPrivate ? "私有" : "公开")
            DevelopmentControlStore.saveProbe(service: "GitHub Source", ok: true, startedAt: started, message: status)
            saveCredentials()
        } catch {
            repoState = "❌"; status = "❌ \(error.localizedDescription)"
            DevelopmentControlStore.saveProbe(service: "GitHub Source", ok: false, startedAt: started, message: error.localizedDescription)
        }
    }


}
