import SwiftUI

/// Build220：工作台中央特效的渲染与连续旋转状态独立。
/// 只接收展示状态，不创建 Run、不访问网络、不改变编译/AI 主链。
struct BMCentralWorkOrb: View {
    let stage: BuildWorkStage
    let customEffectEnabled: Bool
    let customEffectURL: URL?
    let customEffectRotates: Bool
    let customMotionMode: BMCentralMotionMode
    let customFixedSpeed: Double
    let customEffectScale: Double
    let customCircleCorrection: Bool
    let theme: BMCentralTheme

    @Binding var anchorAngle: Double
    @Binding var transitionStart: Date
    @Binding var startSpeed: Double
    @Binding var targetSpeed: Double

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: false)) { context in
            let time = context.date.timeIntervalSinceReferenceDate
            let spin = BMCentralMotionEngine.angle(
                at: context.date,
                anchorAngle: anchorAngle,
                transitionStart: transitionStart,
                startSpeed: startSpeed,
                targetSpeed: targetSpeed
            )

            BMCentralEffectRenderer(
                size: 104,
                spin: spin,
                time: time,
                customEffectEnabled: customEffectEnabled,
                customEffectURL: customEffectURL,
                customEffectRotates: customEffectRotates,
                customMotionMode: customMotionMode,
                customFixedSpeed: customFixedSpeed,
                customEffectScale: customEffectScale,
                customCircleCorrection: customCircleCorrection,
                theme: theme
            )
            .accessibilityLabel("\(stage.title) · 中央特效")
        }
        .onAppear {
            targetSpeed = BMCentralMotionEngine.targetSpeed(for: stage)
            startSpeed = targetSpeed
            transitionStart = Date()
        }
        .onChange(of: stage) { newStage in
            retarget(for: newStage)
        }
    }

    private func retarget(for stage: BuildWorkStage) {
        let now = Date()
        let angle = BMCentralMotionEngine.angle(
            at: now,
            anchorAngle: anchorAngle,
            transitionStart: transitionStart,
            startSpeed: startSpeed,
            targetSpeed: targetSpeed
        )
        let velocity = BMCentralMotionEngine.velocity(
            at: now,
            transitionStart: transitionStart,
            startSpeed: startSpeed,
            targetSpeed: targetSpeed
        )
        anchorAngle = angle.truncatingRemainder(dividingBy: 360)
        startSpeed = velocity
        targetSpeed = BMCentralMotionEngine.targetSpeed(for: stage)
        transitionStart = now
    }
}
