import SwiftUI
import UniformTypeIdentifiers
import UIKit

extension ContentView {
    var hero: some View {
        BMHomeHeroView(
            overallReady: heroOverallReady, workspaceName: workspaceDisplayName, branchLabel: heroBranchLabel,
            sourceProviderLabel: activeSourceProviderLabel, sourceReady: credentialsReady,
            compilerLabel: heroCloudLabel, compilerReady: activeBuildProviderReady,
            environmentDestination: AnyView(developmentEnvironmentPage)
        )
    }

    var heroOverallReady: Bool {
        credentialsReady && activeBuildProviderReady
    }

    var activeBuildProviderReady: Bool { BMHomePresentation.compilerReady(cloudCompiler, credentialsReady: credentialsReady) }

    var heroCloudLabel: String { BMHomePresentation.compilerLabel(cloudCompiler) }

    var activeSourceProviderLabel: String {
        BMSourceProviderRegistry.currentDescriptor.name
    }

    var workspaceDisplayName: String { BMHomePresentation.workspaceName(repo: repo) }

    var heroBranchLabel: String { BMHomePresentation.branchLabel(repo: repo, owner: owner, projects: savedProjects, repoState: repoState) }




    var projectCard: some View {
        BMHomeProjectCard(
            repo: repo, owner: owner, sourceProviderLabel: activeSourceProviderLabel, branchLabel: heroBranchLabel,
            latestRunID: latestRunID, onSwitch: { openProjectPicker() }
        )
    }

    var sourceCard: some View {
        BMHomeSourceCard(
            sourceURL: sourceURL, iconURL: iconURL, sourceSizeText: sourceSizeText, busy: busy,
            autoCleanup: $autoCleanupSourceOnHome,
            onPickIcon: { showingIconPicker = true },
            onPickSource: { showingSourcePicker = true },
            onClearSource: { clearWorkingSource(manual: true) },
            onAutoCleanupChanged: { BMSourceLifecycleStore.autoCleanupAfterDelivery = $0 }
        )
    }

    var actionCard: some View {
        BMActionWorkbenchLayout(
            banner: (busy || workStage != .idle) ? AnyView(activeWorkBanner) : nil,
            duplicateConfirm: nil,
            compileAction: AnyView(dynamicActionButton(slot: .compileAction)),
            artifactAction: AnyView(dynamicActionButton(slot: .artifactAction)),
            report: AnyView(dynamicActionButton(slot: .report)),
            nextStep: AnyView(dynamicActionButton(slot: .nextStep)),
            centralOrb: AnyView(
                Button { showingCentralEffectPicker = true } label: { centralWorkOrb }
                    .buttonStyle(.plain)
                    .accessibilityLabel("更换中央素材")
            ),
            smartDetail: nil
        )
    }

    @ViewBuilder func dynamicActionButton(slot: BMHomeActionSlot) -> some View {
        let spec = dynamicActionSpec(slot)
        BMCompactAction(
            spec.title,
            icon: spec.icon,
            horizontalShift: actionContentShift(for: slot)
        ) { spec.action() }
            .disabled(spec.disabled)
            .opacity(spec.disabled ? 0.72 : 1)
    }

    // Build94：四宫格始终围绕中央写轮眼排布，内容必须主动避让中央圆。
    // 不改按钮尺寸/位置，也不缩小中央核心；只把每一格的图标与标题向外侧偏移。
    // 这样无论“自动 / GitHub / Codemagic / Bitrise”等动态文案如何变化，
    // 主标题都不会再次进入中央 128pt 圆形覆盖区。
    func actionContentShift(for slot: BMHomeActionSlot) -> CGFloat {
        switch slot {
        case .compileAction, .report:
            return BMHomePresentation.actionShift(isLeft: true)
        case .artifactAction, .nextStep:
            return BMHomePresentation.actionShift(isLeft: false)
        }
    }

    func dynamicActionSpec(_ slot: BMHomeActionSlot) -> (title: String, icon: String, disabled: Bool, action: () -> Void) {
        let pending = latestRunID.flatMap { runID in pendingArtifacts.first(where: { $0.runID == runID }) }
        let currentDelivery = currentSourceArtifactDelivery
        // Build1031：云端入口只绑定当前 Task/Build。Codemagic 优先使用当前 buildId 或同一源码的 Artifact Recovery，
        // 不再让历史 GitHub Run / App 总览 URL 混入当前任务。
        let currentRunURL: String? = {
            if !activeCloudBuildID.isEmpty && activeCloudProvider == BMCloudCompiler.codemagic.rawValue {
                let cfg = CodemagicStoredConfig.load()
                if !cfg.appID.isEmpty { return "https://codemagic.io/app/\(cfg.appID)/build/\(activeCloudBuildID)" }
            }
            if let recovery = currentWorkbenchArtifactRecovery,
               let buildURL = recovery.buildURL?.trimmingCharacters(in: .whitespacesAndNewlines),
               !buildURL.isEmpty { return buildURL }
            return runURL
        }()
        let context = BMHomeActionContext(
            busy: busy, stopRequested: stopRequested, failed: workStage == .failed, succeeded: workStage == .success || workStage == .artifactPending,
            ready: sourceURL != nil, credentialsReady: credentialsReady, sourceAvailable: sourceURL != nil,
            cloudCompiler: cloudCompiler, workStage: workStage, reportAvailable: report != nil,
            cancelledDiagnosticAvailable: workStage == .cancelled && diagnosticReportURL != nil,
            lastReportFailedDiagnosticAvailable: report?.runID == latestRunID && report?.ok == false && report?.phase != "preflight" && diagnosticReportURL != nil,
            artifactPendingDiagnosticAvailable: workStage == .artifactPending && diagnosticReportURL != nil,
            pendingArtifactIsLocal: !busy && pending?.localPath != nil, pendingArtifactIsRemote: !busy && pending != nil && pending?.localPath == nil,
            recoveryAvailable: currentWorkbenchArtifactRecovery != nil, runURLAvailable: currentRunURL.flatMap(URL.init(string:)) != nil,
            undeliveredArtifactAvailable: currentDelivery?.localURL.map { BMArtifactDeliveryStore.needsDelivery(localURL: $0) } ?? false,
            verifiedArtifactAvailable: currentDelivery?.verified == true || (report?.runID == latestRunID && report?.hasVerifiedArtifact == true)
        )
        let spec = BMHomePresentation.actionSpec(slot, context: context)
        let action: () -> Void = {
            switch spec.intent {
            case .none: break
            case .stop: requestStopCurrentWork()
            case .startSelectedCompile: launchSelectedCompile()
            case .showCurrentReport: showingCurrentBuildReport = true
            case .showFailureReport: openFailureReport()
            case .showArtifactCenter: showingArtifactCenter = true
            case .downloadPendingArtifact: if let pending { Task { await downloadPendingArtifact(pending) } }
            case .retryArtifact: if let recovery = currentWorkbenchArtifactRecovery { Task { await retryCodemagicArtifact(recovery) } }
            case .openRunURL:
                if let currentRunURL, let url = URL(string: currentRunURL) {
                    cloudRunSheetURL = url
                    showingCloudRunSheet = true
                }
            case .downloadBuildArtifact: Task { await downloadBuildArtifact() }
            case .openCompilerSettings: showingCompilerSettings = true
            case .publishApp: selectedMainTab = 1
            }
        }
        return (spec.title, spec.icon, spec.disabled, action)
    }

    var centralWorkOrb: some View {
        BMCentralWorkOrb(
            stage: workStage,
            customEffectEnabled: customEffectEnabled,
            customEffectURL: customEffectURL,
            customEffectRotates: customEffectRotates,
            customMotionMode: customMotionMode,
            customFixedSpeed: customFixedSpeed,
            customEffectScale: customEffectScale,
            customCircleCorrection: customCircleCorrection,
            theme: selectedCentralTheme,
            anchorAngle: $centralSpinAnchorAngle,
            transitionStart: $centralSpinTransitionStart,
            startSpeed: $centralSpinStartSpeed,
            targetSpeed: $centralSpinTargetSpeed
        )
    }

    var currentSourceArtifactDelivery: BMArtifactDeliveryRecord? {
        guard sourceURL != nil, !sourceLocalSHA256.isEmpty else { return nil }
        return BMArtifactDeliveryStore.load().first(where: { item in
            guard item.sourceSHA256 == sourceLocalSHA256 else { return false }
            if let latestRunID { return item.runID == String(latestRunID) || latestRunID == 0 }
            if !activeCloudBuildID.isEmpty { return item.runID == activeCloudBuildID }
            return workStage == .success
        })
    }

    var currentWorkbenchArtifactRecovery: CodemagicArtifactRecoveryRecord? {
        // Recovery 属于原 Task/原 Source。空工作台、新源码、SHA 不匹配时绝不能污染当前工作台。
        guard sourceURL != nil,
              !sourceLocalSHA256.isEmpty,
              let recovery = CodemagicArtifactRecoveryStore.load(),
              let recoverySHA = recovery.sourceSHA256,
              !recoverySHA.isEmpty,
              recoverySHA == sourceLocalSHA256 else { return nil }
        return recovery
    }

    var selectedCentralTheme: BMCentralTheme { BMHomePresentation.theme(raw: centralThemeRaw) }

    var centralSharinganAccent: Color { BMHomePresentation.accent(stage: workStage, theme: selectedCentralTheme) }

    var centralSharinganShowsParticles: Bool { BMHomePresentation.showsParticles(stage: workStage) }

    var mainTabBar: some View { BMHomeTabBar(selection: $selectedMainTab) }

    var activeWorkBanner: some View {
        BMActiveWorkBanner(
            workStage: workStage, workDetail: workDetail, busy: busy, workStartedAt: workStartedAt,
            aiRound: aiRound, maxRepairRounds: maxRepairRounds,
            onResume: { Task { await resumePendingCodemagicRunIfNeeded(manual: true) } },
            onReturnIdle: { returnWorkbenchToIdle() }
        )
    }

    var duplicateCompileConfirmCard: some View {
        BMDuplicateCompileConfirmCard(
            message: duplicateCompileMessage,
            onCancel: {
                showingDuplicateCompileConfirm = false
                duplicateCompileMessage = ""
                status = "已取消重复源码编译，未消耗新的云端分钟。"
            },
            onContinue: {
                showingDuplicateCompileConfirm = false
                duplicateCompileMessage = ""
                UserDefaults.standard.set(true, forKey: "smart-force-next-v1")
                launchSelectedCompile()
            }
        )
    }

    var pipelineCard: some View {
        BMRunPipelineCard(workStage: workStage, busy: busy, aiRound: aiRound, maxRepairRounds: maxRepairRounds, workDetail: workDetail)
    }

    var currentRunCard: some View {
        BMCurrentRunCard(report: report, latestRunID: latestRunID, workDetail: workDetail, aiRound: aiRound, maxRepairRounds: maxRepairRounds, busy: busy)
    }

    var developmentEnvironmentPage: some View {
        BMSettingsDetailPage(title: "开发环境") {
            VStack(spacing: 12) {
                BMPlainCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("源码仓库", systemImage: "folder.fill").font(.headline)
                        Text(owner.isEmpty || repo.isEmpty ? "尚未选择源码仓库" : "\(owner)/\(repo) · main")
                            .font(.subheadline).foregroundColor(.secondary)
                        NavigationLink("GitHub 连接与权限") { BMSettingsDetailPage(title: "源码仓库") { githubSettingsContent } }
                    }
                }
                BMPlainCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("编译方式", systemImage: "hammer.fill").font(.headline)
                        Text("当前：\(cloudCompiler.rawValue) · 手动选择，不自动切换")
                            .font(.subheadline).foregroundColor(.secondary)
                        NavigationLink("配置编译平台") { CloudCompilerSettingsView(selection: $cloudCompiler) }
                    }
                }
            }
        }
    }

    var connectionCard: some View {
        BMSourcePlatformLauncherCard(
            subtitle: githubLogin.isEmpty ? "当前：GitHub · 待连接" : "当前：GitHub · 已登录 @\(githubLogin) · \(repositories.count) 个仓库",
            destination: AnyView(BMSettingsDetailPage(title: "源码平台 · GitHub") { githubSettingsContent })
        )
    }

    var githubSettingsContent: some View {
        BMGitHubSettingsView(
            token: $token, checking: checking, githubLogin: githubLogin, repositoryCount: repositories.count,
            repo: repo, owner: owner, credentialsReady: credentialsReady, repoState: repoState,
            githubRateLimitText: githubRateLimitText, githubDiagnosticText: githubDiagnosticText,
            currentRepoIsPrivate: currentRepoIsPrivate, visibilityChanging: visibilityChanging,
            onConnect: { Task { await connectAndLoadRepositories() } },
            onChooseRepository: { showingRepoPicker = true },
            onTest: { Task { await testConnection() } },
            onDiagnostics: { Task { await runGitHubDiagnostics() } },
            onChangeVisibility: { showingVisibilityConfirmation = true },
            onDeleteRepository: { showingDeleteRepoConfirmation = true }
        )
    }

    var centralEffectCard: some View {
        BMCentralEffectLauncherCard(
            subtitle: customEffectEnabled && customEffectURL != nil ? "素材仓库 · 批量导入 · SVG 三种运动模式" : "6 套高级动态核心 · 支持 SVG",
            destination: AnyView(BMSettingsDetailPage(title: "中央特效") { centralEffectSettingsContent })
        )
    }

    var centralEffectSettingsContent: some View {
        BMCentralEffectSettingsView(
            customEffectLibraryNames: $customEffectLibraryNames,
            customEffectURL: $customEffectURL,
            customEffectEnabled: $customEffectEnabled,
            centralThemeRaw: $centralThemeRaw,
            customEffectRotates: $customEffectRotates,
            customMotionMode: $customMotionMode,
            customFixedSpeed: $customFixedSpeed,
            customEffectScale: $customEffectScale,
            customCircleCorrection: $customCircleCorrection,
            status: $status,
            workStage: workStage,
            spinAnchorAngle: centralSpinAnchorAngle,
            spinTransitionStart: centralSpinTransitionStart,
            spinStartSpeed: centralSpinStartSpeed,
            spinTargetSpeed: centralSpinTargetSpeed
        )
    }

    var advancedCard: some View {
        BMAdvancedOverrideLauncherCard(
            subtitle: useOverrides ? "已开启源码 App 信息覆盖" : "默认保持源码原始信息",
            destination: AnyView(BMSettingsDetailPage(title: "高级覆盖") { advancedSettingsContent })
        )
    }

    var advancedSettingsContent: some View {
        BMAdvancedSettingsView(
            useOverrides: $useOverrides, displayName: $displayName, bundleID: $bundleID,
            version: $version, overrideBuild: $overrideBuild, build: $build, productName: $productName
        )
    }

    var backupRestoreCard: some View { BMBackupRestoreLauncherCard() }

    var aboutCard: some View { BMAboutLauncherCard() }
}
