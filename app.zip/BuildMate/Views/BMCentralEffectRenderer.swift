import SwiftUI

struct BMCentralEffectRenderer: View {
    let size: CGFloat
    let spin: Double
    let time: TimeInterval
    let customEffectEnabled: Bool
    let customEffectURL: URL?
    let customEffectRotates: Bool
    let customMotionMode: BMCentralMotionMode
    let customFixedSpeed: Double
    let customEffectScale: Double
    let customCircleCorrection: Bool
    let theme: BMCentralTheme

    private var ringColor: Color { customEffectEnabled ? .primary : theme.baseColor }

    private var customRotationAngle: Double {
        guard customEffectRotates else { return 0 }
        switch customMotionMode {
        case .taskLinked: return spin
        case .fixed: return time * customFixedSpeed
        case .intrinsic: return 0
        }
    }

    var body: some View {
        ZStack {
            Circle()
                .fill(Color.black.opacity(customEffectEnabled ? 0.045 : 0.10))
                .frame(width: size * 0.98, height: size * 0.98)

            Circle()
                .stroke(ringColor.opacity(customEffectEnabled ? 0.18 : 0.30), lineWidth: max(1.0, size * 0.014))
                .frame(width: size * 0.94, height: size * 0.94)

            Circle()
                .stroke(ringColor.opacity(customEffectEnabled ? 0.10 : 0.20), lineWidth: max(0.8, size * 0.009))
                .frame(width: size * 0.82, height: size * 0.82)
                .rotationEffect(.degrees(-spin * 0.18))

            if customEffectEnabled, let customEffectURL {
                BMCentralMediaView(url: customEffectURL, size: size * customEffectScale, circleCorrectionEnabled: customCircleCorrection)
                    .rotationEffect(.degrees(customRotationAngle))
                    .frame(width: size * customEffectScale, height: size * customEffectScale)
            } else {
                BMCentralBuiltInEffectView(theme: theme, spin: spin, accent: theme.baseColor, time: time)
                    .saturation(1.14)
                    .contrast(1.11)
                    .scaleEffect((size * 0.94) / 84.0)
                    .frame(width: size * 0.94, height: size * 0.94)
            }
        }
        .frame(width: size, height: size)
        .shadow(color: ringColor.opacity(customEffectEnabled ? 0.08 : 0.18), radius: size * 0.055)
    }
}

struct BMCentralThemePreview: View {
    let theme: BMCentralTheme
    let size: CGFloat

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20.0, paused: false)) { context in
            let time = context.date.timeIntervalSinceReferenceDate
            let spin = time.truncatingRemainder(dividingBy: 360) * 70
            BMCentralBuiltInEffectView(theme: theme, spin: spin, accent: theme.baseColor, time: time)
                .scaleEffect(size / 84.0)
                .frame(width: size, height: size)
        }
    }
}
