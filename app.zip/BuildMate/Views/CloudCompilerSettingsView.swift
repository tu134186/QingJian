import SwiftUI

// Build1029: cloud compiler selection/config are product-level primitives.
// These were accidentally removed during the old AI/Agent cleanup while active views still referenced them.
enum BMCloudCompiler: String, CaseIterable, Identifiable {
    case github = "GitHub Actions"
    case codemagic = "Codemagic"
    // Legacy-only values retained so old task/history records remain decodable.
    // They are not exposed by the current product UI.
    case bitrise = "Bitrise"
    case selfHosted = "自托管 Mac"
    var id: String { rawValue }
}

struct CodemagicStoredConfig {
    static let currentWorkflowID = "buildmate-clean-v1"
    static let legacyWorkflowID = "buildmate-ios-build76"

    var token: String
    var appID: String
    var workflowID: String
    var branch: String

    var isReady: Bool {
        !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !appID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !workflowID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !branch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    static func load() -> Self {
        let defaults = UserDefaults.standard
        let stored = (defaults.string(forKey: "codemagic-workflow-id") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let workflow: String
        if stored.isEmpty || stored == legacyWorkflowID {
            workflow = currentWorkflowID
            // One-time safe migration away from the retired cloud workflow.
            defaults.set(workflow, forKey: "codemagic-workflow-id")
        } else {
            workflow = stored
        }
        return .init(
            token: KeychainStore.read("codemagic-api-token"),
            appID: defaults.string(forKey: "codemagic-app-id") ?? "",
            workflowID: workflow,
            branch: defaults.string(forKey: "codemagic-branch") ?? "main"
        )
    }
}

struct BMGitHubActionsStoredConfig {
    var token: String
    var owner: String
    var repo: String
    var branch: String
    var isReady: Bool {
        !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !owner.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !repo.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !branch.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    static func load() -> Self {
        let defaults = UserDefaults.standard
        var token = KeychainStore.read("github-actions-token").trimmingCharacters(in: .whitespacesAndNewlines)
        var owner = (defaults.string(forKey: "github-actions-owner") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        var repo = (defaults.string(forKey: "github-actions-repo") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        var branch = (defaults.string(forKey: "github-actions-branch") ?? "main").trimmingCharacters(in: .whitespacesAndNewlines)

        // Build1056: old backups did not have a separate GitHub Actions credential.
        // Reuse the already-restored Source GitHub credential only when the independent G fields are empty.
        // This is configuration migration only: it never starts a workflow or consumes build minutes.
        if token.isEmpty {
            let sourceToken = KeychainStore.read("github-token").trimmingCharacters(in: .whitespacesAndNewlines)
            if !sourceToken.isEmpty { token = sourceToken; KeychainStore.save(sourceToken, key: "github-actions-token") }
        }
        if owner.isEmpty {
            let sourceOwner = (defaults.string(forKey: "owner") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if !sourceOwner.isEmpty { owner = sourceOwner; defaults.set(sourceOwner, forKey: "github-actions-owner") }
        }
        if repo.isEmpty {
            let sourceRepo = (defaults.string(forKey: "repo") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            if !sourceRepo.isEmpty { repo = sourceRepo; defaults.set(sourceRepo, forKey: "github-actions-repo") }
        }
        if branch.isEmpty { branch = "main"; defaults.set(branch, forKey: "github-actions-branch") }

        return .init(token: token, owner: owner, repo: repo, branch: branch)
    }
}

struct CloudCompilerNavigationCard: View {
    @Binding var selection: BMCloudCompiler
    @State private var githubUsageText = ""

    private var subtitle: String {
        switch selection {
        case .github:
            return githubUsageText.isEmpty ? "G · GitHub Actions · 已连接" : "G · GitHub Actions · \(githubUsageText)"
        case .codemagic:
            return "C · Codemagic · \(CodemagicStoredConfig.load().isReady ? "已连接" : "未配置")"
        case .selfHosted:
            return "M · 自托管 Mac · \(SelfHostedMacStoredConfig.load().isReady ? "已配置" : "未配置")"
        case .bitrise:
            return "旧平台记录"
        }
    }

    var body: some View {
        NavigationLink(destination: CloudCompilerSettingsView(selection: $selection)) {
            BMUnifiedRow(title: "编译平台", subtitle: subtitle, icon: "hammer.fill")
                .padding(BMDesign.Spacing.card)
        }
        .buttonStyle(.plain)
        .background(BMTheme.palette.card)
        .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous))
        .task(id: selection.rawValue) {
            guard selection == .github else { githubUsageText = ""; return }
            let token = BMGitHubActionsStoredConfig.load().token
            guard !token.isEmpty else { githubUsageText = "未配置"; return }
            do { githubUsageText = try await BMGitHubActionsUsageService.load(token: token).compactText }
            catch { githubUsageText = "用量暂不可用" }
        }
    }
}

struct CloudCompilerSettingsView: View {
    private enum FocusField: Hashable { case ghToken, ghOwner, ghRepo, ghBranch, cmToken, cmApp, cmWorkflow, cmBranch, shEndpoint, shToken }
    @Binding var selection: BMCloudCompiler
    // Build1057: configuration browsing is deliberately separate from the active compiler.
    // Tapping the segmented control only changes which configuration form is visible.
    @State private var configPage: BMCloudCompiler = .codemagic
    @State private var ghToken = ""
    @State private var ghOwner = ""
    @State private var ghRepo = ""
    @State private var ghBranch = "main"
    @State private var ghState = "待配置"
    @State private var cmToken = ""
    @State private var cmApp = ""
    @State private var cmWorkflow = CodemagicStoredConfig.currentWorkflowID
    @State private var cmBranch = "main"
    @State private var cmState = "待配置"
    @State private var shEndpoint = ""
    @State private var shToken = ""
    @State private var shState = "未配置"
    @State private var loaded = false
    @State private var checking = false
    @State private var githubUsage: BMGitHubActionsUsage?
    @State private var githubUsageState = ""
    @FocusState private var focusedField: FocusField?

    private var githubDraftReady: Bool { !ghToken.trimmed.isEmpty && !ghOwner.trimmed.isEmpty && !ghRepo.trimmed.isEmpty && !ghBranch.trimmed.isEmpty }
    private var codemagicDraftReady: Bool { !cmToken.trimmed.isEmpty && !cmApp.trimmed.isEmpty && !cmWorkflow.trimmed.isEmpty && !cmBranch.trimmed.isEmpty }
    private var selfHostedDraftReady: Bool { !shEndpoint.trimmed.isEmpty }

    var body: some View {
        Form {
            Section {
                Picker("查看配置", selection: $configPage) {
                    Text("GitHub Actions").tag(BMCloudCompiler.github)
                    Text("Codemagic").tag(BMCloudCompiler.codemagic)
                }
                .pickerStyle(.segmented)

                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("当前编译平台")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(selection.rawValue)
                            .font(.subheadline.weight(.semibold))
                    }
                    Spacer()
                    if configPage == selection {
                        Label("当前", systemImage: "checkmark.circle.fill")
                            .font(.caption.weight(.semibold))
                            .foregroundColor(.green)
                    } else {
                        Button("设为当前") { setActiveCompiler(configPage) }
                            .buttonStyle(.borderedProminent)
                    }
                }

                Text("上面的分段按钮只用于查看/编辑配置，不会切换编译平台。只有点“设为当前”才会改变下一次编译使用的平台。")
                    .font(.caption).foregroundColor(.secondary)
            } header: { Label("编译平台", systemImage: "hammer.fill") }

            if configPage == .github { githubSection } else { codemagicSection }

            selfHostedSection
        }
        .navigationTitle("编译平台")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { load() }
    }

    private var githubSection: some View {
        Section {
            platformStatus("GitHub Actions", ready: BMGitHubActionsStoredConfig.load().isReady, detail: BMGitHubActionsStoredConfig.load().isReady ? "独立编译配置已保存" : "填写用于 Actions 编译的 Token / Owner / Repo")
            if let usage = githubUsage {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(usage.compactText).font(.subheadline.weight(.semibold))
                        Text("本月已用 \(Int(usage.usedMinutes.rounded())) 分钟" + (usage.includedMinutes.map { " · 额度 \(Int($0.rounded())) 分钟" } ?? " · 官方未返回套餐额度"))
                            .font(.caption2).foregroundColor(.secondary)
                    }
                    Spacer()
                    Button("刷新") { refreshGitHubUsage() }.font(.caption)
                }
            } else if !githubUsageState.isEmpty {
                HStack { Text(githubUsageState).font(.caption).foregroundColor(.secondary); Spacer(); Button("刷新") { refreshGitHubUsage() }.font(.caption) }
            }
            field("Token", .ghToken) { SecureField("GitHub Actions Token", text: $ghToken).focused($focusedField, equals: .ghToken) }
            field("Owner", .ghOwner) { TextField("仓库所有者", text: $ghOwner).focused($focusedField, equals: .ghOwner) }
            field("Repo", .ghRepo) { TextField("编译仓库", text: $ghRepo).focused($focusedField, equals: .ghRepo) }
            field("Branch", .ghBranch) { TextField("main", text: $ghBranch).focused($focusedField, equals: .ghBranch) }
            HStack {
                Button(checking ? "正在测试…" : "保存并测试 GitHub Actions") { saveGitHub() }
                    .buttonStyle(.borderedProminent).disabled(checking || !githubDraftReady)
                Spacer(); Text(ghState).font(.caption).foregroundColor(ghState.hasPrefix("✅") ? .green : .secondary)
            }
            Text("这份 GitHub Actions 配置与“源码平台 · GitHub”分开保存。两边可以填同一个仓库，也可以不同。")
                .font(.caption).foregroundColor(.secondary)
        } header: { Label("GitHub Actions", systemImage: "chevron.left.forwardslash.chevron.right") }
    }

    private var codemagicSection: some View {
        Section {
            platformStatus("Codemagic", ready: CodemagicStoredConfig.load().isReady, detail: CodemagicStoredConfig.load().isReady ? "API 已配置" : "需要 API Token + App ID")
            field("API Token", .cmToken) { SecureField("API Token", text: $cmToken).focused($focusedField, equals: .cmToken) }
            field("App ID", .cmApp) { TextField("App ID", text: $cmApp).focused($focusedField, equals: .cmApp) }
            field("Workflow ID", .cmWorkflow) { TextField("Workflow ID", text: $cmWorkflow).focused($focusedField, equals: .cmWorkflow) }
            field("Branch", .cmBranch) { TextField("Branch", text: $cmBranch).focused($focusedField, equals: .cmBranch) }
            HStack {
                Button(checking ? "正在测试…" : "保存并测试 Codemagic") { saveCM() }
                    .buttonStyle(.borderedProminent).disabled(checking || !codemagicDraftReady)
                Spacer(); Text(cmState).font(.caption).foregroundColor(cmState.hasPrefix("✅") ? .green : .secondary)
            }
        } header: { Label("Codemagic", systemImage: "cloud.fill") }
    }

    private var selfHostedSection: some View {
        Section {
            platformStatus("自托管 Mac", ready: SelfHostedMacStoredConfig.load().isReady, detail: SelfHostedMacStoredConfig.load().isReady ? "地址已保存 · 等待/检查 Mac Agent" : "可先预留；以后有 Mac mini 再启用")
            field("Endpoint", .shEndpoint) {
                TextField("例如 http://192.168.1.20:8787", text: $shEndpoint)
                    .focused($focusedField, equals: .shEndpoint)
                    .keyboardType(.URL)
            }
            field("Token（可选）", .shToken) {
                SecureField("Mac Agent Token", text: $shToken)
                    .focused($focusedField, equals: .shToken)
            }
            HStack {
                Button(checking ? "正在测试…" : "保存并测试连接") { saveSelfHosted() }
                    .buttonStyle(.borderedProminent)
                    .disabled(checking || !selfHostedDraftReady)
                Spacer()
                Text(shState).font(.caption).foregroundColor(shState.hasPrefix("✅") ? .green : .secondary)
            }
            NavigationLink {
                MacAgentNodesView()
            } label: {
                Label("Mac Agent 节点管理", systemImage: "desktopcomputer")
            }
            Text("这是预留接口，不会自动参与现在的 GitHub Actions / Codemagic 编译。只有以后部署 BuildMate Mac Agent、握手成功并明确启用后，才允许作为第三条编译链。")
                .font(.caption).foregroundColor(.secondary)
        } header: { Label("自托管 Mac · 预留", systemImage: "desktopcomputer") }
    }

    @ViewBuilder private func field<V: View>(_ title: String, _ focus: FocusField, @ViewBuilder content: () -> V) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundColor(.secondary)
            content().textInputAutocapitalization(.never).autocorrectionDisabled(true)
                .frame(minHeight: 44).padding(.horizontal, 10)
                .background(Color(uiColor: .tertiarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.compact, style: .continuous))
        }.contentShape(Rectangle()).onTapGesture { focusedField = focus }
    }

    private func platformStatus(_ title: String, ready: Bool, detail: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: ready ? "checkmark.circle.fill" : "circle.dashed").foregroundColor(ready ? .green : .secondary)
            VStack(alignment: .leading, spacing: 2) { Text(title).font(.subheadline.weight(.semibold)); Text(detail).font(.caption2).foregroundColor(.secondary) }
            Spacer()
        }
    }

    private func load() {
        guard !loaded else { return }
        let stored = UserDefaults.standard.string(forKey: "cloud-compiler-v1").flatMap(BMCloudCompiler.init(rawValue:))
        selection = (stored == .github || stored == .codemagic) ? stored! : .codemagic
        UserDefaults.standard.set(selection.rawValue, forKey: "cloud-compiler-v1")
        configPage = selection
        let g = BMGitHubActionsStoredConfig.load(); ghToken = g.token; ghOwner = g.owner; ghRepo = g.repo; ghBranch = g.branch; ghState = g.isReady ? "已保存" : "待配置"
        if g.isReady { refreshGitHubUsage() }
        let c = CodemagicStoredConfig.load(); cmToken = c.token; cmApp = c.appID; cmWorkflow = c.workflowID; cmBranch = c.branch; cmState = c.isReady ? "已保存" : "待配置"
        let sh = SelfHostedMacStoredConfig.load(); shEndpoint = sh.endpoint; shToken = sh.token; shState = sh.isReady ? "已保存" : "未配置"
        loaded = true
    }


    private func setActiveCompiler(_ compiler: BMCloudCompiler) {
        guard compiler == .github || compiler == .codemagic else { return }
        selection = compiler
        UserDefaults.standard.set(compiler.rawValue, forKey: "cloud-compiler-v1")
    }

    private func saveGitHub() {
        checking = true; focusedField = nil
        let t=ghToken.trimmed, o=ghOwner.trimmed, r=ghRepo.trimmed, b=ghBranch.trimmed
        KeychainStore.save(t, key: "github-actions-token")
        UserDefaults.standard.set(o, forKey: "github-actions-owner"); UserDefaults.standard.set(r, forKey: "github-actions-repo"); UserDefaults.standard.set(b, forKey: "github-actions-branch")
        Task {
            do {
                let info = try await GitHubService(owner: o, repo: r, token: t).repoInfo()
                await MainActor.run { ghState = "✅ \(info.fullName)"; checking = false; refreshGitHubUsage() }
            } catch { await MainActor.run { ghState = "❌ \(error.localizedDescription)"; checking = false } }
        }
    }

    private func refreshGitHubUsage() {
        let token = ghToken.trimmed.isEmpty ? BMGitHubActionsStoredConfig.load().token : ghToken.trimmed
        guard !token.isEmpty else { githubUsage = nil; githubUsageState = "用量：Token 未配置"; return }
        githubUsageState = "正在读取 GitHub 官方用量…"
        Task {
            do {
                let usage = try await BMGitHubActionsUsageService.load(token: token)
                await MainActor.run { githubUsage = usage; githubUsageState = "" }
            } catch {
                await MainActor.run { githubUsage = nil; githubUsageState = "用量暂不可用（需要 GitHub Plan: read / Billing 权限）" }
            }
        }
    }

    private func saveCM() {
        checking = true; focusedField = nil
        let t=cmToken.trimmed, a=cmApp.trimmed, w=cmWorkflow.trimmed, b=cmBranch.trimmed
        KeychainStore.save(t, key: "codemagic-api-token")
        UserDefaults.standard.set(a, forKey: "codemagic-app-id"); UserDefaults.standard.set(w, forKey: "codemagic-workflow-id"); UserDefaults.standard.set(b, forKey: "codemagic-branch")
        Task {
            do {
                let msg = try await CodemagicService(token: t, appID: a, workflowID: w, branch: b).testConnection()
                await MainActor.run { cmState = msg.hasPrefix("✅") ? msg : "✅ \(msg)"; checking = false }
            } catch { await MainActor.run { cmState = "❌ \(error.localizedDescription)"; checking = false } }
        }
    }

    private func saveSelfHosted() {
        checking = true
        focusedField = nil
        let endpoint = shEndpoint.trimmed
        let token = shToken.trimmed
        UserDefaults.standard.set(endpoint, forKey: "selfhost-endpoint")
        KeychainStore.save(token, key: "selfhost-token")
        Task {
            do {
                let msg = try await SelfHostedMacService(endpoint: endpoint, token: token).testConnection()
                await MainActor.run {
                    shState = msg
                    checking = false
                }
            } catch {
                await MainActor.run {
                    shState = "❌ \(error.localizedDescription)"
                    checking = false
                }
            }
        }
    }
}

private extension String { var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) } }
