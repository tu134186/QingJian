import SwiftUI

// Build180: reusable ContentView presentation primitives.
// Keep the AnyView card boundary because Build104 proved that eagerly-expanded
// generic SwiftUI card trees can trigger stack-guard issues on iOS 16.5.
func BMCard<Content: View>(@ViewBuilder content: () -> Content) -> AnyView {
    let erased = AnyView(content())
    return AnyView(
        erased
            .padding(.horizontal, BMDesign.Spacing.card)
            .padding(.vertical, 14)
            .background(BMTheme.palette.card)
            .clipShape(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: BMDesign.Radius.card, style: .continuous).stroke(BMTheme.palette.separator, lineWidth: 1))
            .shadow(color: BMTheme.palette.shadow, radius: 14, y: 6)
    )
}

func BMContentSectionTitle(_ title: String, icon: String) -> some View {
    HStack(spacing: 10) {
        Image(systemName: icon)
            .font(.system(size: 18, weight: .semibold))
            .foregroundColor(.blue)
            .frame(width: 26, alignment: .center)
        Text(title).font(.headline)
        Spacer(minLength: 0)
    }
}

func BMStatePill(title: String, value: String, good: Bool) -> some View {
    HStack(spacing: 5) {
        Circle().fill(good ? Color.green : Color.secondary.opacity(0.5)).frame(width: 7, height: 7)
        Text(title).font(.caption.weight(.semibold))
        Text(value.replacingOccurrences(of: "✅ ", with: ""))
            .font(.caption)
            .foregroundColor(.secondary)
            .lineLimit(1)
    }
    .padding(.horizontal, 10)
    .padding(.vertical, 7)
    .background(Color(uiColor: .secondarySystemGroupedBackground))
    .clipShape(Capsule())
}

func BMCompactAction(_ title: String, icon: String, horizontalShift: CGFloat = 0, action: @escaping () -> Void) -> some View {
    Button(action: action) {
        VStack(spacing: 7) {
            Image(systemName: icon).font(.title3)
            Text(title)
                .font(.caption.weight(.semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.82)
                .allowsTightening(true)
        }
        .foregroundColor(.primary)
        .frame(maxWidth: .infinity)
        .offset(x: horizontalShift)
        .padding(.horizontal, 6)
        .padding(.vertical, 12)
        .background(Color(uiColor: .tertiarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .contentShape(Rectangle())
        .clipped()
    }.contentShape(Rectangle())
    .accessibilityIdentifier("ui.3b5fd8e59bdf")
    .buttonStyle(.plain)
}

@ViewBuilder
func BMField(_ placeholder: String, text: Binding<String>, secure: Bool) -> some View {
    if secure {
        SecureField(placeholder, text: text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .padding(.horizontal, 12)
            .frame(height: 46)
            .background(Color(uiColor: .tertiarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    } else {
        TextField(placeholder, text: text)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled(true)
            .padding(.horizontal, 12)
            .frame(height: 46)
            .background(Color(uiColor: .tertiarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

func BMSettingsNavigationCard<Destination: View>(
    title: String,
    subtitle: String,
    icon: String,
    @ViewBuilder destination: () -> Destination
) -> some View {
    BMCard {
        NavigationLink(destination: destination()) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundColor(.blue)
                    .frame(width: 28)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.headline).foregroundColor(.primary)
                    Text(subtitle).font(.caption).foregroundColor(.secondary).lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.secondary)
            }
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }.accessibilityIdentifier("ui.4c9d0a961d8e")
        .buttonStyle(.plain)
    }
}

func BMSettingsDetailPage<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
    ZStack {
        Color(uiColor: .systemGroupedBackground).ignoresSafeArea()
        ScrollView {
            BMCard { content() }
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
        }
    }
    .navigationTitle(title)
    .navigationBarTitleDisplayMode(.inline)
    .navigationBarHidden(false)
}

func BMExpandableCard<Header: View, Content: View>(
    isExpanded: Binding<Bool>,
    @ViewBuilder header: () -> Header,
    @ViewBuilder content: () -> Content
) -> some View {
    BMCard {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.20)) {
                    isExpanded.wrappedValue.toggle()
                }
            } label: {
                HStack(spacing: 12) {
                    header().frame(maxWidth: .infinity, alignment: .leading)
                    Image(systemName: "chevron.down")
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(.blue)
                        .rotationEffect(.degrees(isExpanded.wrappedValue ? 180 : 0))
                }
                .frame(minHeight: 40)
                .contentShape(Rectangle())
            }.accessibilityIdentifier("ui.a42da338cc3e")
            .buttonStyle(.plain)

            if isExpanded.wrappedValue {
                Divider().padding(.top, 10)
                content()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 12)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }
}

// Build181: shared compact action style extracted from ContentView.
struct BMCompactButtonStyle: ButtonStyle {
    var destructive: Bool = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundColor(destructive ? .red : .blue)
            .padding(.horizontal, 13)
            .frame(minHeight: 34)
            .background((destructive ? Color.red : Color.blue).opacity(configuration.isPressed ? 0.16 : 0.10))
            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            .opacity(configuration.isPressed ? 0.82 : 1)
            .contentShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
    }
}
