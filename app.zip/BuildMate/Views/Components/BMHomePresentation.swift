import SwiftUI

// Build200–204: 首页纯展示/派生状态集中到无副作用模型。
// 不持有 Token、不发网络请求、不创建 Run，保持执行主链原样。
enum BMHomePresentation {
    static func compilerReady(_ compiler: BMCloudCompiler, credentialsReady: Bool) -> Bool {
        switch compiler {
        case .github: return BMGitHubActionsStoredConfig.load().isReady
        case .codemagic: return CodemagicStoredConfig.load().isReady
        case .bitrise: return !(UserDefaults.standard.string(forKey: "bitrise-app-slug") ?? "").isEmpty
        case .selfHosted: return !(UserDefaults.standard.string(forKey: "selfhost-endpoint") ?? "").isEmpty
        }
    }

    static func compilerLabel(_ compiler: BMCloudCompiler) -> String {
        compiler.rawValue.replacingOccurrences(of: " Actions", with: "")
    }

    static func workspaceName(repo: String) -> String { repo.isEmpty ? "未选择项目" : repo }

    static func branchLabel(repo: String, owner: String, projects: [BuildMateProjectProfile], repoState: String) -> String {
        guard !repo.isEmpty else { return "未选项目" }
        if let project = projects.first(where: { $0.owner == owner && $0.repo == repo }), !project.branch.isEmpty { return project.branch }
        if repoState.hasPrefix("✅ ") {
            let value = String(repoState.dropFirst(2)).trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty { return value }
        }
        return "main"
    }

    static func failureTitle(kind: BuildFailureKind?) -> String {
        kind == .artifact ? "云端已成功 · 产物回传未完成" : "编译失败 · 下一步"
    }

    static func failureMessage(kind: BuildFailureKind?, provider: String, buildID: String) -> String {
        if provider == BMCloudCompiler.codemagic.rawValue && buildID.isEmpty {
            return "云平台链路发生异常，尚未证明 Xcode/源码编译失败。建议先查看 BUG 报告；只有拿到真实源码错误证据后再手动修改源码。"
        }
        if kind == .artifact {
            return "云端编译已成功，产物尚未回到 BuildMate。可直接重抓当前 Build 的产物，不会重新编译。"
        }
        if let kind, kind != .source {
            return "当前是\(kind.rawValue)异常。先查看 BUG 报告。"
        }
        return "已取得真实编译失败证据。请查看 BUG 报告，根据真实错误修改源码后手动再次编译。"
    }

    static func actionShift(isLeft: Bool) -> CGFloat { isLeft ? -28 : 28 }

    static func filteredRepositories(_ repositories: [GitHubRepository], query: String) -> [GitHubRepository] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return q.isEmpty ? repositories : repositories.filter { $0.fullName.lowercased().contains(q) }
    }

    static func credentialsReady(owner: String, repo: String, token: String) -> Bool {
        !owner.isEmpty && !repo.isEmpty && !token.isEmpty
    }

    static func theme(raw: String) -> BMCentralTheme { BMCentralTheme.migrated(rawValue: raw) }

    static func accent(stage: BuildWorkStage, theme: BMCentralTheme) -> Color {
        switch stage {
        case .artifactPending: return .orange
        case .success: return .green
        case .downloading: return .cyan
        case .packaging: return .orange
        case .failed: return .red
        default: return theme.baseColor
        }
    }

    static func showsParticles(stage: BuildWorkStage) -> Bool {
        switch stage { case .idle, .artifactPending, .success, .failed: return false; default: return true }
    }
}

enum BMHomeActionSlot { case compileAction, artifactAction, report, nextStep }
enum BMHomeActionIntent {
    case none, stop, startSelectedCompile
    case showCurrentReport, showFailureReport, showArtifactCenter
    case downloadPendingArtifact, retryArtifact
    case openRunURL, downloadBuildArtifact, openCompilerSettings, publishApp
}

struct BMHomeActionContext {
    var busy: Bool
    var stopRequested: Bool
    var failed: Bool
    var succeeded: Bool
    var ready: Bool
    var credentialsReady: Bool
    var sourceAvailable: Bool
    var cloudCompiler: BMCloudCompiler
    var workStage: BuildWorkStage
    var reportAvailable: Bool
    var cancelledDiagnosticAvailable: Bool
    var lastReportFailedDiagnosticAvailable: Bool
    var artifactPendingDiagnosticAvailable: Bool
    var pendingArtifactIsLocal: Bool
    var pendingArtifactIsRemote: Bool
    var recoveryAvailable: Bool
    var runURLAvailable: Bool
    var undeliveredArtifactAvailable: Bool
    var verifiedArtifactAvailable: Bool
}

struct BMHomeActionSpec {
    let title: String
    let icon: String
    let disabled: Bool
    let intent: BMHomeActionIntent
}

extension BMHomePresentation {
    static func actionSpec(_ slot: BMHomeActionSlot, context c: BMHomeActionContext) -> BMHomeActionSpec {
        switch slot {
        case .compileAction:
            if c.busy {
                return .init(title: c.stopRequested ? "正在停止" : "停止编译", icon: "stop.fill", disabled: c.stopRequested, intent: .stop)
            }
            if c.failed || c.succeeded {
                return .init(title: "再次编译", icon: "arrow.clockwise", disabled: !c.ready, intent: .startSelectedCompile)
            }
            return .init(title: "开始编译", icon: "play.fill", disabled: !c.ready, intent: .startSelectedCompile)

        case .artifactAction:
            // Build1031：右上角职责固定为“产物”，不再与右下角云端运行重复。
            if c.recoveryAvailable {
                return .init(title: "重抓产物", icon: "arrow.down.circle", disabled: false, intent: .retryArtifact)
            }
            return .init(title: "产物管理", icon: "shippingbox", disabled: false, intent: .showArtifactCenter)

        case .report:
            if c.busy {
                return c.reportAvailable
                    ? .init(title: "运行报告", icon: "doc.text.magnifyingglass", disabled: false, intent: .showCurrentReport)
                    : .init(title: "等待报告", icon: "doc.text.magnifyingglass", disabled: false, intent: .none)
            }
            if c.failed { return .init(title: "BUG 报告", icon: "exclamationmark.bubble", disabled: false, intent: .showFailureReport) }
            if c.artifactPendingDiagnosticAvailable { return .init(title: "BUG 报告", icon: "exclamationmark.bubble", disabled: false, intent: .showFailureReport) }
            if c.cancelledDiagnosticAvailable { return .init(title: "诊断报告", icon: "doc.text.magnifyingglass", disabled: false, intent: .showFailureReport) }
            if c.lastReportFailedDiagnosticAvailable { return .init(title: "上次报告", icon: "doc.text.magnifyingglass", disabled: false, intent: .showFailureReport) }
            if c.reportAvailable { return .init(title: "编译报告", icon: "doc.text.magnifyingglass", disabled: false, intent: .showCurrentReport) }
            return .init(title: "等待报告", icon: "doc.text.magnifyingglass", disabled: false, intent: .none)

        case .nextStep:
            if c.busy {
                return .init(title: "云端运行", icon: c.runURLAvailable ? "arrow.up.right.square" : "icloud", disabled: false, intent: c.runURLAvailable ? .openRunURL : .none)
            }
            if c.failed && c.runURLAvailable {
                return .init(title: "云端运行", icon: "arrow.up.right.square", disabled: false, intent: .openRunURL)
            }
            if c.succeeded && (c.pendingArtifactIsLocal || c.undeliveredArtifactAvailable || c.verifiedArtifactAvailable) {
                return .init(title: "发布应用", icon: "paperplane.fill", disabled: false, intent: .publishApp)
            }
            if c.pendingArtifactIsRemote { return .init(title: "下载产物", icon: "square.and.arrow.down", disabled: false, intent: .downloadPendingArtifact) }
            if c.runURLAvailable { return .init(title: "云端运行", icon: "arrow.up.right.square", disabled: false, intent: .openRunURL) }
            return .init(title: "编译设置", icon: "gearshape", disabled: false, intent: .openCompilerSettings)
        }
    }
}
