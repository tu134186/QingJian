import SwiftUI

struct BMAdvancedSettingsView: View {
    @Binding var useOverrides: Bool
    @Binding var displayName: String
    @Binding var bundleID: String
    @Binding var version: String
    @Binding var overrideBuild: Bool
    @Binding var build: Int
    @Binding var productName: String

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Toggle("覆盖源码 App 信息", isOn: $useOverrides).accessibilityIdentifier("ui.9a3fc2706b52")
            Text(useOverrides ? "仅对你填写的项目应用覆盖值，留空项仍保持源码。" : "关闭时完整保持源码中的名称、Bundle ID、版本号和 Product Name。")
                .font(.caption).foregroundColor(.secondary)
            if useOverrides {
                Divider()
                BMField("桌面标题（留空=保持源码）", text: $displayName, secure: false)
                BMField("Bundle ID（留空=保持源码）", text: $bundleID, secure: false)
                BMField("版本号（留空=保持源码）", text: $version, secure: false)
                Toggle("覆盖 Build", isOn: $overrideBuild).accessibilityIdentifier("ui.c69d935d760f")
                if overrideBuild { Stepper("Build：\(build)", value: $build, in: 1...99999) }
                BMField("Product Name（留空=保持源码）", text: $productName, secure: false)
            }
        }
    }
}

struct BMGitHubSettingsView: View {
    @Binding var token: String
    let checking: Bool
    let githubLogin: String
    let repositoryCount: Int
    let repo: String
    let owner: String
    let credentialsReady: Bool
    let repoState: String
    let githubRateLimitText: String
    let githubDiagnosticText: String
    let currentRepoIsPrivate: Bool?
    let visibilityChanging: Bool
    let onConnect: () -> Void
    let onChooseRepository: () -> Void
    let onTest: () -> Void
    let onDiagnostics: () -> Void
    let onChangeVisibility: () -> Void
    let onDeleteRepository: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            BMField("Fine-grained Token", text: $token, secure: true)
            HStack {
                Spacer()
                Button(checking ? "正在读取源码平台…" : "连接 GitHub 源码平台", action: onConnect).accessibilityIdentifier("ui.c5a978dd2e40")
                    .font(.subheadline.weight(.semibold)).buttonStyle(BMCompactButtonStyle())
                    .disabled(checking || token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Spacer()
            }
            if !githubLogin.isEmpty {
                HStack {
                    Label("已登录 @\(githubLogin)", systemImage: "person.crop.circle.badge.checkmark")
                        .font(.subheadline).foregroundColor(.green)
                    Spacer()
                    Text("\(repositoryCount) 个仓库").font(.caption).foregroundColor(.secondary)
                }
            }
            Divider()
            Button(action: onChooseRepository) {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(repo.isEmpty ? "选择源码仓库" : repo).font(.subheadline.weight(.semibold)).foregroundColor(.primary)
                        Text(owner.isEmpty ? "连接后自动读取可访问仓库" : owner + "/" + repo)
                            .font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                }.contentShape(Rectangle())
            }.accessibilityIdentifier("ui.d579b47a1e89").buttonStyle(.plain).disabled(repositoryCount == 0)

            if credentialsReady {
                Divider()
                HStack(spacing: 10) {
                    Button(checking ? "检测中…" : "测试当前源码", action: onTest).accessibilityIdentifier("ui.5061b9a20ec9")
                        .font(.subheadline.weight(.medium)).buttonStyle(BMCompactButtonStyle()).disabled(checking)
                    Button("权限 / 网络体检", action: onDiagnostics).accessibilityIdentifier("ui.81cdd3e73f5d")
                        .font(.subheadline.weight(.medium)).buttonStyle(BMCompactButtonStyle()).disabled(checking)
                    Spacer()
                }
                HStack {
                    Text("仓库状态").font(.caption).foregroundColor(.secondary)
                    Spacer()
                    Text(repoState).font(.footnote).foregroundColor(.secondary)
                }
                VStack(alignment: .leading, spacing: 4) {
                    Text("API 额度：\(githubRateLimitText)").font(.caption).foregroundColor(.secondary)
                    Text(githubDiagnosticText).font(.caption).foregroundColor(.secondary)
                }.frame(maxWidth: .infinity, alignment: .leading)
                Divider()
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("仓库可见性").font(.subheadline.weight(.semibold))
                        Text(currentRepoIsPrivate == nil ? "点测试当前仓库读取状态" : (currentRepoIsPrivate == true ? "私有 · 仅授权成员可访问" : "公开 · 任何人都可能查看源码"))
                            .font(.caption).foregroundColor(.secondary)
                    }
                    Spacer()
                    if let isPrivate = currentRepoIsPrivate {
                        Button(visibilityChanging ? "处理中…" : (isPrivate ? "改为公开" : "设为私有"), action: onChangeVisibility).accessibilityIdentifier("ui.41d9f08930ee")
                            .font(.subheadline.weight(.semibold)).buttonStyle(BMCompactButtonStyle(destructive: isPrivate)).disabled(visibilityChanging)
                    }
                }
                Text("修改可见性需要 Token 的 Administration → Read and write；不会改动 IPA/DEB 编译配置。")
                    .font(.caption2).foregroundColor(.secondary)
                Divider()
                Button("删除当前仓库", role: .destructive, action: onDeleteRepository).accessibilityIdentifier("ui.423aefe34562")
                    .buttonStyle(BMCompactButtonStyle(destructive: true)).font(.subheadline)
                    .disabled(repo.isEmpty || owner.isEmpty).frame(maxWidth: .infinity, alignment: .center)
            }
        }
    }
}

// Build1051：高级覆盖不再占用“设置”一级入口，而是归位到开始编译流程。
// 这里只编辑 BuildConfig 的既有字段；确认后仍调用原 startSelectedCompile 稳定链。
struct BMCompileLaunchSheet: View {
    let sourceName: String
    let repository: String
    let compiler: String
    @Binding var useOverrides: Bool
    @Binding var displayName: String
    @Binding var bundleID: String
    @Binding var version: String
    @Binding var overrideBuild: Bool
    @Binding var build: Int
    @Binding var productName: String
    let onCancel: () -> Void
    let onCompile: () -> Void

    @State private var advancedExpanded = false

    private var overrideCount: Int {
        guard useOverrides else { return 0 }
        var count = 0
        if !displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { count += 1 }
        if !bundleID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { count += 1 }
        if !version.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { count += 1 }
        if overrideBuild { count += 1 }
        if !productName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { count += 1 }
        return count
    }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 14) {
                    BMPlainCard {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("编译确认", systemImage: "hammer.fill").font(.headline)
                            HStack { Text("源码").foregroundColor(.secondary); Spacer(); Text(sourceName).lineLimit(1) }
                            HStack { Text("仓库").foregroundColor(.secondary); Spacer(); Text(repository).lineLimit(1) }
                            HStack { Text("平台").foregroundColor(.secondary); Spacer(); Text(compiler).fontWeight(.semibold) }
                        }.font(.subheadline)
                    }

                    BMPlainCard {
                        DisclosureGroup(isExpanded: $advancedExpanded) {
                            VStack(alignment: .leading, spacing: 14) {
                                Divider()
                                BMAdvancedSettingsView(
                                    useOverrides: $useOverrides,
                                    displayName: $displayName,
                                    bundleID: $bundleID,
                                    version: $version,
                                    overrideBuild: $overrideBuild,
                                    build: $build,
                                    productName: $productName
                                )
                                if useOverrides {
                                    Button("恢复源码原值") {
                                        useOverrides = false
                                        displayName = ""
                                        bundleID = ""
                                        version = ""
                                        overrideBuild = false
                                        build = 1
                                        productName = ""
                                    }
                                    .font(.subheadline.weight(.semibold))
                                }
                            }.padding(.top, 6)
                        } label: {
                            HStack {
                                Label("高级编译选项", systemImage: "slider.horizontal.3")
                                    .font(.headline).foregroundColor(.primary)
                                Spacer()
                                Text(overrideCount == 0 ? "未设置" : "已覆盖 \(overrideCount) 项")
                                    .font(.subheadline).foregroundColor(overrideCount == 0 ? .secondary : .blue)
                            }
                        }
                        .tint(.blue)
                    }

                    Button(action: onCompile) {
                        Label("开始编译", systemImage: "play.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(16)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("开始编译")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("取消", action: onCancel)
                }
            }
        }
    }
}
