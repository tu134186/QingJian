import SwiftUI

// Build205–209: ContentView 顶层确认/告警 UI 独立。
// 这里只负责系统 Dialog/Alert 的文案与按钮布局；真实编译、GitHub 写操作、
// AI 深度接管、Artifact 重抓和诊断打开仍由 ContentView 原业务回调执行。

private struct BMRepositoryVisibilityConfirmationModifier: ViewModifier {
    @Binding var isPresented: Bool
    let isPrivate: Bool?
    let owner: String
    let repo: String
    let onChange: (Bool) -> Void

    func body(content: Content) -> some View {
        content.confirmationDialog(isPrivate == true ? "将仓库改为公开？" : "将仓库设为私有？", isPresented: $isPresented, titleVisibility: .visible) {
            if isPrivate == true {
                Button("改为公开 \(owner)/\(repo)", role: .destructive) { onChange(false) }.accessibilityIdentifier("ui.c7364662972b")
            } else {
                Button("设为私有 \(owner)/\(repo)") { onChange(true) }.accessibilityIdentifier("ui.613840d32fca")
            }
            Button("取消", role: .cancel) {}.accessibilityIdentifier("ui.5a91290c1794")
        } message: {
            Text(isPrivate == true ? "改为公开后，任何人都可能查看仓库源码和公开的 Actions 信息。" : "设为私有后，未获授权的人无法查看仓库源码和 Actions。不会删除源码、Run、IPA/DEB 或修改编译 Workflow。")
        }
    }
}

private struct BMRepositoryDeleteConfirmationModifier: ViewModifier {
    @Binding var isPresented: Bool
    let owner: String
    let repo: String
    let onDelete: () -> Void

    func body(content: Content) -> some View {
        content.confirmationDialog("永久删除 GitHub 仓库？", isPresented: $isPresented, titleVisibility: .visible) {
            Button("永久删除 \(owner)/\(repo)", role: .destructive) { onDelete() }.accessibilityIdentifier("ui.99fb6a31b0ff")
            Button("取消", role: .cancel) {}.accessibilityIdentifier("ui.eee28513d6b5")
        } message: {
            Text("仓库源码、Actions 历史和相关内容会从 GitHub 删除。此操作不可撤销；BuildMate 不会自动删除仓库。")
        }
    }
}

private struct BMFailureActionAlertModifier: ViewModifier {
    @Binding var isPresented: Bool
    let title: String
    let message: String
    let recoveryAvailable: Bool
    let onRetryArtifact: () -> Void
    let onOpenBugReport: () -> Void

    func body(content: Content) -> some View {
        content.alert(title, isPresented: $isPresented) {
            if recoveryAvailable {
                Button("重新抓取产物") { onRetryArtifact() }.accessibilityIdentifier("ui.5cbfe9d4a5ba")
            }
            Button("查看 BUG 报告") { onOpenBugReport() }.accessibilityIdentifier("ui.f9291534b9d3")
            Button("暂不处理", role: .cancel) {}.accessibilityIdentifier("ui.28e24873b0c7")
        } message: {
            Text(message)
        }
    }
}


extension View {
    func bmRepositoryVisibilityConfirmation(
        isPresented: Binding<Bool>,
        isPrivate: Bool?,
        owner: String,
        repo: String,
        onChange: @escaping (Bool) -> Void
    ) -> some View {
        modifier(BMRepositoryVisibilityConfirmationModifier(
            isPresented: isPresented,
            isPrivate: isPrivate,
            owner: owner,
            repo: repo,
            onChange: onChange
        ))
    }

    func bmRepositoryDeleteConfirmation(
        isPresented: Binding<Bool>,
        owner: String,
        repo: String,
        onDelete: @escaping () -> Void
    ) -> some View {
        modifier(BMRepositoryDeleteConfirmationModifier(
            isPresented: isPresented,
            owner: owner,
            repo: repo,
            onDelete: onDelete
        ))
    }

    func bmFailureActionAlert(
        isPresented: Binding<Bool>,
        title: String,
        message: String,
        recoveryAvailable: Bool,
        onRetryArtifact: @escaping () -> Void,
        onOpenBugReport: @escaping () -> Void
    ) -> some View {
        modifier(BMFailureActionAlertModifier(
            isPresented: isPresented,
            title: title,
            message: message,
            recoveryAvailable: recoveryAvailable,
            onRetryArtifact: onRetryArtifact,
            onOpenBugReport: onOpenBugReport
        ))
    }
}
