import SwiftUI
import UIKit

/// Build183: shared artifact share bridge. Kept outside ContentView so its
/// UIViewControllerRepresentable.Context remains in the correct scope.
struct ActivityShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    var completion: (Bool) -> Void = { _ in }

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        controller.completionWithItemsHandler = { _, completed, _, _ in
            completion(completed)
        }
        return controller
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
