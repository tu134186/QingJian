# Build1066 · GitHub Actions Full Compile Restore

- Base: V7.5.3 Build1065.
- Fixed a real missing-function regression in repository bootstrap/repair: `SmartBuildWorkflow.linuxPreflight` embedded only a Linux preflight workflow, while the shipped `.github/workflows/buildmate.yml` contains the complete macOS/Xcode + Theos builder.
- New/repaired repositories will now receive the same full 315-line `BuildMate Multi Builder` workflow shipped in the source tree.
- Restored GitHub Actions capabilities: full/preflight mode, source fingerprint gate, XcodeGen iOS build, Theos DEB build, IPA/DEB artifact upload, compile.log/compile-errors upload, build report, repair context and source trace.
- Stable Codemagic V7.5.3 Artifact Return Bridge was not modified.
- Version: V7.5.4 Build1066.
