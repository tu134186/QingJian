# Mac Agent v1 / Provider SDK

`buildmate-mac-agent-v1` 是私人 Mac 节点正式协议。端点：`/buildmate/v1/handshake`、`/buildmate/v1/heartbeat`、`/buildmate/v1/tasks`、`/buildmate/v1/tasks/{task}/runs/{run}`。节点回执必须保持 Task ID 与 Source SHA 一致；断线后恢复既有 Run，禁止重新派发。

# Build143 Artifact Return Provider

`Git Relay`：Codemagic post-publish → 独立 `buildmate-relay` 分支 → BuildMate GitHub API 读取 → 短时 URL 下载。关联键：Task ID + Build ID + Source SHA。

## Build141 · V2.9.90 当前补充
Codemagic ArtifactReturnProvider 正在验证 post-publish receipt 经 CM_EXPORT_DIR 持久化；若平台不保留 publishing 后生成文件，将切换日志/Relay 通道。

# Provider Specification v1

BuildMate Core 不依赖任何单一厂商。

## Build Provider 标准能力
身份/配置检测、可用性与能力声明、源码同步、启动任务、状态轮询、取消、日志、真实错误、Artifact、失败分类、健康/冷却、可选额度信息。

## AI Provider 标准能力
模型发现/配置、健康检测、结构化任务输入、结构化 Patch 输出、超时/取消、上下文限制、成本/额度元数据、错误分类。任何 Provider 都不得直接绕过 Patch 审核和稳定基线规则写坏原始源码。

## 失败分流
平台认证、额度、Runner、网络、Provider 服务异常不得触发 AI 修改源码；只有真实源码/Xcode/Theos 错误才进入 Diagnostic/Repair Agent。

## 可替换目标
AI：OpenAI、DeepSeek、豆包、通义千问、未来模型、本地模型。
Build：Codemagic、GitHub Actions、Bitrise、自托管 Mac、Generic REST、未来 BuildMate Agent。
