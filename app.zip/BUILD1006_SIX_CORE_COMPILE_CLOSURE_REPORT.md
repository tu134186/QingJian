# Build1006 六大核心编译收口

- 基线：V7.1.2 Build1005
- 版本：V7.1.3 Build1006
- 删除 AIRepairService 中已经失去 BMAppSpec 定义的 Creator/AppSpec 生成入口，消除 Build1004 真实 Xcode 首因。
- 不恢复 BMAppSpec，不把 Creator 重新接回产品。
- 保留六大核心、备份恢复、中央 6 素材、SVG 素材系统、5~120 码模块。
- 本版重点是已知真实 Xcode 阻断收口；剩余历史 AI 文件若仍被诊断兼容链引用，不在无真实 Xcode 证据下盲删，以免误伤诊断/黑匣子。
