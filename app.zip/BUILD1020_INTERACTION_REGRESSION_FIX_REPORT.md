# BuildMate V7.3.2 · Build 1020

## 本次定位

实机截图显示“智能工作台”四宫格只有“产物管理”可点，同时 Codemagic Token / App ID 输入区无法获得焦点。

全局对比 Build1017 与 Build1019 后确认：Build1018/1019 实际删除的源码文件只有 4 个，均属于预期清理的旧平台/中枢 UI：
- BMPlatformCoreLauncherCard.swift
- CloudBuildConsoleView.swift
- CompilerPlatformsView.swift
- PlatformCoreCenterView.swift

未发现源码管理、源码体检、GitHub Actions、Codemagic、产物管理或黑匣子核心文件被误删。

## 根因与修复

1. 首页“源码体检”按钮错误复用了 `ready`（源码 + 当前编译平台已配置）条件。
   - 结果：Codemagic 未配置时，即使 app.zip 已导入，源码体检也被错误禁用。
   - 修复：源码体检只依赖 `sourceAvailable`。

2. Build1018 新写的 Codemagic 配置页在 iOS 16.5 上出现输入焦点回归。
   - 修复：改用原生 Form/Section；Token、App ID、Workflow ID、Branch 全部使用明确 FocusState；整行点击主动聚焦对应输入框。
   - 保存前统一 trim，保留原 Keychain/UserDefaults key，不破坏既有配置数据。

3. GitHub Actions / Codemagic 两条正式编译链保持不变。
   - 不自动跨平台切换。
   - 不恢复旧 Provider 中枢。
   - 黑匣子继续只记录。

## 验证
- release version check: PASS
- Swift 全源码 parse: PASS
- ZIP integrity: PASS
