# V7.5.2 · Build 1064
Build 1064：Codemagic 官方 Build ID + 官方 Artifacts 单一路径收口。删除 Artifact grace、preflight/receipt 与 Relay 执行判断；Build finished 后只继续查询同一 Build ID，直到官方 API 暴露 IPA、DEB 或官方 artifacts.zip。

# V7.4.31 · Build 1059
Build1059：以 V7.4.30 为基线继续做“只清确认残留、不碰稳定主链”的全局静态收口。移除已经没有任何外部入口的旧 BuildGuard/智能编译中枢/发布准备/最终稳定性页面，避免未来再次被误接回主 UI；同时删除 ContentView 中两个完全未使用的旧展示状态。保留底层 BuildGuardStore / SmartBuildStore 等仍被真实编译、诊断、发布链使用的数据与校验能力，不删除任何仍有调用的编译/诊断逻辑。继续保留 Build1056 的 GitHub Actions 凭据迁移和 Build1058 的 G/C 配置入口修复。本版未触发 GitHub Actions / Codemagic 云编译。

# V7.4.30 · Build 1058
Build1058：以 V7.4.29 为基线做全局入口/导航静态收口。修复首页“编译设置”误切设置 Tab 的错位，改为直接打开 GitHub Actions / Codemagic 配置；恢复底部设置 Tab 的源码平台、编译平台、中央素材、备份恢复与关于入口，源码凭据为空时跳转设置不再落入职责空页。保留 Build1056 的 GitHub Actions 旧凭据自动迁移。本版不触发云编译、不修改 Codemagic / GitHub Actions 执行主链、Artifact Return Bridge 与中央素材渲染主逻辑。

# V7.4.29 · Build 1057
Build1057：修正编译平台配置入口的职责错位：GitHub Actions / Codemagic 分段按钮现在只切换“查看/编辑哪套配置”，不会再立即改变主编译平台；仅点击“设为当前”才切换下一次编译链。开发环境删除重复的“连接状态”卡片，源码与编译配置继续各自独立。待机工作台右下角动态按钮、本次已验证的 Codemagic/Artifact Return Bridge/工作台状态机均不改。

# V7.4.28 · Build 1056
Build1056：GitHub Actions 独立编译配置增加安全迁移：当 G 的 Token / Owner / Repo 为空时，自动复用已经恢复并验证过的“源码 GitHub”凭据与当前仓库配置，写入独立 G 配置；只迁移配置，不启动 Workflow、不消耗编译分钟。原 Codemagic、Artifact Return Bridge、中央素材、工作台与编译执行链保持不动。

# V7.4.27 · Build 1055
Build1055：工作台四宫格加大分隔与中央留白；中央动态素材本体改为快捷入口，点击直接以可下滑关闭 Sheet 打开素材选择/自定义管理，同时从设置首页移除“中央特效”重复入口。云端运行改为应用内可下滑关闭 Sheet；开始编译、产物管理、报告继续统一 Sheet 交互。中央动画增加高速任务结束后的惯性减速，高速→待机约 2.35 秒平滑过渡。仅改 UI/展示与导航，不改 Codemagic/GitHub Actions/Artifact Return Bridge/编译执行链。

# V7.4.26 · Build 1054
Build1054：开发环境页删除重复“切换 / 管理仓库”入口。仓库切换/管理/删除只保留首页源码卡右侧“切换”这一条用户路径；开发环境页继续保留 GitHub 连接与权限、编译平台配置和连接状态。只改 UI 入口，不改仓库服务、Codemagic、GitHub Actions、Artifact Return Bridge 或编译执行链。

# V7.4.25 · Build 1053
Build1053：首页环境入口收口。首页顶部“环境”状态卡现在是唯一开发环境总入口，点击进入完整“开发环境”页；首页源码卡“切换”仍直接进入统一仓库选择/管理页；设置页删除重复“开发环境”入口，仅保留中央特效、备份与恢复、关于 BuildMate。只改导航/UI 入口，不改 GitHub Actions、Codemagic、Artifact Return Bridge 或编译执行链。

# V7.4.24 · Build 1052
Build1052：全局导航中文化。声明简体中文为 App 开发/支持语言，并在 SwiftUI 根层统一 zh-Hans Locale，使系统生成的二级/三级导航返回键按中文显示“返回”；保留系统左滑返回手势。仅修改 App 本地化/导航显示层，不改 GitHub Actions、Codemagic、Artifact Return Bridge、workflow 或编译执行链。

# V7.4.23 · Build 1051
Build1051：高级覆盖归位到开始编译流程。设置首页不再单独显示“高级覆盖”；点击开始编译先进入编译确认页，高级编译选项默认折叠，显示未设置/已覆盖 N 项，并支持一键恢复源码原值。仅调整 UI 与 BuildConfig 编辑入口，稳定云编译与产物回传链未改。

# V7.4.22 · Build 1050
Build1050：仓库入口统一。首页“切换项目”和开发环境“切换 / 管理仓库”统一进入同一仓库列表；列表新增安全删除菜单和仓库名二次确认。移除用户路径中的重复“源码仓库管理”页面。Codemagic IPA/DEB 编译、publishing 与 Artifact Return Bridge 冻结链未改。

# V7.4.21 · Build 1049
Build1049：设置与展示层收口。开发环境统一源码/仓库/编译入口；备份恢复改用 UIKit 文档选择回调解决选中文件无反应；自定义中央素材折叠并提高真实任务阶段转速。Codemagic IPA/DEB 编译、publishing 与 Artifact Return Bridge 冻结链未改。

# V7.4.20 · Build 1048
Build1048：Codemagic 启动结果安全确认加强。POST /builds 出现 cannot-parse/超时/断线等不确定结果时，延长只读反查窗口等待云端索引，找到同一 Task/SHA 后直接接管；全过程绝不自动第二次 POST。异常分类同步修正。C→IPA / C→DEB 编译与 Artifact Return Bridge 冻结链未改。

# V7.4.19 · Build 1047
Build1047：任务中心终态与展示收口。Artifact Return Bridge 已回传并完成校验时，黑匣子展示层直接归一为“已完成”；任务卡改为简短摘要，异常任务直达诊断，成功任务直达对应产物；最近 10 条之外进入历史任务。C→IPA / C→DEB 编译与回传冻结链未改。

# V7.4.18 · Build 1046
Build1046：Codemagic POST /builds 对 cannot-parse/超时/断线采用只读反查，不自动二次 POST，避免重复云构建；C→IPA/C→DEB 回传冻结链未改。


## 本轮原则
只做旁路/UI/备份兼容收口；禁止重构已实机验证的 Codemagic IPA/DEB 编译与回传链。平台状态仅只读展示，不参与自动调度。

- 冻结已实机验证成功的 Codemagic → IPA / DEB 编译与 Artifact Return Bridge 回传主链；本版不修改其 workflow、publishing、Relay 或产物下载协议。
- Codemagic 成功后的等待文案统一为“正在同步编译产物”，不再让 DEB 任务误显示等待 IPA。
- 新增“自托管 Mac · 预留”配置与 BuildMate Mac Agent v1 接口：Endpoint、可选 Token、握手/心跳/节点管理；未部署 Agent 前不会进入正式编译平台选择。
- 关于页明确当前云编译平台为 GitHub Actions 与 Codemagic；自托管 Mac 标记为未来私有编译节点。

# V7.4.15 · Build 1043

- 根据 Build1042 的真实 Codemagic/Xcode 日志修复唯一 Swift 类型错误：Codemagic Build ID 是 String，不能传入 GitHub 专用的 Int64 Run ID 字段。
- Codemagic Build ID 仍完整保存在黑匣子、Artifact Return Bridge receipt 与恢复记录中；SmartBuild 历史记录的 Int64 runID 对 Codemagic 留空。
- 不改 Artifact Return Bridge、CM_ARTIFACT_LINKS、IPA/DEB 双产物工作流，也不改 GitHub Actions 编译主链。

# V7.4.14 · Build 1042

- 修复 Codemagic IPA 回传最后一跳：识别 `itms-services://?action=download-manifest&url=<https artifact>` 302 包装并直接跟随其中 HTTPS signed artifact。
- 同一用户动作仍只执行一轮 Artifact 获取，不自动重复、不重新触发云 Build。
- Codemagic `buildmate-clean-v1` 升级为 IPA/DEB 双工程：XcodeGen 走 Xcode，Theos Makefile 走官方 Theos + ldid + `make clean package FINALPACKAGE=1`。
- Codemagic 产物下载/验证/恢复支持 `.ipa` 与 `.deb`；DEB 使用标准 ar 文件头和最小体积校验。

# V7.4.12 · Build 1040

开发收口：Codemagic Artifact 解析从“short-lived 优先”改为“稳定 authenticated URL 优先”。状态仍以 v3 为权威，但 Artifact 元数据始终补读旧 Builds API 后去重排序。稳定 URL 使用官方 public-url 两步法；签名 URL 必须原样 GET。

# V7.4.9 · Build 1037

- 彻底移除现行“源码体检”功能，不再用本地 ZIP 结构识别判断源码是否正确。
- 开始编译只做文件读取、SHA 与恢复点准备，随后直接进入真实 GitHub Actions / Codemagic 编译。
- 四宫格右下待机入口改为“编译设置”；有 BUG 的源码允许直接交给 Xcode/Theos 得到真实错误。
- 保留单次 IPA 抓取、Artifact URL 规范化、BUG 诊断包、任务黑匣子与中央动态素材。

# V7.4.8 · Build 1036

- 源码体检主链重构：新增独立 BMSourcePreflightService，不再依赖旧 SmartBuildStore/历史任务状态。
- 修复 App 重启后“开始编译”因内存 GitHub Token 尚未同步而不可点；首页开始编译只看当前源码，真正执行时从 Keychain 读取凭据并做明确校验。
- BUG 报告首开不再白板；移除失败报告右上角“完成”，保留下拉关闭。
- 保留 Codemagic 单次 IPA 抓取、Artifact URL 规范化、GitHub/Codemagic 正式编译主链与中央动态素材。

# V7.4.7 · Build 1035

- 修复通用源码体检与首次导入后的按钮点击命中；保持编译主链和单次产物抓取不变。

## V7.4.5 · Build 1033 — Artifact single-attempt + fresh source session

- Codemagic IPA 自动抓取和“重抓产物”每次只跑 1 轮；不再延迟自动第 2~5 次。
- 同一轮兼容 v3 `short_lived_download_url`，短时公开地址直接 GET，不再错误追加 `/public-url`。
- 每次手动导入源码都创建新的工作台会话：旧 Run/Artifact Recovery 不再因相同 SHA 自动恢复；黑匣子/历史仍保留。
- 首次导入源码后“源码体检”立即可点。
- 不改已验证的 Xcode/Codemagic clean workflow，不进行 AI/Agent 批量删除。

## V7.4.4 · Build 1032 — Real Xcode compile closure for Build1031

- 修复真实 Codemagic/Xcode 暴露的 3 个 Swift 编译错误：relayBranch、relayPath 残留引用，以及可选 buildURL 的 isEmpty。
- Codemagic 失败诊断收口为只读当前 Build ID 的 Artifact，不再依赖 Git Relay。
- 不改 Xcode/Codemagic 主编译链，不进行 AI/Agent 大删除。

## V7.4.3 · Build 1031 — Artifact return closure + four-button dedup

- Codemagic finished 后的 Artifact 官方下载改为同一 Build ID 有限退避重试（0/5/10/20/30 秒），不创建新 Build。
- 移除 Git Relay 作为 Codemagic 成功产物回传的必要链路；下载暂失败保持“编译成功 · IPA 待获取”。
- 工作台四键固定职责：编译 / 产物 / 报告 / 下一步；同一状态不再出现两个相同动作。
- 云端入口绑定当前 Codemagic Build ID / 当前源码恢复记录，避免历史 Run URL 污染。
- 保持已成功的 Xcode/Codemagic 编译主链、GitHub Actions、DEB 和中央素材不变。

## V7.4.0 · Build 1028 — GitHub Actions 422 真实调用路径修复

- 根据 Build1027 真实诊断包修复：首次 workflow_dispatch 返回 HTTP 422 后，旧逻辑没有进入兼容降级，Run ID 为空。
- 新逻辑不再只依赖 NSError.code；同时识别 HTTP 422 / Unexpected inputs 文本，并按“完整 inputs → mode-only → 无 inputs”顺序逐级重试。
- 401 / 403 / 404 / 网络错误仍原样抛出，不会被错误降级掩盖；422 dispatch 本身不会创建 Run，因此兼容重试不会造成重复编译。
- IPA、Theos DEB、Codemagic、停止逻辑与无 AI 纯编译路线保持不变。

## V7.4.2 · Build 1030 — Real Xcode Sheet compile closure

- 根据真实 Codemagic/Xcode 编译日志，仅剩 `ContentView.swift` 两处 `presentationDetents` 编译错误。
- 两个报告 Sheet 改为 `Group` 包装内容后再应用展示修饰符，避免条件 View 上的错误类型绑定。
- 新增 iOS 16 可用性封装，继续保持 iOS 15 deployment target；iOS 16+ 保留 medium/large detents 与 drag indicator。
- 不改动 `buildmate-clean-v1`、GitHub Actions、IPA/DEB、六大核心功能和中央动态素材。

## V7.3.9 · Build 1027 — GitHub Actions Workflow 输入兼容修复

- 修复 GitHub Actions HTTP 422 `Unexpected inputs provided`：远端旧版 `buildmate.yml` 未声明新版源码指纹 inputs 时，不再直接终止。
- 派发优先发送完整 inputs；仅在 GitHub 明确判定未知 inputs 时降级为 `mode`，极老 workflow 再降级为无 inputs。
- 422 dispatch 不会创建 Run，因此降级重试不会产生重复编译。
- 不恢复 AI/Agent 自动修复；IPA、Theos DEB、Codemagic 与停止逻辑保持原链。

## V7.3.8 · Build 1026 — Codemagic 源码预检误拦截修复

- 修复 Codemagic 第 2 步“解压并检查源码结构 / 版本”在版本检查通过后仍可能被旧关键文件硬编码误判失败。
- 预检只保留 project.yml、BuildMate 目录、Swift 源文件存在与版本一致性硬门禁；其他文件交给 XcodeGen/Xcode 真实编译验证，避免假失败。
- 不改变 IPA / Theos DEB、GitHub Actions、产物、停止与发布主链；不恢复 AI 自动修复。

## V7.3.7 · Build 1025
- 修复停止任务卡死：取消顶层编译 Task，准备/上传阶段可立即停止；已有云端 Run 时后台发送取消请求。

## V7.3.6 · Build 1024 · 2026-09-11
- 修复 GitHub Actions 独立凭据拆分后的 HTTP 401 回归。
- 独立 Actions Token 若返回 401，会尝试此前已保存且不同的 GitHub Token；验证成功后自动迁移到 Actions 独立配置。
- IPA / Theos DEB 编译链保持不变；AI 自动修复继续保持删除状态。

## V7.3.5 · Build 1023 · 2026-09-11

- 纯编译收口：移除现行 AI 开发标题与 GitHub Actions repair/AI Patch 模式。
- 保留并回归检查 iOS IPA 与 Theos DEB 编译/产物上传链。
- Android APK 仍为未验证接口骨架，不标记为已打通。

## V7.3.4 · Build 1022 · 2026-09-11
- 全局 UI 收口：统一页面间距、圆角、卡片和 Sheet 风格。
- 删除主流程 AI 自动修复/深度接管入口；保留统一 AI 配置与首页状态灯。
- 四宫格改为纯状态驱动；运行中显示编译状态/云端运行，失败显示 BUG 报告，成功显示发布应用。
- 产物动作绑定当前 Source SHA / Run，旧 IPA 不再污染新任务。
- BUG 报告改为半屏/大屏可拖拽 Sheet，原始报告默认折叠。
- GitHub Actions 编译凭据与源码 GitHub 分离；平台选择只显示对应配置。

## V7.3.2 · Build 1020 · 2026-09-11
- 修复 Codemagic 配置输入框焦点/点击回归；源码体检不再受编译平台配置状态错误禁用。
- GitHub Actions 与 Codemagic 双主编译链保持不变，旧 Provider 中枢不恢复。

## V7.3.1 · Build 1019
- 修复 GitHub Actions / Codemagic 双平台设置与执行链中的 String.trim 编译错误；双平台结构不变。

## V7.3.0 · Build 1018 · 2026-09-11
- 正式编译平台只保留 GitHub Actions 与 Codemagic；禁止自动跨平台切换。
- 设置页移除平台总览与旧云编译控制台，统一为一个编译平台入口。
- GitHub Actions 恢复手动正式 Workflow 编译；Codemagic 保持主编译链。
- 黑匣子只记录，不参与编译调度。

## V7.3.0 · Build 1018 · Task Center No-Core Cleanup
- SourceLifecycle 事件仅作审计，不进入任务列表。
- 任务详情移除 UnifiedTask 恢复入口。
- 真实编译链不变。

## V7.2.8 · Build 1016 · Minimal No-Core Runtime
- 正常编译主链改为用户明确触发的 Provider 构建，不经过旧中枢自动编排。
- 启动、回前台、源码导入/清理不再执行 UnifiedTask / Agent 自动恢复。
- Task Black Box 只负责记录与诊断，不参与任务控制。
- 保留旧类型作为兼容壳，降低一次性删除造成的 Swift 编译引用风险。

## V7.2.6 · Build 1014 · Manual Provider Compile
- Removed compiler auto-selection, cooldown routing and fallback switching.
- Explicit provider selection only; legacy automatic preference migrates to Codemagic.
- Preserved local preflight, task black box, recovery, diagnostics and artifacts.

## V7.2.5 · Build 1013 · Dispatch Chain Fix

Explicit user builds ignore stale provider cooldown. Empty automatic dispatch now produces a terminal failure instead of an orphan running task. Local preflight no longer calls the retired GitHub execution path.

## V7.2.4 · Build 1012 · Source SHA Unlock
本版将 Source SHA 降级为追踪证据，不再作为永久编译门禁。用户可以重复上传、重复编译完全相同的 ZIP。仅当前一次请求正在执行时使用内存 busy 状态防止快速双击产生两个真实云端 Run。

# 开发规范（入口）

完整规范见 `DEVELOPMENT_MANUAL.md`。

每次修改遵守：六核心边界 → 最小模块化修改 → 版本全域同步 → 本地静态/语法检查 → 真实云编译 → 失败按首个根错误修复 → 成功后更新有效 CHANGELOG。

禁止为了消除编译错误而恢复已废弃类型或模块。禁止破坏中央视觉保护区。禁止把预检成功写成真实编译成功。


## Build1012 诊断证据隔离
诊断根因必须与当前 Codemagic Build ID 完全一致。禁止使用 BuildGuardStore 的旧缓存诊断解释新的 Build；不匹配的证据只能标记为已隔离，不能作为修复依据。

## V7.4.1 · Build 1029 — Real Xcode compile closure
- Restored `BMCloudCompiler` and `CodemagicStoredConfig`, which active compile/UI code still requires.
- Migrates the retired Codemagic workflow ID `buildmate-ios-build76` to `buildmate-clean-v1`.
- Synchronizes the repository `codemagic.yaml` and in-app Codemagic template to the clean workflow that reaches real Xcode compilation.
- No AI/Agent/DeepTakeover runtime feature is restored.
