## V5.7.25 — 红点 leaf 重建追踪
实机逐帧证明 V5.7.24 的主要残留问题不是容器 side，也不是 0.16/0.35s 本身，而是系统在展开/收起时把原生录屏红点重建到同一 SAUIElementView 的其它临时 leaf。仅对 RSInstalledContainer 调 RSHideContainer 会漏掉 sibling leaf。V5.7.25 只在当前录屏 element 子树内压小型红色 leaf，并用弱表追踪、在恢复/停止时还原。此逻辑不得扩大到整窗扫描，避免误伤其它 Live Activity。最新实机日志恢复 drift 稳定在 4.0~4.33pt，因此恢复稳定容差改为 5pt；历史危险错位约 145pt，仍有巨大安全余量。


## V5.7.24 — 右侧交接静默化
实机 V5.7.23 已证明 side lock 有效，但高德 Live Activity 展开/收起仍有红点闪现和左上角阴影。处理原则：overlay 不参与 morph，不做自身淡入；恢复时使用保存 right anchor。系统可能在 grace 后重建红色叶子，因此只在前 0.42s 做有限次数补压，不新增常驻高频驱动。
# RecordingSharingan 开发规范

当前规范版本：v5.7.17

## 1. 版本号同步（强制）

每次发布前，必须先确定唯一版本号，并同步检查以下所有位置：

1. `Tweak.xm` 的 `RSVersion` 与顶部版本注释。
2. `Tweak.xm` 的 loaded / initialized 日志。
3. `control` 的 `Version:`。
4. `README.md` 标题与版本更新说明。
5. `layout/Library/PreferenceLoader/Preferences/RecordingSharingan.plist` 的页脚/版本显示。
6. `DEVELOPMENT.md` 当前规范版本。
7. `CHANGELOG.md` 新版本条目。
8. GitHub workflow 的标题、artifact 和 DEB 名称。
9. 最终 ZIP 文件名。
10. 当前如果未启用独立 PreferenceBundle，禁止清单里继续要求不存在的 `prefs/` 版本号。

发布前必须全局搜索旧版本号，确认没有残留。

## 2. SpringBoard 安全规则

- 禁止在 `%ctor` 同步调用 `[UIScreen mainScreen]`、遍历 SpringBoard window 或执行依赖 UIKit 完整启动状态的逻辑。
- `%ctor` 只注册通知和延迟任务。
- 真正初始化必须在 SpringBoard 完成启动后、主线程上执行。
- UIKit / 私有视图扫描必须使用 `@try/@catch` 保护关键边界。

## 3. 录屏状态与轮询

- 轮询只允许在录屏期间运行。
- 每一次 `0 -> 1` 开始录屏都必须调用 `RSEnsurePollTimer()` 与 `RSEnsureGeometryDisplayLink()`。
- 每一次 `1 -> 0` 停止录屏必须停止 Timer、CADisplayLink 并清理 Overlay。
- 不允许出现“Timer 第一次被 invalidate 后永久不重建”的问题。

## 4. 灵动岛容器规则

- 不写死左右绝对坐标。
- 系统 `_SAUIProvidedViewContainerView` 只作为位置锚点。
- 录屏状态变化、`layoutSubviews`、`didMoveToWindow`、定时重扫都可触发重新识别。
- 必须采用候选评分/过滤，禁止像 v5.4 那样无差别给所有小容器安装写轮眼。
- 全局同一时间只允许一个写轮眼 Overlay。

## 5. 写轮眼显示规则

- 视觉尺寸：左侧药丸 31pt，右侧独立圆 37pt。
- Overlay 独立于系统红点容器 bounds，避免 17x22 时图案过小。
- 使用同一 UIWindow 坐标跟随锚点中心，减少父容器裁切/缺角。
- 停止录屏或关闭插件必须恢复系统红点容器原 alpha。

## 6. 素材规则

- 当前素材目录：`layout/Library/Application Support/RecordingSharingan/eye/`。
- `replay1.png` = 素材 1。
- `replay2.png` = 素材 2。
- 新增素材时不得破坏旧素材编号；设置页选项与代码读取逻辑必须同步。

## 7. 设置页规则

- 设置入口名称固定为“录屏写轮眼”。
- Preference domain：`com.tu.recordingsharingan.settings`。
- Darwin 通知：`com.tu.recordingsharingan.settings.changed`。
- 修改开关/素材后应尽量即时生效，不要求注销 SpringBoard。

## 8. 打包规则

- ZIP 根目录必须直接是项目文件，不允许外面再包一层项目目录。
- 编译产物以版本号命名。
- 发布前检查 `Makefile`、`control`、`layout/`、`.github/workflows/` 是否完整；V5.7.11 起不再要求 `prefs/` 子工程。

## 9. v5.7.3 几何跟随基线规则

- 任一边超过 30pt 的 provided container 不允许作为录屏红点候选。
- 系统过渡动画期间优先读取 `presentationLayer` 实时位置。
- Overlay 不叠加自己的位移动画；逐帧跟随只负责几何，不负责候选扫描。
- CADisplayLink 只能在录屏期间存在，停止录屏必须 invalidate。

## 10. 长期迭代档案规则
- 每一版必须保留历史版本记录，不得只保留最新版。
- 记录：问题、修改方案、实测结果、失败方案及原因、安全风险、遗留问题、下一版建议。
- 无可靠依据时不得虚构“修了多久”；可以记录实际经历的测试轮次/版本次数。
- 新对话/新 AI 接手时，必须先阅读 `AI接手开发说明.md` 与 `历史问题与踩坑记录.md`。

## 11. 低风险测试记录规则（自 v5.7.5 起）
- `testLogging` 默认关闭。
- 测试记录只能复用既有事件点，不得为诊断新增高频调度器。
- 禁止逐帧写日志；单次快照最多输出 12 个小型候选容器。
- 诊断代码必须有异常保护，失败时直接放弃记录。
- 测试记录功能本身不得改变候选阈值、轮询间隔、DisplayLink 生命周期和 ctor 安全初始化。

## 12. v5.7.6 几何修复规则
- 左侧静止缺角的实测特征是“按住向左拉完整，松手回弹又缺角”；不得误记成滑动后永久恢复。
- 左侧小幅静态校正必须远离灵动岛中间，禁止再次把 `center.x` 正向推向中间。
- 动画期坐标换算不得混用 presentation layer 的 position 与 model superLayer 的坐标树。
- 首次创建 UIImageView 不得先以 512x512 等素材原始尺寸显示后再缩小；应先设最终几何再启动旋转。
- 本版不删除既有 geometry DisplayLink；若后续仍跳动，必须先基于日志判断，再决定是否收敛其生命周期。

## 13. Rootless PreferenceBundle 路径规则
- Theos rootless 工程源码中使用标准 `/Library/PreferenceBundles` 与 `layout/Library/PreferenceLoader/Preferences`。
- 不要在 `*_INSTALL_PATH` 或 layout 中手工同时写 `/var/jb/...` 与 `/Library/...` 两套路径。
- rootless scheme 负责最终重定位到 `/var/jb`。

## 14. V5.7.8 设置调参规范
- Bug 测试设置不再作为开发目标；优先使用录屏视频与 `RecordingSharingan.log`。
- 设置页仅负责写偏好值与发送通知，不直接扫描 SpringBoard 视图。
- 总开关、素材、速度、左右 X、Y、左右尺寸均应通过偏好读取；小幅视觉调整优先调参数，不为 0.5～1pt 反复改硬编码。
- 左右位置和左右尺寸分开保存，避免修左侧时破坏右侧独立圆。
- 设置模块失败不得阻断主插件；不得把 Preferences 代码并入 `%ctor`。
- 本版仅支持两套内置素材；“从相册/文件直接导入自定义素材”后续单独实现，不能把半成品文件选择器塞进稳定版。


## 15. V5.7.10 设置页资源规则
- V5.7.8 的 PreferenceLoader 入口已成功出现，但详情页空白，说明入口和 Controller 已能加载，问题集中在 specifier 资源。
- prefs 子工程必须显式保留 `RecordingSharinganPrefs_RESOURCE_DIRS = Resources`；不得删除，否则可能再次出现有标题但整页空白。
- `Root.plist` 是设置项唯一基线；新增/删除设置时同时检查运行时 preference key。
- 设置图标使用 PreferenceLoader entry 同目录的 `RecordingSharingan.png`，并在 prefs bundle 中保留 `icon.png` 备用。
- 后续不再为 Bug 记录功能单独扩展设置页；视频 + 主日志作为首选诊断方式。
- 左侧位置默认 -1.0pt，取消按容器尺寸额外叠加隐藏 inset；小幅调整优先走设置页。

## 16. 出包前编译卫生检查（V5.7.10 起强制）
- 删除 unused variable / unused function / dead local declarations。
- 按 `-Werror` 标准审查 warning：任何 warning 都按可能导致 GitHub 构建失败处理。
- 检查 tweak 与 prefs Makefile、PreferenceBundle 资源打包、plist 路径。
- 全局检查版本号、workflow 产物名、control、README、设置页、日志常量。
- 检查 ZIP 解压后源码直接位于根目录，不增加外层包装文件夹。
- 上一版已经发生过的编译错误必须加入本规范，后续不得重复。

## V5.7.11 固定开发规则补充
1. 当前只保证并优先测试 iOS 控制中心原生屏幕录制（3-2-1 倒计时）。02 分屏等第三方快捷启动不得混入本阶段验收。
2. 设置页优先使用 PreferenceLoader `entry + items` 单文件方式；在公开 Theos SDK 缺少 Preferences.framework linker stub 的环境，不得无必要重新引入独立 PreferenceBundle。
3. 动画过渡期间优先保持当前已确认容器身份；不要因临时候选分数略高就抢绑。
4. 同侧容器重建的视觉修复只允许做短时、小距离平滑；左右侧切换不得人为做跨岛飞行动画。
5. 出包前检查：plist XML 可解析、版本号全局一致、Makefile 无失效 subproject、无 unused variable、ZIP 根目录可直接编译。


## V5.7.12 固定回归规则补充
- 继续只以“控制中心 → 屏幕录制 → 3、2、1”作为本阶段唯一标准启动路径；02 分屏快捷启动后续单独处理。
- 原生控制中心回归至少覆盖：无活动直接录屏、音乐存在后录屏、高德存在后录屏、录屏中回桌面、左右活动切换、停止后立即重新开始。
- 若新会话首先出现 22x22 且位于灵动岛左内侧，不得约 0.1 秒内直接抢绑；应给 17x22 / 19.67x19 或更稳定轨迹出现的时间。
- 不允许用固定绝对屏幕坐标做永久白名单；位置判断必须基于 window 中线相对范围。
- V5.7.11 已实机证明设置页可以即时修改素材与速度；后续不得为了调参重新引入独立 PreferenceBundle。

## V5.7.14 控制中心弹簧拖动规则（永久）
- `presentationLayer` 只能用于视觉跟随，不能反向写入“已确认容器身份”数据。
- `RSLastConfirmedCenter / RSLastWasRight / RSLastConfirmedAt` 只允许在真正 `RSInstallOnContainer()` 绑定时更新；禁止在逐帧 geometry tick 中更新。
- 单独录屏左右弹簧拖动时，同一已绑定容器可保留小幅视觉弹性，但大幅 overshoot 必须限幅，不能让 UIWindow Overlay 飞出灵动岛。
- 当前容器仍有效时，同一侧距离稳定中心明显过远（当前经验阈值约 16pt）的临时候选不得抢绑；真实 left↔right 状态切换另行判断。
- 修改这些阈值前必须先对照实机视频 + 日志，不允许再次用单纯 `x +/- N` 掩盖身份/坐标问题。

## V5.7.14 单独原生录屏弹簧锚点规则（永久）

- 当录屏开始时 baseline provided containers `<= 3`，视为当前主线的“单独原生录屏”几何场景。
- 已确认左侧录屏小容器在交互/弹簧动画中，不允许 presentation/model 的临时漂移直接决定写轮眼中心。
- 手势期间优先使用本次绑定得到的 `RSLastConfirmedCenter`；松手稳定后自然恢复系统稳定几何。
- 该规则目前不要直接推广到 baseline=6 的音乐/高德多活动场景，必须等单独录屏稳定后再单独验证。
- “弹簧飞出”和“静止缺角”必须分开处理：前者修锚点/动画跟随，后者只用设置页左侧 X 微调，不要用同一个硬编码补丁同时解决。

## V5.7.15 capture 状态去抖规则（永久）

- `UIScreen.isCaptured` 的短暂 `1 -> 0 -> 1` 不得直接等同于一次完整“停止录屏再开始录屏”。
- 已安装写轮眼时，短暂 capture-off 先进入约 1.35 秒宽限；若期间恢复，必须保留当前会话/容器/动画，禁止 teardown + reinstall。
- 宽限期禁止重新选录屏容器，避免展开/收起灵动岛时误绑临时 UI。
- 真正停止超过宽限期再统一清理。
- 此规则优先服务控制中心 3、2、1 原生录屏；02 分屏快捷启动仍不作为当前主线。
- 弹簧飞出仍与静止缺角分开处理：本版只把 presentation 跟随进一步收紧，不通过扩大 leftX 硬编码掩盖状态机问题。


## V5.7.17 暂停显示状态规则（永久）

- 已验证：V5.7.15 的 session-preserving grace 能消除暂停/收起时的 teardown/reinstall 卡顿；不得恢复为 capture=false 立即 remove。
- grace 期间若需要视觉上“暂停”，只能隐藏/冻结现有写轮眼，不要 removeFromSuperview，不要重新创建 UIImageView，不要重新扫描容器。
- 冻结旋转使用 CALayer 本地时间（speed/timeOffset/beginTime）；恢复必须从原动画相位继续，避免恢复瞬间角度跳变。
- 真正录屏停止后才允许完整 remove，并确保清理 layer 的 speed/timeOffset/beginTime。
- 禁止为了暂停状态去改 V5.7.15 已验证通过的单独录屏弹簧锚点锁。

## V5.7.17 设置页规则（永久）
- 简单 PreferenceLoader plist 已经验证稳定，优先继续使用，不为了 ± 按钮重新引入编译型 PreferenceBundle。
- 数值类参数必须同时提供可恢复的推荐默认值；X 范围至少 ±20pt。
- 小数精调优先用 0.5pt 精确点选列表，避免手指滑杆误差。


## V5.7.18 暂停卡顿实机结论
V5.7.17 日志显示 capture-off grace 经常开始后在 0~1 秒内恢复，但真正停止固定在 1.35 秒后 finalize。V5.7.18 不先缩短 grace；先在 grace 开始时暂停插件自己的 poll timer 与 geometry display link，让宽限只“保留身份”而不继续逐帧触碰灵动岛。恢复时原地重启驱动。此修改不得回退 V5.7.15 已验证通过的左右弹簧锁。

## V5.7.20 右侧独立圆结束尾部抖动结论
V5.7.18 实机日志显示，APP/Live Activity 下录屏指示器位于右侧 22x22 独立圆时，结束录屏后的系统尾声会多次把 `UIScreen.isCaptured` 从 NO 短暂抖回 YES。禁止再采用“一见 YES 就立即恢复 eye/驱动”的逻辑。恢复必须通过持续 YES 确认：左侧 0.28s，右侧 0.75s；确认期保持 eye 隐藏、旋转冻结、poll/displayLink 停止。若再次 NO 或旧 container 已失效，则视为停止尾声假恢复，不点亮旧 overlay。


## V5.7.20 右侧独立圆过渡规则
- 实机视频显示：Live Activity 长条 + 右侧录屏独立圆时，点独立圆展开、点空白收起，系统会把录屏 provided container 做 morph；不能让 UIWindow overlay 逐帧横穿长条。
- 过渡期间只做视觉隐藏，不删除 UIImageView、不重绑容器、不重扫候选，不改录屏状态。
- 恢复必须等右侧 model/presentation 都回到确认锚点附近并稳定约 0.16s，再淡入。
- V5.7.19 的结束尾声稳定 YES 确认必须保留，V5.7.15 的左右弹簧锁也不得回退。


## V5.7.21 — 二次点击消失与跨侧误判
- V5.7.20 的 “visibility deferred to stable geometry” 没有硬超时，实机日志多次只有 deferred，没有对应 shown，导致第二次点开/收起后 eye 永久 hidden。
- 新规则：恢复可见性最多延迟 0.16s；右侧 morph 隐藏最多 0.22s，之后强制使用已确认锚点恢复。
- 同一个 RSLastConfirmedContainer 的 side 以 RSLastWasRight 为准，禁止 morph 中临时 modelCenter 改变左右身份。真正换边只允许通过新容器重新绑定。
- 这是最小改动：不新增 Timer/DisplayLink/Hook，不改 ctor，不动已验证的单录屏弹簧锁和结束尾部假恢复逻辑。


## V5.7.24 — 恢复显示“双门槛”
V5.7.21 已证明 0.16s 硬上限能解决永久隐藏，但实机视频显示固定时刻强制点亮可能仍处于右侧圆 ↔ 长条 morph 尾声。V5.7.24 改为：0.16s 最早放行 + 连续两次几何稳定；0.35s 绝对超时后回保存锚点。检查通过既有 main queue 的少量 dispatch_after 完成，不增加常驻高频机制。恢复等待期间重复调用现有 RSHideContainer 压住原生红点叶子。

## V6.0.0 — SystemAperture ScreenRecording 元素定位规则（永久）

- V6 定位主链路：`systemApertureControllerForMainDisplay` → `_systemApertureViewController` → `_systemApertureManager` → `registeredElements[]` → `elementIdentifier` 匹配 `systemApertureElementIdentifierScreenRecording` → `elementViewControllerForElement:` → `view`。
- identifier 匹配必须同时支持 dlsym 常量与字面量兜底（"ScreenRecording" / screenRecording / 含 record 文案）；探测用 KVC 多键 + element 对象透传，全部 @try 保护。
- 视图树备链路：`SAUIElementView` 类名 + identifier 命中或子树证据（`SBSystemApertureSceneElement` + 红色叶子 + 元素内 provided 容器）。
- 写轮眼挂载进元素子树后，禁止旧窗口 overlay 路径把 eye 拽回 UIWindow（`RSUpdateEyeGeometry` 元素模式早退）。
- 防重复 addSubview：全局单 eye；已挂载只同步；元素挂载模式下 `RSInstallOnContainer` 直接 return。
- 第一版默认不隐藏系统红点（`hideRedDot` 默认 NO）；红点隐藏相关函数保留但默认 no-op。
- 找不到元素时回退旧 provided-container 评分管线；位于录屏元素子树内的容器 +160 决定性加分。
- 新增 SAUIElementView `setFrame:/setCenter:` hook 与 `SBSystemApertureContainerView layoutSubviews` hook 用于宿主跟随与布局刷新；禁止删除或禁用这些 hook 而破坏宿主跟随。
- 版本号全局同步规则继续适用：Tweak.xm / control / 设置 plist / README / CHANGELOG / CI / ZIP / DEB 必须一致。
