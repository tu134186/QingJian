# App Review Notes 草案

1. BuildMate 本机不运行 Xcode；云端构建由用户授权的 GitHub Actions 执行。
2. GitHub 与 AI 凭据由用户自行提供并保存在 Keychain。
3. 审核版本必须逐项核对可见功能与审核规则，不隐藏未申报功能。
4. Theos/DEB 等能力在真正提交审核前单独复核当时规则，必要时通过同一源码的编译配置关闭，不维护第二套 App。
