# BuildMate 隐私说明草案

- GitHub Token 与 AI API Key 保存在设备 Keychain。
- 源码 ZIP 会在用户主动编译时上传到用户选择的 GitHub 仓库。
- 只有用户启用 AI 修复后，编译错误和相关源码片段才会发送给用户配置的 AI 服务。
- 正式提交 App Store 前必须根据最终数据流、第三方 SDK 与当时 App Store Connect 要求完成最终隐私政策和 App Privacy 申报。
