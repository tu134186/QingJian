# BuildMate App Store 产品说明

BuildMate 是面向 iPhone 的 GitHub 云端编译与 AI 修复助手。iPhone 负责项目、任务、日志和产物管理，实际 Xcode / Theos 构建由用户自己的 GitHub Actions macOS Runner 执行。

原则：所有成功状态必须来自真实 Run、真实报告和真实产物，不使用假进度或假成功。
