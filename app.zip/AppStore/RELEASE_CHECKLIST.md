
## Build224 发布工作台
- [ ] 在 App 内发布工作台填写并保存 App 名称、Bundle ID、SKU、主语言、Support URL 与隐私政策 URL。
- [ ] 确认发布资料总览中的 Bundle ID、真实 IPA、稳定源码锚点均通过。
- [ ] 仅登记 App Store Connect 凭据引用；禁止把 .p8 私钥正文、Token、密码或 Cookie 写入源码、日志或交接单。
- [ ] 创建 TestFlight 或 App Store 发布计划，核对版本、Build、IPA 名称与 Source SHA。
- [ ] 提交审核/正式上线前必须主人明确批准；Build224 不会自动提交商店。
# App Store 发布检查清单

- [ ] Release 构建无崩溃/无占位按钮
- [ ] 预检、编译、打包、Artifact 状态严格区分
- [ ] 隐私政策 URL 与 App Privacy 填写完成
- [ ] App 名称、副标题、描述、关键词完成
- [ ] iPhone 截图与实际 UI 一致
- [ ] Support URL / 联系方式可用
- [ ] GitHub / AI 授权与删除入口完成
- [ ] 审核账号/演示路径准备完成（如需要）
- [ ] 提交当天重新核对 Apple Review Guidelines
