# Build 1017 · Task Center No-Core Cleanup

- 源码导入仍写入黑匣子，但 `SourceLifecycle` 不再出现在任务列表。
- 删除任务页“重新对账并收口 / 中枢恢复已停用”。
- 删除任务详情 `UnifiedTask` 安全恢复区。
- 真实编译、Codemagic、产物、黑匣子、中央素材保持不变。
