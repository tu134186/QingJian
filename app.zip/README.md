# RecordingSharingan v6.1.0-debug（V6.1 Debug Loader）

适用于 Dopamine Rootless / iOS 16.x 的录屏灵动岛写轮眼插件。

## V6.1 Debug Loader 目标（本版）

- **只确认一件事：dylib 有没有真正加载进 SpringBoard。**
- 不改动画、不改定位、不改设置页、不改任何 V5/V6 既有逻辑（V6.0.0 SystemAperture 定位全部保留）。
- `%ctor` 最开始写入加载证据日志，同时写两个位置：
  - `/var/mobile/Library/Logs/RecordingSharingan-V6.log`
  - `/var/jb/tmp/RecordingSharingan-V6.log`
- 日志内容：`[V6.1] dylib loaded`、`[V6.1] ctor executed`、进程名、NSBundle 信息、dylib 自身路径、是否 SpringBoard。

## V6.0.0 当前目标（沿用）

- 基线 V5.7.25 全部稳定逻辑保留：安全初始化、轮询生命周期、全局单写轮眼、capture-off grace、左右弹簧锚点锁、右侧 morph 抑制。
- 新增 SystemAperture 精准定位：不再只扫描 `_SAUIProvidedViewContainerView`，优先通过
  `SBSystemApertureController → _systemApertureViewController → _systemApertureManager → registeredElements[] → elementIdentifier（systemApertureElementIdentifierScreenRecording）→ elementViewControllerForElement: → SAUIElementView`
  找到真正的录屏灵动岛元素，并把写轮眼作为额外动画层挂进该元素子树（宿主跟随，自动随系统 morph 过渡）。
- 第一版约定：系统 3-2-1 保留、系统录屏红点保留（默认不隐藏，设置里有“隐藏系统红点”开关可开旧版观感）、
  不删除 `SBRecordingIndicatorView`、不修改 `record.circle.fill`；写轮眼作为覆盖层显示。
- 防重复 addSubview：同一时间全局只有一只写轮眼；已挂载只同步不重复添加。
- 生命周期管理：开始/停止录屏、切后台、切音乐/其他灵动岛活动、灵动岛重新布局均已有对应路径。
- 位置同步：监听 SAUIElementView `frame`/`center`/`layoutSubviews` 变化，写轮眼跟随宿主。

## 设置
安装并 Respring 后：`设置 → 录屏写轮眼`。新增“隐藏系统红点（默认关）”。

## 编译
ZIP 根目录直接包含 `Makefile`、`Tweak.xm`、`control`、`layout/`、`.github/` 和开发文档，不套外层目录。

需要 Theos rootless 环境与 PreferenceLoader。

```sh
make clean
make package
# 发布包（CI 使用）：make clean package FINALPACKAGE=1
```

### V5.7.15
控制中心原生录屏状态去抖专项：减少暂停/收起时反复卸载和重新安装写轮眼造成的顿挫，同时继续收紧单独录屏的弹簧视觉漂移。


## V5.7.20 右侧独立圆过渡规则
- 实机视频显示：Live Activity 长条 + 右侧录屏独立圆时，点独立圆展开、点空白收起，系统会把录屏 provided container 做 morph；不能让 UIWindow overlay 逐帧横穿长条。
- 过渡期间只做视觉隐藏，不删除 UIImageView、不重绑容器、不重扫候选，不改录屏状态。
- 恢复必须等右侧 model/presentation 都回到确认锚点附近并稳定约 0.16s，再淡入。
- V5.7.19 的结束尾声稳定 YES 确认必须保留，V5.7.15 的左右弹簧锁也不得回退。


## V5.7.25 恢复显示规则
- 右侧独立圆从展开/暂停状态回到录屏时，0.16s 只是最早显示时间。
- model / presentation 连续两次回到绑定锚点附近后再显示；最多等待 0.35s。
- 超时仍未稳定时，在保存锚点显示，不使用 morph 中临时位置。
- eye 暂时隐藏期间继续压住系统录屏红点叶子，减少红点闪现。
