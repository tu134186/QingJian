# 轻剪 QingJian V1.0.0 — BuildMate / GitHub Actions

目标：iPhone / iOS 16.3+，SwiftUI + AVFoundation，无第三方运行时依赖。

## BuildMate 使用方式
- 将本 ZIP 作为“当前源码”导入 BuildMate。
- 源码 GitHub 指向 `tu134186/QingJian` 的 `main` 分支。
- 编译平台选择 GitHub Actions。
- BuildMate 将本包内容推送到仓库根目录后，触发 `.github/workflows/build.yml`。
- Workflow 使用标准 `macos-15` runner，安装 XcodeGen，生成工程并执行无签名 Release 真机构建。
- 成功产物：`QingJian-V1.0.0.ipa`，Artifact 名：`QingJian-V1.0.0`。
- 无需 Codemagic。

## 目录要求
`.github/`、`QingJian/`、`project.yml` 必须直接位于 GitHub 仓库根目录。本 ZIP 已按此结构整理，没有外层 `QingJian/QingJianV1` 套娃目录。

## 编译原则
不重构、不升级最低系统、不替换 AVFoundation、不添加 CocoaPods/SPM。若编译失败，保留并上传完整 `build.log`，只针对实际编译错误修复。

## 当前闭环
多视频导入、预览、时间轴选择、首尾裁剪、分割、排序、删除、0.25x~3x 速度、标题叠加、合并和 MP4 导出、系统分享。
