# 轻剪 QingJian V1.0.0
目标：iPhone / iOS 16.3+，SwiftUI + AVFoundation，无第三方运行时依赖。

## 给云编译/豆包的要求
1. 不重构、不升级最低系统、不替换 AVFoundation、不添加 CocoaPods/SPM。
2. macOS runner 安装 XcodeGen 后执行 `xcodegen generate`。
3. 先执行：`xcodebuild -project QingJian.xcodeproj -scheme QingJian -configuration Release -sdk iphoneos -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO`
4. 成功后将 `build/Build/Products/Release-iphoneos/QingJian.app` 放进 Payload 并 zip 为 IPA。
5. 若失败，只修复编译错误；禁止删功能。把完整 xcodebuild 错误日志返回。

## 当前闭环
多视频导入、预览、时间轴选择、首尾裁剪、分割、排序、删除、0.25x~3x 速度、标题叠加、合并和 MP4 导出、系统分享。

## V1.0.0 编译修复说明（云编译前已静态修复）
1. `project.yml`：sources 中排除 `Info.plist`，避免 Xcode 报 "Multiple commands produce .../QingJian.app/Info.plist"。
2. `project.yml`：显式声明 `QingJian` scheme，保证 `xcodebuild -scheme QingJian` 可用（XcodeGen 不会为无 scheme 定义的 target 自动生成 scheme）。
3. `QingJian/Services/Exporter.swift`：`label.alignmentMode=.center`、`session.outputFileType=.mp4` 两处 `=` 两侧补空格，满足 Swift 6 解析器的空白一致性要求（否则编译报 "'=' must have consistent whitespace on both sides"）。
4. `QingJian/Views/EditorView.swift`：结尾裁剪 Slider 区间改为 `0.1...max(0.1,c.duration)`，防止短片段（<0.1s）触发区间反转崩溃。
5. `.github/workflows/build.yml`：增加 `-destination 'generic/platform=iOS'`、`tee build.log` 完整日志留存、失败时上传 build.log；IPA 文件名固定为 `QingJian-V1.0.0.ipa`。


## V1.0.1 GitHub Actions compile fix
- MediaStore no longer depends on PhotosPickerItem.
- Explicit Data.WritingOptions.atomic.
- EditorView split into smaller SwiftUI expressions to avoid compiler type-check timeout.


## V1.0.2 TrollStore bundle fix
- Added CFBundleExecutable=$(EXECUTABLE_NAME).
- Added CFBundlePackageType=APPL and standard bundle metadata.
- Explicit PRODUCT_NAME/EXECUTABLE_NAME=QingJian in XcodeGen settings.
