# Build 1016 · Minimal No-Core Compile Fix

- 以 Build1014 原始结构重新打补丁，不沿用 Build1015 对 SwiftUI 页面的大范围删减。
- 普通编译直接进入用户选择的 Provider，不创建 UnifiedTask/云审批任务。
- App 启动、回前台、源码导入不调用 Agent Orchestrator / TaskLifecycleRecovery 自动对账。
- 旧审批通知只撤销 lease，不触发续跑。
- 任务页旧恢复控件保留兼容外形但逻辑停用，避免改动大型 SwiftUI 类型树。
- 黑匣子仅记录，不调度。
- 版本 V7.2.8 · Build1016。
