# Build1044 · 自托管 Mac 预留与稳定链冻结

- 冻结已实机验证成功的 Codemagic → IPA / DEB Artifact Return Bridge 主链。
- 不修改 Codemagic workflow、publishing、CM_ARTIFACT_LINKS、Relay 回传协议或 IPA/DEB 验证逻辑。
- Codemagic 成功但产物尚未出现时，UI 改为“正在同步编译产物（不重新编译）”；若已识别 IPA/DEB，则显示对应产物类型。
- 编译平台设置新增“自托管 Mac · 预留”：Endpoint、可选 Token、保存并测试连接、Mac Agent 节点管理。
- 自托管 Mac 当前不加入正式平台 Picker，不会自动参与 GitHub Actions / Codemagic 编译；只有未来部署 Mac Agent 并完成握手后再启用正式派发。
- 关于页只将 GitHub Actions / Codemagic 描述为当前云编译平台，自托管 Mac 明确为未来私有节点。
