# Build1053 首页开发环境入口收口

- 首页顶部“环境”状态卡改为可点击，并作为“开发环境”唯一总入口。
- 点击首页环境卡进入既有开发环境页：源码仓库、编译方式、连接状态。
- 首页源码卡“切换”继续直达统一仓库选择/管理页。
- 设置页删除重复“开发环境”入口；保留中央特效、备份与恢复、关于 BuildMate。
- 中央写轮眼仍只负责状态展示，不增加任务控制。
- 未修改 Codemagic / GitHub Actions / Artifact Return Bridge / codemagic.yaml / workflow / 编译执行链。
